module pmic_top (CP_trig,
    CS_n,
    En,
    Green_LED,
    MISO,
    MOSI,
    OTP_trig,
    Osc_in,
    PGOOD,
    PGOOD_comp,
    PWM_out,
    Red_LED1,
    Red_LED2,
    Red_LED3,
    SCK,
    UVLO_trig,
    clk,
    en_from_switch,
    latch_out,
    latch_stat,
    pgood_LED,
    rst_n_pin,
    switch_supply,
    VSS,
    VDD);
 input CP_trig;
 input CS_n;
 output En;
 output Green_LED;
 output MISO;
 input MOSI;
 input OTP_trig;
 input Osc_in;
 output PGOOD;
 input PGOOD_comp;
 output PWM_out;
 output Red_LED1;
 output Red_LED2;
 output Red_LED3;
 input SCK;
 input UVLO_trig;
 input clk;
 input en_from_switch;
 output latch_out;
 input latch_stat;
 output pgood_LED;
 input rst_n_pin;
 output switch_supply;
 inout VSS;
 inout VDD;

 wire CP_sync;
 wire net3;
 wire OTP_sync;
 wire OTP_sync_db;
 wire Osc_sync;
 wire PGOOD_comp_sync;
 wire SS_done;
 wire UVLO_sync;
 wire UVLO_sync_db;
 wire _0000_;
 wire _0001_;
 wire _0002_;
 wire _0003_;
 wire _0004_;
 wire _0005_;
 wire _0006_;
 wire _0007_;
 wire _0008_;
 wire _0009_;
 wire _0010_;
 wire _0011_;
 wire _0012_;
 wire _0013_;
 wire _0014_;
 wire _0015_;
 wire _0016_;
 wire _0017_;
 wire _0018_;
 wire _0019_;
 wire _0020_;
 wire _0021_;
 wire _0022_;
 wire _0023_;
 wire _0024_;
 wire _0025_;
 wire _0026_;
 wire _0027_;
 wire _0028_;
 wire _0029_;
 wire _0030_;
 wire _0031_;
 wire _0032_;
 wire _0033_;
 wire _0034_;
 wire _0035_;
 wire _0036_;
 wire _0037_;
 wire _0038_;
 wire _0039_;
 wire _0040_;
 wire _0041_;
 wire _0042_;
 wire _0043_;
 wire _0044_;
 wire _0045_;
 wire _0046_;
 wire _0047_;
 wire _0048_;
 wire _0049_;
 wire _0050_;
 wire _0051_;
 wire _0052_;
 wire _0053_;
 wire _0054_;
 wire _0055_;
 wire _0056_;
 wire _0057_;
 wire _0058_;
 wire _0059_;
 wire _0060_;
 wire _0061_;
 wire _0062_;
 wire _0063_;
 wire _0064_;
 wire _0065_;
 wire _0066_;
 wire _0067_;
 wire _0068_;
 wire _0069_;
 wire _0070_;
 wire _0071_;
 wire _0072_;
 wire _0073_;
 wire _0074_;
 wire _0075_;
 wire _0076_;
 wire _0077_;
 wire _0078_;
 wire _0079_;
 wire _0080_;
 wire _0081_;
 wire _0082_;
 wire _0083_;
 wire _0084_;
 wire _0085_;
 wire _0086_;
 wire _0087_;
 wire _0088_;
 wire _0089_;
 wire _0090_;
 wire _0091_;
 wire _0092_;
 wire _0093_;
 wire _0094_;
 wire _0095_;
 wire _0096_;
 wire _0097_;
 wire _0098_;
 wire _0099_;
 wire _0100_;
 wire _0101_;
 wire _0102_;
 wire _0103_;
 wire _0104_;
 wire _0105_;
 wire _0106_;
 wire _0107_;
 wire _0108_;
 wire _0109_;
 wire _0110_;
 wire _0111_;
 wire _0112_;
 wire _0113_;
 wire _0114_;
 wire _0115_;
 wire _0116_;
 wire _0117_;
 wire _0118_;
 wire _0119_;
 wire _0120_;
 wire _0121_;
 wire _0122_;
 wire _0123_;
 wire _0124_;
 wire _0125_;
 wire _0126_;
 wire _0127_;
 wire _0128_;
 wire _0129_;
 wire _0130_;
 wire _0131_;
 wire _0132_;
 wire _0133_;
 wire _0134_;
 wire _0135_;
 wire _0136_;
 wire _0137_;
 wire _0138_;
 wire _0139_;
 wire _0140_;
 wire _0141_;
 wire _0142_;
 wire _0143_;
 wire _0144_;
 wire _0145_;
 wire _0146_;
 wire _0147_;
 wire _0148_;
 wire _0149_;
 wire _0150_;
 wire _0151_;
 wire _0152_;
 wire _0153_;
 wire _0154_;
 wire _0155_;
 wire _0156_;
 wire _0157_;
 wire _0158_;
 wire _0159_;
 wire _0160_;
 wire _0161_;
 wire _0162_;
 wire _0163_;
 wire _0164_;
 wire _0165_;
 wire _0166_;
 wire _0167_;
 wire _0168_;
 wire _0169_;
 wire _0170_;
 wire _0171_;
 wire _0172_;
 wire _0173_;
 wire _0174_;
 wire _0175_;
 wire _0176_;
 wire _0177_;
 wire _0178_;
 wire _0179_;
 wire _0180_;
 wire _0181_;
 wire _0182_;
 wire _0183_;
 wire _0184_;
 wire _0185_;
 wire _0186_;
 wire _0187_;
 wire _0188_;
 wire _0189_;
 wire _0190_;
 wire _0191_;
 wire _0192_;
 wire _0193_;
 wire _0194_;
 wire _0195_;
 wire _0196_;
 wire _0197_;
 wire _0198_;
 wire _0199_;
 wire _0200_;
 wire _0201_;
 wire _0202_;
 wire _0203_;
 wire _0204_;
 wire _0205_;
 wire _0206_;
 wire _0207_;
 wire _0208_;
 wire _0209_;
 wire _0210_;
 wire _0211_;
 wire _0212_;
 wire _0213_;
 wire _0214_;
 wire _0215_;
 wire _0216_;
 wire _0217_;
 wire _0218_;
 wire _0219_;
 wire _0220_;
 wire _0221_;
 wire _0222_;
 wire _0223_;
 wire _0224_;
 wire _0225_;
 wire _0226_;
 wire _0227_;
 wire _0228_;
 wire _0229_;
 wire _0230_;
 wire _0231_;
 wire _0232_;
 wire _0233_;
 wire _0234_;
 wire _0235_;
 wire _0236_;
 wire _0237_;
 wire _0238_;
 wire _0239_;
 wire _0240_;
 wire _0241_;
 wire _0242_;
 wire _0243_;
 wire _0244_;
 wire _0245_;
 wire _0246_;
 wire _0247_;
 wire _0248_;
 wire _0249_;
 wire _0250_;
 wire _0251_;
 wire _0252_;
 wire _0253_;
 wire _0254_;
 wire _0255_;
 wire _0256_;
 wire _0257_;
 wire _0258_;
 wire _0259_;
 wire _0260_;
 wire _0261_;
 wire _0262_;
 wire _0263_;
 wire _0264_;
 wire _0265_;
 wire _0266_;
 wire _0267_;
 wire _0268_;
 wire _0269_;
 wire _0270_;
 wire _0271_;
 wire _0272_;
 wire _0273_;
 wire _0274_;
 wire _0275_;
 wire _0276_;
 wire _0277_;
 wire _0278_;
 wire _0279_;
 wire _0280_;
 wire _0281_;
 wire _0282_;
 wire _0283_;
 wire _0284_;
 wire _0285_;
 wire _0286_;
 wire _0287_;
 wire _0288_;
 wire _0289_;
 wire _0290_;
 wire _0291_;
 wire _0292_;
 wire _0293_;
 wire _0294_;
 wire _0295_;
 wire _0296_;
 wire _0297_;
 wire _0298_;
 wire _0299_;
 wire _0300_;
 wire _0301_;
 wire _0302_;
 wire _0303_;
 wire _0304_;
 wire _0305_;
 wire _0306_;
 wire _0307_;
 wire _0308_;
 wire _0309_;
 wire _0310_;
 wire _0311_;
 wire _0312_;
 wire _0313_;
 wire _0314_;
 wire _0315_;
 wire _0316_;
 wire _0317_;
 wire _0318_;
 wire _0319_;
 wire _0320_;
 wire _0321_;
 wire _0322_;
 wire _0323_;
 wire _0324_;
 wire _0325_;
 wire _0326_;
 wire _0327_;
 wire _0328_;
 wire _0329_;
 wire _0330_;
 wire _0331_;
 wire _0332_;
 wire _0333_;
 wire _0334_;
 wire _0335_;
 wire _0336_;
 wire _0337_;
 wire _0338_;
 wire _0339_;
 wire _0340_;
 wire _0341_;
 wire _0342_;
 wire _0343_;
 wire _0344_;
 wire _0345_;
 wire _0346_;
 wire _0347_;
 wire _0348_;
 wire _0349_;
 wire _0350_;
 wire _0351_;
 wire _0352_;
 wire _0353_;
 wire _0354_;
 wire _0355_;
 wire _0356_;
 wire _0357_;
 wire _0358_;
 wire _0359_;
 wire _0360_;
 wire _0361_;
 wire _0362_;
 wire _0363_;
 wire _0364_;
 wire _0365_;
 wire _0366_;
 wire _0367_;
 wire _0368_;
 wire _0369_;
 wire _0370_;
 wire _0371_;
 wire _0372_;
 wire _0373_;
 wire _0374_;
 wire _0375_;
 wire _0376_;
 wire _0377_;
 wire _0378_;
 wire _0379_;
 wire _0380_;
 wire _0381_;
 wire _0382_;
 wire _0383_;
 wire _0384_;
 wire _0385_;
 wire _0386_;
 wire _0387_;
 wire _0388_;
 wire _0389_;
 wire _0390_;
 wire _0391_;
 wire _0392_;
 wire _0393_;
 wire _0394_;
 wire _0395_;
 wire _0396_;
 wire _0397_;
 wire _0398_;
 wire _0399_;
 wire _0400_;
 wire _0401_;
 wire _0402_;
 wire _0403_;
 wire _0404_;
 wire _0405_;
 wire _0406_;
 wire _0407_;
 wire _0408_;
 wire _0409_;
 wire _0410_;
 wire _0411_;
 wire _0412_;
 wire _0413_;
 wire _0414_;
 wire _0415_;
 wire _0416_;
 wire _0417_;
 wire _0418_;
 wire _0419_;
 wire _0420_;
 wire _0421_;
 wire _0422_;
 wire _0423_;
 wire _0424_;
 wire _0425_;
 wire _0426_;
 wire _0427_;
 wire _0428_;
 wire _0429_;
 wire _0430_;
 wire _0431_;
 wire _0432_;
 wire _0433_;
 wire _0434_;
 wire _0435_;
 wire _0436_;
 wire _0437_;
 wire _0438_;
 wire _0439_;
 wire _0440_;
 wire _0441_;
 wire _0442_;
 wire _0443_;
 wire _0444_;
 wire _0445_;
 wire _0446_;
 wire _0447_;
 wire _0448_;
 wire _0449_;
 wire _0450_;
 wire _0451_;
 wire _0452_;
 wire _0453_;
 wire _0454_;
 wire _0455_;
 wire _0456_;
 wire _0457_;
 wire _0458_;
 wire _0459_;
 wire _0460_;
 wire _0461_;
 wire _0462_;
 wire _0463_;
 wire _0464_;
 wire _0465_;
 wire _0466_;
 wire _0467_;
 wire _0468_;
 wire _0469_;
 wire _0470_;
 wire _0471_;
 wire _0472_;
 wire _0473_;
 wire _0474_;
 wire _0475_;
 wire _0476_;
 wire _0477_;
 wire _0478_;
 wire _0479_;
 wire _0480_;
 wire _0481_;
 wire _0482_;
 wire _0483_;
 wire _0484_;
 wire _0485_;
 wire _0486_;
 wire _0487_;
 wire _0488_;
 wire _0489_;
 wire _0490_;
 wire _0491_;
 wire _0492_;
 wire _0493_;
 wire _0494_;
 wire _0495_;
 wire _0496_;
 wire _0497_;
 wire _0498_;
 wire _0499_;
 wire _0500_;
 wire _0501_;
 wire _0502_;
 wire _0503_;
 wire _0504_;
 wire _0505_;
 wire _0506_;
 wire _0507_;
 wire _0508_;
 wire _0509_;
 wire _0510_;
 wire _0511_;
 wire _0512_;
 wire _0513_;
 wire _0514_;
 wire _0515_;
 wire _0516_;
 wire _0517_;
 wire _0518_;
 wire _0519_;
 wire _0520_;
 wire _0521_;
 wire _0522_;
 wire _0523_;
 wire _0524_;
 wire _0525_;
 wire _0526_;
 wire _0527_;
 wire _0528_;
 wire _0529_;
 wire _0530_;
 wire _0531_;
 wire _0532_;
 wire _0533_;
 wire _0534_;
 wire _0535_;
 wire _0536_;
 wire _0537_;
 wire _0538_;
 wire _0539_;
 wire _0540_;
 wire _0541_;
 wire _0542_;
 wire _0543_;
 wire _0544_;
 wire _0545_;
 wire _0546_;
 wire _0547_;
 wire _0548_;
 wire _0549_;
 wire _0550_;
 wire _0551_;
 wire _0552_;
 wire _0553_;
 wire _0554_;
 wire _0555_;
 wire _0556_;
 wire _0557_;
 wire _0558_;
 wire _0559_;
 wire _0560_;
 wire _0561_;
 wire _0562_;
 wire _0563_;
 wire _0564_;
 wire _0565_;
 wire _0566_;
 wire _0567_;
 wire _0568_;
 wire _0569_;
 wire _0570_;
 wire _0571_;
 wire _0572_;
 wire _0573_;
 wire _0574_;
 wire _0575_;
 wire _0576_;
 wire _0577_;
 wire _0578_;
 wire _0579_;
 wire _0580_;
 wire _0581_;
 wire _0582_;
 wire _0583_;
 wire _0584_;
 wire _0585_;
 wire _0586_;
 wire _0587_;
 wire _0588_;
 wire _0589_;
 wire _0590_;
 wire _0591_;
 wire _0592_;
 wire _0593_;
 wire _0594_;
 wire _0595_;
 wire _0596_;
 wire _0597_;
 wire _0598_;
 wire _0599_;
 wire _0600_;
 wire _0601_;
 wire _0602_;
 wire _0603_;
 wire _0604_;
 wire _0605_;
 wire _0606_;
 wire _0607_;
 wire _0608_;
 wire _0609_;
 wire _0610_;
 wire _0611_;
 wire _0612_;
 wire _0613_;
 wire _0614_;
 wire _0615_;
 wire _0616_;
 wire _0617_;
 wire _0618_;
 wire _0619_;
 wire _0620_;
 wire _0621_;
 wire _0622_;
 wire _0623_;
 wire _0624_;
 wire _0625_;
 wire _0626_;
 wire _0627_;
 wire _0628_;
 wire _0629_;
 wire _0630_;
 wire _0631_;
 wire _0632_;
 wire _0633_;
 wire _0634_;
 wire _0635_;
 wire _0636_;
 wire _0637_;
 wire _0638_;
 wire _0639_;
 wire _0640_;
 wire _0641_;
 wire _0642_;
 wire _0643_;
 wire _0644_;
 wire _0645_;
 wire _0646_;
 wire _0647_;
 wire _0648_;
 wire _0649_;
 wire _0650_;
 wire _0651_;
 wire _0652_;
 wire _0653_;
 wire _0654_;
 wire _0655_;
 wire _0656_;
 wire _0657_;
 wire _0658_;
 wire _0659_;
 wire _0660_;
 wire _0661_;
 wire _0662_;
 wire _0663_;
 wire _0664_;
 wire _0665_;
 wire _0666_;
 wire _0667_;
 wire _0668_;
 wire _0669_;
 wire _0670_;
 wire _0671_;
 wire _0672_;
 wire _0673_;
 wire _0674_;
 wire _0675_;
 wire _0676_;
 wire _0677_;
 wire _0678_;
 wire _0679_;
 wire _0680_;
 wire _0681_;
 wire _0682_;
 wire _0683_;
 wire _0684_;
 wire _0685_;
 wire _0686_;
 wire _0687_;
 wire _0688_;
 wire _0689_;
 wire _0690_;
 wire _0691_;
 wire _0692_;
 wire _0693_;
 wire _0694_;
 wire _0695_;
 wire _0696_;
 wire _0697_;
 wire _0698_;
 wire _0699_;
 wire _0700_;
 wire _0701_;
 wire _0702_;
 wire _0703_;
 wire _0704_;
 wire _0705_;
 wire _0706_;
 wire _0707_;
 wire _0708_;
 wire _0709_;
 wire _0710_;
 wire _0711_;
 wire _0712_;
 wire _0713_;
 wire _0714_;
 wire _0715_;
 wire net2;
 wire en_from_switch_sync;
 wire en_from_switch_sync_db;
 wire \fault_count_run[0] ;
 wire \fault_count_run[1] ;
 wire \fault_count_run[2] ;
 wire \fault_count_run[3] ;
 wire \fault_count_run[4] ;
 wire \fault_count_ss[0] ;
 wire \fault_count_ss[1] ;
 wire \fault_count_ss[2] ;
 wire \fault_count_ss[3] ;
 wire \fault_count_ss[4] ;
 wire \fault_count_ss[5] ;
 wire hiccup_active;
 wire hiccup_done;
 wire latch_stat_sync;
 wire latch_stat_sync_db;
 wire \max_on_counts[0] ;
 wire \max_on_counts[1] ;
 wire \max_on_counts[2] ;
 wire \max_on_counts[3] ;
 wire \max_on_counts[4] ;
 wire rst_n;
 wire \rst_sync.meta_ff ;
 wire run_active;
 wire ss_active;
 wire \strike_level[0] ;
 wire \strike_level[1] ;
 wire \u_OTP_sync_db.disagree_counter[0] ;
 wire \u_OTP_sync_db.disagree_counter[10] ;
 wire \u_OTP_sync_db.disagree_counter[11] ;
 wire \u_OTP_sync_db.disagree_counter[12] ;
 wire \u_OTP_sync_db.disagree_counter[13] ;
 wire \u_OTP_sync_db.disagree_counter[1] ;
 wire \u_OTP_sync_db.disagree_counter[2] ;
 wire \u_OTP_sync_db.disagree_counter[3] ;
 wire \u_OTP_sync_db.disagree_counter[4] ;
 wire \u_OTP_sync_db.disagree_counter[5] ;
 wire \u_OTP_sync_db.disagree_counter[6] ;
 wire \u_OTP_sync_db.disagree_counter[7] ;
 wire \u_OTP_sync_db.disagree_counter[8] ;
 wire \u_OTP_sync_db.disagree_counter[9] ;
 wire \u_UVLO_sync_db.disagree_counter[0] ;
 wire \u_UVLO_sync_db.disagree_counter[10] ;
 wire \u_UVLO_sync_db.disagree_counter[11] ;
 wire \u_UVLO_sync_db.disagree_counter[12] ;
 wire \u_UVLO_sync_db.disagree_counter[13] ;
 wire \u_UVLO_sync_db.disagree_counter[1] ;
 wire \u_UVLO_sync_db.disagree_counter[2] ;
 wire \u_UVLO_sync_db.disagree_counter[3] ;
 wire \u_UVLO_sync_db.disagree_counter[4] ;
 wire \u_UVLO_sync_db.disagree_counter[5] ;
 wire \u_UVLO_sync_db.disagree_counter[6] ;
 wire \u_UVLO_sync_db.disagree_counter[7] ;
 wire \u_UVLO_sync_db.disagree_counter[8] ;
 wire \u_UVLO_sync_db.disagree_counter[9] ;
 wire \u_cp_sync.meta_ff ;
 wire \u_en_from_switch_db.disagree_counter[0] ;
 wire \u_en_from_switch_db.disagree_counter[10] ;
 wire \u_en_from_switch_db.disagree_counter[11] ;
 wire \u_en_from_switch_db.disagree_counter[12] ;
 wire \u_en_from_switch_db.disagree_counter[13] ;
 wire \u_en_from_switch_db.disagree_counter[14] ;
 wire \u_en_from_switch_db.disagree_counter[15] ;
 wire \u_en_from_switch_db.disagree_counter[16] ;
 wire \u_en_from_switch_db.disagree_counter[17] ;
 wire \u_en_from_switch_db.disagree_counter[1] ;
 wire \u_en_from_switch_db.disagree_counter[2] ;
 wire \u_en_from_switch_db.disagree_counter[3] ;
 wire \u_en_from_switch_db.disagree_counter[4] ;
 wire \u_en_from_switch_db.disagree_counter[5] ;
 wire \u_en_from_switch_db.disagree_counter[6] ;
 wire \u_en_from_switch_db.disagree_counter[7] ;
 wire \u_en_from_switch_db.disagree_counter[8] ;
 wire \u_en_from_switch_db.disagree_counter[9] ;
 wire \u_en_from_switch_sync.meta_ff ;
 wire \u_fault_LED.blink ;
 wire \u_fault_LED.blink_counter[0] ;
 wire \u_fault_LED.blink_counter[10] ;
 wire \u_fault_LED.blink_counter[11] ;
 wire \u_fault_LED.blink_counter[12] ;
 wire \u_fault_LED.blink_counter[13] ;
 wire \u_fault_LED.blink_counter[14] ;
 wire \u_fault_LED.blink_counter[15] ;
 wire \u_fault_LED.blink_counter[16] ;
 wire \u_fault_LED.blink_counter[17] ;
 wire \u_fault_LED.blink_counter[18] ;
 wire \u_fault_LED.blink_counter[19] ;
 wire \u_fault_LED.blink_counter[1] ;
 wire \u_fault_LED.blink_counter[20] ;
 wire \u_fault_LED.blink_counter[2] ;
 wire \u_fault_LED.blink_counter[3] ;
 wire \u_fault_LED.blink_counter[4] ;
 wire \u_fault_LED.blink_counter[5] ;
 wire \u_fault_LED.blink_counter[6] ;
 wire \u_fault_LED.blink_counter[7] ;
 wire \u_fault_LED.blink_counter[8] ;
 wire \u_fault_LED.blink_counter[9] ;
 wire \u_fault_arbiter.cp_delay[0] ;
 wire \u_fault_arbiter.cp_delay[1] ;
 wire \u_fault_arbiter.cp_delay[2] ;
 wire \u_fault_arbiter.cp_delay[3] ;
 wire \u_fault_arbiter.cp_delay[4] ;
 wire \u_fault_arbiter.fault_shifter_RUN[0] ;
 wire \u_fault_arbiter.fault_shifter_RUN[10] ;
 wire \u_fault_arbiter.fault_shifter_RUN[11] ;
 wire \u_fault_arbiter.fault_shifter_RUN[12] ;
 wire \u_fault_arbiter.fault_shifter_RUN[13] ;
 wire \u_fault_arbiter.fault_shifter_RUN[14] ;
 wire \u_fault_arbiter.fault_shifter_RUN[15] ;
 wire \u_fault_arbiter.fault_shifter_RUN[1] ;
 wire \u_fault_arbiter.fault_shifter_RUN[2] ;
 wire \u_fault_arbiter.fault_shifter_RUN[3] ;
 wire \u_fault_arbiter.fault_shifter_RUN[4] ;
 wire \u_fault_arbiter.fault_shifter_RUN[5] ;
 wire \u_fault_arbiter.fault_shifter_RUN[6] ;
 wire \u_fault_arbiter.fault_shifter_RUN[7] ;
 wire \u_fault_arbiter.fault_shifter_RUN[8] ;
 wire \u_fault_arbiter.fault_shifter_RUN[9] ;
 wire \u_fault_arbiter.fault_shifter_SS[0] ;
 wire \u_fault_arbiter.fault_shifter_SS[10] ;
 wire \u_fault_arbiter.fault_shifter_SS[11] ;
 wire \u_fault_arbiter.fault_shifter_SS[12] ;
 wire \u_fault_arbiter.fault_shifter_SS[13] ;
 wire \u_fault_arbiter.fault_shifter_SS[14] ;
 wire \u_fault_arbiter.fault_shifter_SS[15] ;
 wire \u_fault_arbiter.fault_shifter_SS[16] ;
 wire \u_fault_arbiter.fault_shifter_SS[17] ;
 wire \u_fault_arbiter.fault_shifter_SS[18] ;
 wire \u_fault_arbiter.fault_shifter_SS[19] ;
 wire \u_fault_arbiter.fault_shifter_SS[1] ;
 wire \u_fault_arbiter.fault_shifter_SS[20] ;
 wire \u_fault_arbiter.fault_shifter_SS[21] ;
 wire \u_fault_arbiter.fault_shifter_SS[22] ;
 wire \u_fault_arbiter.fault_shifter_SS[23] ;
 wire \u_fault_arbiter.fault_shifter_SS[24] ;
 wire \u_fault_arbiter.fault_shifter_SS[25] ;
 wire \u_fault_arbiter.fault_shifter_SS[26] ;
 wire \u_fault_arbiter.fault_shifter_SS[27] ;
 wire \u_fault_arbiter.fault_shifter_SS[28] ;
 wire \u_fault_arbiter.fault_shifter_SS[29] ;
 wire \u_fault_arbiter.fault_shifter_SS[2] ;
 wire \u_fault_arbiter.fault_shifter_SS[30] ;
 wire \u_fault_arbiter.fault_shifter_SS[31] ;
 wire \u_fault_arbiter.fault_shifter_SS[3] ;
 wire \u_fault_arbiter.fault_shifter_SS[4] ;
 wire \u_fault_arbiter.fault_shifter_SS[5] ;
 wire \u_fault_arbiter.fault_shifter_SS[6] ;
 wire \u_fault_arbiter.fault_shifter_SS[7] ;
 wire \u_fault_arbiter.fault_shifter_SS[8] ;
 wire \u_fault_arbiter.fault_shifter_SS[9] ;
 wire \u_fault_arbiter.pwm_sync_d ;
 wire \u_hiccup_timer.cool_counter[0] ;
 wire \u_hiccup_timer.cool_counter[10] ;
 wire \u_hiccup_timer.cool_counter[11] ;
 wire \u_hiccup_timer.cool_counter[12] ;
 wire \u_hiccup_timer.cool_counter[13] ;
 wire \u_hiccup_timer.cool_counter[14] ;
 wire \u_hiccup_timer.cool_counter[15] ;
 wire \u_hiccup_timer.cool_counter[16] ;
 wire \u_hiccup_timer.cool_counter[17] ;
 wire \u_hiccup_timer.cool_counter[18] ;
 wire \u_hiccup_timer.cool_counter[19] ;
 wire \u_hiccup_timer.cool_counter[1] ;
 wire \u_hiccup_timer.cool_counter[2] ;
 wire \u_hiccup_timer.cool_counter[3] ;
 wire \u_hiccup_timer.cool_counter[4] ;
 wire \u_hiccup_timer.cool_counter[5] ;
 wire \u_hiccup_timer.cool_counter[6] ;
 wire \u_hiccup_timer.cool_counter[7] ;
 wire \u_hiccup_timer.cool_counter[8] ;
 wire \u_hiccup_timer.cool_counter[9] ;
 wire \u_latch_stat_sync.meta_ff ;
 wire \u_latch_stat_sync_db.disagree_counter[0] ;
 wire \u_latch_stat_sync_db.disagree_counter[10] ;
 wire \u_latch_stat_sync_db.disagree_counter[11] ;
 wire \u_latch_stat_sync_db.disagree_counter[12] ;
 wire \u_latch_stat_sync_db.disagree_counter[13] ;
 wire \u_latch_stat_sync_db.disagree_counter[1] ;
 wire \u_latch_stat_sync_db.disagree_counter[2] ;
 wire \u_latch_stat_sync_db.disagree_counter[3] ;
 wire \u_latch_stat_sync_db.disagree_counter[4] ;
 wire \u_latch_stat_sync_db.disagree_counter[5] ;
 wire \u_latch_stat_sync_db.disagree_counter[6] ;
 wire \u_latch_stat_sync_db.disagree_counter[7] ;
 wire \u_latch_stat_sync_db.disagree_counter[8] ;
 wire \u_latch_stat_sync_db.disagree_counter[9] ;
 wire \u_osc_sync.meta_ff ;
 wire \u_otp_sync.meta_ff ;
 wire \u_pgood_comp_sync.meta_ff ;
 wire \u_pgood_gen.qualify_counter[0] ;
 wire \u_pgood_gen.qualify_counter[10] ;
 wire \u_pgood_gen.qualify_counter[11] ;
 wire \u_pgood_gen.qualify_counter[1] ;
 wire \u_pgood_gen.qualify_counter[2] ;
 wire \u_pgood_gen.qualify_counter[3] ;
 wire \u_pgood_gen.qualify_counter[4] ;
 wire \u_pgood_gen.qualify_counter[5] ;
 wire \u_pgood_gen.qualify_counter[6] ;
 wire \u_pgood_gen.qualify_counter[7] ;
 wire \u_pgood_gen.qualify_counter[8] ;
 wire \u_pgood_gen.qualify_counter[9] ;
 wire \u_pwm_mask.pulse_allowed ;
 wire \u_pwm_mask.run_counter[0] ;
 wire \u_pwm_mask.run_counter[1] ;
 wire \u_pwm_mask.run_counter[2] ;
 wire \u_pwm_mask.run_counter[3] ;
 wire \u_pwm_mask.run_counter[4] ;
 wire \u_soft_start.cycle_counter[0] ;
 wire \u_soft_start.cycle_counter[1] ;
 wire \u_soft_start.cycle_counter[2] ;
 wire \u_soft_start.cycle_counter[3] ;
 wire \u_soft_start.cycle_counter[4] ;
 wire \u_soft_start.cycle_counter[5] ;
 wire \u_soft_start.cycle_counter[6] ;
 wire \u_strike_counter.clean_counter[0] ;
 wire \u_strike_counter.clean_counter[10] ;
 wire \u_strike_counter.clean_counter[11] ;
 wire \u_strike_counter.clean_counter[12] ;
 wire \u_strike_counter.clean_counter[13] ;
 wire \u_strike_counter.clean_counter[14] ;
 wire \u_strike_counter.clean_counter[15] ;
 wire \u_strike_counter.clean_counter[16] ;
 wire \u_strike_counter.clean_counter[17] ;
 wire \u_strike_counter.clean_counter[18] ;
 wire \u_strike_counter.clean_counter[1] ;
 wire \u_strike_counter.clean_counter[2] ;
 wire \u_strike_counter.clean_counter[3] ;
 wire \u_strike_counter.clean_counter[4] ;
 wire \u_strike_counter.clean_counter[5] ;
 wire \u_strike_counter.clean_counter[6] ;
 wire \u_strike_counter.clean_counter[7] ;
 wire \u_strike_counter.clean_counter[8] ;
 wire \u_strike_counter.clean_counter[9] ;
 wire \u_strike_counter.hiccup_active_d ;
 wire \u_supervisor.state[0] ;
 wire \u_uvlo_sync.meta_ff ;
 wire net1;
 wire net4;
 wire net5;
 wire net6;
 wire clknet_0_clk;
 wire clknet_4_0_0_clk;
 wire clknet_4_1_0_clk;
 wire clknet_4_2_0_clk;
 wire clknet_4_3_0_clk;
 wire clknet_4_4_0_clk;
 wire clknet_4_5_0_clk;
 wire clknet_4_6_0_clk;
 wire clknet_4_7_0_clk;
 wire clknet_4_8_0_clk;
 wire clknet_4_9_0_clk;
 wire clknet_4_10_0_clk;
 wire clknet_4_11_0_clk;
 wire clknet_4_12_0_clk;
 wire clknet_4_13_0_clk;
 wire clknet_4_14_0_clk;
 wire clknet_4_15_0_clk;
 wire clknet_5_0__leaf_clk;
 wire clknet_5_1__leaf_clk;
 wire clknet_5_2__leaf_clk;
 wire clknet_5_3__leaf_clk;
 wire clknet_5_4__leaf_clk;
 wire clknet_5_5__leaf_clk;
 wire clknet_5_6__leaf_clk;
 wire clknet_5_7__leaf_clk;
 wire clknet_5_8__leaf_clk;
 wire clknet_5_9__leaf_clk;
 wire clknet_5_10__leaf_clk;
 wire clknet_5_11__leaf_clk;
 wire clknet_5_12__leaf_clk;
 wire clknet_5_13__leaf_clk;
 wire clknet_5_14__leaf_clk;
 wire clknet_5_15__leaf_clk;
 wire clknet_5_16__leaf_clk;
 wire clknet_5_17__leaf_clk;
 wire clknet_5_18__leaf_clk;
 wire clknet_5_19__leaf_clk;
 wire clknet_5_20__leaf_clk;
 wire clknet_5_21__leaf_clk;
 wire clknet_5_22__leaf_clk;
 wire clknet_5_23__leaf_clk;
 wire clknet_5_24__leaf_clk;
 wire clknet_5_25__leaf_clk;
 wire clknet_5_26__leaf_clk;
 wire clknet_5_27__leaf_clk;
 wire clknet_5_28__leaf_clk;
 wire clknet_5_29__leaf_clk;
 wire clknet_5_30__leaf_clk;
 wire clknet_5_31__leaf_clk;

 sky130_fd_sc_hd__inv_1 _0716_ (.A(\u_latch_stat_sync_db.disagree_counter[13] ),
    .Y(_0335_));
 sky130_fd_sc_hd__inv_1 _0717_ (.A(SS_done),
    .Y(_0336_));
 sky130_fd_sc_hd__inv_1 _0718_ (.A(\u_strike_counter.clean_counter[3] ),
    .Y(_0345_));
 sky130_fd_sc_hd__nor3b_1 _0719_ (.A(_0423_),
    .B(_0426_),
    .C_N(\u_soft_start.cycle_counter[6] ),
    .Y(_0224_));
 sky130_fd_sc_hd__nor2_1 _0720_ (.A(_0340_),
    .B(\u_strike_counter.hiccup_active_d ),
    .Y(_0428_));
 sky130_fd_sc_hd__a21o_1 _0721_ (.A1(\strike_level[1] ),
    .A2(_0428_),
    .B1(latch_out),
    .X(_0223_));
 sky130_fd_sc_hd__nand4_1 _0722_ (.A(\u_strike_counter.clean_counter[12] ),
    .B(\u_strike_counter.clean_counter[15] ),
    .C(\u_strike_counter.clean_counter[8] ),
    .D(\u_strike_counter.clean_counter[18] ),
    .Y(_0429_));
 sky130_fd_sc_hd__nand4_1 _0723_ (.A(\u_strike_counter.clean_counter[7] ),
    .B(\u_strike_counter.clean_counter[10] ),
    .C(\u_strike_counter.clean_counter[6] ),
    .D(\u_strike_counter.clean_counter[4] ),
    .Y(_0430_));
 sky130_fd_sc_hd__nor2_1 _0724_ (.A(_0429_),
    .B(_0430_),
    .Y(_0431_));
 sky130_fd_sc_hd__nor3_1 _0725_ (.A(\u_strike_counter.clean_counter[5] ),
    .B(\u_strike_counter.clean_counter[13] ),
    .C(\u_strike_counter.clean_counter[16] ),
    .Y(_0432_));
 sky130_fd_sc_hd__nor4b_1 _0726_ (.A(\u_strike_counter.clean_counter[1] ),
    .B(\u_strike_counter.clean_counter[0] ),
    .C(\u_strike_counter.clean_counter[9] ),
    .D_N(\u_strike_counter.clean_counter[14] ),
    .Y(_0433_));
 sky130_fd_sc_hd__nor4bb_1 _0727_ (.A(\u_strike_counter.clean_counter[2] ),
    .B(\u_strike_counter.clean_counter[3] ),
    .C_N(\u_strike_counter.clean_counter[17] ),
    .D_N(\u_strike_counter.clean_counter[11] ),
    .Y(_0434_));
 sky130_fd_sc_hd__and3_1 _0728_ (.A(_0432_),
    .B(_0433_),
    .C(_0434_),
    .X(_0435_));
 sky130_fd_sc_hd__inv_1 _0729_ (.A(\max_on_counts[3] ),
    .Y(_0346_));
 sky130_fd_sc_hd__a21oi_1 _0730_ (.A1(_0431_),
    .A2(_0435_),
    .B1(_0428_),
    .Y(_0436_));
 sky130_fd_sc_hd__xor2_1 _0731_ (.A(\strike_level[1] ),
    .B(\strike_level[0] ),
    .X(_0437_));
 sky130_fd_sc_hd__a22o_1 _0732_ (.A1(\strike_level[1] ),
    .A2(_0436_),
    .B1(_0437_),
    .B2(_0428_),
    .X(_0222_));
 sky130_fd_sc_hd__a21oi_2 _0733_ (.A1(\fault_count_run[2] ),
    .A2(\fault_count_run[3] ),
    .B1(\fault_count_run[4] ),
    .Y(_0438_));
 sky130_fd_sc_hd__and2_2 _0734_ (.A(run_active),
    .B(_0438_),
    .X(_0439_));
 sky130_fd_sc_hd__nand2_4 _0735_ (.A(run_active),
    .B(_0438_),
    .Y(_0440_));
 sky130_fd_sc_hd__a21oi_4 _0736_ (.A1(_0431_),
    .A2(_0435_),
    .B1(_0385_),
    .Y(_0441_));
 sky130_fd_sc_hd__nor2_1 _0737_ (.A(_0440_),
    .B(_0441_),
    .Y(_0442_));
 sky130_fd_sc_hd__nand3_1 _0738_ (.A(\u_strike_counter.clean_counter[7] ),
    .B(\u_strike_counter.clean_counter[8] ),
    .C(\u_strike_counter.clean_counter[9] ),
    .Y(_0443_));
 sky130_fd_sc_hd__nand3_2 _0739_ (.A(\u_strike_counter.clean_counter[6] ),
    .B(\u_strike_counter.clean_counter[4] ),
    .C(\u_strike_counter.clean_counter[5] ),
    .Y(_0444_));
 sky130_fd_sc_hd__inv_1 _0740_ (.A(\fault_count_ss[2] ),
    .Y(_0347_));
 sky130_fd_sc_hd__nand4_2 _0741_ (.A(\u_strike_counter.clean_counter[2] ),
    .B(\u_strike_counter.clean_counter[3] ),
    .C(\u_strike_counter.clean_counter[1] ),
    .D(\u_strike_counter.clean_counter[0] ),
    .Y(_0445_));
 sky130_fd_sc_hd__nor3_1 _0742_ (.A(_0443_),
    .B(_0444_),
    .C(_0445_),
    .Y(_0446_));
 sky130_fd_sc_hd__nor3_1 _0743_ (.A(_0443_),
    .B(_0444_),
    .C(_0445_),
    .Y(_0447_));
 sky130_fd_sc_hd__nand2_1 _0744_ (.A(\u_strike_counter.clean_counter[10] ),
    .B(_0447_),
    .Y(_0448_));
 sky130_fd_sc_hd__nor2_1 _0745_ (.A(_0442_),
    .B(_0448_),
    .Y(_0449_));
 sky130_fd_sc_hd__and3_1 _0746_ (.A(\u_strike_counter.clean_counter[12] ),
    .B(\u_strike_counter.clean_counter[11] ),
    .C(\u_strike_counter.clean_counter[13] ),
    .X(_0450_));
 sky130_fd_sc_hd__o2111a_1 _0747_ (.A1(_0440_),
    .A2(_0441_),
    .B1(_0447_),
    .C1(_0450_),
    .D1(\u_strike_counter.clean_counter[10] ),
    .X(_0451_));
 sky130_fd_sc_hd__and3_1 _0748_ (.A(\u_strike_counter.clean_counter[15] ),
    .B(\u_strike_counter.clean_counter[14] ),
    .C(_0451_),
    .X(_0452_));
 sky130_fd_sc_hd__and2_0 _0749_ (.A(\u_strike_counter.clean_counter[16] ),
    .B(_0452_),
    .X(_0453_));
 sky130_fd_sc_hd__nand3_1 _0750_ (.A(\u_strike_counter.clean_counter[17] ),
    .B(\u_strike_counter.clean_counter[16] ),
    .C(_0452_),
    .Y(_0454_));
 sky130_fd_sc_hd__inv_1 _0751_ (.A(\u_pwm_mask.run_counter[0] ),
    .Y(_0348_));
 sky130_fd_sc_hd__xor2_1 _0752_ (.A(\u_strike_counter.clean_counter[18] ),
    .B(_0454_),
    .X(_0455_));
 sky130_fd_sc_hd__nor2_1 _0753_ (.A(_0440_),
    .B(_0455_),
    .Y(_0221_));
 sky130_fd_sc_hd__nor2_1 _0754_ (.A(latch_stat_sync_db),
    .B(_0360_),
    .Y(_0456_));
 sky130_fd_sc_hd__a21oi_1 _0755_ (.A1(_0339_),
    .A2(_0360_),
    .B1(_0456_),
    .Y(_0220_));
 sky130_fd_sc_hd__nand2b_1 _0756_ (.A_N(\u_hiccup_timer.cool_counter[5] ),
    .B(\u_hiccup_timer.cool_counter[9] ),
    .Y(_0457_));
 sky130_fd_sc_hd__nand2_1 _0757_ (.A(\strike_level[1] ),
    .B(\strike_level[0] ),
    .Y(_0458_));
 sky130_fd_sc_hd__nor2_1 _0758_ (.A(\strike_level[1] ),
    .B(\strike_level[0] ),
    .Y(_0459_));
 sky130_fd_sc_hd__nor3_1 _0759_ (.A(\strike_level[1] ),
    .B(\strike_level[0] ),
    .C(\u_hiccup_timer.cool_counter[4] ),
    .Y(_0460_));
 sky130_fd_sc_hd__a21oi_1 _0760_ (.A1(\u_hiccup_timer.cool_counter[8] ),
    .A2(_0349_),
    .B1(\strike_level[0] ),
    .Y(_0461_));
 sky130_fd_sc_hd__xor2_1 _0761_ (.A(\u_hiccup_timer.cool_counter[12] ),
    .B(_0458_),
    .X(_0462_));
 sky130_fd_sc_hd__inv_1 _0762_ (.A(\u_hiccup_timer.cool_counter[7] ),
    .Y(_0349_));
 sky130_fd_sc_hd__nor2_1 _0763_ (.A(\u_hiccup_timer.cool_counter[4] ),
    .B(_0459_),
    .Y(_0463_));
 sky130_fd_sc_hd__a21oi_1 _0764_ (.A1(\strike_level[1] ),
    .A2(_0338_),
    .B1(\u_hiccup_timer.cool_counter[9] ),
    .Y(_0464_));
 sky130_fd_sc_hd__nor4b_1 _0765_ (.A(\strike_level[1] ),
    .B(\u_hiccup_timer.cool_counter[11] ),
    .C(\u_hiccup_timer.cool_counter[17] ),
    .D_N(\u_hiccup_timer.cool_counter[15] ),
    .Y(_0465_));
 sky130_fd_sc_hd__and4b_1 _0766_ (.A_N(\u_hiccup_timer.cool_counter[15] ),
    .B(\u_hiccup_timer.cool_counter[17] ),
    .C(\strike_level[1] ),
    .D(\u_hiccup_timer.cool_counter[11] ),
    .X(_0466_));
 sky130_fd_sc_hd__xor2_1 _0767_ (.A(\u_hiccup_timer.cool_counter[18] ),
    .B(_0458_),
    .X(_0467_));
 sky130_fd_sc_hd__a21oi_1 _0768_ (.A1(\strike_level[0] ),
    .A2(_0349_),
    .B1(\u_hiccup_timer.cool_counter[14] ),
    .Y(_0468_));
 sky130_fd_sc_hd__nor2_1 _0769_ (.A(\u_hiccup_timer.cool_counter[10] ),
    .B(\u_hiccup_timer.cool_counter[16] ),
    .Y(_0469_));
 sky130_fd_sc_hd__nor2_1 _0770_ (.A(_0437_),
    .B(_0469_),
    .Y(_0470_));
 sky130_fd_sc_hd__nand3_1 _0771_ (.A(\u_hiccup_timer.cool_counter[10] ),
    .B(\u_hiccup_timer.cool_counter[16] ),
    .C(_0457_),
    .Y(_0471_));
 sky130_fd_sc_hd__a21oi_1 _0772_ (.A1(_0437_),
    .A2(_0471_),
    .B1(_0470_),
    .Y(_0472_));
 sky130_fd_sc_hd__inv_1 _0773_ (.A(\u_fault_LED.blink_counter[19] ),
    .Y(_0350_));
 sky130_fd_sc_hd__nor2_1 _0774_ (.A(\u_hiccup_timer.cool_counter[8] ),
    .B(_0338_),
    .Y(_0473_));
 sky130_fd_sc_hd__nor2_1 _0775_ (.A(\u_hiccup_timer.cool_counter[6] ),
    .B(_0473_),
    .Y(_0474_));
 sky130_fd_sc_hd__a211o_1 _0776_ (.A1(\u_hiccup_timer.cool_counter[6] ),
    .A2(\strike_level[0] ),
    .B1(\u_hiccup_timer.cool_counter[13] ),
    .C1(\u_hiccup_timer.cool_counter[3] ),
    .X(_0475_));
 sky130_fd_sc_hd__o22ai_1 _0777_ (.A1(\strike_level[1] ),
    .A2(_0338_),
    .B1(_0461_),
    .B2(\u_hiccup_timer.cool_counter[5] ),
    .Y(_0476_));
 sky130_fd_sc_hd__o211ai_1 _0778_ (.A1(_0465_),
    .A2(_0466_),
    .B1(_0467_),
    .C1(_0476_),
    .Y(_0477_));
 sky130_fd_sc_hd__nor4_1 _0779_ (.A(\u_hiccup_timer.cool_counter[19] ),
    .B(\u_hiccup_timer.cool_counter[2] ),
    .C(_0475_),
    .D(_0477_),
    .Y(_0478_));
 sky130_fd_sc_hd__o21ai_0 _0780_ (.A1(_0459_),
    .A2(_0468_),
    .B1(_0462_),
    .Y(_0479_));
 sky130_fd_sc_hd__or3_1 _0781_ (.A(_0460_),
    .B(_0464_),
    .C(_0474_),
    .X(_0480_));
 sky130_fd_sc_hd__nor4_1 _0782_ (.A(\u_hiccup_timer.cool_counter[0] ),
    .B(\u_hiccup_timer.cool_counter[1] ),
    .C(_0479_),
    .D(_0480_),
    .Y(_0481_));
 sky130_fd_sc_hd__o2111a_1 _0783_ (.A1(\u_hiccup_timer.cool_counter[14] ),
    .A2(_0463_),
    .B1(_0472_),
    .C1(_0478_),
    .D1(_0481_),
    .X(_0482_));
 sky130_fd_sc_hd__inv_1 _0784_ (.A(\u_fault_LED.blink_counter[0] ),
    .Y(_0006_));
 sky130_fd_sc_hd__o21a_1 _0785_ (.A1(hiccup_done),
    .A2(_0482_),
    .B1(hiccup_active),
    .X(_0219_));
 sky130_fd_sc_hd__and3_1 _0786_ (.A(\u_hiccup_timer.cool_counter[0] ),
    .B(\u_hiccup_timer.cool_counter[1] ),
    .C(\u_hiccup_timer.cool_counter[2] ),
    .X(_0483_));
 sky130_fd_sc_hd__and4_1 _0787_ (.A(\u_hiccup_timer.cool_counter[0] ),
    .B(\u_hiccup_timer.cool_counter[1] ),
    .C(\u_hiccup_timer.cool_counter[3] ),
    .D(\u_hiccup_timer.cool_counter[2] ),
    .X(_0484_));
 sky130_fd_sc_hd__and3_1 _0788_ (.A(\u_hiccup_timer.cool_counter[5] ),
    .B(\u_hiccup_timer.cool_counter[4] ),
    .C(_0484_),
    .X(_0485_));
 sky130_fd_sc_hd__and4_1 _0789_ (.A(\u_hiccup_timer.cool_counter[6] ),
    .B(\u_hiccup_timer.cool_counter[5] ),
    .C(\u_hiccup_timer.cool_counter[4] ),
    .D(_0484_),
    .X(_0486_));
 sky130_fd_sc_hd__and2_0 _0790_ (.A(\u_hiccup_timer.cool_counter[7] ),
    .B(_0486_),
    .X(_0487_));
 sky130_fd_sc_hd__and3_1 _0791_ (.A(\u_hiccup_timer.cool_counter[8] ),
    .B(\u_hiccup_timer.cool_counter[7] ),
    .C(_0486_),
    .X(_0488_));
 sky130_fd_sc_hd__and3_1 _0792_ (.A(\u_hiccup_timer.cool_counter[9] ),
    .B(\u_hiccup_timer.cool_counter[10] ),
    .C(_0488_),
    .X(_0489_));
 sky130_fd_sc_hd__and4_1 _0793_ (.A(\u_hiccup_timer.cool_counter[11] ),
    .B(\u_hiccup_timer.cool_counter[9] ),
    .C(\u_hiccup_timer.cool_counter[10] ),
    .D(_0488_),
    .X(_0490_));
 sky130_fd_sc_hd__and3_1 _0794_ (.A(\u_hiccup_timer.cool_counter[12] ),
    .B(\u_hiccup_timer.cool_counter[13] ),
    .C(_0490_),
    .X(_0491_));
 sky130_fd_sc_hd__nand3_2 _0795_ (.A(\u_latch_stat_sync_db.disagree_counter[8] ),
    .B(\u_latch_stat_sync_db.disagree_counter[9] ),
    .C(\u_latch_stat_sync_db.disagree_counter[10] ),
    .Y(_0351_));
 sky130_fd_sc_hd__and4_1 _0796_ (.A(\u_hiccup_timer.cool_counter[12] ),
    .B(\u_hiccup_timer.cool_counter[13] ),
    .C(\u_hiccup_timer.cool_counter[14] ),
    .D(_0490_),
    .X(_0492_));
 sky130_fd_sc_hd__and3_1 _0797_ (.A(\u_hiccup_timer.cool_counter[15] ),
    .B(\u_hiccup_timer.cool_counter[16] ),
    .C(_0492_),
    .X(_0493_));
 sky130_fd_sc_hd__and4_1 _0798_ (.A(\u_hiccup_timer.cool_counter[15] ),
    .B(\u_hiccup_timer.cool_counter[17] ),
    .C(\u_hiccup_timer.cool_counter[16] ),
    .D(_0492_),
    .X(_0494_));
 sky130_fd_sc_hd__a21oi_1 _0799_ (.A1(\u_hiccup_timer.cool_counter[18] ),
    .A2(_0494_),
    .B1(\u_hiccup_timer.cool_counter[19] ),
    .Y(_0495_));
 sky130_fd_sc_hd__and3_1 _0800_ (.A(\u_hiccup_timer.cool_counter[19] ),
    .B(\u_hiccup_timer.cool_counter[18] ),
    .C(_0494_),
    .X(_0496_));
 sky130_fd_sc_hd__nor3_1 _0801_ (.A(_0340_),
    .B(_0495_),
    .C(_0496_),
    .Y(_0218_));
 sky130_fd_sc_hd__and2_0 _0802_ (.A(\u_en_from_switch_db.disagree_counter[11] ),
    .B(\u_en_from_switch_db.disagree_counter[10] ),
    .X(_0497_));
 sky130_fd_sc_hd__and3_1 _0803_ (.A(\u_en_from_switch_db.disagree_counter[4] ),
    .B(\u_en_from_switch_db.disagree_counter[5] ),
    .C(\u_en_from_switch_db.disagree_counter[3] ),
    .X(_0498_));
 sky130_fd_sc_hd__and3_1 _0804_ (.A(\u_en_from_switch_db.disagree_counter[1] ),
    .B(\u_en_from_switch_db.disagree_counter[0] ),
    .C(\u_en_from_switch_db.disagree_counter[2] ),
    .X(_0499_));
 sky130_fd_sc_hd__a21o_1 _0805_ (.A1(_0498_),
    .A2(_0499_),
    .B1(\u_en_from_switch_db.disagree_counter[6] ),
    .X(_0500_));
 sky130_fd_sc_hd__o21ai_1 _0806_ (.A1(\u_latch_stat_sync_db.disagree_counter[6] ),
    .A2(\u_latch_stat_sync_db.disagree_counter[7] ),
    .B1(latch_stat_sync),
    .Y(_0352_));
 sky130_fd_sc_hd__a21oi_1 _0807_ (.A1(\u_en_from_switch_db.disagree_counter[8] ),
    .A2(\u_en_from_switch_db.disagree_counter[7] ),
    .B1(\u_en_from_switch_db.disagree_counter[9] ),
    .Y(_0501_));
 sky130_fd_sc_hd__a21bo_1 _0808_ (.A1(\u_en_from_switch_db.disagree_counter[8] ),
    .A2(_0500_),
    .B1_N(_0501_),
    .X(_0502_));
 sky130_fd_sc_hd__or4_1 _0809_ (.A(\u_en_from_switch_db.disagree_counter[14] ),
    .B(\u_en_from_switch_db.disagree_counter[13] ),
    .C(\u_en_from_switch_db.disagree_counter[12] ),
    .D(\u_en_from_switch_db.disagree_counter[15] ),
    .X(_0503_));
 sky130_fd_sc_hd__a21oi_1 _0810_ (.A1(_0497_),
    .A2(_0502_),
    .B1(_0503_),
    .Y(_0504_));
 sky130_fd_sc_hd__nand2_1 _0811_ (.A(\u_en_from_switch_db.disagree_counter[17] ),
    .B(\u_en_from_switch_db.disagree_counter[16] ),
    .Y(_0505_));
 sky130_fd_sc_hd__nor2_1 _0812_ (.A(_0504_),
    .B(_0505_),
    .Y(_0506_));
 sky130_fd_sc_hd__or2_2 _0813_ (.A(_0504_),
    .B(_0505_),
    .X(_0507_));
 sky130_fd_sc_hd__nor2_1 _0814_ (.A(en_from_switch_sync_db),
    .B(_0506_),
    .Y(_0508_));
 sky130_fd_sc_hd__nor2_1 _0815_ (.A(en_from_switch_sync),
    .B(_0507_),
    .Y(_0509_));
 sky130_fd_sc_hd__nor2_1 _0816_ (.A(_0508_),
    .B(_0509_),
    .Y(_0217_));
 sky130_fd_sc_hd__and3_1 _0817_ (.A(\u_latch_stat_sync_db.disagree_counter[2] ),
    .B(\u_latch_stat_sync_db.disagree_counter[0] ),
    .C(\u_latch_stat_sync_db.disagree_counter[1] ),
    .X(_0353_));
 sky130_fd_sc_hd__xnor2_4 _0818_ (.A(en_from_switch_sync_db),
    .B(en_from_switch_sync),
    .Y(_0510_));
 sky130_fd_sc_hd__xor2_1 _0819_ (.A(en_from_switch_sync_db),
    .B(en_from_switch_sync),
    .X(_0511_));
 sky130_fd_sc_hd__nand3_2 _0820_ (.A(\u_en_from_switch_db.disagree_counter[6] ),
    .B(_0498_),
    .C(_0499_),
    .Y(_0512_));
 sky130_fd_sc_hd__nand4_1 _0821_ (.A(\u_en_from_switch_db.disagree_counter[9] ),
    .B(\u_en_from_switch_db.disagree_counter[8] ),
    .C(\u_en_from_switch_db.disagree_counter[7] ),
    .D(_0497_),
    .Y(_0513_));
 sky130_fd_sc_hd__nand2_1 _0822_ (.A(\u_en_from_switch_db.disagree_counter[13] ),
    .B(\u_en_from_switch_db.disagree_counter[12] ),
    .Y(_0514_));
 sky130_fd_sc_hd__nor3_1 _0823_ (.A(_0512_),
    .B(_0513_),
    .C(_0514_),
    .Y(_0515_));
 sky130_fd_sc_hd__and2_0 _0824_ (.A(\u_en_from_switch_db.disagree_counter[14] ),
    .B(_0515_),
    .X(_0516_));
 sky130_fd_sc_hd__nand3_1 _0825_ (.A(\u_en_from_switch_db.disagree_counter[9] ),
    .B(\u_en_from_switch_db.disagree_counter[8] ),
    .C(\u_en_from_switch_db.disagree_counter[7] ),
    .Y(_0517_));
 sky130_fd_sc_hd__a31oi_1 _0826_ (.A1(\u_en_from_switch_db.disagree_counter[16] ),
    .A2(\u_en_from_switch_db.disagree_counter[15] ),
    .A3(_0516_),
    .B1(\u_en_from_switch_db.disagree_counter[17] ),
    .Y(_0518_));
 sky130_fd_sc_hd__nor2_1 _0827_ (.A(_0510_),
    .B(_0518_),
    .Y(_0216_));
 sky130_fd_sc_hd__inv_1 _0828_ (.A(\max_on_counts[0] ),
    .Y(_0337_));
 sky130_fd_sc_hd__and4_1 _0829_ (.A(\u_latch_stat_sync_db.disagree_counter[2] ),
    .B(\u_latch_stat_sync_db.disagree_counter[0] ),
    .C(\u_latch_stat_sync_db.disagree_counter[1] ),
    .D(\u_latch_stat_sync_db.disagree_counter[3] ),
    .X(_0354_));
 sky130_fd_sc_hd__nor3b_4 _0830_ (.A(run_active),
    .B(\u_fault_arbiter.pwm_sync_d ),
    .C_N(Osc_sync),
    .Y(_0519_));
 sky130_fd_sc_hd__nor2_8 _0831_ (.A(_0423_),
    .B(_0519_),
    .Y(_0520_));
 sky130_fd_sc_hd__nor2_1 _0832_ (.A(\fault_count_ss[1] ),
    .B(\fault_count_ss[2] ),
    .Y(_0521_));
 sky130_fd_sc_hd__xor2_2 _0833_ (.A(\fault_count_ss[1] ),
    .B(\fault_count_ss[2] ),
    .X(_0522_));
 sky130_fd_sc_hd__nor2b_1 _0834_ (.A(\fault_count_ss[0] ),
    .B_N(\u_fault_arbiter.fault_shifter_SS[31] ),
    .Y(_0523_));
 sky130_fd_sc_hd__xor2_1 _0835_ (.A(\fault_count_ss[0] ),
    .B(\u_fault_arbiter.fault_shifter_SS[31] ),
    .X(_0524_));
 sky130_fd_sc_hd__nand2_1 _0836_ (.A(\u_fault_arbiter.cp_delay[4] ),
    .B(_0524_),
    .Y(_0525_));
 sky130_fd_sc_hd__xnor2_1 _0837_ (.A(\fault_count_ss[1] ),
    .B(_0523_),
    .Y(_0526_));
 sky130_fd_sc_hd__maj3_2 _0838_ (.A(\fault_count_ss[1] ),
    .B(_0523_),
    .C(_0525_),
    .X(_0527_));
 sky130_fd_sc_hd__nor2_1 _0839_ (.A(_0522_),
    .B(_0527_),
    .Y(_0528_));
 sky130_fd_sc_hd__nor3_1 _0840_ (.A(\u_latch_stat_sync_db.disagree_counter[5] ),
    .B(\u_latch_stat_sync_db.disagree_counter[4] ),
    .C(_0354_),
    .Y(_0355_));
 sky130_fd_sc_hd__xor2_2 _0841_ (.A(\fault_count_ss[2] ),
    .B(\fault_count_ss[3] ),
    .X(_0529_));
 sky130_fd_sc_hd__o32ai_4 _0842_ (.A1(_0522_),
    .A2(_0527_),
    .A3(_0529_),
    .B1(_0521_),
    .B2(\fault_count_ss[3] ),
    .Y(_0530_));
 sky130_fd_sc_hd__nand3_1 _0843_ (.A(\fault_count_ss[4] ),
    .B(\fault_count_ss[3] ),
    .C(_0530_),
    .Y(_0531_));
 sky130_fd_sc_hd__or3_1 _0844_ (.A(\fault_count_ss[4] ),
    .B(\fault_count_ss[3] ),
    .C(_0530_),
    .X(_0532_));
 sky130_fd_sc_hd__a21oi_1 _0845_ (.A1(_0531_),
    .A2(_0532_),
    .B1(_0520_),
    .Y(_0533_));
 sky130_fd_sc_hd__o21ai_0 _0846_ (.A1(\fault_count_ss[5] ),
    .A2(_0533_),
    .B1(_0424_),
    .Y(_0534_));
 sky130_fd_sc_hd__a21oi_1 _0847_ (.A1(\fault_count_ss[5] ),
    .A2(_0533_),
    .B1(_0534_),
    .Y(_0215_));
 sky130_fd_sc_hd__nor3b_4 _0848_ (.A(_0342_),
    .B(\u_fault_arbiter.pwm_sync_d ),
    .C_N(Osc_sync),
    .Y(_0535_));
 sky130_fd_sc_hd__nor2_8 _0849_ (.A(_0423_),
    .B(_0535_),
    .Y(_0536_));
 sky130_fd_sc_hd__nand2_1 _0850_ (.A(\fault_count_run[4] ),
    .B(_0536_),
    .Y(_0537_));
 sky130_fd_sc_hd__nand2_2 _0851_ (.A(\u_latch_stat_sync_db.disagree_counter[6] ),
    .B(\u_latch_stat_sync_db.disagree_counter[7] ),
    .Y(_0356_));
 sky130_fd_sc_hd__nor2_1 _0852_ (.A(\fault_count_run[1] ),
    .B(\fault_count_run[2] ),
    .Y(_0538_));
 sky130_fd_sc_hd__xor2_1 _0853_ (.A(\fault_count_run[1] ),
    .B(\fault_count_run[2] ),
    .X(_0539_));
 sky130_fd_sc_hd__nor2b_1 _0854_ (.A(\fault_count_run[0] ),
    .B_N(\u_fault_arbiter.fault_shifter_RUN[15] ),
    .Y(_0540_));
 sky130_fd_sc_hd__xor2_1 _0855_ (.A(\u_fault_arbiter.fault_shifter_RUN[15] ),
    .B(\fault_count_run[0] ),
    .X(_0541_));
 sky130_fd_sc_hd__nand2_1 _0856_ (.A(\u_fault_arbiter.cp_delay[4] ),
    .B(_0541_),
    .Y(_0542_));
 sky130_fd_sc_hd__xnor2_1 _0857_ (.A(\fault_count_run[1] ),
    .B(_0540_),
    .Y(_0543_));
 sky130_fd_sc_hd__maj3_1 _0858_ (.A(\fault_count_run[1] ),
    .B(_0540_),
    .C(_0542_),
    .X(_0544_));
 sky130_fd_sc_hd__or2_1 _0859_ (.A(_0539_),
    .B(_0544_),
    .X(_0545_));
 sky130_fd_sc_hd__xor2_1 _0860_ (.A(\fault_count_run[2] ),
    .B(\fault_count_run[3] ),
    .X(_0546_));
 sky130_fd_sc_hd__o22a_1 _0861_ (.A1(\fault_count_run[3] ),
    .A2(_0538_),
    .B1(_0545_),
    .B2(_0546_),
    .X(_0547_));
 sky130_fd_sc_hd__a221oi_4 _0862_ (.A1(_0352_),
    .A2(_0355_),
    .B1(_0356_),
    .B2(_0339_),
    .C1(_0351_),
    .Y(_0357_));
 sky130_fd_sc_hd__xor2_1 _0863_ (.A(\fault_count_run[4] ),
    .B(\fault_count_run[3] ),
    .X(_0548_));
 sky130_fd_sc_hd__and2_0 _0864_ (.A(_0547_),
    .B(_0548_),
    .X(_0549_));
 sky130_fd_sc_hd__o21ai_0 _0865_ (.A1(_0547_),
    .A2(_0548_),
    .B1(_0535_),
    .Y(_0550_));
 sky130_fd_sc_hd__o21ai_0 _0866_ (.A1(_0549_),
    .A2(_0550_),
    .B1(_0537_),
    .Y(_0214_));
 sky130_fd_sc_hd__a22o_1 _0867_ (.A1(\u_fault_arbiter.fault_shifter_RUN[14] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[15] ),
    .X(_0213_));
 sky130_fd_sc_hd__xnor2_4 _0868_ (.A(OTP_sync_db),
    .B(OTP_sync),
    .Y(_0551_));
 sky130_fd_sc_hd__xor2_2 _0869_ (.A(OTP_sync_db),
    .B(OTP_sync),
    .X(_0552_));
 sky130_fd_sc_hd__nand3_1 _0870_ (.A(\u_OTP_sync_db.disagree_counter[9] ),
    .B(\u_OTP_sync_db.disagree_counter[8] ),
    .C(\u_OTP_sync_db.disagree_counter[10] ),
    .Y(_0553_));
 sky130_fd_sc_hd__o21a_1 _0871_ (.A1(\u_OTP_sync_db.disagree_counter[7] ),
    .A2(\u_OTP_sync_db.disagree_counter[6] ),
    .B1(OTP_sync),
    .X(_0554_));
 sky130_fd_sc_hd__nand3_1 _0872_ (.A(\u_OTP_sync_db.disagree_counter[2] ),
    .B(\u_OTP_sync_db.disagree_counter[1] ),
    .C(\u_OTP_sync_db.disagree_counter[0] ),
    .Y(_0555_));
 sky130_fd_sc_hd__nor2_1 _0873_ (.A(\u_latch_stat_sync_db.disagree_counter[11] ),
    .B(\u_latch_stat_sync_db.disagree_counter[12] ),
    .Y(_0358_));
 sky130_fd_sc_hd__and4_1 _0874_ (.A(\u_OTP_sync_db.disagree_counter[2] ),
    .B(\u_OTP_sync_db.disagree_counter[1] ),
    .C(\u_OTP_sync_db.disagree_counter[0] ),
    .D(\u_OTP_sync_db.disagree_counter[3] ),
    .X(_0556_));
 sky130_fd_sc_hd__a21oi_1 _0875_ (.A1(\u_OTP_sync_db.disagree_counter[7] ),
    .A2(\u_OTP_sync_db.disagree_counter[6] ),
    .B1(OTP_sync),
    .Y(_0557_));
 sky130_fd_sc_hd__nor4_1 _0876_ (.A(\u_OTP_sync_db.disagree_counter[4] ),
    .B(\u_OTP_sync_db.disagree_counter[5] ),
    .C(_0554_),
    .D(_0556_),
    .Y(_0558_));
 sky130_fd_sc_hd__nor2b_1 _0877_ (.A(OTP_sync),
    .B_N(\u_OTP_sync_db.disagree_counter[13] ),
    .Y(_0559_));
 sky130_fd_sc_hd__nor3_1 _0878_ (.A(\u_OTP_sync_db.disagree_counter[12] ),
    .B(\u_OTP_sync_db.disagree_counter[11] ),
    .C(_0559_),
    .Y(_0560_));
 sky130_fd_sc_hd__o31a_1 _0879_ (.A1(_0553_),
    .A2(_0557_),
    .A3(_0558_),
    .B1(_0560_),
    .X(_0561_));
 sky130_fd_sc_hd__nor2_1 _0880_ (.A(OTP_sync),
    .B(_0561_),
    .Y(_0562_));
 sky130_fd_sc_hd__a21o_2 _0881_ (.A1(_0344_),
    .A2(OTP_sync),
    .B1(_0561_),
    .X(_0563_));
 sky130_fd_sc_hd__and3_1 _0882_ (.A(\u_OTP_sync_db.disagree_counter[4] ),
    .B(\u_OTP_sync_db.disagree_counter[5] ),
    .C(_0556_),
    .X(_0564_));
 sky130_fd_sc_hd__and2_0 _0883_ (.A(_0563_),
    .B(_0564_),
    .X(_0565_));
 sky130_fd_sc_hd__o21ai_2 _0884_ (.A1(_0335_),
    .A2(latch_stat_sync),
    .B1(_0358_),
    .Y(_0359_));
 sky130_fd_sc_hd__and3_1 _0885_ (.A(\u_OTP_sync_db.disagree_counter[7] ),
    .B(\u_OTP_sync_db.disagree_counter[6] ),
    .C(_0564_),
    .X(_0566_));
 sky130_fd_sc_hd__nor2b_1 _0886_ (.A(_0553_),
    .B_N(_0566_),
    .Y(_0567_));
 sky130_fd_sc_hd__nand4_1 _0887_ (.A(\u_OTP_sync_db.disagree_counter[12] ),
    .B(\u_OTP_sync_db.disagree_counter[11] ),
    .C(_0563_),
    .D(_0567_),
    .Y(_0568_));
 sky130_fd_sc_hd__a21oi_1 _0888_ (.A1(_0344_),
    .A2(_0568_),
    .B1(_0551_),
    .Y(_0212_));
 sky130_fd_sc_hd__a21oi_1 _0889_ (.A1(_0341_),
    .A2(_0563_),
    .B1(_0562_),
    .Y(_0211_));
 sky130_fd_sc_hd__and2_4 _0890_ (.A(ss_active),
    .B(_0519_),
    .X(_0569_));
 sky130_fd_sc_hd__a22o_1 _0891_ (.A1(\u_fault_arbiter.fault_shifter_SS[31] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[30] ),
    .X(_0210_));
 sky130_fd_sc_hd__nand3_1 _0892_ (.A(\u_UVLO_sync_db.disagree_counter[8] ),
    .B(\u_UVLO_sync_db.disagree_counter[9] ),
    .C(\u_UVLO_sync_db.disagree_counter[10] ),
    .Y(_0570_));
 sky130_fd_sc_hd__o21a_1 _0893_ (.A1(\u_UVLO_sync_db.disagree_counter[6] ),
    .A2(\u_UVLO_sync_db.disagree_counter[7] ),
    .B1(UVLO_sync),
    .X(_0571_));
 sky130_fd_sc_hd__nand2_1 _0894_ (.A(\u_UVLO_sync_db.disagree_counter[0] ),
    .B(\u_UVLO_sync_db.disagree_counter[1] ),
    .Y(_0572_));
 sky130_fd_sc_hd__a2bb2oi_4 _0895_ (.A1_N(_0359_),
    .A2_N(_0357_),
    .B1(latch_stat_sync),
    .B2(_0335_),
    .Y(_0360_));
 sky130_fd_sc_hd__and4_1 _0896_ (.A(\u_UVLO_sync_db.disagree_counter[0] ),
    .B(\u_UVLO_sync_db.disagree_counter[1] ),
    .C(\u_UVLO_sync_db.disagree_counter[3] ),
    .D(\u_UVLO_sync_db.disagree_counter[2] ),
    .X(_0573_));
 sky130_fd_sc_hd__a21oi_1 _0897_ (.A1(\u_UVLO_sync_db.disagree_counter[6] ),
    .A2(\u_UVLO_sync_db.disagree_counter[7] ),
    .B1(UVLO_sync),
    .Y(_0574_));
 sky130_fd_sc_hd__nor4_1 _0898_ (.A(\u_UVLO_sync_db.disagree_counter[4] ),
    .B(\u_UVLO_sync_db.disagree_counter[5] ),
    .C(_0571_),
    .D(_0573_),
    .Y(_0575_));
 sky130_fd_sc_hd__nor2b_1 _0899_ (.A(UVLO_sync),
    .B_N(\u_UVLO_sync_db.disagree_counter[13] ),
    .Y(_0576_));
 sky130_fd_sc_hd__nor3_1 _0900_ (.A(\u_UVLO_sync_db.disagree_counter[12] ),
    .B(\u_UVLO_sync_db.disagree_counter[11] ),
    .C(_0576_),
    .Y(_0577_));
 sky130_fd_sc_hd__o31a_1 _0901_ (.A1(_0570_),
    .A2(_0574_),
    .A3(_0575_),
    .B1(_0577_),
    .X(_0578_));
 sky130_fd_sc_hd__a21oi_4 _0902_ (.A1(_0343_),
    .A2(UVLO_sync),
    .B1(_0578_),
    .Y(_0579_));
 sky130_fd_sc_hd__nand2_1 _0903_ (.A(\u_UVLO_sync_db.disagree_counter[4] ),
    .B(_0573_),
    .Y(_0580_));
 sky130_fd_sc_hd__nor2_1 _0904_ (.A(_0579_),
    .B(_0580_),
    .Y(_0581_));
 sky130_fd_sc_hd__and2_1 _0905_ (.A(\u_UVLO_sync_db.disagree_counter[5] ),
    .B(_0581_),
    .X(_0582_));
 sky130_fd_sc_hd__o22ai_2 _0906_ (.A1(\u_latch_stat_sync_db.disagree_counter[13] ),
    .A2(_0339_),
    .B1(_0357_),
    .B2(_0359_),
    .Y(_0361_));
 sky130_fd_sc_hd__and3_1 _0907_ (.A(\u_UVLO_sync_db.disagree_counter[6] ),
    .B(\u_UVLO_sync_db.disagree_counter[7] ),
    .C(\u_UVLO_sync_db.disagree_counter[5] ),
    .X(_0583_));
 sky130_fd_sc_hd__nand3_1 _0908_ (.A(\u_UVLO_sync_db.disagree_counter[4] ),
    .B(_0573_),
    .C(_0583_),
    .Y(_0584_));
 sky130_fd_sc_hd__nor3_1 _0909_ (.A(_0570_),
    .B(_0579_),
    .C(_0584_),
    .Y(_0585_));
 sky130_fd_sc_hd__and2_0 _0910_ (.A(\u_UVLO_sync_db.disagree_counter[11] ),
    .B(_0585_),
    .X(_0586_));
 sky130_fd_sc_hd__nand2_1 _0911_ (.A(\u_UVLO_sync_db.disagree_counter[12] ),
    .B(_0586_),
    .Y(_0587_));
 sky130_fd_sc_hd__xnor2_4 _0912_ (.A(UVLO_sync_db),
    .B(UVLO_sync),
    .Y(_0588_));
 sky130_fd_sc_hd__xor2_2 _0913_ (.A(UVLO_sync_db),
    .B(UVLO_sync),
    .X(_0589_));
 sky130_fd_sc_hd__a21oi_1 _0914_ (.A1(_0343_),
    .A2(_0587_),
    .B1(_0588_),
    .Y(_0209_));
 sky130_fd_sc_hd__o22a_1 _0915_ (.A1(UVLO_sync),
    .A2(_0578_),
    .B1(_0579_),
    .B2(UVLO_sync_db),
    .X(_0208_));
 sky130_fd_sc_hd__nand2_1 _0916_ (.A(_0579_),
    .B(_0589_),
    .Y(_0590_));
 sky130_fd_sc_hd__and3_1 _0917_ (.A(\u_latch_stat_sync_db.disagree_counter[4] ),
    .B(_0354_),
    .C(_0361_),
    .X(_0362_));
 sky130_fd_sc_hd__nor2_1 _0918_ (.A(_0579_),
    .B(_0588_),
    .Y(_0591_));
 sky130_fd_sc_hd__nor2_1 _0919_ (.A(\u_UVLO_sync_db.disagree_counter[0] ),
    .B(_0591_),
    .Y(_0592_));
 sky130_fd_sc_hd__a21oi_1 _0920_ (.A1(\u_UVLO_sync_db.disagree_counter[0] ),
    .A2(_0590_),
    .B1(_0592_),
    .Y(_0207_));
 sky130_fd_sc_hd__a21oi_1 _0921_ (.A1(\u_UVLO_sync_db.disagree_counter[0] ),
    .A2(_0590_),
    .B1(\u_UVLO_sync_db.disagree_counter[1] ),
    .Y(_0593_));
 sky130_fd_sc_hd__nor2_1 _0922_ (.A(_0572_),
    .B(_0579_),
    .Y(_0594_));
 sky130_fd_sc_hd__nor3_1 _0923_ (.A(_0588_),
    .B(_0593_),
    .C(_0594_),
    .Y(_0206_));
 sky130_fd_sc_hd__xnor2_1 _0924_ (.A(\u_UVLO_sync_db.disagree_counter[2] ),
    .B(_0594_),
    .Y(_0595_));
 sky130_fd_sc_hd__nor2_1 _0925_ (.A(_0588_),
    .B(_0595_),
    .Y(_0205_));
 sky130_fd_sc_hd__a41oi_1 _0926_ (.A1(\u_UVLO_sync_db.disagree_counter[0] ),
    .A2(\u_UVLO_sync_db.disagree_counter[1] ),
    .A3(\u_UVLO_sync_db.disagree_counter[2] ),
    .A4(_0590_),
    .B1(\u_UVLO_sync_db.disagree_counter[3] ),
    .Y(_0596_));
 sky130_fd_sc_hd__a211oi_1 _0927_ (.A1(_0573_),
    .A2(_0590_),
    .B1(_0596_),
    .C1(_0588_),
    .Y(_0204_));
 sky130_fd_sc_hd__nand3_1 _0928_ (.A(\u_latch_stat_sync_db.disagree_counter[5] ),
    .B(\u_latch_stat_sync_db.disagree_counter[4] ),
    .C(_0354_),
    .Y(_0363_));
 sky130_fd_sc_hd__a21oi_1 _0929_ (.A1(_0573_),
    .A2(_0590_),
    .B1(\u_UVLO_sync_db.disagree_counter[4] ),
    .Y(_0597_));
 sky130_fd_sc_hd__nor3_1 _0930_ (.A(_0581_),
    .B(_0588_),
    .C(_0597_),
    .Y(_0203_));
 sky130_fd_sc_hd__nor2_1 _0931_ (.A(\u_UVLO_sync_db.disagree_counter[5] ),
    .B(_0581_),
    .Y(_0598_));
 sky130_fd_sc_hd__nor3_1 _0932_ (.A(_0582_),
    .B(_0588_),
    .C(_0598_),
    .Y(_0202_));
 sky130_fd_sc_hd__a21oi_1 _0933_ (.A1(\u_UVLO_sync_db.disagree_counter[6] ),
    .A2(_0582_),
    .B1(_0588_),
    .Y(_0599_));
 sky130_fd_sc_hd__o21a_1 _0934_ (.A1(\u_UVLO_sync_db.disagree_counter[6] ),
    .A2(_0582_),
    .B1(_0599_),
    .X(_0201_));
 sky130_fd_sc_hd__a21oi_1 _0935_ (.A1(\u_UVLO_sync_db.disagree_counter[6] ),
    .A2(_0582_),
    .B1(\u_UVLO_sync_db.disagree_counter[7] ),
    .Y(_0600_));
 sky130_fd_sc_hd__a21oi_1 _0936_ (.A1(_0579_),
    .A2(_0589_),
    .B1(_0584_),
    .Y(_0601_));
 sky130_fd_sc_hd__nor3_1 _0937_ (.A(_0588_),
    .B(_0600_),
    .C(_0601_),
    .Y(_0200_));
 sky130_fd_sc_hd__and2_0 _0938_ (.A(\u_UVLO_sync_db.disagree_counter[8] ),
    .B(_0601_),
    .X(_0602_));
 sky130_fd_sc_hd__inv_1 _0939_ (.A(\strike_level[0] ),
    .Y(_0338_));
 sky130_fd_sc_hd__nor2_1 _0940_ (.A(_0360_),
    .B(_0363_),
    .Y(_0364_));
 sky130_fd_sc_hd__o21ai_0 _0941_ (.A1(\u_UVLO_sync_db.disagree_counter[8] ),
    .A2(_0601_),
    .B1(_0589_),
    .Y(_0603_));
 sky130_fd_sc_hd__nor2_1 _0942_ (.A(_0602_),
    .B(_0603_),
    .Y(_0199_));
 sky130_fd_sc_hd__and3_1 _0943_ (.A(\u_UVLO_sync_db.disagree_counter[8] ),
    .B(\u_UVLO_sync_db.disagree_counter[9] ),
    .C(_0601_),
    .X(_0604_));
 sky130_fd_sc_hd__o21ai_0 _0944_ (.A1(\u_UVLO_sync_db.disagree_counter[9] ),
    .A2(_0602_),
    .B1(_0589_),
    .Y(_0605_));
 sky130_fd_sc_hd__nor2_1 _0945_ (.A(_0604_),
    .B(_0605_),
    .Y(_0198_));
 sky130_fd_sc_hd__o21ai_0 _0946_ (.A1(\u_UVLO_sync_db.disagree_counter[10] ),
    .A2(_0604_),
    .B1(_0589_),
    .Y(_0606_));
 sky130_fd_sc_hd__nor2_1 _0947_ (.A(_0585_),
    .B(_0606_),
    .Y(_0197_));
 sky130_fd_sc_hd__o21ai_0 _0948_ (.A1(\u_UVLO_sync_db.disagree_counter[11] ),
    .A2(_0585_),
    .B1(_0589_),
    .Y(_0607_));
 sky130_fd_sc_hd__nor2_1 _0949_ (.A(_0586_),
    .B(_0607_),
    .Y(_0196_));
 sky130_fd_sc_hd__o21ai_0 _0950_ (.A1(\u_UVLO_sync_db.disagree_counter[12] ),
    .A2(_0586_),
    .B1(_0589_),
    .Y(_0608_));
 sky130_fd_sc_hd__nor2_1 _0951_ (.A(_0356_),
    .B(_0363_),
    .Y(_0365_));
 sky130_fd_sc_hd__a21oi_1 _0952_ (.A1(\u_UVLO_sync_db.disagree_counter[12] ),
    .A2(_0586_),
    .B1(_0608_),
    .Y(_0195_));
 sky130_fd_sc_hd__a22o_1 _0953_ (.A1(\u_fault_arbiter.fault_shifter_SS[0] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.cp_delay[4] ),
    .X(_0194_));
 sky130_fd_sc_hd__a22o_1 _0954_ (.A1(\u_fault_arbiter.fault_shifter_SS[1] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[0] ),
    .X(_0193_));
 sky130_fd_sc_hd__a22o_1 _0955_ (.A1(\u_fault_arbiter.fault_shifter_SS[2] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[1] ),
    .X(_0192_));
 sky130_fd_sc_hd__a22o_1 _0956_ (.A1(\u_fault_arbiter.fault_shifter_SS[3] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[2] ),
    .X(_0191_));
 sky130_fd_sc_hd__a22o_1 _0957_ (.A1(\u_fault_arbiter.fault_shifter_SS[4] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[3] ),
    .X(_0190_));
 sky130_fd_sc_hd__a22o_1 _0958_ (.A1(\u_fault_arbiter.fault_shifter_SS[5] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[4] ),
    .X(_0189_));
 sky130_fd_sc_hd__a22o_1 _0959_ (.A1(\u_fault_arbiter.fault_shifter_SS[6] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[5] ),
    .X(_0188_));
 sky130_fd_sc_hd__a22o_1 _0960_ (.A1(\u_fault_arbiter.fault_shifter_SS[7] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[6] ),
    .X(_0187_));
 sky130_fd_sc_hd__a22o_1 _0961_ (.A1(\u_fault_arbiter.fault_shifter_SS[8] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[7] ),
    .X(_0186_));
 sky130_fd_sc_hd__nor3_1 _0962_ (.A(_0356_),
    .B(_0360_),
    .C(_0363_),
    .Y(_0366_));
 sky130_fd_sc_hd__a22o_1 _0963_ (.A1(\u_fault_arbiter.fault_shifter_SS[9] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[8] ),
    .X(_0185_));
 sky130_fd_sc_hd__a22o_1 _0964_ (.A1(\u_fault_arbiter.fault_shifter_SS[10] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[9] ),
    .X(_0184_));
 sky130_fd_sc_hd__a22o_1 _0965_ (.A1(\u_fault_arbiter.fault_shifter_SS[11] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[10] ),
    .X(_0183_));
 sky130_fd_sc_hd__a22o_1 _0966_ (.A1(\u_fault_arbiter.fault_shifter_SS[12] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[11] ),
    .X(_0182_));
 sky130_fd_sc_hd__a22o_1 _0967_ (.A1(\u_fault_arbiter.fault_shifter_SS[13] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[12] ),
    .X(_0181_));
 sky130_fd_sc_hd__a22o_1 _0968_ (.A1(\u_fault_arbiter.fault_shifter_SS[14] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[13] ),
    .X(_0180_));
 sky130_fd_sc_hd__a22o_1 _0969_ (.A1(\u_fault_arbiter.fault_shifter_SS[15] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[14] ),
    .X(_0179_));
 sky130_fd_sc_hd__a22o_1 _0970_ (.A1(\u_fault_arbiter.fault_shifter_SS[16] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[15] ),
    .X(_0178_));
 sky130_fd_sc_hd__a22o_1 _0971_ (.A1(\u_fault_arbiter.fault_shifter_SS[17] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[16] ),
    .X(_0177_));
 sky130_fd_sc_hd__a22o_1 _0972_ (.A1(\u_fault_arbiter.fault_shifter_SS[18] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[17] ),
    .X(_0176_));
 sky130_fd_sc_hd__nor4_1 _0973_ (.A(_0351_),
    .B(_0356_),
    .C(_0360_),
    .D(_0363_),
    .Y(_0367_));
 sky130_fd_sc_hd__a22o_1 _0974_ (.A1(\u_fault_arbiter.fault_shifter_SS[19] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[18] ),
    .X(_0175_));
 sky130_fd_sc_hd__a22o_1 _0975_ (.A1(\u_fault_arbiter.fault_shifter_SS[20] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[19] ),
    .X(_0174_));
 sky130_fd_sc_hd__a22o_1 _0976_ (.A1(\u_fault_arbiter.fault_shifter_SS[21] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[20] ),
    .X(_0173_));
 sky130_fd_sc_hd__a22o_1 _0977_ (.A1(\u_fault_arbiter.fault_shifter_SS[22] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[21] ),
    .X(_0172_));
 sky130_fd_sc_hd__a22o_1 _0978_ (.A1(\u_fault_arbiter.fault_shifter_SS[23] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[22] ),
    .X(_0171_));
 sky130_fd_sc_hd__a22o_1 _0979_ (.A1(\u_fault_arbiter.fault_shifter_SS[24] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[23] ),
    .X(_0170_));
 sky130_fd_sc_hd__a22o_1 _0980_ (.A1(\u_fault_arbiter.fault_shifter_SS[25] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[24] ),
    .X(_0169_));
 sky130_fd_sc_hd__a22o_1 _0981_ (.A1(\u_fault_arbiter.fault_shifter_SS[26] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[25] ),
    .X(_0168_));
 sky130_fd_sc_hd__a22o_1 _0982_ (.A1(\u_fault_arbiter.fault_shifter_SS[27] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[26] ),
    .X(_0167_));
 sky130_fd_sc_hd__a22o_1 _0983_ (.A1(\u_fault_arbiter.fault_shifter_SS[28] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[27] ),
    .X(_0166_));
 sky130_fd_sc_hd__and2_0 _0984_ (.A(\u_latch_stat_sync_db.disagree_counter[11] ),
    .B(_0367_),
    .X(_0368_));
 sky130_fd_sc_hd__a22o_1 _0985_ (.A1(\u_fault_arbiter.fault_shifter_SS[29] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[28] ),
    .X(_0165_));
 sky130_fd_sc_hd__a22o_1 _0986_ (.A1(\u_fault_arbiter.fault_shifter_SS[30] ),
    .A2(_0520_),
    .B1(_0569_),
    .B2(\u_fault_arbiter.fault_shifter_SS[29] ),
    .X(_0164_));
 sky130_fd_sc_hd__o21ai_0 _0987_ (.A1(\u_OTP_sync_db.disagree_counter[0] ),
    .A2(_0563_),
    .B1(_0552_),
    .Y(_0609_));
 sky130_fd_sc_hd__a21oi_1 _0988_ (.A1(\u_OTP_sync_db.disagree_counter[0] ),
    .A2(_0563_),
    .B1(_0609_),
    .Y(_0163_));
 sky130_fd_sc_hd__a21oi_1 _0989_ (.A1(\u_OTP_sync_db.disagree_counter[0] ),
    .A2(_0563_),
    .B1(\u_OTP_sync_db.disagree_counter[1] ),
    .Y(_0610_));
 sky130_fd_sc_hd__nor2_1 _0990_ (.A(_0551_),
    .B(_0563_),
    .Y(_0611_));
 sky130_fd_sc_hd__inv_1 _0991_ (.A(_0611_),
    .Y(_0612_));
 sky130_fd_sc_hd__a311oi_1 _0992_ (.A1(\u_OTP_sync_db.disagree_counter[1] ),
    .A2(\u_OTP_sync_db.disagree_counter[0] ),
    .A3(_0563_),
    .B1(_0610_),
    .C1(_0551_),
    .Y(_0162_));
 sky130_fd_sc_hd__a31oi_1 _0993_ (.A1(\u_OTP_sync_db.disagree_counter[1] ),
    .A2(\u_OTP_sync_db.disagree_counter[0] ),
    .A3(_0612_),
    .B1(\u_OTP_sync_db.disagree_counter[2] ),
    .Y(_0613_));
 sky130_fd_sc_hd__nor2_1 _0994_ (.A(_0555_),
    .B(_0611_),
    .Y(_0614_));
 sky130_fd_sc_hd__a21oi_1 _0995_ (.A1(\u_latch_stat_sync_db.disagree_counter[12] ),
    .A2(_0368_),
    .B1(\u_latch_stat_sync_db.disagree_counter[13] ),
    .Y(_0369_));
 sky130_fd_sc_hd__nor3_1 _0996_ (.A(_0551_),
    .B(_0613_),
    .C(_0614_),
    .Y(_0161_));
 sky130_fd_sc_hd__nor2b_1 _0997_ (.A(_0611_),
    .B_N(_0556_),
    .Y(_0615_));
 sky130_fd_sc_hd__o21ai_0 _0998_ (.A1(\u_OTP_sync_db.disagree_counter[3] ),
    .A2(_0614_),
    .B1(_0552_),
    .Y(_0616_));
 sky130_fd_sc_hd__nor2_1 _0999_ (.A(_0615_),
    .B(_0616_),
    .Y(_0160_));
 sky130_fd_sc_hd__o21ai_0 _1000_ (.A1(\u_OTP_sync_db.disagree_counter[4] ),
    .A2(_0615_),
    .B1(_0552_),
    .Y(_0617_));
 sky130_fd_sc_hd__a21oi_1 _1001_ (.A1(\u_OTP_sync_db.disagree_counter[4] ),
    .A2(_0615_),
    .B1(_0617_),
    .Y(_0159_));
 sky130_fd_sc_hd__a21oi_1 _1002_ (.A1(\u_OTP_sync_db.disagree_counter[4] ),
    .A2(_0615_),
    .B1(\u_OTP_sync_db.disagree_counter[5] ),
    .Y(_0618_));
 sky130_fd_sc_hd__nor3_1 _1003_ (.A(_0551_),
    .B(_0565_),
    .C(_0618_),
    .Y(_0158_));
 sky130_fd_sc_hd__xnor2_1 _1004_ (.A(\u_OTP_sync_db.disagree_counter[6] ),
    .B(_0565_),
    .Y(_0619_));
 sky130_fd_sc_hd__nor2_1 _1005_ (.A(_0551_),
    .B(_0619_),
    .Y(_0157_));
 sky130_fd_sc_hd__xnor2_4 _1006_ (.A(latch_stat_sync_db),
    .B(latch_stat_sync),
    .Y(_0370_));
 sky130_fd_sc_hd__a31oi_1 _1007_ (.A1(\u_OTP_sync_db.disagree_counter[6] ),
    .A2(_0564_),
    .A3(_0612_),
    .B1(\u_OTP_sync_db.disagree_counter[7] ),
    .Y(_0620_));
 sky130_fd_sc_hd__nor2b_1 _1008_ (.A(_0611_),
    .B_N(_0566_),
    .Y(_0621_));
 sky130_fd_sc_hd__nor3_1 _1009_ (.A(_0551_),
    .B(_0620_),
    .C(_0621_),
    .Y(_0156_));
 sky130_fd_sc_hd__nand3_1 _1010_ (.A(\u_OTP_sync_db.disagree_counter[8] ),
    .B(_0563_),
    .C(_0566_),
    .Y(_0622_));
 sky130_fd_sc_hd__o211a_1 _1011_ (.A1(\u_OTP_sync_db.disagree_counter[8] ),
    .A2(_0621_),
    .B1(_0622_),
    .C1(_0552_),
    .X(_0155_));
 sky130_fd_sc_hd__xor2_1 _1012_ (.A(\u_OTP_sync_db.disagree_counter[9] ),
    .B(_0622_),
    .X(_0623_));
 sky130_fd_sc_hd__nor2_1 _1013_ (.A(_0551_),
    .B(_0623_),
    .Y(_0154_));
 sky130_fd_sc_hd__a31oi_1 _1014_ (.A1(\u_OTP_sync_db.disagree_counter[9] ),
    .A2(\u_OTP_sync_db.disagree_counter[8] ),
    .A3(_0621_),
    .B1(\u_OTP_sync_db.disagree_counter[10] ),
    .Y(_0624_));
 sky130_fd_sc_hd__and2_0 _1015_ (.A(_0563_),
    .B(_0567_),
    .X(_0625_));
 sky130_fd_sc_hd__nor3_1 _1016_ (.A(_0551_),
    .B(_0624_),
    .C(_0625_),
    .Y(_0153_));
 sky130_fd_sc_hd__nor2_1 _1017_ (.A(_0369_),
    .B(_0370_),
    .Y(_0230_));
 sky130_fd_sc_hd__o21ai_0 _1018_ (.A1(\u_OTP_sync_db.disagree_counter[11] ),
    .A2(_0625_),
    .B1(_0552_),
    .Y(_0626_));
 sky130_fd_sc_hd__and3_1 _1019_ (.A(\u_OTP_sync_db.disagree_counter[11] ),
    .B(_0563_),
    .C(_0567_),
    .X(_0627_));
 sky130_fd_sc_hd__nor2_1 _1020_ (.A(_0626_),
    .B(_0627_),
    .Y(_0152_));
 sky130_fd_sc_hd__xnor2_1 _1021_ (.A(\u_OTP_sync_db.disagree_counter[12] ),
    .B(_0627_),
    .Y(_0628_));
 sky130_fd_sc_hd__nor2_1 _1022_ (.A(_0551_),
    .B(_0628_),
    .Y(_0151_));
 sky130_fd_sc_hd__a22o_1 _1023_ (.A1(\u_fault_arbiter.cp_delay[4] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[0] ),
    .X(_0150_));
 sky130_fd_sc_hd__a22o_1 _1024_ (.A1(\u_fault_arbiter.fault_shifter_RUN[0] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[1] ),
    .X(_0149_));
 sky130_fd_sc_hd__a22o_1 _1025_ (.A1(\u_fault_arbiter.fault_shifter_RUN[1] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[2] ),
    .X(_0148_));
 sky130_fd_sc_hd__a22o_1 _1026_ (.A1(\u_fault_arbiter.fault_shifter_RUN[2] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[3] ),
    .X(_0147_));
 sky130_fd_sc_hd__a22o_1 _1027_ (.A1(\u_fault_arbiter.fault_shifter_RUN[3] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[4] ),
    .X(_0146_));
 sky130_fd_sc_hd__nor2_1 _1028_ (.A(\u_fault_LED.blink_counter[5] ),
    .B(\u_fault_LED.blink_counter[4] ),
    .Y(_0371_));
 sky130_fd_sc_hd__a22o_1 _1029_ (.A1(\u_fault_arbiter.fault_shifter_RUN[4] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[5] ),
    .X(_0145_));
 sky130_fd_sc_hd__a22o_1 _1030_ (.A1(\u_fault_arbiter.fault_shifter_RUN[5] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[6] ),
    .X(_0144_));
 sky130_fd_sc_hd__a22o_1 _1031_ (.A1(\u_fault_arbiter.fault_shifter_RUN[6] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[7] ),
    .X(_0143_));
 sky130_fd_sc_hd__a22o_1 _1032_ (.A1(\u_fault_arbiter.fault_shifter_RUN[7] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[8] ),
    .X(_0142_));
 sky130_fd_sc_hd__a22o_1 _1033_ (.A1(\u_fault_arbiter.fault_shifter_RUN[8] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[9] ),
    .X(_0141_));
 sky130_fd_sc_hd__a22o_1 _1034_ (.A1(\u_fault_arbiter.fault_shifter_RUN[9] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[10] ),
    .X(_0140_));
 sky130_fd_sc_hd__a22o_1 _1035_ (.A1(\u_fault_arbiter.fault_shifter_RUN[10] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[11] ),
    .X(_0139_));
 sky130_fd_sc_hd__a22o_1 _1036_ (.A1(\u_fault_arbiter.fault_shifter_RUN[11] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[12] ),
    .X(_0138_));
 sky130_fd_sc_hd__a22o_1 _1037_ (.A1(\u_fault_arbiter.fault_shifter_RUN[12] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[13] ),
    .X(_0137_));
 sky130_fd_sc_hd__a22o_1 _1038_ (.A1(\u_fault_arbiter.fault_shifter_RUN[13] ),
    .A2(_0535_),
    .B1(_0536_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[14] ),
    .X(_0136_));
 sky130_fd_sc_hd__nand2_1 _1039_ (.A(\u_fault_LED.blink_counter[20] ),
    .B(_0371_),
    .Y(_0372_));
 sky130_fd_sc_hd__nand2_1 _1040_ (.A(\fault_count_run[0] ),
    .B(_0536_),
    .Y(_0629_));
 sky130_fd_sc_hd__nor2_1 _1041_ (.A(\u_fault_arbiter.cp_delay[4] ),
    .B(_0541_),
    .Y(_0630_));
 sky130_fd_sc_hd__nand2_1 _1042_ (.A(_0535_),
    .B(_0542_),
    .Y(_0631_));
 sky130_fd_sc_hd__o21ai_0 _1043_ (.A1(_0630_),
    .A2(_0631_),
    .B1(_0629_),
    .Y(_0135_));
 sky130_fd_sc_hd__o21ai_0 _1044_ (.A1(_0542_),
    .A2(_0543_),
    .B1(_0535_),
    .Y(_0632_));
 sky130_fd_sc_hd__a21oi_1 _1045_ (.A1(_0542_),
    .A2(_0543_),
    .B1(_0632_),
    .Y(_0633_));
 sky130_fd_sc_hd__a21o_1 _1046_ (.A1(\fault_count_run[1] ),
    .A2(_0536_),
    .B1(_0633_),
    .X(_0134_));
 sky130_fd_sc_hd__nand2_1 _1047_ (.A(_0539_),
    .B(_0544_),
    .Y(_0634_));
 sky130_fd_sc_hd__a32o_1 _1048_ (.A1(_0535_),
    .A2(_0545_),
    .A3(_0634_),
    .B1(_0536_),
    .B2(\fault_count_run[2] ),
    .X(_0133_));
 sky130_fd_sc_hd__nand2_1 _1049_ (.A(\fault_count_run[3] ),
    .B(_0536_),
    .Y(_0635_));
 sky130_fd_sc_hd__clkinv_1 _1050_ (.A(latch_stat_sync),
    .Y(_0339_));
 sky130_fd_sc_hd__nand4b_1 _1051_ (.A_N(\u_fault_LED.blink_counter[8] ),
    .B(\u_fault_LED.blink_counter[7] ),
    .C(\u_fault_LED.blink_counter[6] ),
    .D(\u_fault_LED.blink_counter[9] ),
    .Y(_0373_));
 sky130_fd_sc_hd__nand2b_1 _1052_ (.A_N(\fault_count_run[2] ),
    .B(\fault_count_run[1] ),
    .Y(_0636_));
 sky130_fd_sc_hd__nand3_1 _1053_ (.A(_0545_),
    .B(_0546_),
    .C(_0636_),
    .Y(_0637_));
 sky130_fd_sc_hd__a21oi_1 _1054_ (.A1(_0545_),
    .A2(_0636_),
    .B1(_0546_),
    .Y(_0638_));
 sky130_fd_sc_hd__nand2_1 _1055_ (.A(_0535_),
    .B(_0637_),
    .Y(_0639_));
 sky130_fd_sc_hd__o21ai_0 _1056_ (.A1(_0638_),
    .A2(_0639_),
    .B1(_0635_),
    .Y(_0132_));
 sky130_fd_sc_hd__nand2_1 _1057_ (.A(\fault_count_ss[0] ),
    .B(_0520_),
    .Y(_0640_));
 sky130_fd_sc_hd__nor2_1 _1058_ (.A(\u_fault_arbiter.cp_delay[4] ),
    .B(_0524_),
    .Y(_0641_));
 sky130_fd_sc_hd__nand2_1 _1059_ (.A(_0525_),
    .B(_0569_),
    .Y(_0642_));
 sky130_fd_sc_hd__o21ai_0 _1060_ (.A1(_0641_),
    .A2(_0642_),
    .B1(_0640_),
    .Y(_0131_));
 sky130_fd_sc_hd__o21ai_0 _1061_ (.A1(_0525_),
    .A2(_0526_),
    .B1(_0569_),
    .Y(_0643_));
 sky130_fd_sc_hd__or4b_2 _1062_ (.A(\u_fault_LED.blink_counter[13] ),
    .B(\u_fault_LED.blink_counter[11] ),
    .C(\u_fault_LED.blink_counter[10] ),
    .D_N(\u_fault_LED.blink_counter[12] ),
    .X(_0374_));
 sky130_fd_sc_hd__a21oi_1 _1063_ (.A1(_0525_),
    .A2(_0526_),
    .B1(_0643_),
    .Y(_0644_));
 sky130_fd_sc_hd__a21o_1 _1064_ (.A1(\fault_count_ss[1] ),
    .A2(_0520_),
    .B1(_0644_),
    .X(_0130_));
 sky130_fd_sc_hd__o21ai_0 _1065_ (.A1(_0522_),
    .A2(_0527_),
    .B1(_0569_),
    .Y(_0645_));
 sky130_fd_sc_hd__a21oi_1 _1066_ (.A1(_0522_),
    .A2(_0527_),
    .B1(_0645_),
    .Y(_0646_));
 sky130_fd_sc_hd__a21o_1 _1067_ (.A1(\fault_count_ss[2] ),
    .A2(_0520_),
    .B1(_0646_),
    .X(_0129_));
 sky130_fd_sc_hd__a21oi_1 _1068_ (.A1(\fault_count_ss[1] ),
    .A2(_0347_),
    .B1(_0528_),
    .Y(_0647_));
 sky130_fd_sc_hd__o21ai_0 _1069_ (.A1(_0529_),
    .A2(_0647_),
    .B1(_0569_),
    .Y(_0648_));
 sky130_fd_sc_hd__a21oi_1 _1070_ (.A1(_0529_),
    .A2(_0647_),
    .B1(_0648_),
    .Y(_0649_));
 sky130_fd_sc_hd__a21o_1 _1071_ (.A1(\fault_count_ss[3] ),
    .A2(_0520_),
    .B1(_0649_),
    .X(_0128_));
 sky130_fd_sc_hd__xnor2_1 _1072_ (.A(\fault_count_ss[4] ),
    .B(\fault_count_ss[3] ),
    .Y(_0650_));
 sky130_fd_sc_hd__nand2_1 _1073_ (.A(\u_fault_LED.blink_counter[1] ),
    .B(\u_fault_LED.blink_counter[0] ),
    .Y(_0375_));
 sky130_fd_sc_hd__o21ai_0 _1074_ (.A1(_0530_),
    .A2(_0650_),
    .B1(_0569_),
    .Y(_0651_));
 sky130_fd_sc_hd__a21oi_1 _1075_ (.A1(_0530_),
    .A2(_0650_),
    .B1(_0651_),
    .Y(_0652_));
 sky130_fd_sc_hd__a21o_1 _1076_ (.A1(\fault_count_ss[4] ),
    .A2(_0520_),
    .B1(_0652_),
    .X(_0127_));
 sky130_fd_sc_hd__a21oi_1 _1077_ (.A1(\u_en_from_switch_db.disagree_counter[0] ),
    .A2(_0507_),
    .B1(_0510_),
    .Y(_0653_));
 sky130_fd_sc_hd__o21a_1 _1078_ (.A1(\u_en_from_switch_db.disagree_counter[0] ),
    .A2(_0507_),
    .B1(_0653_),
    .X(_0126_));
 sky130_fd_sc_hd__a21oi_1 _1079_ (.A1(\u_en_from_switch_db.disagree_counter[0] ),
    .A2(_0507_),
    .B1(\u_en_from_switch_db.disagree_counter[1] ),
    .Y(_0654_));
 sky130_fd_sc_hd__and3_1 _1080_ (.A(\u_en_from_switch_db.disagree_counter[1] ),
    .B(\u_en_from_switch_db.disagree_counter[0] ),
    .C(_0507_),
    .X(_0655_));
 sky130_fd_sc_hd__nor3_1 _1081_ (.A(_0510_),
    .B(_0654_),
    .C(_0655_),
    .Y(_0125_));
 sky130_fd_sc_hd__and2_1 _1082_ (.A(_0499_),
    .B(_0507_),
    .X(_0656_));
 sky130_fd_sc_hd__o21ai_0 _1083_ (.A1(\u_en_from_switch_db.disagree_counter[2] ),
    .A2(_0655_),
    .B1(_0511_),
    .Y(_0657_));
 sky130_fd_sc_hd__and4_2 _1084_ (.A(\u_fault_LED.blink_counter[3] ),
    .B(\u_fault_LED.blink_counter[2] ),
    .C(\u_fault_LED.blink_counter[1] ),
    .D(\u_fault_LED.blink_counter[0] ),
    .X(_0376_));
 sky130_fd_sc_hd__nor2_1 _1085_ (.A(_0656_),
    .B(_0657_),
    .Y(_0124_));
 sky130_fd_sc_hd__o21ai_0 _1086_ (.A1(\u_en_from_switch_db.disagree_counter[3] ),
    .A2(_0656_),
    .B1(_0511_),
    .Y(_0658_));
 sky130_fd_sc_hd__a21oi_1 _1087_ (.A1(\u_en_from_switch_db.disagree_counter[3] ),
    .A2(_0656_),
    .B1(_0658_),
    .Y(_0123_));
 sky130_fd_sc_hd__a21oi_1 _1088_ (.A1(\u_en_from_switch_db.disagree_counter[3] ),
    .A2(_0656_),
    .B1(\u_en_from_switch_db.disagree_counter[4] ),
    .Y(_0659_));
 sky130_fd_sc_hd__and3_1 _1089_ (.A(\u_en_from_switch_db.disagree_counter[4] ),
    .B(\u_en_from_switch_db.disagree_counter[3] ),
    .C(_0656_),
    .X(_0660_));
 sky130_fd_sc_hd__nor3_1 _1090_ (.A(_0510_),
    .B(_0659_),
    .C(_0660_),
    .Y(_0122_));
 sky130_fd_sc_hd__a21oi_1 _1091_ (.A1(_0498_),
    .A2(_0656_),
    .B1(_0510_),
    .Y(_0661_));
 sky130_fd_sc_hd__o21a_1 _1092_ (.A1(\u_en_from_switch_db.disagree_counter[5] ),
    .A2(_0660_),
    .B1(_0661_),
    .X(_0121_));
 sky130_fd_sc_hd__nor2_1 _1093_ (.A(\u_en_from_switch_db.disagree_counter[6] ),
    .B(_0507_),
    .Y(_0662_));
 sky130_fd_sc_hd__a21oi_1 _1094_ (.A1(_0500_),
    .A2(_0512_),
    .B1(_0506_),
    .Y(_0663_));
 sky130_fd_sc_hd__nor2_1 _1095_ (.A(\u_fault_LED.blink_counter[19] ),
    .B(\u_fault_LED.blink_counter[18] ),
    .Y(_0377_));
 sky130_fd_sc_hd__nor3_1 _1096_ (.A(_0510_),
    .B(_0662_),
    .C(_0663_),
    .Y(_0120_));
 sky130_fd_sc_hd__nor3_1 _1097_ (.A(_0504_),
    .B(_0505_),
    .C(_0510_),
    .Y(_0664_));
 sky130_fd_sc_hd__nand2_1 _1098_ (.A(_0506_),
    .B(_0511_),
    .Y(_0665_));
 sky130_fd_sc_hd__nor2_1 _1099_ (.A(_0512_),
    .B(_0664_),
    .Y(_0666_));
 sky130_fd_sc_hd__nor2_1 _1100_ (.A(\u_en_from_switch_db.disagree_counter[7] ),
    .B(_0666_),
    .Y(_0667_));
 sky130_fd_sc_hd__nor3b_1 _1101_ (.A(_0664_),
    .B(_0512_),
    .C_N(\u_en_from_switch_db.disagree_counter[7] ),
    .Y(_0668_));
 sky130_fd_sc_hd__nor3_1 _1102_ (.A(_0510_),
    .B(_0667_),
    .C(_0668_),
    .Y(_0119_));
 sky130_fd_sc_hd__nor2_1 _1103_ (.A(\u_en_from_switch_db.disagree_counter[8] ),
    .B(_0668_),
    .Y(_0669_));
 sky130_fd_sc_hd__nor4bb_2 _1104_ (.A(_0664_),
    .B(_0512_),
    .C_N(\u_en_from_switch_db.disagree_counter[7] ),
    .D_N(\u_en_from_switch_db.disagree_counter[8] ),
    .Y(_0670_));
 sky130_fd_sc_hd__nor3_1 _1105_ (.A(_0510_),
    .B(_0669_),
    .C(_0670_),
    .Y(_0118_));
 sky130_fd_sc_hd__nand2_1 _1106_ (.A(\u_fault_LED.blink_counter[17] ),
    .B(\u_fault_LED.blink_counter[16] ),
    .Y(_0378_));
 sky130_fd_sc_hd__nor2_1 _1107_ (.A(\u_en_from_switch_db.disagree_counter[9] ),
    .B(_0670_),
    .Y(_0671_));
 sky130_fd_sc_hd__and2_0 _1108_ (.A(\u_en_from_switch_db.disagree_counter[9] ),
    .B(_0670_),
    .X(_0672_));
 sky130_fd_sc_hd__nor3_1 _1109_ (.A(_0510_),
    .B(_0671_),
    .C(_0672_),
    .Y(_0117_));
 sky130_fd_sc_hd__a21oi_1 _1110_ (.A1(\u_en_from_switch_db.disagree_counter[9] ),
    .A2(_0670_),
    .B1(\u_en_from_switch_db.disagree_counter[10] ),
    .Y(_0673_));
 sky130_fd_sc_hd__a211oi_1 _1111_ (.A1(\u_en_from_switch_db.disagree_counter[10] ),
    .A2(_0672_),
    .B1(_0673_),
    .C1(_0510_),
    .Y(_0116_));
 sky130_fd_sc_hd__a31oi_1 _1112_ (.A1(\u_en_from_switch_db.disagree_counter[9] ),
    .A2(\u_en_from_switch_db.disagree_counter[10] ),
    .A3(_0670_),
    .B1(\u_en_from_switch_db.disagree_counter[11] ),
    .Y(_0674_));
 sky130_fd_sc_hd__nor4b_2 _1113_ (.A(_0506_),
    .B(_0512_),
    .C(_0517_),
    .D_N(_0497_),
    .Y(_0675_));
 sky130_fd_sc_hd__nor3_1 _1114_ (.A(_0510_),
    .B(_0674_),
    .C(_0675_),
    .Y(_0115_));
 sky130_fd_sc_hd__o21ai_0 _1115_ (.A1(\u_en_from_switch_db.disagree_counter[12] ),
    .A2(_0675_),
    .B1(_0511_),
    .Y(_0676_));
 sky130_fd_sc_hd__a21oi_1 _1116_ (.A1(\u_en_from_switch_db.disagree_counter[12] ),
    .A2(_0675_),
    .B1(_0676_),
    .Y(_0114_));
 sky130_fd_sc_hd__nor3_1 _1117_ (.A(\u_fault_LED.blink_counter[15] ),
    .B(\u_fault_LED.blink_counter[14] ),
    .C(_0378_),
    .Y(_0379_));
 sky130_fd_sc_hd__a21oi_1 _1118_ (.A1(\u_en_from_switch_db.disagree_counter[12] ),
    .A2(_0675_),
    .B1(\u_en_from_switch_db.disagree_counter[13] ),
    .Y(_0677_));
 sky130_fd_sc_hd__a21o_1 _1119_ (.A1(_0507_),
    .A2(_0515_),
    .B1(_0510_),
    .X(_0678_));
 sky130_fd_sc_hd__nor2_1 _1120_ (.A(_0677_),
    .B(_0678_),
    .Y(_0113_));
 sky130_fd_sc_hd__a21oi_1 _1121_ (.A1(_0515_),
    .A2(_0665_),
    .B1(\u_en_from_switch_db.disagree_counter[14] ),
    .Y(_0679_));
 sky130_fd_sc_hd__and3_1 _1122_ (.A(\u_en_from_switch_db.disagree_counter[14] ),
    .B(_0505_),
    .C(_0515_),
    .X(_0680_));
 sky130_fd_sc_hd__nor3_1 _1123_ (.A(_0510_),
    .B(_0679_),
    .C(_0680_),
    .Y(_0112_));
 sky130_fd_sc_hd__nor2_1 _1124_ (.A(\u_en_from_switch_db.disagree_counter[15] ),
    .B(_0680_),
    .Y(_0681_));
 sky130_fd_sc_hd__a31o_1 _1125_ (.A1(\u_en_from_switch_db.disagree_counter[15] ),
    .A2(_0507_),
    .A3(_0516_),
    .B1(_0510_),
    .X(_0682_));
 sky130_fd_sc_hd__nor2_1 _1126_ (.A(_0681_),
    .B(_0682_),
    .Y(_0111_));
 sky130_fd_sc_hd__a21oi_1 _1127_ (.A1(\u_en_from_switch_db.disagree_counter[15] ),
    .A2(_0516_),
    .B1(\u_en_from_switch_db.disagree_counter[16] ),
    .Y(_0683_));
 sky130_fd_sc_hd__nand3_1 _1128_ (.A(_0376_),
    .B(_0377_),
    .C(_0379_),
    .Y(_0380_));
 sky130_fd_sc_hd__and4b_1 _1129_ (.A_N(\u_en_from_switch_db.disagree_counter[17] ),
    .B(\u_en_from_switch_db.disagree_counter[16] ),
    .C(\u_en_from_switch_db.disagree_counter[15] ),
    .D(_0516_),
    .X(_0684_));
 sky130_fd_sc_hd__nor3_1 _1130_ (.A(_0510_),
    .B(_0683_),
    .C(_0684_),
    .Y(_0110_));
 sky130_fd_sc_hd__nor3_1 _1131_ (.A(\u_hiccup_timer.cool_counter[0] ),
    .B(_0340_),
    .C(_0482_),
    .Y(_0109_));
 sky130_fd_sc_hd__o21ai_0 _1132_ (.A1(\u_hiccup_timer.cool_counter[0] ),
    .A2(\u_hiccup_timer.cool_counter[1] ),
    .B1(hiccup_active),
    .Y(_0685_));
 sky130_fd_sc_hd__a21oi_1 _1133_ (.A1(\u_hiccup_timer.cool_counter[0] ),
    .A2(\u_hiccup_timer.cool_counter[1] ),
    .B1(_0685_),
    .Y(_0108_));
 sky130_fd_sc_hd__a21oi_1 _1134_ (.A1(\u_hiccup_timer.cool_counter[0] ),
    .A2(\u_hiccup_timer.cool_counter[1] ),
    .B1(\u_hiccup_timer.cool_counter[2] ),
    .Y(_0686_));
 sky130_fd_sc_hd__nor3_1 _1135_ (.A(_0340_),
    .B(_0483_),
    .C(_0686_),
    .Y(_0107_));
 sky130_fd_sc_hd__o21ai_0 _1136_ (.A1(\u_hiccup_timer.cool_counter[3] ),
    .A2(_0483_),
    .B1(hiccup_active),
    .Y(_0687_));
 sky130_fd_sc_hd__nor2_1 _1137_ (.A(_0484_),
    .B(_0687_),
    .Y(_0106_));
 sky130_fd_sc_hd__o21ai_0 _1138_ (.A1(\u_hiccup_timer.cool_counter[4] ),
    .A2(_0484_),
    .B1(hiccup_active),
    .Y(_0688_));
 sky130_fd_sc_hd__nor4_4 _1139_ (.A(_0372_),
    .B(_0373_),
    .C(_0374_),
    .D(_0380_),
    .Y(_0381_));
 sky130_fd_sc_hd__a21oi_1 _1140_ (.A1(\u_hiccup_timer.cool_counter[4] ),
    .A2(_0484_),
    .B1(_0688_),
    .Y(_0105_));
 sky130_fd_sc_hd__a21oi_1 _1141_ (.A1(\u_hiccup_timer.cool_counter[4] ),
    .A2(_0484_),
    .B1(\u_hiccup_timer.cool_counter[5] ),
    .Y(_0689_));
 sky130_fd_sc_hd__nor3_1 _1142_ (.A(_0340_),
    .B(_0485_),
    .C(_0689_),
    .Y(_0104_));
 sky130_fd_sc_hd__o21ai_0 _1143_ (.A1(\u_hiccup_timer.cool_counter[6] ),
    .A2(_0485_),
    .B1(hiccup_active),
    .Y(_0690_));
 sky130_fd_sc_hd__nor2_1 _1144_ (.A(_0486_),
    .B(_0690_),
    .Y(_0103_));
 sky130_fd_sc_hd__nor2_1 _1145_ (.A(_0340_),
    .B(_0487_),
    .Y(_0691_));
 sky130_fd_sc_hd__o21a_1 _1146_ (.A1(\u_hiccup_timer.cool_counter[7] ),
    .A2(_0486_),
    .B1(_0691_),
    .X(_0102_));
 sky130_fd_sc_hd__o21ai_0 _1147_ (.A1(\u_hiccup_timer.cool_counter[8] ),
    .A2(_0487_),
    .B1(hiccup_active),
    .Y(_0692_));
 sky130_fd_sc_hd__nor2_1 _1148_ (.A(_0488_),
    .B(_0692_),
    .Y(_0101_));
 sky130_fd_sc_hd__o21ai_0 _1149_ (.A1(\u_hiccup_timer.cool_counter[9] ),
    .A2(_0488_),
    .B1(hiccup_active),
    .Y(_0693_));
 sky130_fd_sc_hd__xor2_1 _1150_ (.A(\u_fault_LED.blink ),
    .B(_0381_),
    .X(_0229_));
 sky130_fd_sc_hd__a21oi_1 _1151_ (.A1(\u_hiccup_timer.cool_counter[9] ),
    .A2(_0488_),
    .B1(_0693_),
    .Y(_0100_));
 sky130_fd_sc_hd__a21oi_1 _1152_ (.A1(\u_hiccup_timer.cool_counter[9] ),
    .A2(_0488_),
    .B1(\u_hiccup_timer.cool_counter[10] ),
    .Y(_0694_));
 sky130_fd_sc_hd__nor3_1 _1153_ (.A(_0340_),
    .B(_0489_),
    .C(_0694_),
    .Y(_0099_));
 sky130_fd_sc_hd__o21ai_0 _1154_ (.A1(\u_hiccup_timer.cool_counter[11] ),
    .A2(_0489_),
    .B1(hiccup_active),
    .Y(_0695_));
 sky130_fd_sc_hd__nor2_1 _1155_ (.A(_0490_),
    .B(_0695_),
    .Y(_0098_));
 sky130_fd_sc_hd__o21ai_0 _1156_ (.A1(\u_hiccup_timer.cool_counter[12] ),
    .A2(_0490_),
    .B1(hiccup_active),
    .Y(_0696_));
 sky130_fd_sc_hd__a21oi_1 _1157_ (.A1(\u_hiccup_timer.cool_counter[12] ),
    .A2(_0490_),
    .B1(_0696_),
    .Y(_0097_));
 sky130_fd_sc_hd__a21oi_1 _1158_ (.A1(\u_hiccup_timer.cool_counter[12] ),
    .A2(_0490_),
    .B1(\u_hiccup_timer.cool_counter[13] ),
    .Y(_0697_));
 sky130_fd_sc_hd__nor3_1 _1159_ (.A(_0340_),
    .B(_0491_),
    .C(_0697_),
    .Y(_0096_));
 sky130_fd_sc_hd__o21ai_0 _1160_ (.A1(\u_hiccup_timer.cool_counter[14] ),
    .A2(_0491_),
    .B1(hiccup_active),
    .Y(_0698_));
 sky130_fd_sc_hd__clkinv_4 _1161_ (.A(hiccup_active),
    .Y(_0340_));
 sky130_fd_sc_hd__and2_2 _1162_ (.A(run_active),
    .B(PGOOD_comp_sync),
    .X(_0382_));
 sky130_fd_sc_hd__nor2_1 _1163_ (.A(_0492_),
    .B(_0698_),
    .Y(_0095_));
 sky130_fd_sc_hd__o21ai_0 _1164_ (.A1(\u_hiccup_timer.cool_counter[15] ),
    .A2(_0492_),
    .B1(hiccup_active),
    .Y(_0699_));
 sky130_fd_sc_hd__a21oi_1 _1165_ (.A1(\u_hiccup_timer.cool_counter[15] ),
    .A2(_0492_),
    .B1(_0699_),
    .Y(_0094_));
 sky130_fd_sc_hd__a21oi_1 _1166_ (.A1(\u_hiccup_timer.cool_counter[15] ),
    .A2(_0492_),
    .B1(\u_hiccup_timer.cool_counter[16] ),
    .Y(_0700_));
 sky130_fd_sc_hd__nor3_1 _1167_ (.A(_0340_),
    .B(_0493_),
    .C(_0700_),
    .Y(_0093_));
 sky130_fd_sc_hd__o21ai_0 _1168_ (.A1(\u_hiccup_timer.cool_counter[17] ),
    .A2(_0493_),
    .B1(hiccup_active),
    .Y(_0701_));
 sky130_fd_sc_hd__nor2_1 _1169_ (.A(_0494_),
    .B(_0701_),
    .Y(_0092_));
 sky130_fd_sc_hd__o21ai_0 _1170_ (.A1(\u_hiccup_timer.cool_counter[18] ),
    .A2(_0494_),
    .B1(hiccup_active),
    .Y(_0702_));
 sky130_fd_sc_hd__a21oi_1 _1171_ (.A1(\u_hiccup_timer.cool_counter[18] ),
    .A2(_0494_),
    .B1(_0702_),
    .Y(_0091_));
 sky130_fd_sc_hd__o21ai_0 _1172_ (.A1(\u_strike_counter.clean_counter[0] ),
    .A2(_0441_),
    .B1(_0439_),
    .Y(_0703_));
 sky130_fd_sc_hd__nand2_2 _1173_ (.A(run_active),
    .B(PGOOD_comp_sync),
    .Y(_0383_));
 sky130_fd_sc_hd__a21oi_1 _1174_ (.A1(\u_strike_counter.clean_counter[0] ),
    .A2(_0441_),
    .B1(_0703_),
    .Y(_0090_));
 sky130_fd_sc_hd__a21o_1 _1175_ (.A1(\u_strike_counter.clean_counter[0] ),
    .A2(_0441_),
    .B1(\u_strike_counter.clean_counter[1] ),
    .X(_0704_));
 sky130_fd_sc_hd__nand2_1 _1176_ (.A(_0439_),
    .B(_0704_),
    .Y(_0705_));
 sky130_fd_sc_hd__a31oi_1 _1177_ (.A1(\u_strike_counter.clean_counter[1] ),
    .A2(\u_strike_counter.clean_counter[0] ),
    .A3(_0441_),
    .B1(_0705_),
    .Y(_0089_));
 sky130_fd_sc_hd__nand4_2 _1178_ (.A(\u_strike_counter.clean_counter[2] ),
    .B(\u_strike_counter.clean_counter[1] ),
    .C(\u_strike_counter.clean_counter[0] ),
    .D(_0441_),
    .Y(_0706_));
 sky130_fd_sc_hd__a31oi_1 _1179_ (.A1(\u_strike_counter.clean_counter[1] ),
    .A2(\u_strike_counter.clean_counter[0] ),
    .A3(_0441_),
    .B1(\u_strike_counter.clean_counter[2] ),
    .Y(_0707_));
 sky130_fd_sc_hd__nor3b_1 _1180_ (.A(_0707_),
    .B(_0440_),
    .C_N(_0706_),
    .Y(_0088_));
 sky130_fd_sc_hd__and2_0 _1181_ (.A(_0345_),
    .B(_0706_),
    .X(_0708_));
 sky130_fd_sc_hd__nor2_1 _1182_ (.A(_0345_),
    .B(_0706_),
    .Y(_0709_));
 sky130_fd_sc_hd__nor3_1 _1183_ (.A(_0440_),
    .B(_0708_),
    .C(_0709_),
    .Y(_0087_));
 sky130_fd_sc_hd__nor2b_4 _1184_ (.A(Osc_sync),
    .B_N(\u_fault_arbiter.pwm_sync_d ),
    .Y(_0384_));
 sky130_fd_sc_hd__o21ai_0 _1185_ (.A1(\u_strike_counter.clean_counter[4] ),
    .A2(_0709_),
    .B1(_0439_),
    .Y(_0710_));
 sky130_fd_sc_hd__a21oi_1 _1186_ (.A1(\u_strike_counter.clean_counter[4] ),
    .A2(_0709_),
    .B1(_0710_),
    .Y(_0086_));
 sky130_fd_sc_hd__and3_1 _1187_ (.A(\u_strike_counter.clean_counter[4] ),
    .B(\u_strike_counter.clean_counter[5] ),
    .C(_0709_),
    .X(_0711_));
 sky130_fd_sc_hd__a21oi_1 _1188_ (.A1(\u_strike_counter.clean_counter[4] ),
    .A2(_0709_),
    .B1(\u_strike_counter.clean_counter[5] ),
    .Y(_0712_));
 sky130_fd_sc_hd__nor3_1 _1189_ (.A(_0440_),
    .B(_0711_),
    .C(_0712_),
    .Y(_0085_));
 sky130_fd_sc_hd__nor2_1 _1190_ (.A(\u_strike_counter.clean_counter[6] ),
    .B(_0711_),
    .Y(_0713_));
 sky130_fd_sc_hd__nor3_2 _1191_ (.A(_0442_),
    .B(_0444_),
    .C(_0445_),
    .Y(_0714_));
 sky130_fd_sc_hd__nor3_1 _1192_ (.A(_0440_),
    .B(_0713_),
    .C(_0714_),
    .Y(_0084_));
 sky130_fd_sc_hd__o21ai_0 _1193_ (.A1(\u_strike_counter.clean_counter[7] ),
    .A2(_0714_),
    .B1(_0439_),
    .Y(_0715_));
 sky130_fd_sc_hd__a21oi_1 _1194_ (.A1(\u_strike_counter.clean_counter[7] ),
    .A2(_0714_),
    .B1(_0715_),
    .Y(_0083_));
 sky130_fd_sc_hd__nand2b_4 _1195_ (.A_N(Osc_sync),
    .B(\u_fault_arbiter.pwm_sync_d ),
    .Y(_0385_));
 sky130_fd_sc_hd__a21o_1 _1196_ (.A1(\u_strike_counter.clean_counter[7] ),
    .A2(_0714_),
    .B1(\u_strike_counter.clean_counter[8] ),
    .X(_0231_));
 sky130_fd_sc_hd__nand2_1 _1197_ (.A(_0439_),
    .B(_0231_),
    .Y(_0232_));
 sky130_fd_sc_hd__a31oi_1 _1198_ (.A1(\u_strike_counter.clean_counter[7] ),
    .A2(\u_strike_counter.clean_counter[8] ),
    .A3(_0714_),
    .B1(_0232_),
    .Y(_0082_));
 sky130_fd_sc_hd__a31oi_1 _1199_ (.A1(\u_strike_counter.clean_counter[7] ),
    .A2(\u_strike_counter.clean_counter[8] ),
    .A3(_0714_),
    .B1(\u_strike_counter.clean_counter[9] ),
    .Y(_0233_));
 sky130_fd_sc_hd__nor4_1 _1200_ (.A(_0345_),
    .B(_0443_),
    .C(_0444_),
    .D(_0706_),
    .Y(_0234_));
 sky130_fd_sc_hd__nor3_1 _1201_ (.A(_0440_),
    .B(_0233_),
    .C(_0234_),
    .Y(_0081_));
 sky130_fd_sc_hd__nor2_1 _1202_ (.A(\u_strike_counter.clean_counter[10] ),
    .B(_0234_),
    .Y(_0235_));
 sky130_fd_sc_hd__nor3_1 _1203_ (.A(_0440_),
    .B(_0449_),
    .C(_0235_),
    .Y(_0080_));
 sky130_fd_sc_hd__o21ai_0 _1204_ (.A1(\u_strike_counter.clean_counter[11] ),
    .A2(_0449_),
    .B1(_0439_),
    .Y(_0236_));
 sky130_fd_sc_hd__and4_1 _1205_ (.A(\u_strike_counter.clean_counter[10] ),
    .B(\u_strike_counter.clean_counter[11] ),
    .C(_0441_),
    .D(_0446_),
    .X(_0237_));
 sky130_fd_sc_hd__nand2_1 _1206_ (.A(\u_pgood_gen.qualify_counter[0] ),
    .B(\u_pgood_gen.qualify_counter[1] ),
    .Y(_0386_));
 sky130_fd_sc_hd__nor2_1 _1207_ (.A(_0236_),
    .B(_0237_),
    .Y(_0079_));
 sky130_fd_sc_hd__o21ai_0 _1208_ (.A1(\u_strike_counter.clean_counter[12] ),
    .A2(_0237_),
    .B1(_0439_),
    .Y(_0238_));
 sky130_fd_sc_hd__a21oi_1 _1209_ (.A1(\u_strike_counter.clean_counter[12] ),
    .A2(_0237_),
    .B1(_0238_),
    .Y(_0078_));
 sky130_fd_sc_hd__a21oi_1 _1210_ (.A1(\u_strike_counter.clean_counter[12] ),
    .A2(_0237_),
    .B1(\u_strike_counter.clean_counter[13] ),
    .Y(_0239_));
 sky130_fd_sc_hd__nor3_1 _1211_ (.A(_0440_),
    .B(_0451_),
    .C(_0239_),
    .Y(_0077_));
 sky130_fd_sc_hd__o21ai_0 _1212_ (.A1(\u_strike_counter.clean_counter[14] ),
    .A2(_0451_),
    .B1(_0439_),
    .Y(_0240_));
 sky130_fd_sc_hd__a21oi_1 _1213_ (.A1(\u_strike_counter.clean_counter[14] ),
    .A2(_0451_),
    .B1(_0240_),
    .Y(_0076_));
 sky130_fd_sc_hd__a21oi_1 _1214_ (.A1(\u_strike_counter.clean_counter[14] ),
    .A2(_0451_),
    .B1(\u_strike_counter.clean_counter[15] ),
    .Y(_0241_));
 sky130_fd_sc_hd__nor3_1 _1215_ (.A(_0440_),
    .B(_0452_),
    .C(_0241_),
    .Y(_0075_));
 sky130_fd_sc_hd__o21ai_0 _1216_ (.A1(\u_strike_counter.clean_counter[16] ),
    .A2(_0452_),
    .B1(_0439_),
    .Y(_0242_));
 sky130_fd_sc_hd__nand3_1 _1217_ (.A(\u_pgood_gen.qualify_counter[0] ),
    .B(\u_pgood_gen.qualify_counter[1] ),
    .C(\u_pgood_gen.qualify_counter[2] ),
    .Y(_0387_));
 sky130_fd_sc_hd__nor2_1 _1218_ (.A(_0453_),
    .B(_0242_),
    .Y(_0074_));
 sky130_fd_sc_hd__o21ai_0 _1219_ (.A1(\u_strike_counter.clean_counter[17] ),
    .A2(_0453_),
    .B1(_0439_),
    .Y(_0243_));
 sky130_fd_sc_hd__a21oi_1 _1220_ (.A1(\u_strike_counter.clean_counter[17] ),
    .A2(_0453_),
    .B1(_0243_),
    .Y(_0073_));
 sky130_fd_sc_hd__nor2_1 _1221_ (.A(\strike_level[0] ),
    .B(_0428_),
    .Y(_0244_));
 sky130_fd_sc_hd__nor2_1 _1222_ (.A(_0338_),
    .B(_0436_),
    .Y(_0245_));
 sky130_fd_sc_hd__nor2_1 _1223_ (.A(_0244_),
    .B(_0245_),
    .Y(_0072_));
 sky130_fd_sc_hd__a21oi_1 _1224_ (.A1(ss_active),
    .A2(_0384_),
    .B1(\u_soft_start.cycle_counter[0] ),
    .Y(_0246_));
 sky130_fd_sc_hd__a21oi_1 _1225_ (.A1(\u_soft_start.cycle_counter[0] ),
    .A2(_0427_),
    .B1(_0246_),
    .Y(_0071_));
 sky130_fd_sc_hd__a21oi_1 _1226_ (.A1(\u_soft_start.cycle_counter[0] ),
    .A2(_0427_),
    .B1(\u_soft_start.cycle_counter[1] ),
    .Y(_0247_));
 sky130_fd_sc_hd__nand4_1 _1227_ (.A(ss_active),
    .B(\u_soft_start.cycle_counter[1] ),
    .C(\u_soft_start.cycle_counter[0] ),
    .D(_0384_),
    .Y(_0248_));
 sky130_fd_sc_hd__nand4_1 _1228_ (.A(\u_pgood_gen.qualify_counter[0] ),
    .B(\u_pgood_gen.qualify_counter[1] ),
    .C(\u_pgood_gen.qualify_counter[3] ),
    .D(\u_pgood_gen.qualify_counter[2] ),
    .Y(_0388_));
 sky130_fd_sc_hd__nand2_1 _1229_ (.A(_0424_),
    .B(_0248_),
    .Y(_0249_));
 sky130_fd_sc_hd__nor2_1 _1230_ (.A(_0247_),
    .B(_0249_),
    .Y(_0070_));
 sky130_fd_sc_hd__nand3_1 _1231_ (.A(\u_soft_start.cycle_counter[2] ),
    .B(_0424_),
    .C(_0248_),
    .Y(_0250_));
 sky130_fd_sc_hd__o21ai_0 _1232_ (.A1(\u_soft_start.cycle_counter[2] ),
    .A2(_0248_),
    .B1(_0250_),
    .Y(_0069_));
 sky130_fd_sc_hd__a41oi_1 _1233_ (.A1(\u_soft_start.cycle_counter[1] ),
    .A2(\u_soft_start.cycle_counter[0] ),
    .A3(\u_soft_start.cycle_counter[2] ),
    .A4(_0427_),
    .B1(\u_soft_start.cycle_counter[3] ),
    .Y(_0251_));
 sky130_fd_sc_hd__nand3_1 _1234_ (.A(ss_active),
    .B(_0384_),
    .C(_0416_),
    .Y(_0252_));
 sky130_fd_sc_hd__nand2_1 _1235_ (.A(_0424_),
    .B(_0252_),
    .Y(_0253_));
 sky130_fd_sc_hd__nor2_1 _1236_ (.A(_0251_),
    .B(_0253_),
    .Y(_0068_));
 sky130_fd_sc_hd__nand3_1 _1237_ (.A(\u_soft_start.cycle_counter[4] ),
    .B(_0424_),
    .C(_0252_),
    .Y(_0254_));
 sky130_fd_sc_hd__o21ai_0 _1238_ (.A1(\u_soft_start.cycle_counter[4] ),
    .A2(_0252_),
    .B1(_0254_),
    .Y(_0067_));
 sky130_fd_sc_hd__a21oi_1 _1239_ (.A1(_0382_),
    .A2(_0385_),
    .B1(_0388_),
    .Y(_0389_));
 sky130_fd_sc_hd__a31oi_1 _1240_ (.A1(\u_soft_start.cycle_counter[4] ),
    .A2(_0416_),
    .A3(_0427_),
    .B1(\u_soft_start.cycle_counter[5] ),
    .Y(_0255_));
 sky130_fd_sc_hd__nor3_1 _1241_ (.A(_0423_),
    .B(_0426_),
    .C(_0255_),
    .Y(_0066_));
 sky130_fd_sc_hd__o21ai_0 _1242_ (.A1(\max_on_counts[4] ),
    .A2(\max_on_counts[0] ),
    .B1(ss_active),
    .Y(_0256_));
 sky130_fd_sc_hd__nand2_1 _1243_ (.A(_0418_),
    .B(_0256_),
    .Y(_0257_));
 sky130_fd_sc_hd__o21ai_0 _1244_ (.A1(_0337_),
    .A2(_0418_),
    .B1(_0257_),
    .Y(_0065_));
 sky130_fd_sc_hd__a21oi_1 _1245_ (.A1(\max_on_counts[0] ),
    .A2(\max_on_counts[1] ),
    .B1(\max_on_counts[4] ),
    .Y(_0258_));
 sky130_fd_sc_hd__nor2_1 _1246_ (.A(\max_on_counts[1] ),
    .B(_0418_),
    .Y(_0259_));
 sky130_fd_sc_hd__o21ai_0 _1247_ (.A1(\max_on_counts[0] ),
    .A2(\max_on_counts[1] ),
    .B1(_0258_),
    .Y(_0260_));
 sky130_fd_sc_hd__a31oi_1 _1248_ (.A1(ss_active),
    .A2(_0418_),
    .A3(_0260_),
    .B1(_0259_),
    .Y(_0064_));
 sky130_fd_sc_hd__nor2_1 _1249_ (.A(\max_on_counts[2] ),
    .B(_0419_),
    .Y(_0261_));
 sky130_fd_sc_hd__and2_0 _1250_ (.A(\u_pgood_gen.qualify_counter[4] ),
    .B(_0389_),
    .X(_0390_));
 sky130_fd_sc_hd__nor2_1 _1251_ (.A(_0421_),
    .B(_0261_),
    .Y(_0063_));
 sky130_fd_sc_hd__a21oi_1 _1252_ (.A1(_0346_),
    .A2(_0420_),
    .B1(_0422_),
    .Y(_0062_));
 sky130_fd_sc_hd__o21ai_0 _1253_ (.A1(_0348_),
    .A2(_0407_),
    .B1(Osc_sync),
    .Y(_0262_));
 sky130_fd_sc_hd__a21oi_1 _1254_ (.A1(_0348_),
    .A2(_0407_),
    .B1(_0262_),
    .Y(_0061_));
 sky130_fd_sc_hd__o21ai_0 _1255_ (.A1(\u_pwm_mask.run_counter[1] ),
    .A2(_0408_),
    .B1(Osc_sync),
    .Y(_0263_));
 sky130_fd_sc_hd__nor2_1 _1256_ (.A(_0410_),
    .B(_0263_),
    .Y(_0060_));
 sky130_fd_sc_hd__o21ai_0 _1257_ (.A1(\u_pwm_mask.run_counter[2] ),
    .A2(_0410_),
    .B1(Osc_sync),
    .Y(_0264_));
 sky130_fd_sc_hd__nor2_1 _1258_ (.A(_0411_),
    .B(_0264_),
    .Y(_0059_));
 sky130_fd_sc_hd__o21ai_0 _1259_ (.A1(\u_pwm_mask.run_counter[3] ),
    .A2(_0411_),
    .B1(Osc_sync),
    .Y(_0265_));
 sky130_fd_sc_hd__nor2_1 _1260_ (.A(_0412_),
    .B(_0265_),
    .Y(_0058_));
 sky130_fd_sc_hd__and3_1 _1261_ (.A(\u_pgood_gen.qualify_counter[5] ),
    .B(\u_pgood_gen.qualify_counter[4] ),
    .C(_0389_),
    .X(_0391_));
 sky130_fd_sc_hd__nor4bb_1 _1262_ (.A(\u_pgood_gen.qualify_counter[0] ),
    .B(\u_pgood_gen.qualify_counter[3] ),
    .C_N(\u_pgood_gen.qualify_counter[11] ),
    .D_N(\u_pgood_gen.qualify_counter[1] ),
    .Y(_0266_));
 sky130_fd_sc_hd__nor4b_1 _1263_ (.A(\u_pgood_gen.qualify_counter[5] ),
    .B(\u_pgood_gen.qualify_counter[2] ),
    .C(_0395_),
    .D_N(\u_pgood_gen.qualify_counter[8] ),
    .Y(_0267_));
 sky130_fd_sc_hd__nand4_1 _1264_ (.A(\u_pgood_gen.qualify_counter[9] ),
    .B(\u_pgood_gen.qualify_counter[10] ),
    .C(_0266_),
    .D(_0267_),
    .Y(_0268_));
 sky130_fd_sc_hd__a21oi_1 _1265_ (.A1(_0384_),
    .A2(_0268_),
    .B1(\u_pgood_gen.qualify_counter[0] ),
    .Y(_0269_));
 sky130_fd_sc_hd__a211oi_1 _1266_ (.A1(\u_pgood_gen.qualify_counter[0] ),
    .A2(_0384_),
    .B1(_0269_),
    .C1(_0383_),
    .Y(_0057_));
 sky130_fd_sc_hd__a21oi_1 _1267_ (.A1(_0382_),
    .A2(_0385_),
    .B1(_0386_),
    .Y(_0270_));
 sky130_fd_sc_hd__a21oi_1 _1268_ (.A1(\u_pgood_gen.qualify_counter[0] ),
    .A2(_0384_),
    .B1(\u_pgood_gen.qualify_counter[1] ),
    .Y(_0271_));
 sky130_fd_sc_hd__nor3_1 _1269_ (.A(_0383_),
    .B(_0270_),
    .C(_0271_),
    .Y(_0056_));
 sky130_fd_sc_hd__nor2_1 _1270_ (.A(_0385_),
    .B(_0387_),
    .Y(_0272_));
 sky130_fd_sc_hd__o21ai_0 _1271_ (.A1(\u_pgood_gen.qualify_counter[2] ),
    .A2(_0270_),
    .B1(_0382_),
    .Y(_0273_));
 sky130_fd_sc_hd__inv_1 _1272_ (.A(OTP_sync_db),
    .Y(_0341_));
 sky130_fd_sc_hd__and3_1 _1273_ (.A(\u_pgood_gen.qualify_counter[7] ),
    .B(\u_pgood_gen.qualify_counter[6] ),
    .C(_0391_),
    .X(_0392_));
 sky130_fd_sc_hd__nor2_1 _1274_ (.A(_0272_),
    .B(_0273_),
    .Y(_0055_));
 sky130_fd_sc_hd__o21ai_0 _1275_ (.A1(\u_pgood_gen.qualify_counter[3] ),
    .A2(_0272_),
    .B1(_0382_),
    .Y(_0274_));
 sky130_fd_sc_hd__nor2_1 _1276_ (.A(_0389_),
    .B(_0274_),
    .Y(_0054_));
 sky130_fd_sc_hd__o21ai_0 _1277_ (.A1(\u_pgood_gen.qualify_counter[4] ),
    .A2(_0389_),
    .B1(_0382_),
    .Y(_0275_));
 sky130_fd_sc_hd__nor2_1 _1278_ (.A(_0390_),
    .B(_0275_),
    .Y(_0053_));
 sky130_fd_sc_hd__o21ai_0 _1279_ (.A1(\u_pgood_gen.qualify_counter[5] ),
    .A2(_0390_),
    .B1(_0382_),
    .Y(_0276_));
 sky130_fd_sc_hd__nor2_1 _1280_ (.A(_0391_),
    .B(_0276_),
    .Y(_0052_));
 sky130_fd_sc_hd__o21ai_0 _1281_ (.A1(\u_pgood_gen.qualify_counter[6] ),
    .A2(_0391_),
    .B1(_0382_),
    .Y(_0277_));
 sky130_fd_sc_hd__a21oi_1 _1282_ (.A1(\u_pgood_gen.qualify_counter[6] ),
    .A2(_0391_),
    .B1(_0277_),
    .Y(_0051_));
 sky130_fd_sc_hd__a21oi_1 _1283_ (.A1(\u_pgood_gen.qualify_counter[6] ),
    .A2(_0391_),
    .B1(\u_pgood_gen.qualify_counter[7] ),
    .Y(_0278_));
 sky130_fd_sc_hd__and2_1 _1284_ (.A(\u_pgood_gen.qualify_counter[8] ),
    .B(_0392_),
    .X(_0393_));
 sky130_fd_sc_hd__nor3_1 _1285_ (.A(_0383_),
    .B(_0392_),
    .C(_0278_),
    .Y(_0050_));
 sky130_fd_sc_hd__o21ai_0 _1286_ (.A1(\u_pgood_gen.qualify_counter[8] ),
    .A2(_0392_),
    .B1(_0382_),
    .Y(_0279_));
 sky130_fd_sc_hd__nor2_1 _1287_ (.A(_0393_),
    .B(_0279_),
    .Y(_0049_));
 sky130_fd_sc_hd__o21ai_0 _1288_ (.A1(\u_pgood_gen.qualify_counter[9] ),
    .A2(_0393_),
    .B1(_0382_),
    .Y(_0280_));
 sky130_fd_sc_hd__a21oi_1 _1289_ (.A1(\u_pgood_gen.qualify_counter[9] ),
    .A2(_0393_),
    .B1(_0280_),
    .Y(_0048_));
 sky130_fd_sc_hd__a21oi_1 _1290_ (.A1(\u_pgood_gen.qualify_counter[9] ),
    .A2(_0393_),
    .B1(\u_pgood_gen.qualify_counter[10] ),
    .Y(_0281_));
 sky130_fd_sc_hd__nand3_1 _1291_ (.A(\u_pgood_gen.qualify_counter[5] ),
    .B(\u_pgood_gen.qualify_counter[8] ),
    .C(_0384_),
    .Y(_0282_));
 sky130_fd_sc_hd__nor4_1 _1292_ (.A(_0388_),
    .B(_0394_),
    .C(_0395_),
    .D(_0282_),
    .Y(_0283_));
 sky130_fd_sc_hd__nor3_1 _1293_ (.A(_0383_),
    .B(_0281_),
    .C(_0283_),
    .Y(_0047_));
 sky130_fd_sc_hd__nand2b_2 _1294_ (.A_N(_0370_),
    .B(_0360_),
    .Y(_0284_));
 sky130_fd_sc_hd__nand2_1 _1295_ (.A(\u_pgood_gen.qualify_counter[9] ),
    .B(\u_pgood_gen.qualify_counter[10] ),
    .Y(_0394_));
 sky130_fd_sc_hd__nor2_1 _1296_ (.A(_0360_),
    .B(_0370_),
    .Y(_0285_));
 sky130_fd_sc_hd__nor2_1 _1297_ (.A(\u_latch_stat_sync_db.disagree_counter[0] ),
    .B(_0285_),
    .Y(_0286_));
 sky130_fd_sc_hd__a21oi_1 _1298_ (.A1(\u_latch_stat_sync_db.disagree_counter[0] ),
    .A2(_0284_),
    .B1(_0286_),
    .Y(_0046_));
 sky130_fd_sc_hd__a21oi_1 _1299_ (.A1(\u_latch_stat_sync_db.disagree_counter[0] ),
    .A2(_0284_),
    .B1(\u_latch_stat_sync_db.disagree_counter[1] ),
    .Y(_0287_));
 sky130_fd_sc_hd__and3_1 _1300_ (.A(\u_latch_stat_sync_db.disagree_counter[0] ),
    .B(\u_latch_stat_sync_db.disagree_counter[1] ),
    .C(_0361_),
    .X(_0288_));
 sky130_fd_sc_hd__nor3_1 _1301_ (.A(_0370_),
    .B(_0287_),
    .C(_0288_),
    .Y(_0045_));
 sky130_fd_sc_hd__nor2_1 _1302_ (.A(\u_latch_stat_sync_db.disagree_counter[2] ),
    .B(_0288_),
    .Y(_0289_));
 sky130_fd_sc_hd__a211oi_1 _1303_ (.A1(_0353_),
    .A2(_0361_),
    .B1(_0370_),
    .C1(_0289_),
    .Y(_0044_));
 sky130_fd_sc_hd__a21oi_1 _1304_ (.A1(_0353_),
    .A2(_0284_),
    .B1(\u_latch_stat_sync_db.disagree_counter[3] ),
    .Y(_0290_));
 sky130_fd_sc_hd__a211oi_1 _1305_ (.A1(_0354_),
    .A2(_0361_),
    .B1(_0370_),
    .C1(_0290_),
    .Y(_0043_));
 sky130_fd_sc_hd__nand3_1 _1306_ (.A(\u_pgood_gen.qualify_counter[7] ),
    .B(\u_pgood_gen.qualify_counter[4] ),
    .C(\u_pgood_gen.qualify_counter[6] ),
    .Y(_0395_));
 sky130_fd_sc_hd__a21oi_1 _1307_ (.A1(_0354_),
    .A2(_0284_),
    .B1(\u_latch_stat_sync_db.disagree_counter[4] ),
    .Y(_0291_));
 sky130_fd_sc_hd__nor3_1 _1308_ (.A(_0362_),
    .B(_0370_),
    .C(_0291_),
    .Y(_0042_));
 sky130_fd_sc_hd__nor2_1 _1309_ (.A(\u_latch_stat_sync_db.disagree_counter[5] ),
    .B(_0362_),
    .Y(_0292_));
 sky130_fd_sc_hd__nor3_1 _1310_ (.A(_0364_),
    .B(_0370_),
    .C(_0292_),
    .Y(_0041_));
 sky130_fd_sc_hd__a21oi_1 _1311_ (.A1(\u_latch_stat_sync_db.disagree_counter[6] ),
    .A2(_0364_),
    .B1(_0370_),
    .Y(_0293_));
 sky130_fd_sc_hd__o21a_1 _1312_ (.A1(\u_latch_stat_sync_db.disagree_counter[6] ),
    .A2(_0364_),
    .B1(_0293_),
    .X(_0040_));
 sky130_fd_sc_hd__a21oi_1 _1313_ (.A1(\u_latch_stat_sync_db.disagree_counter[6] ),
    .A2(_0364_),
    .B1(\u_latch_stat_sync_db.disagree_counter[7] ),
    .Y(_0294_));
 sky130_fd_sc_hd__nor3_1 _1314_ (.A(_0366_),
    .B(_0370_),
    .C(_0294_),
    .Y(_0039_));
 sky130_fd_sc_hd__nor2_1 _1315_ (.A(\u_latch_stat_sync_db.disagree_counter[8] ),
    .B(_0366_),
    .Y(_0295_));
 sky130_fd_sc_hd__a311oi_1 _1316_ (.A1(\u_latch_stat_sync_db.disagree_counter[8] ),
    .A2(_0365_),
    .A3(_0284_),
    .B1(_0295_),
    .C1(_0370_),
    .Y(_0038_));
 sky130_fd_sc_hd__a31oi_1 _1317_ (.A1(\u_pgood_gen.qualify_counter[9] ),
    .A2(\u_pgood_gen.qualify_counter[10] ),
    .A3(_0393_),
    .B1(\u_pgood_gen.qualify_counter[11] ),
    .Y(_0396_));
 sky130_fd_sc_hd__a31oi_1 _1318_ (.A1(\u_latch_stat_sync_db.disagree_counter[8] ),
    .A2(_0365_),
    .A3(_0284_),
    .B1(\u_latch_stat_sync_db.disagree_counter[9] ),
    .Y(_0296_));
 sky130_fd_sc_hd__and4_1 _1319_ (.A(\u_latch_stat_sync_db.disagree_counter[8] ),
    .B(\u_latch_stat_sync_db.disagree_counter[9] ),
    .C(_0365_),
    .D(_0284_),
    .X(_0297_));
 sky130_fd_sc_hd__nor3_1 _1320_ (.A(_0370_),
    .B(_0296_),
    .C(_0297_),
    .Y(_0037_));
 sky130_fd_sc_hd__nor2_1 _1321_ (.A(\u_latch_stat_sync_db.disagree_counter[10] ),
    .B(_0297_),
    .Y(_0298_));
 sky130_fd_sc_hd__nor3_1 _1322_ (.A(_0367_),
    .B(_0370_),
    .C(_0298_),
    .Y(_0036_));
 sky130_fd_sc_hd__nor2_1 _1323_ (.A(\u_latch_stat_sync_db.disagree_counter[11] ),
    .B(_0367_),
    .Y(_0299_));
 sky130_fd_sc_hd__nor3_1 _1324_ (.A(_0368_),
    .B(_0370_),
    .C(_0299_),
    .Y(_0035_));
 sky130_fd_sc_hd__nor2_1 _1325_ (.A(\u_latch_stat_sync_db.disagree_counter[12] ),
    .B(_0368_),
    .Y(_0300_));
 sky130_fd_sc_hd__a211oi_1 _1326_ (.A1(\u_latch_stat_sync_db.disagree_counter[12] ),
    .A2(_0368_),
    .B1(_0370_),
    .C1(_0300_),
    .Y(_0034_));
 sky130_fd_sc_hd__nor2_1 _1327_ (.A(latch_out),
    .B(latch_stat_sync_db),
    .Y(_0301_));
 sky130_fd_sc_hd__a41o_1 _1328_ (.A1(\u_pgood_gen.qualify_counter[9] ),
    .A2(\u_pgood_gen.qualify_counter[11] ),
    .A3(\u_pgood_gen.qualify_counter[10] ),
    .A4(_0393_),
    .B1(_0383_),
    .X(_0397_));
 sky130_fd_sc_hd__nor2_1 _1329_ (.A(UVLO_sync_db),
    .B(OTP_sync_db),
    .Y(_0302_));
 sky130_fd_sc_hd__and3_1 _1330_ (.A(_0424_),
    .B(_0301_),
    .C(_0302_),
    .X(_0004_));
 sky130_fd_sc_hd__nand3_2 _1331_ (.A(en_from_switch_sync_db),
    .B(_0301_),
    .C(_0302_),
    .Y(_0303_));
 sky130_fd_sc_hd__inv_1 _1332_ (.A(_0303_),
    .Y(_0304_));
 sky130_fd_sc_hd__nor2_1 _1333_ (.A(_0423_),
    .B(_0303_),
    .Y(En));
 sky130_fd_sc_hd__and2_0 _1334_ (.A(\u_fault_arbiter.cp_delay[2] ),
    .B(_0424_),
    .X(_0030_));
 sky130_fd_sc_hd__and2_0 _1335_ (.A(\u_fault_arbiter.cp_delay[1] ),
    .B(_0424_),
    .X(_0029_));
 sky130_fd_sc_hd__and2_0 _1336_ (.A(\u_fault_arbiter.cp_delay[0] ),
    .B(_0424_),
    .X(_0028_));
 sky130_fd_sc_hd__nand2_1 _1337_ (.A(\u_fault_LED.blink_counter[4] ),
    .B(_0376_),
    .Y(_0305_));
 sky130_fd_sc_hd__and4_1 _1338_ (.A(\u_fault_LED.blink_counter[6] ),
    .B(\u_fault_LED.blink_counter[5] ),
    .C(\u_fault_LED.blink_counter[4] ),
    .D(_0376_),
    .X(_0306_));
 sky130_fd_sc_hd__nor2_1 _1339_ (.A(_0396_),
    .B(_0397_),
    .Y(_0228_));
 sky130_fd_sc_hd__and2_0 _1340_ (.A(\u_fault_LED.blink_counter[7] ),
    .B(_0306_),
    .X(_0307_));
 sky130_fd_sc_hd__and4_1 _1341_ (.A(\u_fault_LED.blink_counter[9] ),
    .B(\u_fault_LED.blink_counter[8] ),
    .C(\u_fault_LED.blink_counter[7] ),
    .D(_0306_),
    .X(_0308_));
 sky130_fd_sc_hd__and3_1 _1342_ (.A(\u_fault_LED.blink_counter[11] ),
    .B(\u_fault_LED.blink_counter[10] ),
    .C(_0308_),
    .X(_0309_));
 sky130_fd_sc_hd__and4_1 _1343_ (.A(\u_fault_LED.blink_counter[12] ),
    .B(\u_fault_LED.blink_counter[11] ),
    .C(\u_fault_LED.blink_counter[10] ),
    .D(_0308_),
    .X(_0310_));
 sky130_fd_sc_hd__nand2_1 _1344_ (.A(\u_fault_LED.blink_counter[13] ),
    .B(_0310_),
    .Y(_0311_));
 sky130_fd_sc_hd__and4_1 _1345_ (.A(\u_fault_LED.blink_counter[15] ),
    .B(\u_fault_LED.blink_counter[14] ),
    .C(\u_fault_LED.blink_counter[13] ),
    .D(_0310_),
    .X(_0312_));
 sky130_fd_sc_hd__and2_0 _1346_ (.A(\u_fault_LED.blink_counter[16] ),
    .B(_0312_),
    .X(_0313_));
 sky130_fd_sc_hd__nand2_1 _1347_ (.A(\u_fault_LED.blink_counter[17] ),
    .B(_0313_),
    .Y(_0314_));
 sky130_fd_sc_hd__nand4_1 _1348_ (.A(\u_fault_LED.blink_counter[18] ),
    .B(\u_fault_LED.blink_counter[17] ),
    .C(\u_fault_LED.blink_counter[16] ),
    .D(_0312_),
    .Y(_0315_));
 sky130_fd_sc_hd__xnor2_1 _1349_ (.A(\u_fault_LED.blink_counter[19] ),
    .B(_0315_),
    .Y(_0016_));
 sky130_fd_sc_hd__nor2b_1 _1350_ (.A(\u_pwm_mask.run_counter[4] ),
    .B_N(\max_on_counts[4] ),
    .Y(_0398_));
 sky130_fd_sc_hd__xnor2_1 _1351_ (.A(\u_fault_LED.blink_counter[18] ),
    .B(_0314_),
    .Y(_0015_));
 sky130_fd_sc_hd__nor2_1 _1352_ (.A(\u_fault_LED.blink_counter[17] ),
    .B(_0313_),
    .Y(_0316_));
 sky130_fd_sc_hd__a211oi_1 _1353_ (.A1(\u_fault_LED.blink_counter[17] ),
    .A2(_0313_),
    .B1(_0316_),
    .C1(_0381_),
    .Y(_0014_));
 sky130_fd_sc_hd__nor2_1 _1354_ (.A(\u_fault_LED.blink_counter[16] ),
    .B(_0312_),
    .Y(_0317_));
 sky130_fd_sc_hd__nor3_1 _1355_ (.A(_0381_),
    .B(_0313_),
    .C(_0317_),
    .Y(_0013_));
 sky130_fd_sc_hd__a31oi_1 _1356_ (.A1(\u_fault_LED.blink_counter[14] ),
    .A2(\u_fault_LED.blink_counter[13] ),
    .A3(_0310_),
    .B1(\u_fault_LED.blink_counter[15] ),
    .Y(_0318_));
 sky130_fd_sc_hd__nor2_1 _1357_ (.A(_0312_),
    .B(_0318_),
    .Y(_0012_));
 sky130_fd_sc_hd__xnor2_1 _1358_ (.A(\u_fault_LED.blink_counter[14] ),
    .B(_0311_),
    .Y(_0011_));
 sky130_fd_sc_hd__xor2_1 _1359_ (.A(\u_fault_LED.blink_counter[13] ),
    .B(_0310_),
    .X(_0010_));
 sky130_fd_sc_hd__nor2_1 _1360_ (.A(\u_fault_LED.blink_counter[12] ),
    .B(_0309_),
    .Y(_0319_));
 sky130_fd_sc_hd__nor2b_1 _1361_ (.A(\max_on_counts[2] ),
    .B_N(\u_pwm_mask.run_counter[2] ),
    .Y(_0399_));
 sky130_fd_sc_hd__nor3_1 _1362_ (.A(_0381_),
    .B(_0310_),
    .C(_0319_),
    .Y(_0009_));
 sky130_fd_sc_hd__a21oi_1 _1363_ (.A1(\u_fault_LED.blink_counter[10] ),
    .A2(_0308_),
    .B1(\u_fault_LED.blink_counter[11] ),
    .Y(_0320_));
 sky130_fd_sc_hd__nor2_1 _1364_ (.A(_0309_),
    .B(_0320_),
    .Y(_0008_));
 sky130_fd_sc_hd__xor2_1 _1365_ (.A(\u_fault_LED.blink_counter[10] ),
    .B(_0308_),
    .X(_0007_));
 sky130_fd_sc_hd__a21oi_1 _1366_ (.A1(\u_fault_LED.blink_counter[8] ),
    .A2(_0307_),
    .B1(\u_fault_LED.blink_counter[9] ),
    .Y(_0321_));
 sky130_fd_sc_hd__nor3_1 _1367_ (.A(_0381_),
    .B(_0308_),
    .C(_0321_),
    .Y(_0026_));
 sky130_fd_sc_hd__xor2_1 _1368_ (.A(\u_fault_LED.blink_counter[8] ),
    .B(_0307_),
    .X(_0025_));
 sky130_fd_sc_hd__nor2_1 _1369_ (.A(\u_fault_LED.blink_counter[7] ),
    .B(_0306_),
    .Y(_0322_));
 sky130_fd_sc_hd__nor3_1 _1370_ (.A(_0381_),
    .B(_0307_),
    .C(_0322_),
    .Y(_0024_));
 sky130_fd_sc_hd__a31oi_1 _1371_ (.A1(\u_fault_LED.blink_counter[5] ),
    .A2(\u_fault_LED.blink_counter[4] ),
    .A3(_0376_),
    .B1(\u_fault_LED.blink_counter[6] ),
    .Y(_0323_));
 sky130_fd_sc_hd__nand2b_1 _1372_ (.A_N(\max_on_counts[3] ),
    .B(\u_pwm_mask.run_counter[3] ),
    .Y(_0400_));
 sky130_fd_sc_hd__nor3_1 _1373_ (.A(_0381_),
    .B(_0306_),
    .C(_0323_),
    .Y(_0023_));
 sky130_fd_sc_hd__xnor2_1 _1374_ (.A(\u_fault_LED.blink_counter[5] ),
    .B(_0305_),
    .Y(_0022_));
 sky130_fd_sc_hd__xnor2_1 _1375_ (.A(\u_fault_LED.blink_counter[4] ),
    .B(_0376_),
    .Y(_0324_));
 sky130_fd_sc_hd__nor2_1 _1376_ (.A(_0381_),
    .B(_0324_),
    .Y(_0021_));
 sky130_fd_sc_hd__a31oi_1 _1377_ (.A1(\u_fault_LED.blink_counter[2] ),
    .A2(\u_fault_LED.blink_counter[1] ),
    .A3(\u_fault_LED.blink_counter[0] ),
    .B1(\u_fault_LED.blink_counter[3] ),
    .Y(_0325_));
 sky130_fd_sc_hd__nor2_1 _1378_ (.A(_0376_),
    .B(_0325_),
    .Y(_0020_));
 sky130_fd_sc_hd__xnor2_1 _1379_ (.A(\u_fault_LED.blink_counter[2] ),
    .B(_0375_),
    .Y(_0019_));
 sky130_fd_sc_hd__xor2_1 _1380_ (.A(\u_fault_LED.blink_counter[1] ),
    .B(\u_fault_LED.blink_counter[0] ),
    .X(_0017_));
 sky130_fd_sc_hd__a21oi_1 _1381_ (.A1(hiccup_done),
    .A2(hiccup_active),
    .B1(\u_supervisor.state[0] ),
    .Y(_0326_));
 sky130_fd_sc_hd__nand2_1 _1382_ (.A(ss_active),
    .B(_0304_),
    .Y(_0327_));
 sky130_fd_sc_hd__clkinvlp_4 _1383_ (.A(run_active),
    .Y(_0342_));
 sky130_fd_sc_hd__nor2b_1 _1384_ (.A(\max_on_counts[1] ),
    .B_N(\u_pwm_mask.run_counter[1] ),
    .Y(_0401_));
 sky130_fd_sc_hd__a31o_1 _1385_ (.A1(\fault_count_ss[2] ),
    .A2(\fault_count_ss[4] ),
    .A3(\fault_count_ss[3] ),
    .B1(\fault_count_ss[5] ),
    .X(_0328_));
 sky130_fd_sc_hd__o32ai_1 _1386_ (.A1(SS_done),
    .A2(_0327_),
    .A3(_0328_),
    .B1(_0303_),
    .B2(_0326_),
    .Y(_0002_));
 sky130_fd_sc_hd__o32ai_1 _1387_ (.A1(_0336_),
    .A2(_0327_),
    .A3(_0328_),
    .B1(_0440_),
    .B2(_0303_),
    .Y(_0001_));
 sky130_fd_sc_hd__nor3_1 _1388_ (.A(hiccup_active),
    .B(\u_supervisor.state[0] ),
    .C(_0424_),
    .Y(_0329_));
 sky130_fd_sc_hd__nor2_1 _1389_ (.A(_0304_),
    .B(_0329_),
    .Y(_0000_));
 sky130_fd_sc_hd__o22ai_1 _1390_ (.A1(hiccup_done),
    .A2(_0340_),
    .B1(_0342_),
    .B2(_0438_),
    .Y(_0330_));
 sky130_fd_sc_hd__a21oi_1 _1391_ (.A1(ss_active),
    .A2(_0328_),
    .B1(_0330_),
    .Y(_0331_));
 sky130_fd_sc_hd__nor2_1 _1392_ (.A(_0303_),
    .B(_0331_),
    .Y(_0003_));
 sky130_fd_sc_hd__and2_0 _1393_ (.A(\u_fault_arbiter.cp_delay[3] ),
    .B(_0424_),
    .X(_0031_));
 sky130_fd_sc_hd__and2_0 _1394_ (.A(CP_sync),
    .B(_0424_),
    .X(_0027_));
 sky130_fd_sc_hd__nand2b_1 _1395_ (.A_N(\u_pwm_mask.run_counter[1] ),
    .B(\max_on_counts[1] ),
    .Y(_0402_));
 sky130_fd_sc_hd__and2_0 _1396_ (.A(Osc_sync),
    .B(\u_pwm_mask.pulse_allowed ),
    .X(_0033_));
 sky130_fd_sc_hd__nand2_1 _1397_ (.A(Osc_sync),
    .B(_0407_),
    .Y(_0032_));
 sky130_fd_sc_hd__o21ai_1 _1398_ (.A1(\strike_level[1] ),
    .A2(\strike_level[0] ),
    .B1(\u_fault_LED.blink ),
    .Y(_0332_));
 sky130_fd_sc_hd__nand2_1 _1399_ (.A(_0301_),
    .B(_0332_),
    .Y(_0005_));
 sky130_fd_sc_hd__o21ai_0 _1400_ (.A1(_0350_),
    .A2(_0315_),
    .B1(\u_fault_LED.blink_counter[20] ),
    .Y(_0333_));
 sky130_fd_sc_hd__or3_1 _1401_ (.A(_0350_),
    .B(\u_fault_LED.blink_counter[20] ),
    .C(_0315_),
    .X(_0334_));
 sky130_fd_sc_hd__a21oi_1 _1402_ (.A1(_0333_),
    .A2(_0334_),
    .B1(_0381_),
    .Y(_0018_));
 sky130_fd_sc_hd__nor2_1 _1403_ (.A(_0383_),
    .B(_0268_),
    .Y(PGOOD));
 sky130_fd_sc_hd__o311a_1 _1404_ (.A1(_0337_),
    .A2(\u_pwm_mask.run_counter[0] ),
    .A3(_0401_),
    .B1(_0402_),
    .C1(_0400_),
    .X(_0403_));
 sky130_fd_sc_hd__nand2b_1 _1405_ (.A_N(\u_pwm_mask.run_counter[2] ),
    .B(\max_on_counts[2] ),
    .Y(_0404_));
 sky130_fd_sc_hd__o221ai_4 _1406_ (.A1(_0346_),
    .A2(\u_pwm_mask.run_counter[3] ),
    .B1(_0399_),
    .B2(_0403_),
    .C1(_0404_),
    .Y(_0405_));
 sky130_fd_sc_hd__nand2b_1 _1407_ (.A_N(\max_on_counts[4] ),
    .B(\u_pwm_mask.run_counter[4] ),
    .Y(_0406_));
 sky130_fd_sc_hd__a31oi_4 _1408_ (.A1(_0400_),
    .A2(_0405_),
    .A3(_0406_),
    .B1(_0398_),
    .Y(_0407_));
 sky130_fd_sc_hd__nor2_1 _1409_ (.A(_0348_),
    .B(_0407_),
    .Y(_0408_));
 sky130_fd_sc_hd__nand2_1 _1410_ (.A(\u_pwm_mask.run_counter[0] ),
    .B(\u_pwm_mask.run_counter[1] ),
    .Y(_0409_));
 sky130_fd_sc_hd__nor2_1 _1411_ (.A(_0407_),
    .B(_0409_),
    .Y(_0410_));
 sky130_fd_sc_hd__inv_1 _1412_ (.A(\u_UVLO_sync_db.disagree_counter[13] ),
    .Y(_0343_));
 sky130_fd_sc_hd__and2_0 _1413_ (.A(\u_pwm_mask.run_counter[2] ),
    .B(_0410_),
    .X(_0411_));
 sky130_fd_sc_hd__and3_1 _1414_ (.A(\u_pwm_mask.run_counter[3] ),
    .B(\u_pwm_mask.run_counter[2] ),
    .C(_0410_),
    .X(_0412_));
 sky130_fd_sc_hd__o21a_1 _1415_ (.A1(\u_pwm_mask.run_counter[4] ),
    .A2(_0412_),
    .B1(Osc_sync),
    .X(_0227_));
 sky130_fd_sc_hd__nand2b_1 _1416_ (.A_N(\max_on_counts[4] ),
    .B(ss_active),
    .Y(_0413_));
 sky130_fd_sc_hd__nor2_1 _1417_ (.A(ss_active),
    .B(_0342_),
    .Y(_0414_));
 sky130_fd_sc_hd__o21ai_2 _1418_ (.A1(ss_active),
    .A2(_0342_),
    .B1(_0413_),
    .Y(_0415_));
 sky130_fd_sc_hd__and4_1 _1419_ (.A(\u_soft_start.cycle_counter[3] ),
    .B(\u_soft_start.cycle_counter[1] ),
    .C(\u_soft_start.cycle_counter[0] ),
    .D(\u_soft_start.cycle_counter[2] ),
    .X(_0416_));
 sky130_fd_sc_hd__nand3_2 _1420_ (.A(\u_soft_start.cycle_counter[4] ),
    .B(\u_soft_start.cycle_counter[5] ),
    .C(_0416_),
    .Y(_0417_));
 sky130_fd_sc_hd__o41ai_4 _1421_ (.A1(\u_soft_start.cycle_counter[6] ),
    .A2(_0385_),
    .A3(_0414_),
    .A4(_0417_),
    .B1(_0415_),
    .Y(_0418_));
 sky130_fd_sc_hd__and3_1 _1422_ (.A(\max_on_counts[0] ),
    .B(\max_on_counts[1] ),
    .C(_0418_),
    .X(_0419_));
 sky130_fd_sc_hd__inv_1 _1423_ (.A(\u_OTP_sync_db.disagree_counter[13] ),
    .Y(_0344_));
 sky130_fd_sc_hd__nand2_1 _1424_ (.A(\max_on_counts[2] ),
    .B(_0419_),
    .Y(_0420_));
 sky130_fd_sc_hd__nand2_1 _1425_ (.A(_0415_),
    .B(_0420_),
    .Y(_0421_));
 sky130_fd_sc_hd__o21a_1 _1426_ (.A1(\max_on_counts[3] ),
    .A2(_0413_),
    .B1(_0421_),
    .X(_0422_));
 sky130_fd_sc_hd__mux2_1 _1427_ (.A0(SS_done),
    .A1(ss_active),
    .S(_0422_),
    .X(_0226_));
 sky130_fd_sc_hd__a22o_1 _1428_ (.A1(\max_on_counts[4] ),
    .A2(_0414_),
    .B1(_0422_),
    .B2(ss_active),
    .X(_0225_));
 sky130_fd_sc_hd__nor2_8 _1429_ (.A(ss_active),
    .B(run_active),
    .Y(_0423_));
 sky130_fd_sc_hd__or2_4 _1430_ (.A(ss_active),
    .B(run_active),
    .X(_0424_));
 sky130_fd_sc_hd__nand2_1 _1431_ (.A(ss_active),
    .B(_0384_),
    .Y(_0425_));
 sky130_fd_sc_hd__nor2_1 _1432_ (.A(_0417_),
    .B(_0425_),
    .Y(_0426_));
 sky130_fd_sc_hd__nand2_1 _1433_ (.A(_0424_),
    .B(_0425_),
    .Y(_0427_));
 sky130_fd_sc_hd__dfstp_2 _1434_ (.D(_0208_),
    .Q(UVLO_sync_db),
    .SET_B(net4),
    .CLK(clknet_5_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1435_ (.D(_0207_),
    .Q(\u_UVLO_sync_db.disagree_counter[0] ),
    .RESET_B(net4),
    .CLK(clknet_5_9__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1436_ (.D(_0206_),
    .Q(\u_UVLO_sync_db.disagree_counter[1] ),
    .RESET_B(net4),
    .CLK(clknet_5_9__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1437_ (.D(_0205_),
    .Q(\u_UVLO_sync_db.disagree_counter[2] ),
    .RESET_B(net4),
    .CLK(clknet_5_9__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1438_ (.D(_0204_),
    .Q(\u_UVLO_sync_db.disagree_counter[3] ),
    .RESET_B(net4),
    .CLK(clknet_5_12__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1439_ (.D(_0203_),
    .Q(\u_UVLO_sync_db.disagree_counter[4] ),
    .RESET_B(net4),
    .CLK(clknet_5_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1440_ (.D(_0202_),
    .Q(\u_UVLO_sync_db.disagree_counter[5] ),
    .RESET_B(net4),
    .CLK(clknet_5_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1441_ (.D(_0201_),
    .Q(\u_UVLO_sync_db.disagree_counter[6] ),
    .RESET_B(net4),
    .CLK(clknet_5_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1442_ (.D(_0200_),
    .Q(\u_UVLO_sync_db.disagree_counter[7] ),
    .RESET_B(net4),
    .CLK(clknet_5_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1443_ (.D(_0199_),
    .Q(\u_UVLO_sync_db.disagree_counter[8] ),
    .RESET_B(net4),
    .CLK(clknet_5_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1444_ (.D(_0198_),
    .Q(\u_UVLO_sync_db.disagree_counter[9] ),
    .RESET_B(net4),
    .CLK(clknet_5_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1445_ (.D(_0197_),
    .Q(\u_UVLO_sync_db.disagree_counter[10] ),
    .RESET_B(net4),
    .CLK(clknet_5_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1446_ (.D(_0196_),
    .Q(\u_UVLO_sync_db.disagree_counter[11] ),
    .RESET_B(net4),
    .CLK(clknet_5_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1447_ (.D(_0195_),
    .Q(\u_UVLO_sync_db.disagree_counter[12] ),
    .RESET_B(net4),
    .CLK(clknet_5_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1448_ (.D(_0209_),
    .Q(\u_UVLO_sync_db.disagree_counter[13] ),
    .RESET_B(net4),
    .CLK(clknet_5_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1449_ (.D(_0194_),
    .Q(\u_fault_arbiter.fault_shifter_SS[0] ),
    .RESET_B(net5),
    .CLK(clknet_5_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1450_ (.D(_0193_),
    .Q(\u_fault_arbiter.fault_shifter_SS[1] ),
    .RESET_B(net5),
    .CLK(clknet_5_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1451_ (.D(_0192_),
    .Q(\u_fault_arbiter.fault_shifter_SS[2] ),
    .RESET_B(net5),
    .CLK(clknet_5_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1452_ (.D(_0191_),
    .Q(\u_fault_arbiter.fault_shifter_SS[3] ),
    .RESET_B(net5),
    .CLK(clknet_5_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1453_ (.D(_0190_),
    .Q(\u_fault_arbiter.fault_shifter_SS[4] ),
    .RESET_B(net5),
    .CLK(clknet_5_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1454_ (.D(_0189_),
    .Q(\u_fault_arbiter.fault_shifter_SS[5] ),
    .RESET_B(net5),
    .CLK(clknet_5_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1455_ (.D(_0188_),
    .Q(\u_fault_arbiter.fault_shifter_SS[6] ),
    .RESET_B(net5),
    .CLK(clknet_5_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1456_ (.D(_0187_),
    .Q(\u_fault_arbiter.fault_shifter_SS[7] ),
    .RESET_B(net5),
    .CLK(clknet_5_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1457_ (.D(_0186_),
    .Q(\u_fault_arbiter.fault_shifter_SS[8] ),
    .RESET_B(net5),
    .CLK(clknet_5_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1458_ (.D(_0185_),
    .Q(\u_fault_arbiter.fault_shifter_SS[9] ),
    .RESET_B(net5),
    .CLK(clknet_5_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1459_ (.D(_0184_),
    .Q(\u_fault_arbiter.fault_shifter_SS[10] ),
    .RESET_B(net5),
    .CLK(clknet_5_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1460_ (.D(_0183_),
    .Q(\u_fault_arbiter.fault_shifter_SS[11] ),
    .RESET_B(net5),
    .CLK(clknet_5_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1461_ (.D(_0182_),
    .Q(\u_fault_arbiter.fault_shifter_SS[12] ),
    .RESET_B(net5),
    .CLK(clknet_5_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1462_ (.D(_0181_),
    .Q(\u_fault_arbiter.fault_shifter_SS[13] ),
    .RESET_B(net5),
    .CLK(clknet_5_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1463_ (.D(_0180_),
    .Q(\u_fault_arbiter.fault_shifter_SS[14] ),
    .RESET_B(net5),
    .CLK(clknet_5_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1464_ (.D(_0179_),
    .Q(\u_fault_arbiter.fault_shifter_SS[15] ),
    .RESET_B(net5),
    .CLK(clknet_5_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1465_ (.D(_0178_),
    .Q(\u_fault_arbiter.fault_shifter_SS[16] ),
    .RESET_B(net5),
    .CLK(clknet_5_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1466_ (.D(_0177_),
    .Q(\u_fault_arbiter.fault_shifter_SS[17] ),
    .RESET_B(net5),
    .CLK(clknet_5_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1467_ (.D(_0176_),
    .Q(\u_fault_arbiter.fault_shifter_SS[18] ),
    .RESET_B(net5),
    .CLK(clknet_5_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1468_ (.D(_0175_),
    .Q(\u_fault_arbiter.fault_shifter_SS[19] ),
    .RESET_B(net5),
    .CLK(clknet_5_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1469_ (.D(_0174_),
    .Q(\u_fault_arbiter.fault_shifter_SS[20] ),
    .RESET_B(net5),
    .CLK(clknet_5_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1470_ (.D(_0173_),
    .Q(\u_fault_arbiter.fault_shifter_SS[21] ),
    .RESET_B(net5),
    .CLK(clknet_5_22__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1471_ (.D(_0172_),
    .Q(\u_fault_arbiter.fault_shifter_SS[22] ),
    .RESET_B(net5),
    .CLK(clknet_5_22__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1472_ (.D(_0171_),
    .Q(\u_fault_arbiter.fault_shifter_SS[23] ),
    .RESET_B(net5),
    .CLK(clknet_5_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1473_ (.D(_0170_),
    .Q(\u_fault_arbiter.fault_shifter_SS[24] ),
    .RESET_B(net5),
    .CLK(clknet_5_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1474_ (.D(_0169_),
    .Q(\u_fault_arbiter.fault_shifter_SS[25] ),
    .RESET_B(net5),
    .CLK(clknet_5_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1475_ (.D(_0168_),
    .Q(\u_fault_arbiter.fault_shifter_SS[26] ),
    .RESET_B(net5),
    .CLK(clknet_5_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1476_ (.D(_0167_),
    .Q(\u_fault_arbiter.fault_shifter_SS[27] ),
    .RESET_B(net5),
    .CLK(clknet_5_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1477_ (.D(_0166_),
    .Q(\u_fault_arbiter.fault_shifter_SS[28] ),
    .RESET_B(net5),
    .CLK(clknet_5_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1478_ (.D(_0165_),
    .Q(\u_fault_arbiter.fault_shifter_SS[29] ),
    .RESET_B(net5),
    .CLK(clknet_5_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1479_ (.D(_0164_),
    .Q(\u_fault_arbiter.fault_shifter_SS[30] ),
    .RESET_B(net5),
    .CLK(clknet_5_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1480_ (.D(_0210_),
    .Q(\u_fault_arbiter.fault_shifter_SS[31] ),
    .RESET_B(net5),
    .CLK(clknet_5_17__leaf_clk));
 sky130_fd_sc_hd__dfstp_4 _1481_ (.D(_0211_),
    .Q(OTP_sync_db),
    .SET_B(net4),
    .CLK(clknet_5_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1482_ (.D(_0163_),
    .Q(\u_OTP_sync_db.disagree_counter[0] ),
    .RESET_B(net4),
    .CLK(clknet_5_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1483_ (.D(_0162_),
    .Q(\u_OTP_sync_db.disagree_counter[1] ),
    .RESET_B(net4),
    .CLK(clknet_5_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1484_ (.D(_0161_),
    .Q(\u_OTP_sync_db.disagree_counter[2] ),
    .RESET_B(net4),
    .CLK(clknet_5_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1485_ (.D(_0160_),
    .Q(\u_OTP_sync_db.disagree_counter[3] ),
    .RESET_B(net4),
    .CLK(clknet_5_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1486_ (.D(_0159_),
    .Q(\u_OTP_sync_db.disagree_counter[4] ),
    .RESET_B(net4),
    .CLK(clknet_5_9__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1487_ (.D(_0158_),
    .Q(\u_OTP_sync_db.disagree_counter[5] ),
    .RESET_B(net4),
    .CLK(clknet_5_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1488_ (.D(_0157_),
    .Q(\u_OTP_sync_db.disagree_counter[6] ),
    .RESET_B(net4),
    .CLK(clknet_5_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1489_ (.D(_0156_),
    .Q(\u_OTP_sync_db.disagree_counter[7] ),
    .RESET_B(net4),
    .CLK(clknet_5_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1490_ (.D(_0155_),
    .Q(\u_OTP_sync_db.disagree_counter[8] ),
    .RESET_B(net4),
    .CLK(clknet_5_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1491_ (.D(_0154_),
    .Q(\u_OTP_sync_db.disagree_counter[9] ),
    .RESET_B(net4),
    .CLK(clknet_5_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1492_ (.D(_0153_),
    .Q(\u_OTP_sync_db.disagree_counter[10] ),
    .RESET_B(net4),
    .CLK(clknet_5_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1493_ (.D(_0152_),
    .Q(\u_OTP_sync_db.disagree_counter[11] ),
    .RESET_B(net4),
    .CLK(clknet_5_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1494_ (.D(_0151_),
    .Q(\u_OTP_sync_db.disagree_counter[12] ),
    .RESET_B(net4),
    .CLK(clknet_5_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1495_ (.D(_0212_),
    .Q(\u_OTP_sync_db.disagree_counter[13] ),
    .RESET_B(net4),
    .CLK(clknet_5_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1496_ (.D(_0150_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[0] ),
    .RESET_B(net5),
    .CLK(clknet_5_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1497_ (.D(_0149_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[1] ),
    .RESET_B(net5),
    .CLK(clknet_5_19__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1498_ (.D(_0148_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[2] ),
    .RESET_B(net5),
    .CLK(clknet_5_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1499_ (.D(_0147_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[3] ),
    .RESET_B(net5),
    .CLK(clknet_5_22__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1500_ (.D(_0146_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[4] ),
    .RESET_B(net5),
    .CLK(clknet_5_22__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1501_ (.D(_0145_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[5] ),
    .RESET_B(net5),
    .CLK(clknet_5_22__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1502_ (.D(_0144_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[6] ),
    .RESET_B(net5),
    .CLK(clknet_5_22__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1503_ (.D(_0143_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[7] ),
    .RESET_B(net5),
    .CLK(clknet_5_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1504_ (.D(_0142_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[8] ),
    .RESET_B(net5),
    .CLK(clknet_5_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1505_ (.D(_0141_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[9] ),
    .RESET_B(net5),
    .CLK(clknet_5_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1506_ (.D(_0140_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[10] ),
    .RESET_B(net5),
    .CLK(clknet_5_25__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1507_ (.D(_0139_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[11] ),
    .RESET_B(net5),
    .CLK(clknet_5_25__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1508_ (.D(_0138_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[12] ),
    .RESET_B(net5),
    .CLK(clknet_5_25__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1509_ (.D(_0137_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[13] ),
    .RESET_B(net5),
    .CLK(clknet_5_19__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1510_ (.D(_0136_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[14] ),
    .RESET_B(net5),
    .CLK(clknet_5_19__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1511_ (.D(_0213_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[15] ),
    .RESET_B(net5),
    .CLK(clknet_5_19__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1512_ (.D(_0135_),
    .Q(\fault_count_run[0] ),
    .RESET_B(net6),
    .CLK(clknet_5_19__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _1513_ (.D(_0134_),
    .Q(\fault_count_run[1] ),
    .RESET_B(net6),
    .CLK(clknet_5_18__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _1514_ (.D(_0133_),
    .Q(\fault_count_run[2] ),
    .RESET_B(net5),
    .CLK(clknet_5_19__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _1515_ (.D(_0132_),
    .Q(\fault_count_run[3] ),
    .RESET_B(net5),
    .CLK(clknet_5_25__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1516_ (.D(_0214_),
    .Q(\fault_count_run[4] ),
    .RESET_B(net6),
    .CLK(clknet_5_18__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1517_ (.D(_0131_),
    .Q(\fault_count_ss[0] ),
    .RESET_B(net6),
    .CLK(clknet_5_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _1518_ (.D(_0130_),
    .Q(\fault_count_ss[1] ),
    .RESET_B(net6),
    .CLK(clknet_5_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _1519_ (.D(_0129_),
    .Q(\fault_count_ss[2] ),
    .RESET_B(net6),
    .CLK(clknet_5_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _1520_ (.D(_0128_),
    .Q(\fault_count_ss[3] ),
    .RESET_B(net6),
    .CLK(clknet_5_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1521_ (.D(_0127_),
    .Q(\fault_count_ss[4] ),
    .RESET_B(net6),
    .CLK(clknet_5_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1522_ (.D(_0215_),
    .Q(\fault_count_ss[5] ),
    .RESET_B(net6),
    .CLK(clknet_5_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1523_ (.D(_0126_),
    .Q(\u_en_from_switch_db.disagree_counter[0] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1524_ (.D(_0125_),
    .Q(\u_en_from_switch_db.disagree_counter[1] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1525_ (.D(_0124_),
    .Q(\u_en_from_switch_db.disagree_counter[2] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1526_ (.D(_0123_),
    .Q(\u_en_from_switch_db.disagree_counter[3] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1527_ (.D(_0122_),
    .Q(\u_en_from_switch_db.disagree_counter[4] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1528_ (.D(_0121_),
    .Q(\u_en_from_switch_db.disagree_counter[5] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1529_ (.D(_0120_),
    .Q(\u_en_from_switch_db.disagree_counter[6] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1530_ (.D(_0119_),
    .Q(\u_en_from_switch_db.disagree_counter[7] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1531_ (.D(_0118_),
    .Q(\u_en_from_switch_db.disagree_counter[8] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _1532_ (.D(_0117_),
    .Q(\u_en_from_switch_db.disagree_counter[9] ),
    .RESET_B(net5),
    .CLK(clknet_5_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1533_ (.D(_0116_),
    .Q(\u_en_from_switch_db.disagree_counter[10] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1534_ (.D(_0115_),
    .Q(\u_en_from_switch_db.disagree_counter[11] ),
    .RESET_B(net5),
    .CLK(clknet_5_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1535_ (.D(_0114_),
    .Q(\u_en_from_switch_db.disagree_counter[12] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1536_ (.D(_0113_),
    .Q(\u_en_from_switch_db.disagree_counter[13] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1537_ (.D(_0112_),
    .Q(\u_en_from_switch_db.disagree_counter[14] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1538_ (.D(_0111_),
    .Q(\u_en_from_switch_db.disagree_counter[15] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1539_ (.D(_0110_),
    .Q(\u_en_from_switch_db.disagree_counter[16] ),
    .RESET_B(net5),
    .CLK(clknet_5_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1540_ (.D(_0216_),
    .Q(\u_en_from_switch_db.disagree_counter[17] ),
    .RESET_B(net5),
    .CLK(clknet_5_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _1541_ (.D(_0217_),
    .Q(en_from_switch_sync_db),
    .RESET_B(rst_n),
    .CLK(clknet_5_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _1542_ (.D(_0109_),
    .Q(\u_hiccup_timer.cool_counter[0] ),
    .RESET_B(net3),
    .CLK(clknet_5_6__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1543_ (.D(_0108_),
    .Q(\u_hiccup_timer.cool_counter[1] ),
    .RESET_B(net3),
    .CLK(clknet_5_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1544_ (.D(_0107_),
    .Q(\u_hiccup_timer.cool_counter[2] ),
    .RESET_B(net3),
    .CLK(clknet_5_6__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1545_ (.D(_0106_),
    .Q(\u_hiccup_timer.cool_counter[3] ),
    .RESET_B(net3),
    .CLK(clknet_5_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _1546_ (.D(_0105_),
    .Q(\u_hiccup_timer.cool_counter[4] ),
    .RESET_B(net3),
    .CLK(clknet_5_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1547_ (.D(_0104_),
    .Q(\u_hiccup_timer.cool_counter[5] ),
    .RESET_B(net3),
    .CLK(clknet_5_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1548_ (.D(_0103_),
    .Q(\u_hiccup_timer.cool_counter[6] ),
    .RESET_B(net3),
    .CLK(clknet_5_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1549_ (.D(_0102_),
    .Q(\u_hiccup_timer.cool_counter[7] ),
    .RESET_B(net3),
    .CLK(clknet_5_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1550_ (.D(_0101_),
    .Q(\u_hiccup_timer.cool_counter[8] ),
    .RESET_B(net3),
    .CLK(clknet_5_3__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1551_ (.D(_0100_),
    .Q(\u_hiccup_timer.cool_counter[9] ),
    .RESET_B(net3),
    .CLK(clknet_5_3__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1552_ (.D(_0099_),
    .Q(\u_hiccup_timer.cool_counter[10] ),
    .RESET_B(net3),
    .CLK(clknet_5_3__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1553_ (.D(_0098_),
    .Q(\u_hiccup_timer.cool_counter[11] ),
    .RESET_B(net3),
    .CLK(clknet_5_3__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1554_ (.D(_0097_),
    .Q(\u_hiccup_timer.cool_counter[12] ),
    .RESET_B(net3),
    .CLK(clknet_5_9__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1555_ (.D(_0096_),
    .Q(\u_hiccup_timer.cool_counter[13] ),
    .RESET_B(net3),
    .CLK(clknet_5_3__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1556_ (.D(_0095_),
    .Q(\u_hiccup_timer.cool_counter[14] ),
    .RESET_B(net3),
    .CLK(clknet_5_9__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1557_ (.D(_0094_),
    .Q(\u_hiccup_timer.cool_counter[15] ),
    .RESET_B(net3),
    .CLK(clknet_5_12__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1558_ (.D(_0093_),
    .Q(\u_hiccup_timer.cool_counter[16] ),
    .RESET_B(net3),
    .CLK(clknet_5_12__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1559_ (.D(_0092_),
    .Q(\u_hiccup_timer.cool_counter[17] ),
    .RESET_B(net3),
    .CLK(clknet_5_12__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1560_ (.D(_0091_),
    .Q(\u_hiccup_timer.cool_counter[18] ),
    .RESET_B(net3),
    .CLK(clknet_5_12__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1561_ (.D(_0218_),
    .Q(\u_hiccup_timer.cool_counter[19] ),
    .RESET_B(net3),
    .CLK(clknet_5_7__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1562_ (.D(_0219_),
    .Q(hiccup_done),
    .RESET_B(net3),
    .CLK(clknet_5_6__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _1563_ (.D(_0220_),
    .Q(latch_stat_sync_db),
    .SET_B(rst_n),
    .CLK(clknet_5_27__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _1564_ (.D(_0090_),
    .Q(\u_strike_counter.clean_counter[0] ),
    .RESET_B(net3),
    .CLK(clknet_5_7__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _1565_ (.D(_0089_),
    .Q(\u_strike_counter.clean_counter[1] ),
    .RESET_B(net3),
    .CLK(clknet_5_7__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1566_ (.D(_0088_),
    .Q(\u_strike_counter.clean_counter[2] ),
    .RESET_B(net6),
    .CLK(clknet_5_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1567_ (.D(_0087_),
    .Q(\u_strike_counter.clean_counter[3] ),
    .RESET_B(net6),
    .CLK(clknet_5_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _1568_ (.D(_0086_),
    .Q(\u_strike_counter.clean_counter[4] ),
    .RESET_B(net6),
    .CLK(clknet_5_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1569_ (.D(_0085_),
    .Q(\u_strike_counter.clean_counter[5] ),
    .RESET_B(net6),
    .CLK(clknet_5_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1570_ (.D(_0084_),
    .Q(\u_strike_counter.clean_counter[6] ),
    .RESET_B(net6),
    .CLK(clknet_5_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _1571_ (.D(_0083_),
    .Q(\u_strike_counter.clean_counter[7] ),
    .RESET_B(net6),
    .CLK(clknet_5_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1572_ (.D(_0082_),
    .Q(\u_strike_counter.clean_counter[8] ),
    .RESET_B(net6),
    .CLK(clknet_5_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1573_ (.D(_0081_),
    .Q(\u_strike_counter.clean_counter[9] ),
    .RESET_B(net6),
    .CLK(clknet_5_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1574_ (.D(_0080_),
    .Q(\u_strike_counter.clean_counter[10] ),
    .RESET_B(net6),
    .CLK(clknet_5_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1575_ (.D(_0079_),
    .Q(\u_strike_counter.clean_counter[11] ),
    .RESET_B(net3),
    .CLK(clknet_5_6__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1576_ (.D(_0078_),
    .Q(\u_strike_counter.clean_counter[12] ),
    .RESET_B(net3),
    .CLK(clknet_5_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1577_ (.D(_0077_),
    .Q(\u_strike_counter.clean_counter[13] ),
    .RESET_B(net3),
    .CLK(clknet_5_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1578_ (.D(_0076_),
    .Q(\u_strike_counter.clean_counter[14] ),
    .RESET_B(net3),
    .CLK(clknet_5_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1579_ (.D(_0075_),
    .Q(\u_strike_counter.clean_counter[15] ),
    .RESET_B(net3),
    .CLK(clknet_5_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1580_ (.D(_0074_),
    .Q(\u_strike_counter.clean_counter[16] ),
    .RESET_B(net6),
    .CLK(clknet_5_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1581_ (.D(_0073_),
    .Q(\u_strike_counter.clean_counter[17] ),
    .RESET_B(net6),
    .CLK(clknet_5_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1582_ (.D(_0221_),
    .Q(\u_strike_counter.clean_counter[18] ),
    .RESET_B(net3),
    .CLK(clknet_5_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _1583_ (.D(_0072_),
    .Q(\strike_level[0] ),
    .RESET_B(net3),
    .CLK(clknet_5_7__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _1584_ (.D(_0222_),
    .Q(\strike_level[1] ),
    .RESET_B(net3),
    .CLK(clknet_5_6__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1585_ (.D(_0223_),
    .Q(latch_out),
    .RESET_B(net3),
    .CLK(clknet_5_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1586_ (.D(_0071_),
    .Q(\u_soft_start.cycle_counter[0] ),
    .RESET_B(net3),
    .CLK(clknet_5_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1587_ (.D(_0070_),
    .Q(\u_soft_start.cycle_counter[1] ),
    .RESET_B(net3),
    .CLK(clknet_5_7__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1588_ (.D(_0069_),
    .Q(\u_soft_start.cycle_counter[2] ),
    .RESET_B(net3),
    .CLK(clknet_5_7__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1589_ (.D(_0068_),
    .Q(\u_soft_start.cycle_counter[3] ),
    .RESET_B(net3),
    .CLK(clknet_5_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1590_ (.D(_0067_),
    .Q(\u_soft_start.cycle_counter[4] ),
    .RESET_B(net6),
    .CLK(clknet_5_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1591_ (.D(_0066_),
    .Q(\u_soft_start.cycle_counter[5] ),
    .RESET_B(net6),
    .CLK(clknet_5_24__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1592_ (.D(_0224_),
    .Q(\u_soft_start.cycle_counter[6] ),
    .RESET_B(net6),
    .CLK(clknet_5_24__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _1593_ (.D(_0065_),
    .Q(\max_on_counts[0] ),
    .SET_B(net5),
    .CLK(clknet_5_25__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _1594_ (.D(_0064_),
    .Q(\max_on_counts[1] ),
    .SET_B(net5),
    .CLK(clknet_5_25__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1595_ (.D(_0063_),
    .Q(\max_on_counts[2] ),
    .RESET_B(net6),
    .CLK(clknet_5_24__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1596_ (.D(_0062_),
    .Q(\max_on_counts[3] ),
    .RESET_B(net6),
    .CLK(clknet_5_24__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1597_ (.D(_0225_),
    .Q(\max_on_counts[4] ),
    .RESET_B(net6),
    .CLK(clknet_5_24__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1598_ (.D(_0226_),
    .Q(SS_done),
    .RESET_B(net6),
    .CLK(clknet_5_18__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1599_ (.D(_0061_),
    .Q(\u_pwm_mask.run_counter[0] ),
    .RESET_B(net5),
    .CLK(clknet_5_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1600_ (.D(_0060_),
    .Q(\u_pwm_mask.run_counter[1] ),
    .RESET_B(net5),
    .CLK(clknet_5_24__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1601_ (.D(_0059_),
    .Q(\u_pwm_mask.run_counter[2] ),
    .RESET_B(net6),
    .CLK(clknet_5_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1602_ (.D(_0058_),
    .Q(\u_pwm_mask.run_counter[3] ),
    .RESET_B(net6),
    .CLK(clknet_5_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1603_ (.D(_0227_),
    .Q(\u_pwm_mask.run_counter[4] ),
    .RESET_B(net6),
    .CLK(clknet_5_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _1604_ (.D(_0057_),
    .Q(\u_pgood_gen.qualify_counter[0] ),
    .RESET_B(net3),
    .CLK(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1605_ (.D(_0056_),
    .Q(\u_pgood_gen.qualify_counter[1] ),
    .RESET_B(net3),
    .CLK(clknet_5_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1606_ (.D(_0055_),
    .Q(\u_pgood_gen.qualify_counter[2] ),
    .RESET_B(net3),
    .CLK(clknet_5_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1607_ (.D(_0054_),
    .Q(\u_pgood_gen.qualify_counter[3] ),
    .RESET_B(net3),
    .CLK(clknet_5_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1608_ (.D(_0053_),
    .Q(\u_pgood_gen.qualify_counter[4] ),
    .RESET_B(net3),
    .CLK(clknet_5_12__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1609_ (.D(_0052_),
    .Q(\u_pgood_gen.qualify_counter[5] ),
    .RESET_B(net3),
    .CLK(clknet_5_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1610_ (.D(_0051_),
    .Q(\u_pgood_gen.qualify_counter[6] ),
    .RESET_B(net4),
    .CLK(clknet_5_12__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1611_ (.D(_0050_),
    .Q(\u_pgood_gen.qualify_counter[7] ),
    .RESET_B(net4),
    .CLK(clknet_5_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1612_ (.D(_0049_),
    .Q(\u_pgood_gen.qualify_counter[8] ),
    .RESET_B(net4),
    .CLK(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _1613_ (.D(_0048_),
    .Q(\u_pgood_gen.qualify_counter[9] ),
    .RESET_B(net3),
    .CLK(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1614_ (.D(_0047_),
    .Q(\u_pgood_gen.qualify_counter[10] ),
    .RESET_B(net3),
    .CLK(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1615_ (.D(_0228_),
    .Q(\u_pgood_gen.qualify_counter[11] ),
    .RESET_B(net3),
    .CLK(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1616_ (.D(_0229_),
    .Q(\u_fault_LED.blink ),
    .RESET_B(net3),
    .CLK(clknet_5_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1617_ (.D(_0046_),
    .Q(\u_latch_stat_sync_db.disagree_counter[0] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_27__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1618_ (.D(_0045_),
    .Q(\u_latch_stat_sync_db.disagree_counter[1] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1619_ (.D(_0044_),
    .Q(\u_latch_stat_sync_db.disagree_counter[2] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1620_ (.D(_0043_),
    .Q(\u_latch_stat_sync_db.disagree_counter[3] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1621_ (.D(_0042_),
    .Q(\u_latch_stat_sync_db.disagree_counter[4] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_27__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1622_ (.D(_0041_),
    .Q(\u_latch_stat_sync_db.disagree_counter[5] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_27__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1623_ (.D(_0040_),
    .Q(\u_latch_stat_sync_db.disagree_counter[6] ),
    .RESET_B(net5),
    .CLK(clknet_5_25__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1624_ (.D(_0039_),
    .Q(\u_latch_stat_sync_db.disagree_counter[7] ),
    .RESET_B(net5),
    .CLK(clknet_5_27__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1625_ (.D(_0038_),
    .Q(\u_latch_stat_sync_db.disagree_counter[8] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1626_ (.D(_0037_),
    .Q(\u_latch_stat_sync_db.disagree_counter[9] ),
    .RESET_B(rst_n),
    .CLK(clknet_5_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1627_ (.D(_0036_),
    .Q(\u_latch_stat_sync_db.disagree_counter[10] ),
    .RESET_B(net5),
    .CLK(clknet_5_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1628_ (.D(_0035_),
    .Q(\u_latch_stat_sync_db.disagree_counter[11] ),
    .RESET_B(net5),
    .CLK(clknet_5_27__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1629_ (.D(_0034_),
    .Q(\u_latch_stat_sync_db.disagree_counter[12] ),
    .RESET_B(net5),
    .CLK(clknet_5_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1630_ (.D(_0230_),
    .Q(\u_latch_stat_sync_db.disagree_counter[13] ),
    .RESET_B(net5),
    .CLK(clknet_5_25__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _1631_ (.D(_0000_),
    .Q(\u_supervisor.state[0] ),
    .SET_B(net6),
    .CLK(clknet_5_6__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _1632_ (.D(_0001_),
    .Q(run_active),
    .RESET_B(net6),
    .CLK(clknet_5_18__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _1633_ (.D(_0002_),
    .Q(ss_active),
    .RESET_B(net6),
    .CLK(clknet_5_18__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _1634_ (.D(_0003_),
    .Q(hiccup_active),
    .RESET_B(net3),
    .CLK(clknet_5_7__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1635_ (.D(PGOOD),
    .Q(pgood_LED),
    .RESET_B(net4),
    .CLK(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1636_ (.D(_0006_),
    .Q(\u_fault_LED.blink_counter[0] ),
    .RESET_B(net3),
    .CLK(clknet_5_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1637_ (.D(_0017_),
    .Q(\u_fault_LED.blink_counter[1] ),
    .RESET_B(net3),
    .CLK(clknet_5_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1638_ (.D(_0019_),
    .Q(\u_fault_LED.blink_counter[2] ),
    .RESET_B(net3),
    .CLK(clknet_5_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1639_ (.D(_0020_),
    .Q(\u_fault_LED.blink_counter[3] ),
    .RESET_B(net3),
    .CLK(clknet_5_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1640_ (.D(_0021_),
    .Q(\u_fault_LED.blink_counter[4] ),
    .RESET_B(net3),
    .CLK(clknet_5_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1641_ (.D(_0022_),
    .Q(\u_fault_LED.blink_counter[5] ),
    .RESET_B(net3),
    .CLK(clknet_5_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1642_ (.D(_0023_),
    .Q(\u_fault_LED.blink_counter[6] ),
    .RESET_B(net3),
    .CLK(clknet_5_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1643_ (.D(_0024_),
    .Q(\u_fault_LED.blink_counter[7] ),
    .RESET_B(net3),
    .CLK(clknet_5_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1644_ (.D(_0025_),
    .Q(\u_fault_LED.blink_counter[8] ),
    .RESET_B(net3),
    .CLK(clknet_5_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1645_ (.D(_0026_),
    .Q(\u_fault_LED.blink_counter[9] ),
    .RESET_B(net3),
    .CLK(clknet_5_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1646_ (.D(_0007_),
    .Q(\u_fault_LED.blink_counter[10] ),
    .RESET_B(net3),
    .CLK(clknet_5_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1647_ (.D(_0008_),
    .Q(\u_fault_LED.blink_counter[11] ),
    .RESET_B(net3),
    .CLK(clknet_5_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1648_ (.D(_0009_),
    .Q(\u_fault_LED.blink_counter[12] ),
    .RESET_B(net3),
    .CLK(clknet_5_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1649_ (.D(_0010_),
    .Q(\u_fault_LED.blink_counter[13] ),
    .RESET_B(net3),
    .CLK(clknet_5_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1650_ (.D(_0011_),
    .Q(\u_fault_LED.blink_counter[14] ),
    .RESET_B(net3),
    .CLK(clknet_5_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1651_ (.D(_0012_),
    .Q(\u_fault_LED.blink_counter[15] ),
    .RESET_B(net3),
    .CLK(clknet_5_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1652_ (.D(_0013_),
    .Q(\u_fault_LED.blink_counter[16] ),
    .RESET_B(net3),
    .CLK(clknet_5_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1653_ (.D(_0014_),
    .Q(\u_fault_LED.blink_counter[17] ),
    .RESET_B(net3),
    .CLK(clknet_5_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1654_ (.D(_0015_),
    .Q(\u_fault_LED.blink_counter[18] ),
    .RESET_B(net3),
    .CLK(clknet_5_3__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1655_ (.D(_0016_),
    .Q(\u_fault_LED.blink_counter[19] ),
    .RESET_B(net3),
    .CLK(clknet_5_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1656_ (.D(_0018_),
    .Q(\u_fault_LED.blink_counter[20] ),
    .RESET_B(net3),
    .CLK(clknet_5_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1657_ (.D(_0005_),
    .Q(Red_LED1),
    .RESET_B(net4),
    .CLK(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1658_ (.D(OTP_sync_db),
    .Q(Red_LED2),
    .RESET_B(net4),
    .CLK(clknet_5_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1659_ (.D(UVLO_sync_db),
    .Q(Red_LED3),
    .RESET_B(net4),
    .CLK(clknet_5_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1660_ (.D(_0004_),
    .Q(Green_LED),
    .RESET_B(net4),
    .CLK(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _1661_ (.D(_0032_),
    .Q(\u_pwm_mask.pulse_allowed ),
    .SET_B(net5),
    .CLK(clknet_5_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1662_ (.D(_0033_),
    .Q(PWM_out),
    .RESET_B(net4),
    .CLK(clknet_5_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1663_ (.D(hiccup_active),
    .Q(\u_strike_counter.hiccup_active_d ),
    .RESET_B(net3),
    .CLK(clknet_5_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1664_ (.D(_0027_),
    .Q(\u_fault_arbiter.cp_delay[0] ),
    .RESET_B(net3),
    .CLK(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1665_ (.D(_0028_),
    .Q(\u_fault_arbiter.cp_delay[1] ),
    .RESET_B(net6),
    .CLK(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1666_ (.D(_0029_),
    .Q(\u_fault_arbiter.cp_delay[2] ),
    .RESET_B(net6),
    .CLK(clknet_5_18__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1667_ (.D(_0030_),
    .Q(\u_fault_arbiter.cp_delay[3] ),
    .RESET_B(net6),
    .CLK(clknet_5_18__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _1668_ (.D(_0031_),
    .Q(\u_fault_arbiter.cp_delay[4] ),
    .RESET_B(net6),
    .CLK(clknet_5_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _1669_ (.D(Osc_sync),
    .Q(\u_fault_arbiter.pwm_sync_d ),
    .RESET_B(net6),
    .CLK(clknet_5_18__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1670_ (.D(en_from_switch),
    .Q(\u_en_from_switch_sync.meta_ff ),
    .RESET_B(rst_n),
    .CLK(clknet_5_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _1671_ (.D(\u_en_from_switch_sync.meta_ff ),
    .Q(en_from_switch_sync),
    .RESET_B(rst_n),
    .CLK(clknet_5_27__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1672_ (.D(PGOOD_comp),
    .Q(\u_pgood_comp_sync.meta_ff ),
    .RESET_B(net3),
    .CLK(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1673_ (.D(\u_pgood_comp_sync.meta_ff ),
    .Q(PGOOD_comp_sync),
    .RESET_B(net6),
    .CLK(clknet_5_26__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _1674_ (.D(latch_stat),
    .Q(\u_latch_stat_sync.meta_ff ),
    .SET_B(rst_n),
    .CLK(clknet_5_26__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _1675_ (.D(\u_latch_stat_sync.meta_ff ),
    .Q(latch_stat_sync),
    .SET_B(rst_n),
    .CLK(clknet_5_27__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _1676_ (.D(UVLO_trig),
    .Q(\u_uvlo_sync.meta_ff ),
    .SET_B(net4),
    .CLK(clknet_5_14__leaf_clk));
 sky130_fd_sc_hd__dfstp_4 _1677_ (.D(\u_uvlo_sync.meta_ff ),
    .Q(UVLO_sync),
    .SET_B(net4),
    .CLK(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _1678_ (.D(OTP_trig),
    .Q(\u_otp_sync.meta_ff ),
    .SET_B(net4),
    .CLK(clknet_5_10__leaf_clk));
 sky130_fd_sc_hd__dfstp_4 _1679_ (.D(\u_otp_sync.meta_ff ),
    .Q(OTP_sync),
    .SET_B(net4),
    .CLK(clknet_5_10__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _1680_ (.D(CP_trig),
    .Q(\u_cp_sync.meta_ff ),
    .SET_B(net4),
    .CLK(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _1681_ (.D(\u_cp_sync.meta_ff ),
    .Q(CP_sync),
    .SET_B(net4),
    .CLK(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1682_ (.D(Osc_in),
    .Q(\u_osc_sync.meta_ff ),
    .RESET_B(net4),
    .CLK(clknet_5_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _1683_ (.D(\u_osc_sync.meta_ff ),
    .Q(Osc_sync),
    .RESET_B(net6),
    .CLK(clknet_5_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _1684_ (.D(\rst_sync.meta_ff ),
    .Q(rst_n),
    .RESET_B(rst_n_pin),
    .CLK(clknet_5_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _1685_ (.D(net1),
    .Q(\rst_sync.meta_ff ),
    .RESET_B(rst_n_pin),
    .CLK(clknet_5_26__leaf_clk));
 sky130_fd_sc_hd__conb_1 pmic_top_2 (.LO(net2));
 sky130_fd_sc_hd__buf_16 load_slew3 (.A(net4),
    .X(net3));
 sky130_fd_sc_hd__clkbuf_1 _1688_ (.A(PGOOD),
    .X(switch_supply));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_0 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_1 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_3 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_4 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_5 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_6 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_7 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_8 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_9 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_10 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_11 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_12 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_13 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_14 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_15 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_16 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_17 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_18 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_19 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_20 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_21 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_22 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_23 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_24 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_25 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_26 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_27 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_28 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_29 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_30 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_31 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_32 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_33 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_34 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_35 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_36 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_37 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_38 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_39 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_40 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_41 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_42 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_43 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_44 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_45 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_46 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_47 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_48 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_49 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_50 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_51 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_52 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_53 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_54 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_55 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_56 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_57 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_58 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_59 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_60 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_61 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_62 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_63 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_64 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_65 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_66 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_67 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_68 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_69 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_70 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_71 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_72 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_73 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_74 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_75 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_76 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_77 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_78 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_79 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_80 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_81 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_82 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_83 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_84 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_85 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_86 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_87 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_88 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_89 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_90 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_91 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_92 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_93 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_94 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_95 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_96 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_97 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_98 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_99 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_100 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_101 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_102 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_103 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_104 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_105 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_106 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_107 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_108 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_109 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_110 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_111 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_112 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_113 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_114 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_115 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_116 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_117 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_118 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_119 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_120 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_121 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_122 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_123 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_124 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_125 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_126 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_127 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_128 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_129 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_130 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_131 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_132 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_133 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_134 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_135 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_136 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_137 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_138 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_139 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_140 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_141 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_142 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_143 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_144 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_145 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_146 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_147 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_148 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_149 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_150 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_151 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_152 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_153 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_154 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_155 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_156 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_157 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_158 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_159 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_160 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_161 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_162 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_163 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_164 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_165 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_166 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_167 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_168 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_169 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_170 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_171 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_172 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_173 ();
 sky130_fd_sc_hd__conb_1 _1685__1 (.HI(net1));
 sky130_fd_sc_hd__buf_16 load_slew4 (.A(net6),
    .X(net4));
 sky130_fd_sc_hd__buf_16 load_slew5 (.A(rst_n),
    .X(net5));
 sky130_fd_sc_hd__buf_12 load_slew6 (.A(rst_n),
    .X(net6));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_0_clk (.A(clk),
    .X(clknet_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_0_0_clk (.A(clknet_0_clk),
    .X(clknet_4_0_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_1_0_clk (.A(clknet_0_clk),
    .X(clknet_4_1_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_2_0_clk (.A(clknet_0_clk),
    .X(clknet_4_2_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_3_0_clk (.A(clknet_0_clk),
    .X(clknet_4_3_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_4_0_clk (.A(clknet_0_clk),
    .X(clknet_4_4_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_5_0_clk (.A(clknet_0_clk),
    .X(clknet_4_5_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_6_0_clk (.A(clknet_0_clk),
    .X(clknet_4_6_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_7_0_clk (.A(clknet_0_clk),
    .X(clknet_4_7_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_8_0_clk (.A(clknet_0_clk),
    .X(clknet_4_8_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_9_0_clk (.A(clknet_0_clk),
    .X(clknet_4_9_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_10_0_clk (.A(clknet_0_clk),
    .X(clknet_4_10_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_11_0_clk (.A(clknet_0_clk),
    .X(clknet_4_11_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_12_0_clk (.A(clknet_0_clk),
    .X(clknet_4_12_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_13_0_clk (.A(clknet_0_clk),
    .X(clknet_4_13_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_14_0_clk (.A(clknet_0_clk),
    .X(clknet_4_14_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_15_0_clk (.A(clknet_0_clk),
    .X(clknet_4_15_0_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_0__f_clk (.A(clknet_4_0_0_clk),
    .X(clknet_5_0__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_1__f_clk (.A(clknet_4_0_0_clk),
    .X(clknet_5_1__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_2__f_clk (.A(clknet_4_1_0_clk),
    .X(clknet_5_2__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_3__f_clk (.A(clknet_4_1_0_clk),
    .X(clknet_5_3__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_4__f_clk (.A(clknet_4_2_0_clk),
    .X(clknet_5_4__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_5__f_clk (.A(clknet_4_2_0_clk),
    .X(clknet_5_5__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_6__f_clk (.A(clknet_4_3_0_clk),
    .X(clknet_5_6__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_7__f_clk (.A(clknet_4_3_0_clk),
    .X(clknet_5_7__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_8__f_clk (.A(clknet_4_4_0_clk),
    .X(clknet_5_8__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_9__f_clk (.A(clknet_4_4_0_clk),
    .X(clknet_5_9__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_10__f_clk (.A(clknet_4_5_0_clk),
    .X(clknet_5_10__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_11__f_clk (.A(clknet_4_5_0_clk),
    .X(clknet_5_11__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_12__f_clk (.A(clknet_4_6_0_clk),
    .X(clknet_5_12__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_13__f_clk (.A(clknet_4_6_0_clk),
    .X(clknet_5_13__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_14__f_clk (.A(clknet_4_7_0_clk),
    .X(clknet_5_14__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_15__f_clk (.A(clknet_4_7_0_clk),
    .X(clknet_5_15__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_16__f_clk (.A(clknet_4_8_0_clk),
    .X(clknet_5_16__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_17__f_clk (.A(clknet_4_8_0_clk),
    .X(clknet_5_17__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_18__f_clk (.A(clknet_4_9_0_clk),
    .X(clknet_5_18__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_19__f_clk (.A(clknet_4_9_0_clk),
    .X(clknet_5_19__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_20__f_clk (.A(clknet_4_10_0_clk),
    .X(clknet_5_20__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_21__f_clk (.A(clknet_4_10_0_clk),
    .X(clknet_5_21__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_22__f_clk (.A(clknet_4_11_0_clk),
    .X(clknet_5_22__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_23__f_clk (.A(clknet_4_11_0_clk),
    .X(clknet_5_23__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_24__f_clk (.A(clknet_4_12_0_clk),
    .X(clknet_5_24__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_25__f_clk (.A(clknet_4_12_0_clk),
    .X(clknet_5_25__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_26__f_clk (.A(clknet_4_13_0_clk),
    .X(clknet_5_26__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_27__f_clk (.A(clknet_4_13_0_clk),
    .X(clknet_5_27__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_28__f_clk (.A(clknet_4_14_0_clk),
    .X(clknet_5_28__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_29__f_clk (.A(clknet_4_14_0_clk),
    .X(clknet_5_29__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_30__f_clk (.A(clknet_4_15_0_clk),
    .X(clknet_5_30__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_5_31__f_clk (.A(clknet_4_15_0_clk),
    .X(clknet_5_31__leaf_clk));
 sky130_fd_sc_hd__fill_8 FILLER_0_0_0 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_8 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_16 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_0_24 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_28 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_31 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_39 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_41 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_58 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_0_74 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_78 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_80 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_91 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_144 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_171 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_205 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_241 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_298 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_328 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_0 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_1_8 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_1_12 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_1_23 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_1_31 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_1_84 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_1_298 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_1_359 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_2_12 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_2_25 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_2_31 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_2_89 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_2_91 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_2_151 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_2_166 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_2_208 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_2_329 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_3_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_3_5 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_3_26 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_3_121 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_3_142 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_3_162 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_3_181 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_3_359 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_4_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_4_21 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_4_95 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_4_141 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_4_160 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_4_177 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_4_186 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_4_328 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_5_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_5_7 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_5_61 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_5_89 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_5_114 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_5_121 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_5_151 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_5_181 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_5_233 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_5_341 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_6_28 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_6_112 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_6_151 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_6_159 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_6_329 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_7_17 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_7_55 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_7_126 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_7_148 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_7_299 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_7_336 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_7_358 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_8_20 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_8_28 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_8_36 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_8_61 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_8_103 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_8_128 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_8_174 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_8_225 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_8_269 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_8_271 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_8_329 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_9_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_9_31 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_9_37 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_9_59 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_9_72 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_9_146 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_9_174 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_9_238 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_9_241 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_9_292 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_9_352 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_10_91 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_10_291 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_10_316 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_10_329 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_11_39 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_11_66 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_11_93 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_11_111 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_11_121 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_11_181 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_11_298 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_11_338 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_11_347 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_11_358 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_11_379 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_12_38 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_12_141 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_12_151 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_12_193 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_12_328 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_12_346 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_12_379 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_13_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_13_51 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_13_91 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_13_109 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_13_118 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_13_136 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_13_181 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_13_246 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_13_276 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_13_292 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_13_341 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_13_358 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_13_376 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_14_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_35 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_44 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_98 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_339 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_15_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_15_58 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_15_118 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_15_286 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_15_299 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_16_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_16_38 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_16_135 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_16_171 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_16_236 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_16_323 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_16_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_17_47 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_90 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_119 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_132 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_196 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_17_221 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_247 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_299 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_17_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_18_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_18_31 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_18_69 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_18_91 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_18_113 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_18_151 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_18_247 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_18_268 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_18_329 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_18_354 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_18_380 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_67 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_19_89 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_19_141 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_238 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_287 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_39 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_81 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_20_91 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_98 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_20_151 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_20_160 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_20_166 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_271 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_328 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_20_359 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_20_380 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_21_29 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_21_66 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_21_88 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_21_179 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_21_234 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_21_319 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_22_38 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_22_46 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_22_91 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_22_120 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_22_180 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_22_211 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_22_261 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_22_301 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_22_331 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_23_158 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_23_186 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_23_217 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_23_257 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_24_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_24_73 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_24_88 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_24_184 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_24_259 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_24_316 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_25_134 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_25_184 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_25_189 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_25_238 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_25_345 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_31 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_54 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_61 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_181 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_263 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_291 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_26_299 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_26_359 ();
 assign MISO = net2;
endmodule
