module pmic_top (CP_trig,
    CS_n,
    En,
    Green_LED,
    MISO,
    MOSI,
    OTP_trig,
    Osc_in,
    PGOOD,
    PGOOD_comp,
    PWM_out,
    Red_LED1,
    Red_LED2,
    Red_LED3,
    SCK,
    UVLO_trig,
    clk,
    en_from_switch,
    latch_out,
    latch_stat,
    pgood_LED,
    rst_n_pin,
    switch_supply,
    VSS,
    VDD);
 input CP_trig;
 input CS_n;
 output En;
 output Green_LED;
 output MISO;
 input MOSI;
 input OTP_trig;
 input Osc_in;
 output PGOOD;
 input PGOOD_comp;
 output PWM_out;
 output Red_LED1;
 output Red_LED2;
 output Red_LED3;
 input SCK;
 input UVLO_trig;
 input clk;
 input en_from_switch;
 output latch_out;
 input latch_stat;
 output pgood_LED;
 input rst_n_pin;
 output switch_supply;
 inout VSS;
 inout VDD;

 wire CP_sync;
 wire OTP_sync;
 wire OTP_sync_db;
 wire Osc_sync;
 wire PGOOD_comp_sync;
 wire SS_done;
 wire UVLO_sync;
 wire UVLO_sync_db;
 wire _0000_;
 wire _0001_;
 wire _0002_;
 wire _0003_;
 wire _0004_;
 wire _0005_;
 wire _0006_;
 wire _0007_;
 wire _0008_;
 wire _0009_;
 wire _0010_;
 wire _0011_;
 wire _0012_;
 wire _0013_;
 wire _0014_;
 wire _0015_;
 wire _0016_;
 wire _0017_;
 wire _0018_;
 wire _0019_;
 wire _0020_;
 wire _0021_;
 wire _0022_;
 wire _0023_;
 wire _0024_;
 wire _0025_;
 wire _0026_;
 wire _0027_;
 wire _0028_;
 wire _0029_;
 wire _0030_;
 wire _0031_;
 wire _0032_;
 wire _0033_;
 wire _0034_;
 wire _0035_;
 wire _0036_;
 wire _0037_;
 wire _0038_;
 wire _0039_;
 wire _0040_;
 wire _0041_;
 wire _0042_;
 wire _0043_;
 wire _0044_;
 wire _0045_;
 wire _0046_;
 wire _0047_;
 wire _0048_;
 wire _0049_;
 wire _0050_;
 wire _0051_;
 wire _0052_;
 wire _0053_;
 wire _0054_;
 wire _0055_;
 wire _0056_;
 wire _0057_;
 wire _0058_;
 wire _0059_;
 wire _0060_;
 wire _0061_;
 wire _0062_;
 wire _0063_;
 wire _0064_;
 wire _0065_;
 wire _0066_;
 wire _0067_;
 wire _0068_;
 wire _0069_;
 wire _0070_;
 wire _0071_;
 wire _0072_;
 wire _0073_;
 wire _0074_;
 wire _0075_;
 wire _0076_;
 wire _0077_;
 wire _0078_;
 wire _0079_;
 wire _0080_;
 wire _0081_;
 wire _0082_;
 wire _0083_;
 wire _0084_;
 wire _0085_;
 wire _0086_;
 wire _0087_;
 wire _0088_;
 wire _0089_;
 wire _0090_;
 wire _0091_;
 wire _0092_;
 wire _0093_;
 wire _0094_;
 wire _0095_;
 wire _0096_;
 wire _0097_;
 wire _0098_;
 wire _0099_;
 wire _0100_;
 wire _0101_;
 wire _0102_;
 wire _0103_;
 wire _0104_;
 wire _0105_;
 wire _0106_;
 wire _0107_;
 wire _0108_;
 wire _0109_;
 wire _0110_;
 wire _0111_;
 wire _0112_;
 wire _0113_;
 wire _0114_;
 wire _0115_;
 wire _0116_;
 wire _0117_;
 wire _0118_;
 wire _0119_;
 wire _0120_;
 wire _0121_;
 wire _0122_;
 wire _0123_;
 wire _0124_;
 wire _0125_;
 wire _0126_;
 wire _0127_;
 wire _0128_;
 wire _0129_;
 wire _0130_;
 wire _0131_;
 wire _0132_;
 wire _0133_;
 wire _0134_;
 wire _0135_;
 wire _0136_;
 wire _0137_;
 wire _0138_;
 wire _0139_;
 wire _0140_;
 wire _0141_;
 wire _0142_;
 wire _0143_;
 wire _0144_;
 wire _0145_;
 wire _0146_;
 wire _0147_;
 wire _0148_;
 wire _0149_;
 wire _0150_;
 wire _0151_;
 wire _0152_;
 wire _0153_;
 wire _0154_;
 wire _0155_;
 wire _0156_;
 wire _0157_;
 wire _0158_;
 wire _0159_;
 wire _0160_;
 wire _0161_;
 wire _0162_;
 wire _0163_;
 wire _0164_;
 wire _0165_;
 wire _0166_;
 wire _0167_;
 wire _0168_;
 wire _0169_;
 wire _0170_;
 wire _0171_;
 wire _0172_;
 wire _0173_;
 wire _0174_;
 wire _0175_;
 wire _0176_;
 wire _0177_;
 wire _0178_;
 wire _0179_;
 wire _0180_;
 wire _0181_;
 wire _0182_;
 wire _0183_;
 wire _0184_;
 wire _0185_;
 wire _0186_;
 wire _0187_;
 wire _0188_;
 wire _0189_;
 wire _0190_;
 wire _0191_;
 wire _0192_;
 wire _0193_;
 wire _0194_;
 wire _0195_;
 wire _0196_;
 wire _0197_;
 wire _0198_;
 wire _0199_;
 wire _0200_;
 wire _0201_;
 wire _0202_;
 wire _0203_;
 wire _0204_;
 wire _0205_;
 wire _0206_;
 wire _0207_;
 wire _0208_;
 wire _0209_;
 wire _0210_;
 wire _0211_;
 wire _0212_;
 wire _0213_;
 wire _0214_;
 wire _0215_;
 wire _0216_;
 wire _0217_;
 wire _0218_;
 wire _0219_;
 wire _0220_;
 wire _0221_;
 wire _0222_;
 wire _0223_;
 wire _0224_;
 wire _0225_;
 wire _0226_;
 wire _0227_;
 wire _0228_;
 wire _0229_;
 wire _0230_;
 wire _0231_;
 wire _0232_;
 wire _0233_;
 wire _0234_;
 wire _0235_;
 wire _0236_;
 wire _0237_;
 wire _0238_;
 wire _0239_;
 wire _0240_;
 wire _0241_;
 wire _0242_;
 wire _0243_;
 wire _0244_;
 wire _0245_;
 wire _0246_;
 wire _0247_;
 wire _0248_;
 wire _0249_;
 wire _0250_;
 wire _0251_;
 wire _0252_;
 wire _0253_;
 wire _0254_;
 wire _0255_;
 wire _0256_;
 wire _0257_;
 wire _0258_;
 wire _0259_;
 wire _0260_;
 wire _0261_;
 wire _0262_;
 wire _0263_;
 wire _0264_;
 wire _0265_;
 wire _0266_;
 wire _0267_;
 wire _0268_;
 wire _0269_;
 wire _0270_;
 wire _0271_;
 wire _0272_;
 wire _0273_;
 wire _0274_;
 wire _0275_;
 wire _0276_;
 wire _0277_;
 wire _0278_;
 wire _0279_;
 wire _0280_;
 wire _0281_;
 wire _0282_;
 wire _0283_;
 wire _0284_;
 wire _0285_;
 wire _0286_;
 wire _0287_;
 wire _0288_;
 wire _0289_;
 wire _0290_;
 wire _0291_;
 wire _0292_;
 wire _0293_;
 wire _0294_;
 wire _0295_;
 wire _0296_;
 wire _0297_;
 wire _0298_;
 wire _0299_;
 wire _0300_;
 wire _0301_;
 wire _0302_;
 wire _0303_;
 wire _0304_;
 wire _0305_;
 wire _0306_;
 wire _0307_;
 wire _0308_;
 wire _0309_;
 wire _0310_;
 wire _0311_;
 wire _0312_;
 wire _0313_;
 wire _0314_;
 wire _0315_;
 wire _0316_;
 wire _0317_;
 wire _0318_;
 wire _0319_;
 wire _0320_;
 wire _0321_;
 wire _0322_;
 wire _0323_;
 wire _0324_;
 wire _0325_;
 wire _0326_;
 wire _0327_;
 wire _0328_;
 wire _0329_;
 wire _0330_;
 wire _0331_;
 wire _0332_;
 wire _0333_;
 wire _0334_;
 wire _0335_;
 wire _0336_;
 wire _0337_;
 wire _0338_;
 wire _0339_;
 wire _0340_;
 wire _0341_;
 wire _0342_;
 wire _0343_;
 wire _0344_;
 wire _0345_;
 wire _0346_;
 wire _0347_;
 wire _0348_;
 wire _0349_;
 wire _0350_;
 wire _0351_;
 wire _0352_;
 wire _0353_;
 wire _0354_;
 wire _0355_;
 wire _0356_;
 wire _0357_;
 wire _0358_;
 wire _0359_;
 wire _0360_;
 wire _0361_;
 wire _0362_;
 wire _0363_;
 wire _0364_;
 wire _0365_;
 wire _0366_;
 wire _0367_;
 wire _0368_;
 wire _0369_;
 wire _0370_;
 wire _0371_;
 wire _0372_;
 wire _0373_;
 wire _0374_;
 wire _0375_;
 wire _0376_;
 wire _0377_;
 wire _0378_;
 wire _0379_;
 wire _0380_;
 wire _0381_;
 wire _0382_;
 wire _0383_;
 wire _0384_;
 wire _0385_;
 wire _0386_;
 wire _0387_;
 wire _0388_;
 wire _0389_;
 wire _0390_;
 wire _0391_;
 wire _0392_;
 wire _0393_;
 wire _0394_;
 wire _0395_;
 wire _0396_;
 wire _0397_;
 wire _0398_;
 wire _0399_;
 wire _0400_;
 wire _0401_;
 wire _0402_;
 wire _0403_;
 wire _0404_;
 wire _0405_;
 wire _0406_;
 wire _0407_;
 wire _0408_;
 wire _0409_;
 wire _0410_;
 wire _0411_;
 wire _0412_;
 wire _0413_;
 wire _0414_;
 wire _0415_;
 wire _0416_;
 wire _0417_;
 wire _0418_;
 wire _0419_;
 wire _0420_;
 wire _0421_;
 wire _0422_;
 wire _0423_;
 wire _0424_;
 wire _0425_;
 wire _0426_;
 wire _0427_;
 wire _0428_;
 wire _0429_;
 wire _0430_;
 wire _0431_;
 wire _0432_;
 wire _0433_;
 wire _0434_;
 wire _0435_;
 wire _0436_;
 wire _0437_;
 wire _0438_;
 wire _0439_;
 wire _0440_;
 wire _0441_;
 wire _0442_;
 wire _0443_;
 wire _0444_;
 wire _0445_;
 wire _0446_;
 wire _0447_;
 wire _0448_;
 wire _0449_;
 wire _0450_;
 wire _0451_;
 wire _0452_;
 wire _0453_;
 wire _0454_;
 wire _0455_;
 wire _0456_;
 wire _0457_;
 wire _0458_;
 wire _0459_;
 wire _0460_;
 wire _0461_;
 wire _0462_;
 wire _0463_;
 wire _0464_;
 wire _0465_;
 wire _0466_;
 wire _0467_;
 wire _0468_;
 wire _0469_;
 wire _0470_;
 wire _0471_;
 wire _0472_;
 wire _0473_;
 wire _0474_;
 wire _0475_;
 wire _0476_;
 wire _0477_;
 wire _0478_;
 wire _0479_;
 wire _0480_;
 wire _0481_;
 wire _0482_;
 wire _0483_;
 wire _0484_;
 wire _0485_;
 wire _0486_;
 wire _0487_;
 wire _0488_;
 wire _0489_;
 wire _0490_;
 wire _0491_;
 wire _0492_;
 wire _0493_;
 wire _0494_;
 wire _0495_;
 wire _0496_;
 wire _0497_;
 wire _0498_;
 wire _0499_;
 wire _0500_;
 wire _0501_;
 wire _0502_;
 wire _0503_;
 wire _0504_;
 wire _0505_;
 wire _0506_;
 wire _0507_;
 wire _0508_;
 wire _0509_;
 wire _0510_;
 wire _0511_;
 wire _0512_;
 wire _0513_;
 wire _0514_;
 wire _0515_;
 wire _0516_;
 wire _0517_;
 wire _0518_;
 wire _0519_;
 wire _0520_;
 wire _0521_;
 wire _0522_;
 wire _0523_;
 wire _0524_;
 wire _0525_;
 wire _0526_;
 wire _0527_;
 wire _0528_;
 wire _0529_;
 wire _0530_;
 wire _0531_;
 wire _0532_;
 wire _0533_;
 wire _0534_;
 wire _0535_;
 wire _0536_;
 wire _0537_;
 wire _0538_;
 wire _0539_;
 wire _0540_;
 wire _0541_;
 wire _0542_;
 wire _0543_;
 wire _0544_;
 wire _0545_;
 wire _0546_;
 wire _0547_;
 wire _0548_;
 wire _0549_;
 wire _0550_;
 wire _0551_;
 wire _0552_;
 wire _0553_;
 wire _0554_;
 wire _0555_;
 wire _0556_;
 wire _0557_;
 wire _0558_;
 wire _0559_;
 wire _0560_;
 wire _0561_;
 wire _0562_;
 wire _0563_;
 wire _0564_;
 wire _0565_;
 wire _0566_;
 wire _0567_;
 wire _0568_;
 wire _0569_;
 wire _0570_;
 wire _0571_;
 wire _0572_;
 wire _0573_;
 wire _0574_;
 wire _0575_;
 wire _0576_;
 wire _0577_;
 wire _0578_;
 wire _0579_;
 wire _0580_;
 wire _0581_;
 wire _0582_;
 wire _0583_;
 wire _0584_;
 wire _0585_;
 wire _0586_;
 wire _0587_;
 wire _0588_;
 wire _0589_;
 wire _0590_;
 wire _0591_;
 wire _0592_;
 wire _0593_;
 wire _0594_;
 wire _0595_;
 wire _0596_;
 wire _0597_;
 wire _0598_;
 wire _0599_;
 wire _0600_;
 wire _0601_;
 wire _0602_;
 wire _0603_;
 wire _0604_;
 wire _0605_;
 wire _0606_;
 wire _0607_;
 wire _0608_;
 wire _0609_;
 wire _0610_;
 wire _0611_;
 wire _0612_;
 wire _0613_;
 wire _0614_;
 wire _0615_;
 wire _0616_;
 wire _0617_;
 wire _0618_;
 wire _0619_;
 wire _0620_;
 wire _0621_;
 wire _0622_;
 wire _0623_;
 wire _0624_;
 wire _0625_;
 wire _0626_;
 wire _0627_;
 wire _0628_;
 wire _0629_;
 wire _0630_;
 wire _0631_;
 wire _0632_;
 wire _0633_;
 wire _0634_;
 wire _0635_;
 wire _0636_;
 wire _0637_;
 wire _0638_;
 wire _0639_;
 wire _0640_;
 wire _0641_;
 wire _0642_;
 wire _0643_;
 wire _0644_;
 wire _0645_;
 wire _0646_;
 wire _0647_;
 wire _0648_;
 wire _0649_;
 wire _0650_;
 wire _0651_;
 wire _0652_;
 wire _0653_;
 wire _0654_;
 wire _0655_;
 wire _0656_;
 wire _0657_;
 wire _0658_;
 wire _0659_;
 wire _0660_;
 wire _0661_;
 wire _0662_;
 wire _0663_;
 wire _0664_;
 wire _0665_;
 wire _0666_;
 wire _0667_;
 wire _0668_;
 wire _0669_;
 wire _0670_;
 wire _0671_;
 wire _0672_;
 wire _0673_;
 wire _0674_;
 wire _0675_;
 wire _0676_;
 wire _0677_;
 wire _0678_;
 wire _0679_;
 wire _0680_;
 wire _0681_;
 wire _0682_;
 wire _0683_;
 wire _0684_;
 wire _0685_;
 wire _0686_;
 wire _0687_;
 wire _0688_;
 wire _0689_;
 wire _0690_;
 wire _0691_;
 wire _0692_;
 wire _0693_;
 wire _0694_;
 wire _0695_;
 wire _0696_;
 wire _0697_;
 wire _0698_;
 wire _0699_;
 wire _0700_;
 wire _0701_;
 wire _0702_;
 wire _0703_;
 wire _0704_;
 wire _0705_;
 wire _0706_;
 wire _0707_;
 wire _0708_;
 wire _0709_;
 wire _0710_;
 wire _0711_;
 wire _0712_;
 wire _0713_;
 wire _0714_;
 wire _0715_;
 wire _0716_;
 wire _0717_;
 wire _0718_;
 wire _0719_;
 wire _0720_;
 wire _0721_;
 wire _0722_;
 wire _0723_;
 wire _0724_;
 wire _0725_;
 wire _0726_;
 wire _0727_;
 wire _0728_;
 wire _0729_;
 wire _0730_;
 wire _0731_;
 wire _0732_;
 wire _0733_;
 wire _0734_;
 wire _0735_;
 wire _0736_;
 wire _0737_;
 wire _0738_;
 wire _0739_;
 wire _0740_;
 wire _0741_;
 wire _0742_;
 wire _0743_;
 wire _0744_;
 wire _0745_;
 wire _0746_;
 wire _0747_;
 wire _0748_;
 wire _0749_;
 wire _0750_;
 wire _0751_;
 wire _0752_;
 wire _0753_;
 wire _0754_;
 wire _0755_;
 wire _0756_;
 wire _0757_;
 wire _0758_;
 wire _0759_;
 wire _0760_;
 wire _0761_;
 wire _0762_;
 wire _0763_;
 wire _0764_;
 wire _0765_;
 wire _0766_;
 wire _0767_;
 wire _0768_;
 wire _0769_;
 wire _0770_;
 wire _0771_;
 wire _0772_;
 wire _0773_;
 wire _0774_;
 wire _0775_;
 wire _0776_;
 wire _0777_;
 wire _0778_;
 wire _0779_;
 wire _0780_;
 wire _0781_;
 wire _0782_;
 wire _0783_;
 wire _0784_;
 wire _0785_;
 wire _0786_;
 wire _0787_;
 wire _0788_;
 wire _0789_;
 wire _0790_;
 wire _0791_;
 wire _0792_;
 wire _0793_;
 wire _0794_;
 wire _0795_;
 wire _0796_;
 wire _0797_;
 wire _0798_;
 wire _0799_;
 wire _0800_;
 wire _0801_;
 wire _0802_;
 wire _0803_;
 wire _0804_;
 wire _0805_;
 wire _0806_;
 wire _0807_;
 wire _0808_;
 wire _0809_;
 wire _0810_;
 wire _0811_;
 wire _0812_;
 wire _0813_;
 wire _0814_;
 wire _0815_;
 wire _0816_;
 wire _0817_;
 wire _0818_;
 wire _0819_;
 wire _0820_;
 wire _0821_;
 wire _0822_;
 wire _0823_;
 wire _0824_;
 wire _0825_;
 wire _0826_;
 wire _0827_;
 wire _0828_;
 wire _0829_;
 wire _0830_;
 wire _0831_;
 wire _0832_;
 wire _0833_;
 wire _0834_;
 wire _0835_;
 wire _0836_;
 wire _0837_;
 wire _0838_;
 wire _0839_;
 wire _0840_;
 wire _0841_;
 wire _0842_;
 wire _0843_;
 wire _0844_;
 wire _0845_;
 wire _0846_;
 wire _0847_;
 wire _0848_;
 wire _0849_;
 wire _0850_;
 wire _0851_;
 wire _0852_;
 wire _0853_;
 wire _0854_;
 wire _0855_;
 wire _0856_;
 wire _0857_;
 wire _0858_;
 wire _0859_;
 wire _0860_;
 wire _0861_;
 wire _0862_;
 wire _0863_;
 wire _0864_;
 wire _0865_;
 wire _0866_;
 wire _0867_;
 wire _0868_;
 wire _0869_;
 wire _0870_;
 wire _0871_;
 wire _0872_;
 wire _0873_;
 wire _0874_;
 wire _0875_;
 wire _0876_;
 wire _0877_;
 wire _0878_;
 wire _0879_;
 wire _0880_;
 wire _0881_;
 wire _0882_;
 wire _0883_;
 wire _0884_;
 wire _0885_;
 wire _0886_;
 wire _0887_;
 wire _0888_;
 wire _0889_;
 wire _0890_;
 wire _0891_;
 wire _0892_;
 wire _0893_;
 wire _0894_;
 wire _0895_;
 wire _0896_;
 wire _0897_;
 wire _0898_;
 wire _0899_;
 wire _0900_;
 wire _0901_;
 wire _0902_;
 wire _0903_;
 wire _0904_;
 wire _0905_;
 wire _0906_;
 wire _0907_;
 wire _0908_;
 wire _0909_;
 wire _0910_;
 wire _0911_;
 wire _0912_;
 wire _0913_;
 wire _0914_;
 wire _0915_;
 wire _0916_;
 wire _0917_;
 wire _0918_;
 wire _0919_;
 wire _0920_;
 wire _0921_;
 wire _0922_;
 wire _0923_;
 wire _0924_;
 wire _0925_;
 wire _0926_;
 wire _0927_;
 wire _0928_;
 wire _0929_;
 wire _0930_;
 wire _0931_;
 wire _0932_;
 wire _0933_;
 wire _0934_;
 wire _0935_;
 wire _0936_;
 wire _0937_;
 wire _0938_;
 wire _0939_;
 wire _0940_;
 wire _0941_;
 wire _0942_;
 wire _0943_;
 wire _0944_;
 wire _0945_;
 wire _0946_;
 wire _0947_;
 wire _0948_;
 wire _0949_;
 wire _0950_;
 wire _0951_;
 wire _0952_;
 wire _0953_;
 wire _0954_;
 wire _0955_;
 wire _0956_;
 wire _0957_;
 wire _0958_;
 wire _0959_;
 wire _0960_;
 wire _0961_;
 wire _0962_;
 wire _0963_;
 wire _0964_;
 wire _0965_;
 wire _0966_;
 wire _0967_;
 wire _0968_;
 wire _0969_;
 wire _0970_;
 wire _0971_;
 wire _0972_;
 wire _0973_;
 wire _0974_;
 wire _0975_;
 wire _0976_;
 wire _0977_;
 wire _0978_;
 wire _0979_;
 wire _0980_;
 wire _0981_;
 wire _0982_;
 wire _0983_;
 wire _0984_;
 wire _0985_;
 wire _0986_;
 wire _0987_;
 wire _0988_;
 wire _0989_;
 wire _0990_;
 wire _0991_;
 wire _0992_;
 wire _0993_;
 wire _0994_;
 wire _0995_;
 wire _0996_;
 wire _0997_;
 wire _0998_;
 wire _0999_;
 wire _1000_;
 wire _1001_;
 wire _1002_;
 wire _1003_;
 wire _1004_;
 wire _1005_;
 wire _1006_;
 wire _1007_;
 wire _1008_;
 wire _1009_;
 wire _1010_;
 wire _1011_;
 wire _1012_;
 wire _1013_;
 wire _1014_;
 wire _1015_;
 wire _1016_;
 wire _1017_;
 wire _1018_;
 wire _1019_;
 wire _1020_;
 wire _1021_;
 wire _1022_;
 wire _1023_;
 wire _1024_;
 wire _1025_;
 wire _1026_;
 wire _1027_;
 wire _1028_;
 wire _1029_;
 wire _1030_;
 wire _1031_;
 wire _1032_;
 wire _1033_;
 wire _1034_;
 wire _1035_;
 wire _1036_;
 wire _1037_;
 wire _1038_;
 wire _1039_;
 wire _1040_;
 wire _1041_;
 wire _1042_;
 wire _1043_;
 wire _1044_;
 wire _1045_;
 wire _1046_;
 wire _1047_;
 wire _1048_;
 wire _1049_;
 wire _1050_;
 wire _1051_;
 wire _1052_;
 wire _1053_;
 wire _1054_;
 wire _1055_;
 wire _1056_;
 wire _1057_;
 wire _1058_;
 wire _1059_;
 wire _1060_;
 wire _1061_;
 wire _1062_;
 wire _1063_;
 wire _1064_;
 wire _1065_;
 wire _1066_;
 wire _1067_;
 wire _1068_;
 wire _1069_;
 wire _1070_;
 wire _1071_;
 wire _1072_;
 wire _1073_;
 wire _1074_;
 wire _1075_;
 wire _1076_;
 wire _1077_;
 wire _1078_;
 wire _1079_;
 wire _1080_;
 wire _1081_;
 wire _1082_;
 wire _1083_;
 wire _1084_;
 wire _1085_;
 wire _1086_;
 wire _1087_;
 wire _1088_;
 wire _1089_;
 wire _1090_;
 wire _1091_;
 wire _1092_;
 wire _1093_;
 wire _1094_;
 wire _1095_;
 wire _1096_;
 wire _1097_;
 wire _1098_;
 wire _1099_;
 wire _1100_;
 wire _1101_;
 wire _1102_;
 wire _1103_;
 wire _1104_;
 wire _1105_;
 wire _1106_;
 wire _1107_;
 wire _1108_;
 wire _1109_;
 wire _1110_;
 wire _1111_;
 wire _1112_;
 wire _1113_;
 wire _1114_;
 wire _1115_;
 wire _1116_;
 wire _1117_;
 wire _1118_;
 wire _1119_;
 wire _1120_;
 wire _1121_;
 wire _1122_;
 wire _1123_;
 wire _1124_;
 wire _1125_;
 wire _1126_;
 wire _1127_;
 wire _1128_;
 wire _1129_;
 wire _1130_;
 wire _1131_;
 wire _1132_;
 wire _1133_;
 wire _1134_;
 wire _1135_;
 wire _1136_;
 wire _1137_;
 wire _1138_;
 wire _1139_;
 wire _1140_;
 wire _1141_;
 wire _1142_;
 wire _1143_;
 wire _1144_;
 wire _1145_;
 wire _1146_;
 wire _1147_;
 wire _1148_;
 wire _1149_;
 wire _1150_;
 wire _1151_;
 wire _1152_;
 wire _1153_;
 wire _1154_;
 wire _1155_;
 wire _1156_;
 wire _1157_;
 wire _1158_;
 wire _1159_;
 wire _1160_;
 wire _1161_;
 wire _1162_;
 wire _1163_;
 wire _1164_;
 wire _1165_;
 wire _1166_;
 wire _1167_;
 wire _1168_;
 wire _1169_;
 wire _1170_;
 wire _1171_;
 wire _1172_;
 wire _1173_;
 wire _1174_;
 wire _1175_;
 wire _1176_;
 wire _1177_;
 wire _1178_;
 wire _1179_;
 wire _1180_;
 wire _1181_;
 wire _1182_;
 wire _1183_;
 wire _1184_;
 wire _1185_;
 wire _1186_;
 wire _1187_;
 wire _1188_;
 wire _1189_;
 wire _1190_;
 wire _1191_;
 wire _1192_;
 wire _1193_;
 wire _1194_;
 wire _1195_;
 wire _1196_;
 wire _1197_;
 wire _1198_;
 wire _1199_;
 wire _1200_;
 wire _1201_;
 wire _1202_;
 wire _1203_;
 wire _1204_;
 wire _1205_;
 wire _1206_;
 wire _1207_;
 wire _1208_;
 wire _1209_;
 wire _1210_;
 wire _1211_;
 wire _1212_;
 wire _1213_;
 wire _1214_;
 wire _1215_;
 wire _1216_;
 wire _1217_;
 wire _1218_;
 wire _1219_;
 wire _1220_;
 wire _1221_;
 wire _1222_;
 wire _1223_;
 wire _1224_;
 wire _1225_;
 wire _1226_;
 wire _1227_;
 wire _1228_;
 wire _1229_;
 wire _1230_;
 wire _1231_;
 wire _1232_;
 wire _1233_;
 wire _1234_;
 wire _1235_;
 wire _1236_;
 wire _1237_;
 wire _1238_;
 wire _1239_;
 wire _1240_;
 wire _1241_;
 wire _1242_;
 wire _1243_;
 wire _1244_;
 wire _1245_;
 wire _1246_;
 wire _1247_;
 wire _1248_;
 wire _1249_;
 wire _1250_;
 wire _1251_;
 wire _1252_;
 wire _1253_;
 wire _1254_;
 wire _1255_;
 wire _1256_;
 wire _1257_;
 wire _1258_;
 wire _1259_;
 wire _1260_;
 wire _1261_;
 wire _1262_;
 wire _1263_;
 wire _1264_;
 wire _1265_;
 wire _1266_;
 wire _1267_;
 wire _1268_;
 wire _1269_;
 wire _1270_;
 wire _1271_;
 wire _1272_;
 wire _1273_;
 wire _1274_;
 wire _1275_;
 wire _1276_;
 wire _1277_;
 wire _1278_;
 wire _1279_;
 wire _1280_;
 wire _1281_;
 wire _1282_;
 wire _1283_;
 wire _1284_;
 wire _1285_;
 wire _1286_;
 wire _1287_;
 wire _1288_;
 wire _1289_;
 wire _1290_;
 wire _1291_;
 wire _1292_;
 wire _1293_;
 wire _1294_;
 wire _1295_;
 wire _1296_;
 wire _1297_;
 wire _1298_;
 wire _1299_;
 wire _1300_;
 wire _1301_;
 wire _1302_;
 wire _1303_;
 wire _1304_;
 wire _1305_;
 wire _1306_;
 wire _1307_;
 wire _1308_;
 wire _1309_;
 wire _1310_;
 wire _1311_;
 wire _1312_;
 wire _1313_;
 wire _1314_;
 wire _1315_;
 wire _1316_;
 wire _1317_;
 wire _1318_;
 wire _1319_;
 wire _1320_;
 wire _1321_;
 wire _1322_;
 wire _1323_;
 wire _1324_;
 wire _1325_;
 wire _1326_;
 wire _1327_;
 wire _1328_;
 wire _1329_;
 wire _1330_;
 wire _1331_;
 wire _1332_;
 wire _1333_;
 wire _1334_;
 wire _1335_;
 wire _1336_;
 wire _1337_;
 wire _1338_;
 wire _1339_;
 wire _1340_;
 wire _1341_;
 wire _1342_;
 wire _1343_;
 wire _1344_;
 wire _1345_;
 wire _1346_;
 wire _1347_;
 wire _1348_;
 wire _1349_;
 wire _1350_;
 wire _1351_;
 wire _1352_;
 wire _1353_;
 wire _1354_;
 wire _1355_;
 wire _1356_;
 wire _1357_;
 wire _1358_;
 wire _1359_;
 wire _1360_;
 wire _1361_;
 wire _1362_;
 wire _1363_;
 wire _1364_;
 wire _1365_;
 wire _1366_;
 wire _1367_;
 wire _1368_;
 wire _1369_;
 wire _1370_;
 wire _1371_;
 wire _1372_;
 wire _1373_;
 wire _1374_;
 wire _1375_;
 wire _1376_;
 wire _1377_;
 wire _1378_;
 wire _1379_;
 wire _1380_;
 wire _1381_;
 wire _1382_;
 wire _1383_;
 wire _1384_;
 wire _1385_;
 wire _1386_;
 wire _1387_;
 wire _1388_;
 wire _1389_;
 wire _1390_;
 wire _1391_;
 wire _1392_;
 wire _1393_;
 wire _1394_;
 wire _1395_;
 wire _1396_;
 wire _1397_;
 wire _1398_;
 wire _1399_;
 wire _1400_;
 wire _1401_;
 wire _1402_;
 wire _1403_;
 wire _1404_;
 wire _1405_;
 wire _1406_;
 wire _1407_;
 wire _1408_;
 wire _1409_;
 wire _1410_;
 wire _1411_;
 wire _1412_;
 wire _1413_;
 wire _1414_;
 wire _1415_;
 wire _1416_;
 wire _1417_;
 wire _1418_;
 wire _1419_;
 wire _1420_;
 wire _1421_;
 wire _1422_;
 wire _1423_;
 wire _1424_;
 wire _1425_;
 wire _1426_;
 wire _1427_;
 wire _1428_;
 wire _1429_;
 wire _1430_;
 wire _1431_;
 wire _1432_;
 wire _1433_;
 wire _1434_;
 wire _1435_;
 wire _1436_;
 wire _1437_;
 wire _1438_;
 wire _1439_;
 wire _1440_;
 wire _1441_;
 wire _1442_;
 wire _1443_;
 wire _1444_;
 wire _1445_;
 wire _1446_;
 wire _1447_;
 wire _1448_;
 wire _1449_;
 wire _1450_;
 wire _1451_;
 wire _1452_;
 wire _1453_;
 wire _1454_;
 wire _1455_;
 wire _1456_;
 wire _1457_;
 wire _1458_;
 wire _1459_;
 wire _1460_;
 wire _1461_;
 wire _1462_;
 wire _1463_;
 wire _1464_;
 wire _1465_;
 wire _1466_;
 wire _1467_;
 wire _1468_;
 wire _1469_;
 wire _1470_;
 wire _1471_;
 wire _1472_;
 wire _1473_;
 wire _1474_;
 wire _1475_;
 wire _1476_;
 wire _1477_;
 wire _1478_;
 wire _1479_;
 wire _1480_;
 wire _1481_;
 wire _1482_;
 wire _1483_;
 wire _1484_;
 wire _1485_;
 wire _1486_;
 wire _1487_;
 wire _1488_;
 wire _1489_;
 wire _1490_;
 wire _1491_;
 wire _1492_;
 wire _1493_;
 wire _1494_;
 wire _1495_;
 wire _1496_;
 wire _1497_;
 wire _1498_;
 wire _1499_;
 wire _1500_;
 wire _1501_;
 wire _1502_;
 wire _1503_;
 wire _1504_;
 wire _1505_;
 wire _1506_;
 wire _1507_;
 wire _1508_;
 wire _1509_;
 wire _1510_;
 wire _1511_;
 wire _1512_;
 wire _1513_;
 wire _1514_;
 wire _1515_;
 wire _1516_;
 wire _1517_;
 wire _1518_;
 wire _1519_;
 wire _1520_;
 wire _1521_;
 wire _1522_;
 wire _1523_;
 wire _1524_;
 wire _1525_;
 wire _1526_;
 wire _1527_;
 wire _1528_;
 wire _1529_;
 wire _1530_;
 wire _1531_;
 wire _1532_;
 wire _1533_;
 wire _1534_;
 wire _1535_;
 wire _1536_;
 wire _1537_;
 wire _1538_;
 wire _1539_;
 wire _1540_;
 wire _1541_;
 wire _1542_;
 wire _1543_;
 wire _1544_;
 wire _1545_;
 wire _1546_;
 wire _1547_;
 wire _1548_;
 wire _1549_;
 wire _1550_;
 wire _1551_;
 wire _1552_;
 wire _1553_;
 wire _1554_;
 wire _1555_;
 wire _1556_;
 wire _1557_;
 wire _1558_;
 wire _1559_;
 wire _1560_;
 wire _1561_;
 wire _1562_;
 wire _1563_;
 wire _1564_;
 wire _1565_;
 wire _1566_;
 wire _1567_;
 wire _1568_;
 wire _1569_;
 wire _1570_;
 wire _1571_;
 wire _1572_;
 wire _1573_;
 wire _1574_;
 wire _1575_;
 wire _1576_;
 wire _1577_;
 wire _1578_;
 wire _1579_;
 wire _1580_;
 wire _1581_;
 wire _1582_;
 wire _1583_;
 wire _1584_;
 wire _1585_;
 wire _1586_;
 wire _1587_;
 wire _1588_;
 wire _1589_;
 wire _1590_;
 wire _1591_;
 wire _1592_;
 wire _1593_;
 wire _1594_;
 wire _1595_;
 wire _1596_;
 wire _1597_;
 wire _1598_;
 wire _1599_;
 wire _1600_;
 wire _1601_;
 wire _1602_;
 wire _1603_;
 wire _1604_;
 wire _1605_;
 wire _1606_;
 wire _1607_;
 wire _1608_;
 wire _1609_;
 wire _1610_;
 wire _1611_;
 wire _1612_;
 wire _1613_;
 wire _1614_;
 wire _1615_;
 wire _1616_;
 wire _1617_;
 wire _1618_;
 wire _1619_;
 wire _1620_;
 wire _1621_;
 wire _1622_;
 wire _1623_;
 wire _1624_;
 wire _1625_;
 wire _1626_;
 wire _1627_;
 wire _1628_;
 wire _1629_;
 wire _1630_;
 wire _1631_;
 wire _1632_;
 wire _1633_;
 wire _1634_;
 wire _1635_;
 wire _1636_;
 wire _1637_;
 wire _1638_;
 wire _1639_;
 wire _1640_;
 wire _1641_;
 wire _1642_;
 wire _1643_;
 wire _1644_;
 wire _1645_;
 wire _1646_;
 wire _1647_;
 wire _1648_;
 wire _1649_;
 wire _1650_;
 wire _1651_;
 wire _1652_;
 wire _1653_;
 wire _1654_;
 wire _1655_;
 wire _1656_;
 wire _1657_;
 wire _1658_;
 wire _1659_;
 wire _1660_;
 wire _1661_;
 wire _1662_;
 wire _1663_;
 wire _1664_;
 wire _1665_;
 wire _1666_;
 wire _1667_;
 wire _1668_;
 wire _1669_;
 wire _1670_;
 wire _1671_;
 wire _1672_;
 wire _1673_;
 wire _1674_;
 wire _1675_;
 wire _1676_;
 wire _1677_;
 wire _1678_;
 wire _1679_;
 wire _1680_;
 wire _1681_;
 wire _1682_;
 wire _1683_;
 wire _1684_;
 wire _1685_;
 wire _1686_;
 wire _1687_;
 wire _1688_;
 wire _1689_;
 wire _1690_;
 wire _1691_;
 wire _1692_;
 wire _1693_;
 wire _1694_;
 wire _1695_;
 wire _1696_;
 wire _1697_;
 wire _1698_;
 wire _1699_;
 wire _1700_;
 wire _1701_;
 wire _1702_;
 wire _1703_;
 wire _1704_;
 wire _1705_;
 wire _1706_;
 wire _1707_;
 wire _1708_;
 wire _1709_;
 wire _1710_;
 wire _1711_;
 wire _1712_;
 wire _1713_;
 wire _1714_;
 wire _1715_;
 wire _1716_;
 wire _1717_;
 wire _1718_;
 wire _1719_;
 wire _1720_;
 wire _1721_;
 wire _1722_;
 wire _1723_;
 wire _1724_;
 wire _1725_;
 wire _1726_;
 wire _1727_;
 wire _1728_;
 wire _1729_;
 wire _1730_;
 wire _1731_;
 wire _1732_;
 wire _1733_;
 wire _1734_;
 wire _1735_;
 wire _1736_;
 wire _1737_;
 wire _1738_;
 wire _1739_;
 wire _1740_;
 wire _1741_;
 wire _1742_;
 wire _1743_;
 wire _1744_;
 wire _1745_;
 wire _1746_;
 wire _1747_;
 wire _1748_;
 wire _1749_;
 wire _1750_;
 wire _1751_;
 wire _1752_;
 wire _1753_;
 wire _1754_;
 wire _1755_;
 wire _1756_;
 wire _1757_;
 wire _1758_;
 wire _1759_;
 wire _1760_;
 wire _1761_;
 wire _1762_;
 wire _1763_;
 wire _1764_;
 wire _1765_;
 wire _1766_;
 wire _1767_;
 wire _1768_;
 wire _1769_;
 wire _1770_;
 wire _1771_;
 wire _1772_;
 wire _1773_;
 wire _1774_;
 wire _1775_;
 wire _1776_;
 wire _1777_;
 wire _1778_;
 wire _1779_;
 wire _1780_;
 wire _1781_;
 wire _1782_;
 wire _1783_;
 wire _1784_;
 wire _1785_;
 wire _1786_;
 wire _1787_;
 wire _1788_;
 wire _1789_;
 wire _1790_;
 wire _1791_;
 wire _1792_;
 wire _1793_;
 wire _1794_;
 wire _1795_;
 wire _1796_;
 wire _1797_;
 wire _1798_;
 wire _1799_;
 wire _1800_;
 wire _1801_;
 wire _1802_;
 wire _1803_;
 wire _1804_;
 wire _1805_;
 wire _1806_;
 wire _1807_;
 wire _1808_;
 wire _1809_;
 wire _1810_;
 wire _1811_;
 wire _1812_;
 wire _1813_;
 wire _1814_;
 wire _1815_;
 wire _1816_;
 wire _1817_;
 wire _1818_;
 wire _1819_;
 wire _1820_;
 wire _1821_;
 wire _1822_;
 wire _1823_;
 wire _1824_;
 wire _1825_;
 wire _1826_;
 wire _1827_;
 wire _1828_;
 wire _1829_;
 wire _1830_;
 wire _1831_;
 wire _1832_;
 wire _1833_;
 wire _1834_;
 wire _1835_;
 wire _1836_;
 wire _1837_;
 wire _1838_;
 wire _1839_;
 wire _1840_;
 wire _1841_;
 wire _1842_;
 wire _1843_;
 wire _1844_;
 wire _1845_;
 wire _1846_;
 wire _1847_;
 wire _1848_;
 wire _1849_;
 wire _1850_;
 wire _1851_;
 wire _1852_;
 wire _1853_;
 wire _1854_;
 wire _1855_;
 wire _1856_;
 wire _1857_;
 wire _1858_;
 wire _1859_;
 wire _1860_;
 wire _1861_;
 wire _1862_;
 wire _1863_;
 wire _1864_;
 wire _1865_;
 wire _1866_;
 wire _1867_;
 wire _1868_;
 wire _1869_;
 wire _1870_;
 wire _1871_;
 wire _1872_;
 wire _1873_;
 wire _1874_;
 wire _1875_;
 wire _1876_;
 wire _1877_;
 wire _1878_;
 wire _1879_;
 wire _1880_;
 wire _1881_;
 wire _1882_;
 wire _1883_;
 wire _1884_;
 wire _1885_;
 wire _1886_;
 wire _1887_;
 wire _1888_;
 wire _1889_;
 wire _1890_;
 wire _1891_;
 wire _1892_;
 wire _1893_;
 wire _1894_;
 wire _1895_;
 wire _1896_;
 wire _1897_;
 wire _1898_;
 wire _1899_;
 wire _1900_;
 wire _1901_;
 wire _1902_;
 wire _1903_;
 wire _1904_;
 wire _1905_;
 wire _1906_;
 wire _1907_;
 wire _1908_;
 wire _1909_;
 wire _1910_;
 wire _1911_;
 wire _1912_;
 wire _1913_;
 wire _1914_;
 wire _1915_;
 wire _1916_;
 wire _1917_;
 wire _1918_;
 wire _1919_;
 wire _1920_;
 wire _1921_;
 wire _1922_;
 wire _1923_;
 wire _1924_;
 wire _1925_;
 wire _1926_;
 wire _1927_;
 wire _1928_;
 wire _1929_;
 wire _1930_;
 wire _1931_;
 wire _1932_;
 wire _1933_;
 wire _1934_;
 wire _1935_;
 wire _1936_;
 wire _1937_;
 wire _1938_;
 wire _1939_;
 wire _1940_;
 wire _1941_;
 wire _1942_;
 wire _1943_;
 wire _1944_;
 wire _1945_;
 wire _1946_;
 wire _1947_;
 wire _1948_;
 wire _1949_;
 wire _1950_;
 wire _1951_;
 wire _1952_;
 wire _1953_;
 wire _1954_;
 wire _1955_;
 wire _1956_;
 wire _1957_;
 wire _1958_;
 wire _1959_;
 wire _1960_;
 wire _1961_;
 wire _1962_;
 wire _1963_;
 wire _1964_;
 wire _1965_;
 wire _1966_;
 wire _1967_;
 wire _1968_;
 wire _1969_;
 wire _1970_;
 wire _1971_;
 wire _1972_;
 wire _1973_;
 wire _1974_;
 wire _1975_;
 wire _1976_;
 wire _1977_;
 wire _1978_;
 wire _1979_;
 wire _1980_;
 wire _1981_;
 wire _1982_;
 wire _1983_;
 wire _1984_;
 wire _1985_;
 wire _1986_;
 wire _1987_;
 wire _1988_;
 wire _1989_;
 wire _1990_;
 wire _1991_;
 wire _1992_;
 wire _1993_;
 wire _1994_;
 wire _1995_;
 wire _1996_;
 wire _1997_;
 wire _1998_;
 wire _1999_;
 wire _2000_;
 wire _2001_;
 wire _2002_;
 wire _2003_;
 wire _2004_;
 wire _2005_;
 wire _2006_;
 wire _2007_;
 wire _2008_;
 wire _2009_;
 wire _2010_;
 wire _2011_;
 wire _2012_;
 wire _2013_;
 wire _2014_;
 wire _2015_;
 wire _2016_;
 wire _2017_;
 wire _2018_;
 wire _2019_;
 wire _2020_;
 wire _2021_;
 wire _2022_;
 wire _2023_;
 wire _2024_;
 wire _2025_;
 wire _2026_;
 wire _2027_;
 wire _2028_;
 wire _2029_;
 wire _2030_;
 wire _2031_;
 wire _2032_;
 wire _2033_;
 wire _2034_;
 wire _2035_;
 wire _2036_;
 wire _2037_;
 wire _2038_;
 wire _2039_;
 wire _2040_;
 wire _2041_;
 wire _2042_;
 wire _2043_;
 wire _2044_;
 wire _2045_;
 wire _2046_;
 wire _2047_;
 wire _2048_;
 wire _2049_;
 wire _2050_;
 wire _2051_;
 wire _2052_;
 wire _2053_;
 wire _2054_;
 wire _2055_;
 wire _2056_;
 wire _2057_;
 wire _2058_;
 wire _2059_;
 wire _2060_;
 wire _2061_;
 wire _2062_;
 wire _2063_;
 wire _2064_;
 wire _2065_;
 wire _2066_;
 wire _2067_;
 wire _2068_;
 wire _2069_;
 wire _2070_;
 wire _2071_;
 wire _2072_;
 wire _2073_;
 wire _2074_;
 wire _2075_;
 wire _2076_;
 wire _2077_;
 wire _2078_;
 wire _2079_;
 wire _2080_;
 wire _2081_;
 wire _2082_;
 wire _2083_;
 wire _2084_;
 wire _2085_;
 wire _2086_;
 wire _2087_;
 wire \clean_run_target[0] ;
 wire \clean_run_target[10] ;
 wire \clean_run_target[11] ;
 wire \clean_run_target[12] ;
 wire \clean_run_target[13] ;
 wire \clean_run_target[14] ;
 wire \clean_run_target[15] ;
 wire \clean_run_target[16] ;
 wire \clean_run_target[17] ;
 wire \clean_run_target[18] ;
 wire \clean_run_target[1] ;
 wire \clean_run_target[2] ;
 wire \clean_run_target[3] ;
 wire \clean_run_target[4] ;
 wire \clean_run_target[5] ;
 wire \clean_run_target[6] ;
 wire \clean_run_target[7] ;
 wire \clean_run_target[8] ;
 wire \clean_run_target[9] ;
 wire cs_n_filt;
 wire cs_n_sync;
 wire \cycles_per_step[0] ;
 wire \cycles_per_step[1] ;
 wire \cycles_per_step[2] ;
 wire \cycles_per_step[3] ;
 wire \cycles_per_step[4] ;
 wire \cycles_per_step[5] ;
 wire \cycles_per_step[6] ;
 wire \duty_count[0] ;
 wire \duty_count[1] ;
 wire \duty_count[2] ;
 wire \duty_count[3] ;
 wire \duty_count[4] ;
 wire \duty_count[5] ;
 wire en_from_switch_sync;
 wire en_from_switch_sync_db;
 wire en_from_switch_sync_db_d;
 wire \fault_count_run[0] ;
 wire \fault_count_run[1] ;
 wire \fault_count_run[2] ;
 wire \fault_count_run[3] ;
 wire \fault_count_run[4] ;
 wire \fault_count_ss[0] ;
 wire \fault_count_ss[1] ;
 wire \fault_count_ss[2] ;
 wire \fault_count_ss[3] ;
 wire \fault_count_ss[4] ;
 wire \fault_count_ss[5] ;
 wire \fault_reg[0] ;
 wire \fault_reg[1] ;
 wire \fault_reg[2] ;
 wire \fault_reg[3] ;
 wire \fault_reg[4] ;
 wire \fault_time[0] ;
 wire \fault_time[10] ;
 wire \fault_time[11] ;
 wire \fault_time[12] ;
 wire \fault_time[13] ;
 wire \fault_time[14] ;
 wire \fault_time[15] ;
 wire \fault_time[16] ;
 wire \fault_time[17] ;
 wire \fault_time[18] ;
 wire \fault_time[19] ;
 wire \fault_time[1] ;
 wire \fault_time[20] ;
 wire \fault_time[21] ;
 wire \fault_time[22] ;
 wire \fault_time[23] ;
 wire \fault_time[2] ;
 wire \fault_time[3] ;
 wire \fault_time[4] ;
 wire \fault_time[5] ;
 wire \fault_time[6] ;
 wire \fault_time[7] ;
 wire \fault_time[8] ;
 wire \fault_time[9] ;
 wire \g_spi_filt.u_cs_filt.disagree_counter[0] ;
 wire \g_spi_filt.u_cs_filt.disagree_counter[1] ;
 wire \g_spi_filt.u_cs_filt.disagree_counter[2] ;
 wire \g_spi_filt.u_cs_filt.disagree_counter[3] ;
 wire \g_spi_filt.u_cs_filt.rst_n ;
 wire net2;
 wire \g_spi_filt.u_mosi_filt.disagree_counter[0] ;
 wire \g_spi_filt.u_mosi_filt.disagree_counter[1] ;
 wire \g_spi_filt.u_mosi_filt.disagree_counter[2] ;
 wire \g_spi_filt.u_mosi_filt.disagree_counter[3] ;
 wire \g_spi_filt.u_mosi_filt.flag_in ;
 wire \g_spi_filt.u_mosi_filt.flag_out ;
 wire \g_spi_filt.u_sck_filt.disagree_counter[0] ;
 wire \g_spi_filt.u_sck_filt.disagree_counter[1] ;
 wire \g_spi_filt.u_sck_filt.disagree_counter[2] ;
 wire \g_spi_filt.u_sck_filt.disagree_counter[3] ;
 wire \g_spi_filt.u_sck_filt.flag_in ;
 wire \g_spi_filt.u_sck_filt.flag_out ;
 wire \g_spi_sync.u_cs_sync.meta_ff ;
 wire \g_spi_sync.u_mosi_sync.meta_ff ;
 wire \g_spi_sync.u_sck_sync.meta_ff ;
 wire \g_telemetry.u_fault_cause.latch_state ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[0] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[10] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[11] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[12] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[13] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[14] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[15] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[16] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[17] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[18] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[19] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[1] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[20] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[21] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[22] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[23] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[2] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[3] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[4] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[5] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[6] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[7] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[8] ;
 wire \g_telemetry.u_fault_cause.timestamp_ms[9] ;
 wire \g_telemetry.u_pwm_stats.period_counter[0] ;
 wire \g_telemetry.u_pwm_stats.period_counter[1] ;
 wire \g_telemetry.u_pwm_stats.period_counter[2] ;
 wire \g_telemetry.u_pwm_stats.period_counter[3] ;
 wire \g_telemetry.u_pwm_stats.period_counter[4] ;
 wire \g_telemetry.u_pwm_stats.period_counter[5] ;
 wire \g_telemetry.u_pwm_stats.prev_period[0] ;
 wire \g_telemetry.u_pwm_stats.prev_period[1] ;
 wire \g_telemetry.u_pwm_stats.prev_period[2] ;
 wire \g_telemetry.u_pwm_stats.prev_period[3] ;
 wire \g_telemetry.u_pwm_stats.prev_period[4] ;
 wire \g_telemetry.u_pwm_stats.prev_period[5] ;
 wire \g_telemetry.u_pwm_stats.pwm_sync_d ;
 wire \g_telemetry.u_reg_file.abort ;
 wire \g_telemetry.u_reg_file.addr[0] ;
 wire \g_telemetry.u_reg_file.addr[1] ;
 wire \g_telemetry.u_reg_file.addr[2] ;
 wire \g_telemetry.u_reg_file.addr[3] ;
 wire \g_telemetry.u_reg_file.addr[4] ;
 wire \g_telemetry.u_reg_file.addr[5] ;
 wire \g_telemetry.u_reg_file.addr[6] ;
 wire \g_telemetry.u_reg_file.arm_timer[0] ;
 wire \g_telemetry.u_reg_file.arm_timer[10] ;
 wire \g_telemetry.u_reg_file.arm_timer[11] ;
 wire \g_telemetry.u_reg_file.arm_timer[12] ;
 wire \g_telemetry.u_reg_file.arm_timer[13] ;
 wire \g_telemetry.u_reg_file.arm_timer[14] ;
 wire \g_telemetry.u_reg_file.arm_timer[15] ;
 wire \g_telemetry.u_reg_file.arm_timer[1] ;
 wire \g_telemetry.u_reg_file.arm_timer[2] ;
 wire \g_telemetry.u_reg_file.arm_timer[3] ;
 wire \g_telemetry.u_reg_file.arm_timer[4] ;
 wire \g_telemetry.u_reg_file.arm_timer[5] ;
 wire \g_telemetry.u_reg_file.arm_timer[6] ;
 wire \g_telemetry.u_reg_file.arm_timer[7] ;
 wire \g_telemetry.u_reg_file.arm_timer[8] ;
 wire \g_telemetry.u_reg_file.arm_timer[9] ;
 wire \g_telemetry.u_reg_file.bus_err_count[0] ;
 wire \g_telemetry.u_reg_file.bus_err_count[10] ;
 wire \g_telemetry.u_reg_file.bus_err_count[11] ;
 wire \g_telemetry.u_reg_file.bus_err_count[12] ;
 wire \g_telemetry.u_reg_file.bus_err_count[13] ;
 wire \g_telemetry.u_reg_file.bus_err_count[14] ;
 wire \g_telemetry.u_reg_file.bus_err_count[15] ;
 wire \g_telemetry.u_reg_file.bus_err_count[1] ;
 wire \g_telemetry.u_reg_file.bus_err_count[2] ;
 wire \g_telemetry.u_reg_file.bus_err_count[3] ;
 wire \g_telemetry.u_reg_file.bus_err_count[4] ;
 wire \g_telemetry.u_reg_file.bus_err_count[5] ;
 wire \g_telemetry.u_reg_file.bus_err_count[6] ;
 wire \g_telemetry.u_reg_file.bus_err_count[7] ;
 wire \g_telemetry.u_reg_file.bus_err_count[8] ;
 wire \g_telemetry.u_reg_file.bus_err_count[9] ;
 wire \g_telemetry.u_reg_file.disable_armed ;
 wire \g_telemetry.u_reg_file.en_pending ;
 wire \g_telemetry.u_reg_file.en_pending_val ;
 wire \g_telemetry.u_reg_file.hiccup_base[0] ;
 wire \g_telemetry.u_reg_file.hiccup_base[10] ;
 wire \g_telemetry.u_reg_file.hiccup_base[11] ;
 wire \g_telemetry.u_reg_file.hiccup_base[12] ;
 wire \g_telemetry.u_reg_file.hiccup_base[13] ;
 wire \g_telemetry.u_reg_file.hiccup_base[14] ;
 wire \g_telemetry.u_reg_file.hiccup_base[15] ;
 wire \g_telemetry.u_reg_file.hiccup_base[16] ;
 wire \g_telemetry.u_reg_file.hiccup_base[17] ;
 wire \g_telemetry.u_reg_file.hiccup_base[1] ;
 wire \g_telemetry.u_reg_file.hiccup_base[2] ;
 wire \g_telemetry.u_reg_file.hiccup_base[3] ;
 wire \g_telemetry.u_reg_file.hiccup_base[4] ;
 wire \g_telemetry.u_reg_file.hiccup_base[5] ;
 wire \g_telemetry.u_reg_file.hiccup_base[6] ;
 wire \g_telemetry.u_reg_file.hiccup_base[7] ;
 wire \g_telemetry.u_reg_file.hiccup_base[8] ;
 wire \g_telemetry.u_reg_file.hiccup_base[9] ;
 wire \g_telemetry.u_reg_file.integrity_OK ;
 wire \g_telemetry.u_reg_file.max_on_limit[0] ;
 wire \g_telemetry.u_reg_file.max_on_limit[1] ;
 wire \g_telemetry.u_reg_file.max_on_limit[2] ;
 wire \g_telemetry.u_reg_file.max_on_limit[3] ;
 wire \g_telemetry.u_reg_file.max_on_limit[4] ;
 wire \g_telemetry.u_reg_file.max_strikes[0] ;
 wire \g_telemetry.u_reg_file.max_strikes[1] ;
 wire \g_telemetry.u_reg_file.scratch_r[0] ;
 wire \g_telemetry.u_reg_file.scratch_r[1] ;
 wire \g_telemetry.u_reg_file.scratch_r[2] ;
 wire \g_telemetry.u_reg_file.scratch_r[3] ;
 wire \g_telemetry.u_reg_file.scratch_r[4] ;
 wire \g_telemetry.u_reg_file.scratch_r[5] ;
 wire \g_telemetry.u_reg_file.scratch_r[6] ;
 wire \g_telemetry.u_reg_file.scratch_r[7] ;
 wire \g_telemetry.u_reg_file.spi_enable ;
 wire \g_telemetry.u_reg_file.strike_level[0] ;
 wire \g_telemetry.u_reg_file.strike_level[1] ;
 wire \g_telemetry.u_reg_file.sup_state[0] ;
 wire \g_telemetry.u_reg_file.sup_state[1] ;
 wire \g_telemetry.u_reg_file.temp_clean_0[0] ;
 wire \g_telemetry.u_reg_file.temp_clean_0[1] ;
 wire \g_telemetry.u_reg_file.temp_clean_0[2] ;
 wire \g_telemetry.u_reg_file.temp_clean_0[3] ;
 wire \g_telemetry.u_reg_file.temp_clean_0[4] ;
 wire \g_telemetry.u_reg_file.temp_clean_0[5] ;
 wire \g_telemetry.u_reg_file.temp_clean_0[6] ;
 wire \g_telemetry.u_reg_file.temp_clean_0[7] ;
 wire \g_telemetry.u_reg_file.temp_clean_1[0] ;
 wire \g_telemetry.u_reg_file.temp_clean_1[1] ;
 wire \g_telemetry.u_reg_file.temp_clean_1[2] ;
 wire \g_telemetry.u_reg_file.temp_clean_1[3] ;
 wire \g_telemetry.u_reg_file.temp_clean_1[4] ;
 wire \g_telemetry.u_reg_file.temp_clean_1[5] ;
 wire \g_telemetry.u_reg_file.temp_clean_1[6] ;
 wire \g_telemetry.u_reg_file.temp_clean_1[7] ;
 wire \g_telemetry.u_reg_file.temp_clean_2[0] ;
 wire \g_telemetry.u_reg_file.temp_clean_2[1] ;
 wire \g_telemetry.u_reg_file.temp_clean_2[2] ;
 wire \g_telemetry.u_reg_file.temp_clean_2[3] ;
 wire \g_telemetry.u_reg_file.temp_clean_2[4] ;
 wire \g_telemetry.u_reg_file.temp_clean_2[5] ;
 wire \g_telemetry.u_reg_file.temp_clean_2[6] ;
 wire \g_telemetry.u_reg_file.temp_clean_2[7] ;
 wire \g_telemetry.u_reg_file.temp_cyc_step[0] ;
 wire \g_telemetry.u_reg_file.temp_cyc_step[1] ;
 wire \g_telemetry.u_reg_file.temp_cyc_step[2] ;
 wire \g_telemetry.u_reg_file.temp_cyc_step[3] ;
 wire \g_telemetry.u_reg_file.temp_cyc_step[4] ;
 wire \g_telemetry.u_reg_file.temp_cyc_step[5] ;
 wire \g_telemetry.u_reg_file.temp_cyc_step[6] ;
 wire \g_telemetry.u_reg_file.temp_cyc_step[7] ;
 wire \g_telemetry.u_reg_file.temp_dirty[0] ;
 wire \g_telemetry.u_reg_file.temp_dirty[10] ;
 wire \g_telemetry.u_reg_file.temp_dirty[1] ;
 wire \g_telemetry.u_reg_file.temp_dirty[2] ;
 wire \g_telemetry.u_reg_file.temp_dirty[3] ;
 wire \g_telemetry.u_reg_file.temp_dirty[4] ;
 wire \g_telemetry.u_reg_file.temp_dirty[5] ;
 wire \g_telemetry.u_reg_file.temp_dirty[6] ;
 wire \g_telemetry.u_reg_file.temp_dirty[7] ;
 wire \g_telemetry.u_reg_file.temp_dirty[8] ;
 wire \g_telemetry.u_reg_file.temp_dirty[9] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_0[0] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_0[1] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_0[2] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_0[3] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_0[4] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_0[5] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_0[6] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_0[7] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_1[0] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_1[1] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_1[2] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_1[3] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_1[4] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_1[5] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_1[6] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_1[7] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_2[0] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_2[1] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_2[2] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_2[3] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_2[4] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_2[5] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_2[6] ;
 wire \g_telemetry.u_reg_file.temp_hiccup_2[7] ;
 wire \g_telemetry.u_reg_file.temp_max_on[0] ;
 wire \g_telemetry.u_reg_file.temp_max_on[1] ;
 wire \g_telemetry.u_reg_file.temp_max_on[2] ;
 wire \g_telemetry.u_reg_file.temp_max_on[3] ;
 wire \g_telemetry.u_reg_file.temp_max_on[4] ;
 wire \g_telemetry.u_reg_file.temp_max_on[5] ;
 wire \g_telemetry.u_reg_file.temp_max_on[6] ;
 wire \g_telemetry.u_reg_file.temp_max_on[7] ;
 wire \g_telemetry.u_reg_file.temp_max_strk[0] ;
 wire \g_telemetry.u_reg_file.temp_max_strk[1] ;
 wire \g_telemetry.u_reg_file.temp_max_strk[2] ;
 wire \g_telemetry.u_reg_file.temp_max_strk[3] ;
 wire \g_telemetry.u_reg_file.temp_max_strk[4] ;
 wire \g_telemetry.u_reg_file.temp_max_strk[5] ;
 wire \g_telemetry.u_reg_file.temp_max_strk[6] ;
 wire \g_telemetry.u_reg_file.temp_max_strk[7] ;
 wire \g_telemetry.u_reg_file.temp_trip_run[0] ;
 wire \g_telemetry.u_reg_file.temp_trip_run[1] ;
 wire \g_telemetry.u_reg_file.temp_trip_run[2] ;
 wire \g_telemetry.u_reg_file.temp_trip_run[3] ;
 wire \g_telemetry.u_reg_file.temp_trip_run[4] ;
 wire \g_telemetry.u_reg_file.temp_trip_run[5] ;
 wire \g_telemetry.u_reg_file.temp_trip_run[6] ;
 wire \g_telemetry.u_reg_file.temp_trip_run[7] ;
 wire \g_telemetry.u_reg_file.temp_trip_ss[0] ;
 wire \g_telemetry.u_reg_file.temp_trip_ss[1] ;
 wire \g_telemetry.u_reg_file.temp_trip_ss[2] ;
 wire \g_telemetry.u_reg_file.temp_trip_ss[3] ;
 wire \g_telemetry.u_reg_file.temp_trip_ss[4] ;
 wire \g_telemetry.u_reg_file.temp_trip_ss[5] ;
 wire \g_telemetry.u_reg_file.temp_trip_ss[6] ;
 wire \g_telemetry.u_reg_file.temp_trip_ss[7] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[0] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[10] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[11] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[12] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[13] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[14] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[15] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[16] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[17] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[18] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[19] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[1] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[20] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[21] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[22] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[23] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[2] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[3] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[4] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[5] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[6] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[7] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[8] ;
 wire \g_telemetry.u_reg_file.timestamp_snap[9] ;
 wire \g_telemetry.u_reg_file.trip_run[0] ;
 wire \g_telemetry.u_reg_file.trip_run[1] ;
 wire \g_telemetry.u_reg_file.trip_run[2] ;
 wire \g_telemetry.u_reg_file.trip_run[3] ;
 wire \g_telemetry.u_reg_file.trip_run[4] ;
 wire \g_telemetry.u_reg_file.trip_run[5] ;
 wire \g_telemetry.u_reg_file.trip_ss[0] ;
 wire \g_telemetry.u_reg_file.trip_ss[1] ;
 wire \g_telemetry.u_reg_file.trip_ss[2] ;
 wire \g_telemetry.u_reg_file.trip_ss[3] ;
 wire \g_telemetry.u_reg_file.trip_ss[4] ;
 wire \g_telemetry.u_reg_file.trip_ss[5] ;
 wire \g_telemetry.u_reg_file.unlock_armed ;
 wire \g_telemetry.u_reg_file.wd_mark[0] ;
 wire \g_telemetry.u_reg_file.wd_mark[10] ;
 wire \g_telemetry.u_reg_file.wd_mark[11] ;
 wire \g_telemetry.u_reg_file.wd_mark[12] ;
 wire \g_telemetry.u_reg_file.wd_mark[13] ;
 wire \g_telemetry.u_reg_file.wd_mark[14] ;
 wire \g_telemetry.u_reg_file.wd_mark[15] ;
 wire \g_telemetry.u_reg_file.wd_mark[16] ;
 wire \g_telemetry.u_reg_file.wd_mark[17] ;
 wire \g_telemetry.u_reg_file.wd_mark[18] ;
 wire \g_telemetry.u_reg_file.wd_mark[19] ;
 wire \g_telemetry.u_reg_file.wd_mark[1] ;
 wire \g_telemetry.u_reg_file.wd_mark[20] ;
 wire \g_telemetry.u_reg_file.wd_mark[21] ;
 wire \g_telemetry.u_reg_file.wd_mark[22] ;
 wire \g_telemetry.u_reg_file.wd_mark[23] ;
 wire \g_telemetry.u_reg_file.wd_mark[2] ;
 wire \g_telemetry.u_reg_file.wd_mark[3] ;
 wire \g_telemetry.u_reg_file.wd_mark[4] ;
 wire \g_telemetry.u_reg_file.wd_mark[5] ;
 wire \g_telemetry.u_reg_file.wd_mark[6] ;
 wire \g_telemetry.u_reg_file.wd_mark[7] ;
 wire \g_telemetry.u_reg_file.wd_mark[8] ;
 wire \g_telemetry.u_reg_file.wd_mark[9] ;
 wire \g_telemetry.u_reg_file.wd_restored ;
 wire \g_telemetry.u_reg_file.wdata[0] ;
 wire \g_telemetry.u_reg_file.wdata[1] ;
 wire \g_telemetry.u_reg_file.wdata[2] ;
 wire \g_telemetry.u_reg_file.wdata[3] ;
 wire \g_telemetry.u_reg_file.wdata[4] ;
 wire \g_telemetry.u_reg_file.wdata[5] ;
 wire \g_telemetry.u_reg_file.wdata[6] ;
 wire \g_telemetry.u_reg_file.wdata[7] ;
 wire \g_telemetry.u_reg_file.wr_en ;
 wire \g_telemetry.u_reg_file.write_rejected ;
 wire \g_telemetry.u_spi_slave.bit_count[0] ;
 wire \g_telemetry.u_spi_slave.bit_count[1] ;
 wire \g_telemetry.u_spi_slave.bit_count[2] ;
 wire \g_telemetry.u_spi_slave.byte_count[0] ;
 wire \g_telemetry.u_spi_slave.byte_count[1] ;
 wire \g_telemetry.u_spi_slave.byte_count[2] ;
 wire \g_telemetry.u_spi_slave.byte_count[3] ;
 wire \g_telemetry.u_spi_slave.crc[0] ;
 wire \g_telemetry.u_spi_slave.crc[1] ;
 wire \g_telemetry.u_spi_slave.crc[2] ;
 wire \g_telemetry.u_spi_slave.crc[3] ;
 wire \g_telemetry.u_spi_slave.crc[4] ;
 wire \g_telemetry.u_spi_slave.crc[5] ;
 wire \g_telemetry.u_spi_slave.crc[6] ;
 wire \g_telemetry.u_spi_slave.crc[7] ;
 wire \g_telemetry.u_spi_slave.cs_n_d ;
 wire \g_telemetry.u_spi_slave.held_data[0] ;
 wire \g_telemetry.u_spi_slave.held_data[1] ;
 wire \g_telemetry.u_spi_slave.held_data[2] ;
 wire \g_telemetry.u_spi_slave.held_data[3] ;
 wire \g_telemetry.u_spi_slave.held_data[4] ;
 wire \g_telemetry.u_spi_slave.held_data[5] ;
 wire \g_telemetry.u_spi_slave.held_data[6] ;
 wire \g_telemetry.u_spi_slave.held_data[7] ;
 wire \g_telemetry.u_spi_slave.held_valid ;
 wire \g_telemetry.u_spi_slave.idle_counter[0] ;
 wire \g_telemetry.u_spi_slave.idle_counter[10] ;
 wire \g_telemetry.u_spi_slave.idle_counter[11] ;
 wire \g_telemetry.u_spi_slave.idle_counter[12] ;
 wire \g_telemetry.u_spi_slave.idle_counter[13] ;
 wire \g_telemetry.u_spi_slave.idle_counter[14] ;
 wire \g_telemetry.u_spi_slave.idle_counter[1] ;
 wire \g_telemetry.u_spi_slave.idle_counter[2] ;
 wire \g_telemetry.u_spi_slave.idle_counter[3] ;
 wire \g_telemetry.u_spi_slave.idle_counter[4] ;
 wire \g_telemetry.u_spi_slave.idle_counter[5] ;
 wire \g_telemetry.u_spi_slave.idle_counter[6] ;
 wire \g_telemetry.u_spi_slave.idle_counter[7] ;
 wire \g_telemetry.u_spi_slave.idle_counter[8] ;
 wire \g_telemetry.u_spi_slave.idle_counter[9] ;
 wire \g_telemetry.u_spi_slave.rw ;
 wire \g_telemetry.u_spi_slave.rx_byte[1] ;
 wire \g_telemetry.u_spi_slave.rx_byte[2] ;
 wire \g_telemetry.u_spi_slave.rx_byte[3] ;
 wire \g_telemetry.u_spi_slave.rx_byte[4] ;
 wire \g_telemetry.u_spi_slave.rx_byte[5] ;
 wire \g_telemetry.u_spi_slave.rx_byte[6] ;
 wire \g_telemetry.u_spi_slave.rx_byte[7] ;
 wire \g_telemetry.u_spi_slave.sck_d ;
 wire \g_telemetry.u_spi_slave.sck_timeout ;
 wire \g_telemetry.u_spi_slave.sdio_oe ;
 wire \g_telemetry.u_spi_slave.sdio_out ;
 wire \g_telemetry.u_spi_slave.spi_state[0] ;
 wire \g_telemetry.u_spi_slave.spi_state[1] ;
 wire \g_telemetry.u_spi_slave.spi_state[2] ;
 wire \g_telemetry.u_spi_slave.spi_state_next[0] ;
 wire \g_telemetry.u_spi_slave.spi_state_next[1] ;
 wire \g_telemetry.u_spi_slave.spi_state_next[2] ;
 wire \g_telemetry.u_spi_slave.tx_shift[0] ;
 wire \g_telemetry.u_spi_slave.tx_shift[1] ;
 wire \g_telemetry.u_spi_slave.tx_shift[2] ;
 wire \g_telemetry.u_spi_slave.tx_shift[3] ;
 wire \g_telemetry.u_spi_slave.tx_shift[4] ;
 wire \g_telemetry.u_spi_slave.tx_shift[5] ;
 wire \g_telemetry.u_spi_slave.tx_shift[6] ;
 wire \g_timestamp.u_timestamp.prescalar[0] ;
 wire \g_timestamp.u_timestamp.prescalar[10] ;
 wire \g_timestamp.u_timestamp.prescalar[11] ;
 wire \g_timestamp.u_timestamp.prescalar[12] ;
 wire \g_timestamp.u_timestamp.prescalar[13] ;
 wire \g_timestamp.u_timestamp.prescalar[1] ;
 wire \g_timestamp.u_timestamp.prescalar[2] ;
 wire \g_timestamp.u_timestamp.prescalar[3] ;
 wire \g_timestamp.u_timestamp.prescalar[4] ;
 wire \g_timestamp.u_timestamp.prescalar[5] ;
 wire \g_timestamp.u_timestamp.prescalar[6] ;
 wire \g_timestamp.u_timestamp.prescalar[7] ;
 wire \g_timestamp.u_timestamp.prescalar[8] ;
 wire \g_timestamp.u_timestamp.prescalar[9] ;
 wire hiccup_active;
 wire hiccup_done;
 wire latch_stat_sync;
 wire \max_on_counts[0] ;
 wire \max_on_counts[1] ;
 wire \max_on_counts[2] ;
 wire \max_on_counts[3] ;
 wire \max_on_counts[4] ;
 wire \rst_sync.meta_ff ;
 wire \u_OTP_sync_db.disagree_counter[0] ;
 wire \u_OTP_sync_db.disagree_counter[10] ;
 wire \u_OTP_sync_db.disagree_counter[11] ;
 wire \u_OTP_sync_db.disagree_counter[12] ;
 wire \u_OTP_sync_db.disagree_counter[13] ;
 wire \u_OTP_sync_db.disagree_counter[1] ;
 wire \u_OTP_sync_db.disagree_counter[2] ;
 wire \u_OTP_sync_db.disagree_counter[3] ;
 wire \u_OTP_sync_db.disagree_counter[4] ;
 wire \u_OTP_sync_db.disagree_counter[5] ;
 wire \u_OTP_sync_db.disagree_counter[6] ;
 wire \u_OTP_sync_db.disagree_counter[7] ;
 wire \u_OTP_sync_db.disagree_counter[8] ;
 wire \u_OTP_sync_db.disagree_counter[9] ;
 wire \u_UVLO_sync_db.disagree_counter[0] ;
 wire \u_UVLO_sync_db.disagree_counter[10] ;
 wire \u_UVLO_sync_db.disagree_counter[11] ;
 wire \u_UVLO_sync_db.disagree_counter[12] ;
 wire \u_UVLO_sync_db.disagree_counter[13] ;
 wire \u_UVLO_sync_db.disagree_counter[1] ;
 wire \u_UVLO_sync_db.disagree_counter[2] ;
 wire \u_UVLO_sync_db.disagree_counter[3] ;
 wire \u_UVLO_sync_db.disagree_counter[4] ;
 wire \u_UVLO_sync_db.disagree_counter[5] ;
 wire \u_UVLO_sync_db.disagree_counter[6] ;
 wire \u_UVLO_sync_db.disagree_counter[7] ;
 wire \u_UVLO_sync_db.disagree_counter[8] ;
 wire \u_UVLO_sync_db.disagree_counter[9] ;
 wire \u_cp_sync.meta_ff ;
 wire \u_en_from_switch_db.disagree_counter[0] ;
 wire \u_en_from_switch_db.disagree_counter[10] ;
 wire \u_en_from_switch_db.disagree_counter[11] ;
 wire \u_en_from_switch_db.disagree_counter[12] ;
 wire \u_en_from_switch_db.disagree_counter[13] ;
 wire \u_en_from_switch_db.disagree_counter[14] ;
 wire \u_en_from_switch_db.disagree_counter[15] ;
 wire \u_en_from_switch_db.disagree_counter[16] ;
 wire \u_en_from_switch_db.disagree_counter[17] ;
 wire \u_en_from_switch_db.disagree_counter[1] ;
 wire \u_en_from_switch_db.disagree_counter[2] ;
 wire \u_en_from_switch_db.disagree_counter[3] ;
 wire \u_en_from_switch_db.disagree_counter[4] ;
 wire \u_en_from_switch_db.disagree_counter[5] ;
 wire \u_en_from_switch_db.disagree_counter[6] ;
 wire \u_en_from_switch_db.disagree_counter[7] ;
 wire \u_en_from_switch_db.disagree_counter[8] ;
 wire \u_en_from_switch_db.disagree_counter[9] ;
 wire \u_en_from_switch_sync.meta_ff ;
 wire \u_fault_LED.blink ;
 wire \u_fault_LED.blink_counter[0] ;
 wire \u_fault_LED.blink_counter[10] ;
 wire \u_fault_LED.blink_counter[11] ;
 wire \u_fault_LED.blink_counter[12] ;
 wire \u_fault_LED.blink_counter[13] ;
 wire \u_fault_LED.blink_counter[14] ;
 wire \u_fault_LED.blink_counter[15] ;
 wire \u_fault_LED.blink_counter[16] ;
 wire \u_fault_LED.blink_counter[17] ;
 wire \u_fault_LED.blink_counter[18] ;
 wire \u_fault_LED.blink_counter[19] ;
 wire \u_fault_LED.blink_counter[1] ;
 wire \u_fault_LED.blink_counter[20] ;
 wire \u_fault_LED.blink_counter[2] ;
 wire \u_fault_LED.blink_counter[3] ;
 wire \u_fault_LED.blink_counter[4] ;
 wire \u_fault_LED.blink_counter[5] ;
 wire \u_fault_LED.blink_counter[6] ;
 wire \u_fault_LED.blink_counter[7] ;
 wire \u_fault_LED.blink_counter[8] ;
 wire \u_fault_LED.blink_counter[9] ;
 wire \u_fault_arbiter.cp_delay[0] ;
 wire \u_fault_arbiter.cp_delay[1] ;
 wire \u_fault_arbiter.cp_delay[2] ;
 wire \u_fault_arbiter.cp_delay[3] ;
 wire \u_fault_arbiter.cp_delay[4] ;
 wire \u_fault_arbiter.fault_shifter_RUN[0] ;
 wire \u_fault_arbiter.fault_shifter_RUN[10] ;
 wire \u_fault_arbiter.fault_shifter_RUN[11] ;
 wire \u_fault_arbiter.fault_shifter_RUN[12] ;
 wire \u_fault_arbiter.fault_shifter_RUN[13] ;
 wire \u_fault_arbiter.fault_shifter_RUN[14] ;
 wire \u_fault_arbiter.fault_shifter_RUN[15] ;
 wire \u_fault_arbiter.fault_shifter_RUN[1] ;
 wire \u_fault_arbiter.fault_shifter_RUN[2] ;
 wire \u_fault_arbiter.fault_shifter_RUN[3] ;
 wire \u_fault_arbiter.fault_shifter_RUN[4] ;
 wire \u_fault_arbiter.fault_shifter_RUN[5] ;
 wire \u_fault_arbiter.fault_shifter_RUN[6] ;
 wire \u_fault_arbiter.fault_shifter_RUN[7] ;
 wire \u_fault_arbiter.fault_shifter_RUN[8] ;
 wire \u_fault_arbiter.fault_shifter_RUN[9] ;
 wire \u_fault_arbiter.fault_shifter_SS[0] ;
 wire \u_fault_arbiter.fault_shifter_SS[10] ;
 wire \u_fault_arbiter.fault_shifter_SS[11] ;
 wire \u_fault_arbiter.fault_shifter_SS[12] ;
 wire \u_fault_arbiter.fault_shifter_SS[13] ;
 wire \u_fault_arbiter.fault_shifter_SS[14] ;
 wire \u_fault_arbiter.fault_shifter_SS[15] ;
 wire \u_fault_arbiter.fault_shifter_SS[16] ;
 wire \u_fault_arbiter.fault_shifter_SS[17] ;
 wire \u_fault_arbiter.fault_shifter_SS[18] ;
 wire \u_fault_arbiter.fault_shifter_SS[19] ;
 wire \u_fault_arbiter.fault_shifter_SS[1] ;
 wire \u_fault_arbiter.fault_shifter_SS[20] ;
 wire \u_fault_arbiter.fault_shifter_SS[21] ;
 wire \u_fault_arbiter.fault_shifter_SS[22] ;
 wire \u_fault_arbiter.fault_shifter_SS[23] ;
 wire \u_fault_arbiter.fault_shifter_SS[24] ;
 wire \u_fault_arbiter.fault_shifter_SS[25] ;
 wire \u_fault_arbiter.fault_shifter_SS[26] ;
 wire \u_fault_arbiter.fault_shifter_SS[27] ;
 wire \u_fault_arbiter.fault_shifter_SS[28] ;
 wire \u_fault_arbiter.fault_shifter_SS[29] ;
 wire \u_fault_arbiter.fault_shifter_SS[2] ;
 wire \u_fault_arbiter.fault_shifter_SS[30] ;
 wire \u_fault_arbiter.fault_shifter_SS[31] ;
 wire \u_fault_arbiter.fault_shifter_SS[3] ;
 wire \u_fault_arbiter.fault_shifter_SS[4] ;
 wire \u_fault_arbiter.fault_shifter_SS[5] ;
 wire \u_fault_arbiter.fault_shifter_SS[6] ;
 wire \u_fault_arbiter.fault_shifter_SS[7] ;
 wire \u_fault_arbiter.fault_shifter_SS[8] ;
 wire \u_fault_arbiter.fault_shifter_SS[9] ;
 wire \u_hiccup_timer.cool_counter[0] ;
 wire \u_hiccup_timer.cool_counter[10] ;
 wire \u_hiccup_timer.cool_counter[11] ;
 wire \u_hiccup_timer.cool_counter[12] ;
 wire \u_hiccup_timer.cool_counter[13] ;
 wire \u_hiccup_timer.cool_counter[14] ;
 wire \u_hiccup_timer.cool_counter[15] ;
 wire \u_hiccup_timer.cool_counter[16] ;
 wire \u_hiccup_timer.cool_counter[17] ;
 wire \u_hiccup_timer.cool_counter[18] ;
 wire \u_hiccup_timer.cool_counter[19] ;
 wire \u_hiccup_timer.cool_counter[1] ;
 wire \u_hiccup_timer.cool_counter[2] ;
 wire \u_hiccup_timer.cool_counter[3] ;
 wire \u_hiccup_timer.cool_counter[4] ;
 wire \u_hiccup_timer.cool_counter[5] ;
 wire \u_hiccup_timer.cool_counter[6] ;
 wire \u_hiccup_timer.cool_counter[7] ;
 wire \u_hiccup_timer.cool_counter[8] ;
 wire \u_hiccup_timer.cool_counter[9] ;
 wire \u_latch_stat_sync.meta_ff ;
 wire \u_latch_stat_sync_db.disagree_counter[0] ;
 wire \u_latch_stat_sync_db.disagree_counter[10] ;
 wire \u_latch_stat_sync_db.disagree_counter[11] ;
 wire \u_latch_stat_sync_db.disagree_counter[12] ;
 wire \u_latch_stat_sync_db.disagree_counter[13] ;
 wire \u_latch_stat_sync_db.disagree_counter[1] ;
 wire \u_latch_stat_sync_db.disagree_counter[2] ;
 wire \u_latch_stat_sync_db.disagree_counter[3] ;
 wire \u_latch_stat_sync_db.disagree_counter[4] ;
 wire \u_latch_stat_sync_db.disagree_counter[5] ;
 wire \u_latch_stat_sync_db.disagree_counter[6] ;
 wire \u_latch_stat_sync_db.disagree_counter[7] ;
 wire \u_latch_stat_sync_db.disagree_counter[8] ;
 wire \u_latch_stat_sync_db.disagree_counter[9] ;
 wire \u_osc_sync.meta_ff ;
 wire \u_otp_sync.meta_ff ;
 wire \u_pgood_comp_sync.meta_ff ;
 wire \u_pgood_gen.qualify_counter[0] ;
 wire \u_pgood_gen.qualify_counter[10] ;
 wire \u_pgood_gen.qualify_counter[11] ;
 wire \u_pgood_gen.qualify_counter[1] ;
 wire \u_pgood_gen.qualify_counter[2] ;
 wire \u_pgood_gen.qualify_counter[3] ;
 wire \u_pgood_gen.qualify_counter[4] ;
 wire \u_pgood_gen.qualify_counter[5] ;
 wire \u_pgood_gen.qualify_counter[6] ;
 wire \u_pgood_gen.qualify_counter[7] ;
 wire \u_pgood_gen.qualify_counter[8] ;
 wire \u_pgood_gen.qualify_counter[9] ;
 wire \u_pwm_mask.pulse_allowed ;
 wire \u_pwm_mask.run_counter[0] ;
 wire \u_pwm_mask.run_counter[1] ;
 wire \u_pwm_mask.run_counter[2] ;
 wire \u_pwm_mask.run_counter[3] ;
 wire \u_pwm_mask.run_counter[4] ;
 wire \u_soft_start.cycle_counter[0] ;
 wire \u_soft_start.cycle_counter[1] ;
 wire \u_soft_start.cycle_counter[2] ;
 wire \u_soft_start.cycle_counter[3] ;
 wire \u_soft_start.cycle_counter[4] ;
 wire \u_soft_start.cycle_counter[5] ;
 wire \u_soft_start.cycle_counter[6] ;
 wire \u_strike_counter.clean_counter[0] ;
 wire \u_strike_counter.clean_counter[10] ;
 wire \u_strike_counter.clean_counter[11] ;
 wire \u_strike_counter.clean_counter[12] ;
 wire \u_strike_counter.clean_counter[13] ;
 wire \u_strike_counter.clean_counter[14] ;
 wire \u_strike_counter.clean_counter[15] ;
 wire \u_strike_counter.clean_counter[16] ;
 wire \u_strike_counter.clean_counter[17] ;
 wire \u_strike_counter.clean_counter[18] ;
 wire \u_strike_counter.clean_counter[1] ;
 wire \u_strike_counter.clean_counter[2] ;
 wire \u_strike_counter.clean_counter[3] ;
 wire \u_strike_counter.clean_counter[4] ;
 wire \u_strike_counter.clean_counter[5] ;
 wire \u_strike_counter.clean_counter[6] ;
 wire \u_strike_counter.clean_counter[7] ;
 wire \u_strike_counter.clean_counter[8] ;
 wire \u_strike_counter.clean_counter[9] ;
 wire \u_strike_counter.hiccup_active_d ;
 wire \u_supervisor.next_state[0] ;
 wire \u_supervisor.next_state[1] ;
 wire \u_uvlo_sync.meta_ff ;
 wire net1;
 wire net3;
 wire net4;
 wire net5;
 wire net6;
 wire net7;
 wire net8;
 wire net9;
 wire net10;
 wire net11;
 wire net12;
 wire clknet_0_clk;
 wire clknet_4_0_0_clk;
 wire clknet_4_1_0_clk;
 wire clknet_4_2_0_clk;
 wire clknet_4_3_0_clk;
 wire clknet_4_4_0_clk;
 wire clknet_4_5_0_clk;
 wire clknet_4_6_0_clk;
 wire clknet_4_7_0_clk;
 wire clknet_4_8_0_clk;
 wire clknet_4_9_0_clk;
 wire clknet_4_10_0_clk;
 wire clknet_4_11_0_clk;
 wire clknet_4_12_0_clk;
 wire clknet_4_13_0_clk;
 wire clknet_4_14_0_clk;
 wire clknet_4_15_0_clk;
 wire clknet_6_0__leaf_clk;
 wire clknet_6_1__leaf_clk;
 wire clknet_6_2__leaf_clk;
 wire clknet_6_3__leaf_clk;
 wire clknet_6_4__leaf_clk;
 wire clknet_6_5__leaf_clk;
 wire clknet_6_6__leaf_clk;
 wire clknet_6_7__leaf_clk;
 wire clknet_6_8__leaf_clk;
 wire clknet_6_9__leaf_clk;
 wire clknet_6_10__leaf_clk;
 wire clknet_6_11__leaf_clk;
 wire clknet_6_12__leaf_clk;
 wire clknet_6_13__leaf_clk;
 wire clknet_6_14__leaf_clk;
 wire clknet_6_15__leaf_clk;
 wire clknet_6_16__leaf_clk;
 wire clknet_6_17__leaf_clk;
 wire clknet_6_18__leaf_clk;
 wire clknet_6_19__leaf_clk;
 wire clknet_6_20__leaf_clk;
 wire clknet_6_21__leaf_clk;
 wire clknet_6_22__leaf_clk;
 wire clknet_6_23__leaf_clk;
 wire clknet_6_24__leaf_clk;
 wire clknet_6_25__leaf_clk;
 wire clknet_6_26__leaf_clk;
 wire clknet_6_27__leaf_clk;
 wire clknet_6_28__leaf_clk;
 wire clknet_6_29__leaf_clk;
 wire clknet_6_30__leaf_clk;
 wire clknet_6_31__leaf_clk;
 wire clknet_6_32__leaf_clk;
 wire clknet_6_33__leaf_clk;
 wire clknet_6_34__leaf_clk;
 wire clknet_6_35__leaf_clk;
 wire clknet_6_36__leaf_clk;
 wire clknet_6_37__leaf_clk;
 wire clknet_6_38__leaf_clk;
 wire clknet_6_39__leaf_clk;
 wire clknet_6_40__leaf_clk;
 wire clknet_6_41__leaf_clk;
 wire clknet_6_42__leaf_clk;
 wire clknet_6_43__leaf_clk;
 wire clknet_6_44__leaf_clk;
 wire clknet_6_45__leaf_clk;
 wire clknet_6_46__leaf_clk;
 wire clknet_6_47__leaf_clk;
 wire clknet_6_48__leaf_clk;
 wire clknet_6_49__leaf_clk;
 wire clknet_6_50__leaf_clk;
 wire clknet_6_51__leaf_clk;
 wire clknet_6_52__leaf_clk;
 wire clknet_6_53__leaf_clk;
 wire clknet_6_54__leaf_clk;
 wire clknet_6_55__leaf_clk;
 wire clknet_6_56__leaf_clk;
 wire clknet_6_57__leaf_clk;
 wire clknet_6_58__leaf_clk;
 wire clknet_6_59__leaf_clk;
 wire clknet_6_60__leaf_clk;
 wire clknet_6_61__leaf_clk;
 wire clknet_6_62__leaf_clk;
 wire clknet_6_63__leaf_clk;

 sky130_fd_sc_hd__inv_1 _2088_ (.A(\cycles_per_step[6] ),
    .Y(_0659_));
 sky130_fd_sc_hd__clkinv_1 _2089_ (.A(hiccup_done),
    .Y(_0660_));
 sky130_fd_sc_hd__inv_1 _2090_ (.A(\u_UVLO_sync_db.disagree_counter[13] ),
    .Y(_0669_));
 sky130_fd_sc_hd__o22ai_1 _2091_ (.A1(\fault_count_ss[5] ),
    .A2(_0662_),
    .B1(\fault_count_ss[4] ),
    .B2(_0688_),
    .Y(_0753_));
 sky130_fd_sc_hd__o21ai_0 _2092_ (.A1(\u_strike_counter.clean_counter[11] ),
    .A2(_1511_),
    .B1(_1318_),
    .Y(_1514_));
 sky130_fd_sc_hd__nor2_1 _2093_ (.A(_1513_),
    .B(_1514_),
    .Y(_0530_));
 sky130_fd_sc_hd__nor2b_1 _2094_ (.A(_1321_),
    .B_N(_1328_),
    .Y(_1515_));
 sky130_fd_sc_hd__o21ai_0 _2095_ (.A1(\u_strike_counter.clean_counter[12] ),
    .A2(_1513_),
    .B1(_1318_),
    .Y(_1516_));
 sky130_fd_sc_hd__nor2_1 _2096_ (.A(_1515_),
    .B(_1516_),
    .Y(_0529_));
 sky130_fd_sc_hd__o21ai_0 _2097_ (.A1(\u_strike_counter.clean_counter[13] ),
    .A2(_1515_),
    .B1(_1318_),
    .Y(_1517_));
 sky130_fd_sc_hd__a21oi_1 _2098_ (.A1(\u_strike_counter.clean_counter[13] ),
    .A2(_1515_),
    .B1(_1517_),
    .Y(_0528_));
 sky130_fd_sc_hd__a21oi_1 _2099_ (.A1(\u_strike_counter.clean_counter[13] ),
    .A2(_1515_),
    .B1(\u_strike_counter.clean_counter[14] ),
    .Y(_1518_));
 sky130_fd_sc_hd__nor3_2 _2100_ (.A(_0767_),
    .B(_1101_),
    .C(_1329_),
    .Y(_1519_));
 sky130_fd_sc_hd__nor3_1 _2101_ (.A(_1319_),
    .B(_1518_),
    .C(_1519_),
    .Y(_0527_));
 sky130_fd_sc_hd__a21oi_1 _2102_ (.A1(_0751_),
    .A2(_0752_),
    .B1(_0753_),
    .Y(_0754_));
 sky130_fd_sc_hd__o21ai_0 _2103_ (.A1(\u_strike_counter.clean_counter[15] ),
    .A2(_1519_),
    .B1(_1318_),
    .Y(_1520_));
 sky130_fd_sc_hd__a21oi_1 _2104_ (.A1(\u_strike_counter.clean_counter[15] ),
    .A2(_1519_),
    .B1(_1520_),
    .Y(_0526_));
 sky130_fd_sc_hd__o21ai_0 _2105_ (.A1(\u_strike_counter.clean_counter[16] ),
    .A2(_1330_),
    .B1(_1318_),
    .Y(_1521_));
 sky130_fd_sc_hd__nor2_1 _2106_ (.A(_1331_),
    .B(_1521_),
    .Y(_0525_));
 sky130_fd_sc_hd__a31oi_1 _2107_ (.A1(\u_strike_counter.clean_counter[15] ),
    .A2(\u_strike_counter.clean_counter[16] ),
    .A3(_1519_),
    .B1(\u_strike_counter.clean_counter[17] ),
    .Y(_1522_));
 sky130_fd_sc_hd__and4_1 _2108_ (.A(\u_strike_counter.clean_counter[15] ),
    .B(\u_strike_counter.clean_counter[16] ),
    .C(\u_strike_counter.clean_counter[17] ),
    .D(_1519_),
    .X(_1523_));
 sky130_fd_sc_hd__nor3_1 _2109_ (.A(_1319_),
    .B(_1522_),
    .C(_1523_),
    .Y(_0524_));
 sky130_fd_sc_hd__mux2_1 _2110_ (.A0(\g_telemetry.u_spi_slave.held_data[0] ),
    .A1(\g_spi_filt.u_mosi_filt.flag_out ),
    .S(_1132_),
    .X(_0523_));
 sky130_fd_sc_hd__mux2_1 _2111_ (.A0(\g_telemetry.u_spi_slave.held_data[1] ),
    .A1(\g_telemetry.u_spi_slave.rx_byte[1] ),
    .S(_1132_),
    .X(_0522_));
 sky130_fd_sc_hd__nor2_1 _2112_ (.A(\g_telemetry.u_spi_slave.held_data[2] ),
    .B(_1132_),
    .Y(_1524_));
 sky130_fd_sc_hd__a21oi_2 _2113_ (.A1(\fault_count_ss[5] ),
    .A2(_0662_),
    .B1(_0754_),
    .Y(_0755_));
 sky130_fd_sc_hd__a21oi_1 _2114_ (.A1(_0686_),
    .A2(_1132_),
    .B1(_1524_),
    .Y(_0521_));
 sky130_fd_sc_hd__mux2_1 _2115_ (.A0(\g_telemetry.u_spi_slave.held_data[3] ),
    .A1(\g_telemetry.u_spi_slave.rx_byte[3] ),
    .S(_1132_),
    .X(_0520_));
 sky130_fd_sc_hd__mux2_1 _2116_ (.A0(\g_telemetry.u_spi_slave.held_data[4] ),
    .A1(\g_telemetry.u_spi_slave.rx_byte[4] ),
    .S(_1132_),
    .X(_0519_));
 sky130_fd_sc_hd__mux2_1 _2117_ (.A0(\g_telemetry.u_spi_slave.held_data[5] ),
    .A1(\g_telemetry.u_spi_slave.rx_byte[5] ),
    .S(_1132_),
    .X(_0518_));
 sky130_fd_sc_hd__mux2_1 _2118_ (.A0(\g_telemetry.u_spi_slave.held_data[6] ),
    .A1(\g_telemetry.u_spi_slave.rx_byte[6] ),
    .S(_1132_),
    .X(_0517_));
 sky130_fd_sc_hd__nand2_1 _2119_ (.A(\fault_count_ss[0] ),
    .B(_1264_),
    .Y(_1525_));
 sky130_fd_sc_hd__nor2_1 _2120_ (.A(\u_fault_arbiter.cp_delay[4] ),
    .B(_1283_),
    .Y(_1526_));
 sky130_fd_sc_hd__nand2_1 _2121_ (.A(_1263_),
    .B(_1284_),
    .Y(_1527_));
 sky130_fd_sc_hd__o21ai_0 _2122_ (.A1(_1526_),
    .A2(_1527_),
    .B1(_1525_),
    .Y(_0516_));
 sky130_fd_sc_hd__o21ai_0 _2123_ (.A1(_1284_),
    .A2(_1285_),
    .B1(_1263_),
    .Y(_1528_));
 sky130_fd_sc_hd__nand2_1 _2124_ (.A(_0747_),
    .B(_0755_),
    .Y(_0756_));
 sky130_fd_sc_hd__a21oi_1 _2125_ (.A1(_1284_),
    .A2(_1285_),
    .B1(_1528_),
    .Y(_1529_));
 sky130_fd_sc_hd__a21o_1 _2126_ (.A1(\fault_count_ss[1] ),
    .A2(_1264_),
    .B1(_1529_),
    .X(_0515_));
 sky130_fd_sc_hd__nand2_1 _2127_ (.A(_1281_),
    .B(_1286_),
    .Y(_1530_));
 sky130_fd_sc_hd__a32o_1 _2128_ (.A1(_1263_),
    .A2(_1287_),
    .A3(_1530_),
    .B1(_1264_),
    .B2(\fault_count_ss[2] ),
    .X(_0514_));
 sky130_fd_sc_hd__xnor2_1 _2129_ (.A(\fault_count_ss[3] ),
    .B(\fault_count_ss[2] ),
    .Y(_1531_));
 sky130_fd_sc_hd__o21ai_0 _2130_ (.A1(\fault_count_ss[2] ),
    .A2(_0679_),
    .B1(_1287_),
    .Y(_1532_));
 sky130_fd_sc_hd__o21ai_0 _2131_ (.A1(_1531_),
    .A2(_1532_),
    .B1(_1263_),
    .Y(_1533_));
 sky130_fd_sc_hd__a21oi_1 _2132_ (.A1(_1531_),
    .A2(_1532_),
    .B1(_1533_),
    .Y(_1534_));
 sky130_fd_sc_hd__a21o_1 _2133_ (.A1(\fault_count_ss[3] ),
    .A2(_1264_),
    .B1(_1534_),
    .X(_0513_));
 sky130_fd_sc_hd__nand2_1 _2134_ (.A(_1290_),
    .B(_1292_),
    .Y(_1535_));
 sky130_fd_sc_hd__nor2_1 _2135_ (.A(_0740_),
    .B(_0756_),
    .Y(_0757_));
 sky130_fd_sc_hd__o21ai_0 _2136_ (.A1(_1289_),
    .A2(_1291_),
    .B1(_1288_),
    .Y(_1536_));
 sky130_fd_sc_hd__a32o_1 _2137_ (.A1(_1263_),
    .A2(_1535_),
    .A3(_1536_),
    .B1(_1264_),
    .B2(\fault_count_ss[4] ),
    .X(_0512_));
 sky130_fd_sc_hd__nand2_1 _2138_ (.A(\fault_count_run[0] ),
    .B(_1266_),
    .Y(_1537_));
 sky130_fd_sc_hd__nor2_1 _2139_ (.A(\u_fault_arbiter.cp_delay[4] ),
    .B(_1270_),
    .Y(_1538_));
 sky130_fd_sc_hd__nand2_1 _2140_ (.A(_1265_),
    .B(_1271_),
    .Y(_1539_));
 sky130_fd_sc_hd__o21ai_0 _2141_ (.A1(_1538_),
    .A2(_1539_),
    .B1(_1537_),
    .Y(_0511_));
 sky130_fd_sc_hd__o21ai_0 _2142_ (.A1(_1271_),
    .A2(_1272_),
    .B1(_1265_),
    .Y(_1540_));
 sky130_fd_sc_hd__a21oi_1 _2143_ (.A1(_1271_),
    .A2(_1272_),
    .B1(_1540_),
    .Y(_1541_));
 sky130_fd_sc_hd__a21o_1 _2144_ (.A1(\fault_count_run[1] ),
    .A2(_1266_),
    .B1(_1541_),
    .X(_0510_));
 sky130_fd_sc_hd__nand2_1 _2145_ (.A(_1268_),
    .B(_1273_),
    .Y(_1542_));
 sky130_fd_sc_hd__or4_1 _2146_ (.A(\fault_reg[3] ),
    .B(\fault_reg[2] ),
    .C(\fault_reg[4] ),
    .D(_0703_),
    .X(_0758_));
 sky130_fd_sc_hd__a32o_1 _2147_ (.A1(_1265_),
    .A2(_1274_),
    .A3(_1542_),
    .B1(_1266_),
    .B2(\fault_count_run[2] ),
    .X(_0509_));
 sky130_fd_sc_hd__xnor2_1 _2148_ (.A(\fault_count_run[3] ),
    .B(\fault_count_run[2] ),
    .Y(_1543_));
 sky130_fd_sc_hd__o21ai_0 _2149_ (.A1(_0678_),
    .A2(\fault_count_run[2] ),
    .B1(_1274_),
    .Y(_1544_));
 sky130_fd_sc_hd__o21ai_0 _2150_ (.A1(_1543_),
    .A2(_1544_),
    .B1(_1265_),
    .Y(_1545_));
 sky130_fd_sc_hd__a21oi_1 _2151_ (.A1(_1543_),
    .A2(_1544_),
    .B1(_1545_),
    .Y(_1546_));
 sky130_fd_sc_hd__a21o_1 _2152_ (.A1(\fault_count_run[3] ),
    .A2(_1266_),
    .B1(_1546_),
    .X(_0508_));
 sky130_fd_sc_hd__a22o_1 _2153_ (.A1(\u_fault_arbiter.cp_delay[4] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[0] ),
    .X(_0507_));
 sky130_fd_sc_hd__a22o_1 _2154_ (.A1(\u_fault_arbiter.fault_shifter_RUN[0] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[1] ),
    .X(_0506_));
 sky130_fd_sc_hd__a22o_1 _2155_ (.A1(\u_fault_arbiter.fault_shifter_RUN[1] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[2] ),
    .X(_0505_));
 sky130_fd_sc_hd__a22o_1 _2156_ (.A1(\u_fault_arbiter.fault_shifter_RUN[2] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[3] ),
    .X(_0504_));
 sky130_fd_sc_hd__nor4_4 _2157_ (.A(\fault_reg[1] ),
    .B(\fault_reg[0] ),
    .C(_0757_),
    .D(_0758_),
    .Y(_0759_));
 sky130_fd_sc_hd__a22o_1 _2158_ (.A1(\u_fault_arbiter.fault_shifter_RUN[3] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[4] ),
    .X(_0503_));
 sky130_fd_sc_hd__a22o_1 _2159_ (.A1(\u_fault_arbiter.fault_shifter_RUN[4] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[5] ),
    .X(_0502_));
 sky130_fd_sc_hd__a22o_1 _2160_ (.A1(\u_fault_arbiter.fault_shifter_RUN[5] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[6] ),
    .X(_0501_));
 sky130_fd_sc_hd__a22o_1 _2161_ (.A1(\u_fault_arbiter.fault_shifter_RUN[6] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[7] ),
    .X(_0500_));
 sky130_fd_sc_hd__a22o_1 _2162_ (.A1(\u_fault_arbiter.fault_shifter_RUN[7] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[8] ),
    .X(_0499_));
 sky130_fd_sc_hd__a22o_1 _2163_ (.A1(\u_fault_arbiter.fault_shifter_RUN[8] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[9] ),
    .X(_0498_));
 sky130_fd_sc_hd__a22o_1 _2164_ (.A1(\u_fault_arbiter.fault_shifter_RUN[9] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[10] ),
    .X(_0497_));
 sky130_fd_sc_hd__a22o_1 _2165_ (.A1(\u_fault_arbiter.fault_shifter_RUN[10] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[11] ),
    .X(_0496_));
 sky130_fd_sc_hd__a22o_1 _2166_ (.A1(\u_fault_arbiter.fault_shifter_RUN[11] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[12] ),
    .X(_0495_));
 sky130_fd_sc_hd__a22o_1 _2167_ (.A1(\u_fault_arbiter.fault_shifter_RUN[12] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[13] ),
    .X(_0494_));
 sky130_fd_sc_hd__nor2_8 _2168_ (.A(_0716_),
    .B(_0759_),
    .Y(_0760_));
 sky130_fd_sc_hd__a22o_1 _2169_ (.A1(\u_fault_arbiter.fault_shifter_RUN[13] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[14] ),
    .X(_0493_));
 sky130_fd_sc_hd__a22o_1 _2170_ (.A1(\u_fault_arbiter.cp_delay[4] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[0] ),
    .X(_0492_));
 sky130_fd_sc_hd__a22o_1 _2171_ (.A1(\u_fault_arbiter.fault_shifter_SS[0] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[1] ),
    .X(_0491_));
 sky130_fd_sc_hd__a22o_1 _2172_ (.A1(\u_fault_arbiter.fault_shifter_SS[1] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[2] ),
    .X(_0490_));
 sky130_fd_sc_hd__a22o_1 _2173_ (.A1(\u_fault_arbiter.fault_shifter_SS[2] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[3] ),
    .X(_0489_));
 sky130_fd_sc_hd__a22o_1 _2174_ (.A1(\u_fault_arbiter.fault_shifter_SS[3] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[4] ),
    .X(_0488_));
 sky130_fd_sc_hd__a22o_1 _2175_ (.A1(\u_fault_arbiter.fault_shifter_SS[4] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[5] ),
    .X(_0487_));
 sky130_fd_sc_hd__a22o_1 _2176_ (.A1(\u_fault_arbiter.fault_shifter_SS[5] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[6] ),
    .X(_0486_));
 sky130_fd_sc_hd__a22o_1 _2177_ (.A1(\u_fault_arbiter.fault_shifter_SS[6] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[7] ),
    .X(_0485_));
 sky130_fd_sc_hd__a22o_1 _2178_ (.A1(\u_fault_arbiter.fault_shifter_SS[7] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[8] ),
    .X(_0484_));
 sky130_fd_sc_hd__nor2b_4 _2179_ (.A(_0716_),
    .B_N(_0759_),
    .Y(_0761_));
 sky130_fd_sc_hd__a22o_1 _2180_ (.A1(\u_fault_arbiter.fault_shifter_SS[8] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[9] ),
    .X(_0483_));
 sky130_fd_sc_hd__a22o_1 _2181_ (.A1(\u_fault_arbiter.fault_shifter_SS[9] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[10] ),
    .X(_0482_));
 sky130_fd_sc_hd__a22o_1 _2182_ (.A1(\u_fault_arbiter.fault_shifter_SS[10] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[11] ),
    .X(_0481_));
 sky130_fd_sc_hd__a22o_1 _2183_ (.A1(\u_fault_arbiter.fault_shifter_SS[11] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[12] ),
    .X(_0480_));
 sky130_fd_sc_hd__a22o_1 _2184_ (.A1(\u_fault_arbiter.fault_shifter_SS[12] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[13] ),
    .X(_0479_));
 sky130_fd_sc_hd__a22o_1 _2185_ (.A1(\u_fault_arbiter.fault_shifter_SS[13] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[14] ),
    .X(_0478_));
 sky130_fd_sc_hd__a22o_1 _2186_ (.A1(\u_fault_arbiter.fault_shifter_SS[14] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[15] ),
    .X(_0477_));
 sky130_fd_sc_hd__a22o_1 _2187_ (.A1(\u_fault_arbiter.fault_shifter_SS[15] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[16] ),
    .X(_0476_));
 sky130_fd_sc_hd__a22o_1 _2188_ (.A1(\u_fault_arbiter.fault_shifter_SS[16] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[17] ),
    .X(_0475_));
 sky130_fd_sc_hd__a22o_1 _2189_ (.A1(\u_fault_arbiter.fault_shifter_SS[17] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[18] ),
    .X(_0474_));
 sky130_fd_sc_hd__a22o_1 _2190_ (.A1(\fault_time[23] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[23] ),
    .X(_0655_));
 sky130_fd_sc_hd__a22o_1 _2191_ (.A1(\u_fault_arbiter.fault_shifter_SS[18] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[19] ),
    .X(_0473_));
 sky130_fd_sc_hd__a22o_1 _2192_ (.A1(\u_fault_arbiter.fault_shifter_SS[19] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[20] ),
    .X(_0472_));
 sky130_fd_sc_hd__a22o_1 _2193_ (.A1(\u_fault_arbiter.fault_shifter_SS[20] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[21] ),
    .X(_0471_));
 sky130_fd_sc_hd__a22o_1 _2194_ (.A1(\u_fault_arbiter.fault_shifter_SS[21] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[22] ),
    .X(_0470_));
 sky130_fd_sc_hd__a22o_1 _2195_ (.A1(\u_fault_arbiter.fault_shifter_SS[22] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[23] ),
    .X(_0469_));
 sky130_fd_sc_hd__a22o_1 _2196_ (.A1(\u_fault_arbiter.fault_shifter_SS[23] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[24] ),
    .X(_0468_));
 sky130_fd_sc_hd__a22o_1 _2197_ (.A1(\u_fault_arbiter.fault_shifter_SS[24] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[25] ),
    .X(_0467_));
 sky130_fd_sc_hd__a22o_1 _2198_ (.A1(\u_fault_arbiter.fault_shifter_SS[25] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[26] ),
    .X(_0466_));
 sky130_fd_sc_hd__a22o_1 _2199_ (.A1(\u_fault_arbiter.fault_shifter_SS[26] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[27] ),
    .X(_0465_));
 sky130_fd_sc_hd__a22o_1 _2200_ (.A1(\u_fault_arbiter.fault_shifter_SS[27] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[28] ),
    .X(_0464_));
 sky130_fd_sc_hd__inv_1 _2201_ (.A(\u_latch_stat_sync_db.disagree_counter[13] ),
    .Y(_0670_));
 sky130_fd_sc_hd__a21oi_1 _2202_ (.A1(UVLO_sync_db),
    .A2(_0704_),
    .B1(\fault_reg[1] ),
    .Y(_0762_));
 sky130_fd_sc_hd__a22o_1 _2203_ (.A1(\u_fault_arbiter.fault_shifter_SS[28] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[29] ),
    .X(_0463_));
 sky130_fd_sc_hd__a22o_1 _2204_ (.A1(\u_fault_arbiter.fault_shifter_SS[29] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[30] ),
    .X(_0462_));
 sky130_fd_sc_hd__nand3_1 _2205_ (.A(\max_on_counts[0] ),
    .B(_0699_),
    .C(_1257_),
    .Y(_1547_));
 sky130_fd_sc_hd__o21a_1 _2206_ (.A1(\max_on_counts[0] ),
    .A2(_1257_),
    .B1(_1547_),
    .X(_0461_));
 sky130_fd_sc_hd__o21ai_0 _2207_ (.A1(_1258_),
    .A2(_1310_),
    .B1(_0699_),
    .Y(_1548_));
 sky130_fd_sc_hd__nand2_1 _2208_ (.A(_1257_),
    .B(_1548_),
    .Y(_1549_));
 sky130_fd_sc_hd__o21ai_0 _2209_ (.A1(_0681_),
    .A2(_1257_),
    .B1(_1549_),
    .Y(_0460_));
 sky130_fd_sc_hd__nor2_1 _2210_ (.A(\max_on_counts[2] ),
    .B(_1258_),
    .Y(_1550_));
 sky130_fd_sc_hd__o31ai_1 _2211_ (.A1(_0700_),
    .A2(_1259_),
    .A3(_1550_),
    .B1(_1257_),
    .Y(_1551_));
 sky130_fd_sc_hd__o21a_1 _2212_ (.A1(\max_on_counts[2] ),
    .A2(_1257_),
    .B1(_1551_),
    .X(_0459_));
 sky130_fd_sc_hd__nor2_1 _2213_ (.A(_0716_),
    .B(_0762_),
    .Y(_0654_));
 sky130_fd_sc_hd__o21ai_0 _2214_ (.A1(_0700_),
    .A2(_1307_),
    .B1(_1257_),
    .Y(_1552_));
 sky130_fd_sc_hd__o21a_1 _2215_ (.A1(\max_on_counts[3] ),
    .A2(_1257_),
    .B1(_1552_),
    .X(_0458_));
 sky130_fd_sc_hd__nand2_1 _2216_ (.A(\u_soft_start.cycle_counter[0] ),
    .B(_1242_),
    .Y(_1553_));
 sky130_fd_sc_hd__nand2_1 _2217_ (.A(_0766_),
    .B(_1241_),
    .Y(_1554_));
 sky130_fd_sc_hd__a21oi_1 _2218_ (.A1(_0766_),
    .A2(_1241_),
    .B1(\u_soft_start.cycle_counter[0] ),
    .Y(_1555_));
 sky130_fd_sc_hd__a21oi_1 _2219_ (.A1(\u_soft_start.cycle_counter[0] ),
    .A2(_1242_),
    .B1(_1555_),
    .Y(_0457_));
 sky130_fd_sc_hd__xor2_1 _2220_ (.A(\u_soft_start.cycle_counter[1] ),
    .B(_1553_),
    .X(_1556_));
 sky130_fd_sc_hd__nor2_1 _2221_ (.A(_1244_),
    .B(_1556_),
    .Y(_0456_));
 sky130_fd_sc_hd__nand2_1 _2222_ (.A(\u_soft_start.cycle_counter[2] ),
    .B(_1243_),
    .Y(_1557_));
 sky130_fd_sc_hd__a21oi_1 _2223_ (.A1(\u_soft_start.cycle_counter[1] ),
    .A2(\u_soft_start.cycle_counter[0] ),
    .B1(\u_soft_start.cycle_counter[2] ),
    .Y(_1558_));
 sky130_fd_sc_hd__nor2b_4 _2224_ (.A(\g_telemetry.u_pwm_stats.pwm_sync_d ),
    .B_N(Osc_sync),
    .Y(_0763_));
 sky130_fd_sc_hd__o31ai_1 _2225_ (.A1(_1245_),
    .A2(_1554_),
    .A3(_1558_),
    .B1(_1557_),
    .Y(_0455_));
 sky130_fd_sc_hd__nand2_1 _2226_ (.A(\u_soft_start.cycle_counter[3] ),
    .B(_1243_),
    .Y(_1559_));
 sky130_fd_sc_hd__xnor2_1 _2227_ (.A(\u_soft_start.cycle_counter[3] ),
    .B(_1245_),
    .Y(_1560_));
 sky130_fd_sc_hd__o21ai_0 _2228_ (.A1(_1554_),
    .A2(_1560_),
    .B1(_1559_),
    .Y(_0454_));
 sky130_fd_sc_hd__nand2_1 _2229_ (.A(\u_soft_start.cycle_counter[4] ),
    .B(_1243_),
    .Y(_1561_));
 sky130_fd_sc_hd__a21o_1 _2230_ (.A1(\u_soft_start.cycle_counter[3] ),
    .A2(_1245_),
    .B1(\u_soft_start.cycle_counter[4] ),
    .X(_1562_));
 sky130_fd_sc_hd__nand2_1 _2231_ (.A(_1246_),
    .B(_1562_),
    .Y(_1563_));
 sky130_fd_sc_hd__o21ai_0 _2232_ (.A1(_1554_),
    .A2(_1563_),
    .B1(_1561_),
    .Y(_0453_));
 sky130_fd_sc_hd__xnor2_1 _2233_ (.A(_0685_),
    .B(_1246_),
    .Y(_1564_));
 sky130_fd_sc_hd__o22ai_1 _2234_ (.A1(_0685_),
    .A2(_1242_),
    .B1(_1554_),
    .B2(_1564_),
    .Y(_0452_));
 sky130_fd_sc_hd__nand2b_4 _2235_ (.A_N(\g_telemetry.u_pwm_stats.pwm_sync_d ),
    .B(Osc_sync),
    .Y(_0764_));
 sky130_fd_sc_hd__o21ai_0 _2236_ (.A1(\u_pwm_mask.run_counter[0] ),
    .A2(_1216_),
    .B1(Osc_sync),
    .Y(_1565_));
 sky130_fd_sc_hd__nor2_1 _2237_ (.A(_1218_),
    .B(_1565_),
    .Y(_0451_));
 sky130_fd_sc_hd__o21ai_0 _2238_ (.A1(\u_pwm_mask.run_counter[1] ),
    .A2(_1218_),
    .B1(Osc_sync),
    .Y(_1566_));
 sky130_fd_sc_hd__nor2_1 _2239_ (.A(_1219_),
    .B(_1566_),
    .Y(_0450_));
 sky130_fd_sc_hd__o21ai_0 _2240_ (.A1(\u_pwm_mask.run_counter[2] ),
    .A2(_1219_),
    .B1(Osc_sync),
    .Y(_1567_));
 sky130_fd_sc_hd__a21oi_1 _2241_ (.A1(\u_pwm_mask.run_counter[2] ),
    .A2(_1219_),
    .B1(_1567_),
    .Y(_0449_));
 sky130_fd_sc_hd__a21oi_1 _2242_ (.A1(\u_pwm_mask.run_counter[2] ),
    .A2(_1219_),
    .B1(\u_pwm_mask.run_counter[3] ),
    .Y(_1568_));
 sky130_fd_sc_hd__nand2_1 _2243_ (.A(Osc_sync),
    .B(_1220_),
    .Y(_1569_));
 sky130_fd_sc_hd__nor2_1 _2244_ (.A(_1568_),
    .B(_1569_),
    .Y(_0448_));
 sky130_fd_sc_hd__mux2_1 _2245_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[0] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[0] ),
    .S(_0994_),
    .X(_0359_));
 sky130_fd_sc_hd__nand2_1 _2246_ (.A(\g_telemetry.u_pwm_stats.prev_period[5] ),
    .B(_0764_),
    .Y(_0765_));
 sky130_fd_sc_hd__mux2_1 _2247_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[16] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[16] ),
    .S(_0994_),
    .X(_0343_));
 sky130_fd_sc_hd__mux2_1 _2248_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[8] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[8] ),
    .S(_0994_),
    .X(_0351_));
 sky130_fd_sc_hd__nand2_1 _2249_ (.A(_1182_),
    .B(_0351_),
    .Y(_1570_));
 sky130_fd_sc_hd__nor2_2 _2250_ (.A(_0776_),
    .B(_1145_),
    .Y(_1571_));
 sky130_fd_sc_hd__nand2_1 _2251_ (.A(\g_telemetry.u_pwm_stats.prev_period[0] ),
    .B(_1161_),
    .Y(_1572_));
 sky130_fd_sc_hd__o21ai_0 _2252_ (.A1(\g_telemetry.u_reg_file.scratch_r[0] ),
    .A2(_0794_),
    .B1(_0997_),
    .Y(_1573_));
 sky130_fd_sc_hd__nand2_1 _2253_ (.A(\g_telemetry.u_reg_file.sup_state[0] ),
    .B(_1151_),
    .Y(_1574_));
 sky130_fd_sc_hd__a222oi_1 _2254_ (.A1(\fault_count_ss[0] ),
    .A2(_1160_),
    .B1(_1172_),
    .B2(\g_telemetry.u_reg_file.strike_level[0] ),
    .C1(\clean_run_target[16] ),
    .C2(_0822_),
    .Y(_1575_));
 sky130_fd_sc_hd__a222oi_1 _2255_ (.A1(\g_telemetry.u_reg_file.hiccup_base[0] ),
    .A2(_0846_),
    .B1(_1171_),
    .B2(\duty_count[0] ),
    .C1(_0987_),
    .C2(\g_telemetry.u_reg_file.spi_enable ),
    .Y(_1576_));
 sky130_fd_sc_hd__nand3_1 _2256_ (.A(_1572_),
    .B(_1575_),
    .C(_1576_),
    .Y(_1577_));
 sky130_fd_sc_hd__o21ai_0 _2257_ (.A1(_0663_),
    .A2(_0764_),
    .B1(_0765_),
    .Y(_0653_));
 sky130_fd_sc_hd__a22o_1 _2258_ (.A1(\clean_run_target[8] ),
    .A2(_0778_),
    .B1(_0863_),
    .B2(\g_telemetry.u_reg_file.max_on_limit[0] ),
    .X(_1578_));
 sky130_fd_sc_hd__a22oi_1 _2259_ (.A1(\g_telemetry.u_reg_file.trip_ss[0] ),
    .A2(_0990_),
    .B1(_1166_),
    .B2(\g_telemetry.u_reg_file.disable_armed ),
    .Y(_1579_));
 sky130_fd_sc_hd__a22oi_1 _2260_ (.A1(\fault_time[16] ),
    .A2(_0714_),
    .B1(_1175_),
    .B2(\fault_count_run[0] ),
    .Y(_1580_));
 sky130_fd_sc_hd__nand3_1 _2261_ (.A(_1574_),
    .B(_1579_),
    .C(_1580_),
    .Y(_1581_));
 sky130_fd_sc_hd__a2111oi_4 _2262_ (.A1(UVLO_sync_db),
    .A2(_1174_),
    .B1(_1577_),
    .C1(_1578_),
    .D1(_1581_),
    .Y(_1582_));
 sky130_fd_sc_hd__a22oi_1 _2263_ (.A1(_1173_),
    .A2(_0359_),
    .B1(_0343_),
    .B2(_1183_),
    .Y(_1583_));
 sky130_fd_sc_hd__nand2_1 _2264_ (.A(_1570_),
    .B(_1583_),
    .Y(_1584_));
 sky130_fd_sc_hd__a222oi_1 _2265_ (.A1(\cycles_per_step[0] ),
    .A2(_0797_),
    .B1(_1165_),
    .B2(\fault_time[8] ),
    .C1(_1158_),
    .C2(\g_telemetry.u_reg_file.unlock_armed ),
    .Y(_1585_));
 sky130_fd_sc_hd__a22oi_4 _2266_ (.A1(\clean_run_target[0] ),
    .A2(_0784_),
    .B1(_0814_),
    .B2(\g_telemetry.u_reg_file.hiccup_base[8] ),
    .Y(_1586_));
 sky130_fd_sc_hd__a22oi_4 _2267_ (.A1(\g_telemetry.u_reg_file.hiccup_base[16] ),
    .A2(_0801_),
    .B1(_0872_),
    .B2(\g_telemetry.u_reg_file.max_strikes[0] ),
    .Y(_1587_));
 sky130_fd_sc_hd__nor2b_4 _2268_ (.A(Osc_sync),
    .B_N(\g_telemetry.u_pwm_stats.pwm_sync_d ),
    .Y(_0766_));
 sky130_fd_sc_hd__nand4_1 _2269_ (.A(_1573_),
    .B(_1585_),
    .C(_1586_),
    .D(_1587_),
    .Y(_1588_));
 sky130_fd_sc_hd__a22oi_1 _2270_ (.A1(\g_telemetry.u_reg_file.trip_run[0] ),
    .A2(_0995_),
    .B1(_1176_),
    .B2(\g_telemetry.u_reg_file.bus_err_count[0] ),
    .Y(_1589_));
 sky130_fd_sc_hd__a222oi_1 _2271_ (.A1(\fault_time[0] ),
    .A2(_1179_),
    .B1(_1180_),
    .B2(\g_telemetry.u_reg_file.bus_err_count[8] ),
    .C1(_1571_),
    .C2(\fault_reg[0] ),
    .Y(_1590_));
 sky130_fd_sc_hd__nand2_1 _2272_ (.A(_1589_),
    .B(_1590_),
    .Y(_1591_));
 sky130_fd_sc_hd__nor3_1 _2273_ (.A(_1584_),
    .B(_1588_),
    .C(_1591_),
    .Y(_1592_));
 sky130_fd_sc_hd__nand2_1 _2274_ (.A(_1582_),
    .B(_1592_),
    .Y(_1593_));
 sky130_fd_sc_hd__a22o_1 _2275_ (.A1(\g_telemetry.u_spi_slave.tx_shift[0] ),
    .A2(_1139_),
    .B1(_1178_),
    .B2(_1593_),
    .X(_0447_));
 sky130_fd_sc_hd__mux2_1 _2276_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[1] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[1] ),
    .S(_0994_),
    .X(_0358_));
 sky130_fd_sc_hd__mux2_1 _2277_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[9] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[9] ),
    .S(_0994_),
    .X(_0350_));
 sky130_fd_sc_hd__mux2_1 _2278_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[17] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[17] ),
    .S(_0994_),
    .X(_0342_));
 sky130_fd_sc_hd__nand2b_4 _2279_ (.A_N(Osc_sync),
    .B(\g_telemetry.u_pwm_stats.pwm_sync_d ),
    .Y(_0767_));
 sky130_fd_sc_hd__nand2_1 _2280_ (.A(_1183_),
    .B(_0342_),
    .Y(_1594_));
 sky130_fd_sc_hd__nand2_1 _2281_ (.A(\g_telemetry.u_reg_file.scratch_r[1] ),
    .B(_0999_),
    .Y(_1595_));
 sky130_fd_sc_hd__nand2_1 _2282_ (.A(\g_telemetry.u_reg_file.hiccup_base[17] ),
    .B(_0801_),
    .Y(_1596_));
 sky130_fd_sc_hd__a22oi_1 _2283_ (.A1(\duty_count[1] ),
    .A2(_1171_),
    .B1(_1172_),
    .B2(\g_telemetry.u_reg_file.strike_level[1] ),
    .Y(_1597_));
 sky130_fd_sc_hd__a22oi_2 _2284_ (.A1(\g_telemetry.u_reg_file.trip_ss[1] ),
    .A2(_0990_),
    .B1(_1165_),
    .B2(\fault_time[9] ),
    .Y(_1598_));
 sky130_fd_sc_hd__a222oi_1 _2285_ (.A1(\clean_run_target[9] ),
    .A2(_0778_),
    .B1(_0784_),
    .B2(\clean_run_target[1] ),
    .C1(_1151_),
    .C2(\g_telemetry.u_reg_file.sup_state[1] ),
    .Y(_1599_));
 sky130_fd_sc_hd__a22oi_2 _2286_ (.A1(\g_telemetry.u_reg_file.hiccup_base[9] ),
    .A2(_0814_),
    .B1(_1571_),
    .B2(\fault_reg[1] ),
    .Y(_1600_));
 sky130_fd_sc_hd__a222oi_1 _2287_ (.A1(\clean_run_target[17] ),
    .A2(_0822_),
    .B1(_0863_),
    .B2(\g_telemetry.u_reg_file.max_on_limit[1] ),
    .C1(_1180_),
    .C2(\g_telemetry.u_reg_file.bus_err_count[9] ),
    .Y(_1601_));
 sky130_fd_sc_hd__nand4_4 _2288_ (.A(_1598_),
    .B(_1599_),
    .C(_1600_),
    .D(_1601_),
    .Y(_1602_));
 sky130_fd_sc_hd__a21o_1 _2289_ (.A1(_1182_),
    .A2(_0350_),
    .B1(_1602_),
    .X(_1603_));
 sky130_fd_sc_hd__nand2_1 _2290_ (.A(\duty_count[5] ),
    .B(_0767_),
    .Y(_0768_));
 sky130_fd_sc_hd__a22oi_1 _2291_ (.A1(\fault_count_ss[1] ),
    .A2(_1160_),
    .B1(_1175_),
    .B2(\fault_count_run[1] ),
    .Y(_1604_));
 sky130_fd_sc_hd__nand4_2 _2292_ (.A(_1595_),
    .B(_1596_),
    .C(_1597_),
    .D(_1604_),
    .Y(_1605_));
 sky130_fd_sc_hd__a221oi_2 _2293_ (.A1(\g_telemetry.u_pwm_stats.prev_period[1] ),
    .A2(_1161_),
    .B1(_1176_),
    .B2(\g_telemetry.u_reg_file.bus_err_count[1] ),
    .C1(_1605_),
    .Y(_1606_));
 sky130_fd_sc_hd__a222oi_1 _2294_ (.A1(\g_telemetry.u_reg_file.max_strikes[1] ),
    .A2(_0874_),
    .B1(_0987_),
    .B2(\g_telemetry.u_reg_file.disable_armed ),
    .C1(_0995_),
    .C2(\g_telemetry.u_reg_file.trip_run[1] ),
    .Y(_1607_));
 sky130_fd_sc_hd__a222oi_1 _2295_ (.A1(\fault_time[17] ),
    .A2(_0714_),
    .B1(_1179_),
    .B2(\fault_time[1] ),
    .C1(_0797_),
    .C2(\cycles_per_step[1] ),
    .Y(_1608_));
 sky130_fd_sc_hd__nand2_1 _2296_ (.A(_1607_),
    .B(_1608_),
    .Y(_1609_));
 sky130_fd_sc_hd__a21oi_1 _2297_ (.A1(_1173_),
    .A2(_0358_),
    .B1(_1609_),
    .Y(_1610_));
 sky130_fd_sc_hd__a22oi_4 _2298_ (.A1(\g_telemetry.u_reg_file.hiccup_base[1] ),
    .A2(_0846_),
    .B1(_1174_),
    .B2(OTP_sync_db),
    .Y(_1611_));
 sky130_fd_sc_hd__nand4_2 _2299_ (.A(_1594_),
    .B(_1606_),
    .C(_1610_),
    .D(_1611_),
    .Y(_1612_));
 sky130_fd_sc_hd__o21ai_0 _2300_ (.A1(_1603_),
    .A2(_1612_),
    .B1(_1178_),
    .Y(_1613_));
 sky130_fd_sc_hd__o21ai_0 _2301_ (.A1(_0663_),
    .A2(_0767_),
    .B1(_0768_),
    .Y(_0652_));
 sky130_fd_sc_hd__nand2_1 _2302_ (.A(\g_telemetry.u_spi_slave.tx_shift[1] ),
    .B(_1139_),
    .Y(_1614_));
 sky130_fd_sc_hd__nand3_1 _2303_ (.A(\g_telemetry.u_spi_slave.tx_shift[0] ),
    .B(_1138_),
    .C(_1141_),
    .Y(_1615_));
 sky130_fd_sc_hd__nand3_1 _2304_ (.A(_1613_),
    .B(_1614_),
    .C(_1615_),
    .Y(_0446_));
 sky130_fd_sc_hd__nor2_1 _2305_ (.A(\g_telemetry.u_spi_slave.tx_shift[2] ),
    .B(_1138_),
    .Y(_1616_));
 sky130_fd_sc_hd__mux2_1 _2306_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[10] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[10] ),
    .S(_0994_),
    .X(_0349_));
 sky130_fd_sc_hd__mux2_1 _2307_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[2] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[2] ),
    .S(_0994_),
    .X(_0357_));
 sky130_fd_sc_hd__mux2_1 _2308_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[18] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[18] ),
    .S(_0994_),
    .X(_0341_));
 sky130_fd_sc_hd__nor2_4 _2309_ (.A(_1335_),
    .B(_1478_),
    .Y(PGOOD));
 sky130_fd_sc_hd__a22oi_1 _2310_ (.A1(\fault_time[2] ),
    .A2(_1179_),
    .B1(PGOOD),
    .B2(_1151_),
    .Y(_1617_));
 sky130_fd_sc_hd__a22oi_1 _2311_ (.A1(\g_telemetry.u_reg_file.bus_err_count[10] ),
    .A2(_1180_),
    .B1(_1571_),
    .B2(\fault_reg[2] ),
    .Y(_1618_));
 sky130_fd_sc_hd__inv_1 _2312_ (.A(UVLO_sync),
    .Y(_0671_));
 sky130_fd_sc_hd__and3_1 _2313_ (.A(\g_telemetry.u_pwm_stats.period_counter[0] ),
    .B(\g_telemetry.u_pwm_stats.period_counter[1] ),
    .C(\g_telemetry.u_pwm_stats.period_counter[2] ),
    .X(_0769_));
 sky130_fd_sc_hd__nand2_1 _2314_ (.A(\g_telemetry.u_pwm_stats.prev_period[2] ),
    .B(_1161_),
    .Y(_1619_));
 sky130_fd_sc_hd__nand2_1 _2315_ (.A(\g_telemetry.u_reg_file.scratch_r[2] ),
    .B(_0999_),
    .Y(_1620_));
 sky130_fd_sc_hd__a22oi_2 _2316_ (.A1(\fault_count_ss[2] ),
    .A2(_1160_),
    .B1(_1175_),
    .B2(\fault_count_run[2] ),
    .Y(_1621_));
 sky130_fd_sc_hd__a22oi_1 _2317_ (.A1(\clean_run_target[18] ),
    .A2(_0822_),
    .B1(_0987_),
    .B2(\g_telemetry.u_reg_file.en_pending ),
    .Y(_1622_));
 sky130_fd_sc_hd__nand3_1 _2318_ (.A(_1619_),
    .B(_1621_),
    .C(_1622_),
    .Y(_1623_));
 sky130_fd_sc_hd__a221oi_1 _2319_ (.A1(\fault_time[18] ),
    .A2(_0714_),
    .B1(_1171_),
    .B2(\duty_count[2] ),
    .C1(_1623_),
    .Y(_1624_));
 sky130_fd_sc_hd__nand3_1 _2320_ (.A(_1617_),
    .B(_1618_),
    .C(_1624_),
    .Y(_1625_));
 sky130_fd_sc_hd__a222oi_1 _2321_ (.A1(\cycles_per_step[2] ),
    .A2(_0797_),
    .B1(_1165_),
    .B2(\fault_time[10] ),
    .C1(_1176_),
    .C2(\g_telemetry.u_reg_file.bus_err_count[2] ),
    .Y(_1626_));
 sky130_fd_sc_hd__a21boi_0 _2322_ (.A1(_1173_),
    .A2(_0357_),
    .B1_N(_1626_),
    .Y(_1627_));
 sky130_fd_sc_hd__a22oi_1 _2323_ (.A1(_1182_),
    .A2(_0349_),
    .B1(_0341_),
    .B2(_1183_),
    .Y(_1628_));
 sky130_fd_sc_hd__and2_1 _2324_ (.A(\g_telemetry.u_pwm_stats.period_counter[3] ),
    .B(_0769_),
    .X(_0770_));
 sky130_fd_sc_hd__a21oi_1 _2325_ (.A1(\g_telemetry.u_reg_file.hiccup_base[2] ),
    .A2(_0846_),
    .B1(_1163_),
    .Y(_1629_));
 sky130_fd_sc_hd__a22oi_1 _2326_ (.A1(\clean_run_target[2] ),
    .A2(_0784_),
    .B1(_0995_),
    .B2(\g_telemetry.u_reg_file.trip_run[2] ),
    .Y(_1630_));
 sky130_fd_sc_hd__a22o_1 _2327_ (.A1(\clean_run_target[10] ),
    .A2(_0778_),
    .B1(_1174_),
    .B2(CP_sync),
    .X(_1631_));
 sky130_fd_sc_hd__a221oi_1 _2328_ (.A1(\g_telemetry.u_reg_file.hiccup_base[10] ),
    .A2(_0814_),
    .B1(_0863_),
    .B2(\g_telemetry.u_reg_file.max_on_limit[2] ),
    .C1(_1631_),
    .Y(_1632_));
 sky130_fd_sc_hd__nand3_1 _2329_ (.A(_1629_),
    .B(_1630_),
    .C(_1632_),
    .Y(_1633_));
 sky130_fd_sc_hd__a21oi_2 _2330_ (.A1(\g_telemetry.u_reg_file.trip_ss[2] ),
    .A2(_0990_),
    .B1(_1633_),
    .Y(_1634_));
 sky130_fd_sc_hd__nand4_1 _2331_ (.A(_1620_),
    .B(_1627_),
    .C(_1628_),
    .D(_1634_),
    .Y(_1635_));
 sky130_fd_sc_hd__o21ai_2 _2332_ (.A1(_1625_),
    .A2(_1635_),
    .B1(_1177_),
    .Y(_1636_));
 sky130_fd_sc_hd__a21oi_1 _2333_ (.A1(\g_telemetry.u_spi_slave.tx_shift[1] ),
    .A2(_1141_),
    .B1(_1139_),
    .Y(_1637_));
 sky130_fd_sc_hd__a21oi_1 _2334_ (.A1(_1636_),
    .A2(_1637_),
    .B1(_1616_),
    .Y(_0445_));
 sky130_fd_sc_hd__a21oi_1 _2335_ (.A1(\g_telemetry.u_pwm_stats.period_counter[4] ),
    .A2(_0770_),
    .B1(\g_telemetry.u_pwm_stats.period_counter[5] ),
    .Y(_0771_));
 sky130_fd_sc_hd__nor2_1 _2336_ (.A(\g_telemetry.u_spi_slave.tx_shift[3] ),
    .B(_1138_),
    .Y(_1638_));
 sky130_fd_sc_hd__mux2_1 _2337_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[3] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[3] ),
    .S(_0994_),
    .X(_0356_));
 sky130_fd_sc_hd__mux2_1 _2338_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[19] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[19] ),
    .S(_0994_),
    .X(_0340_));
 sky130_fd_sc_hd__mux2_1 _2339_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[11] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[11] ),
    .S(_0994_),
    .X(_0348_));
 sky130_fd_sc_hd__a22oi_1 _2340_ (.A1(_1183_),
    .A2(_0340_),
    .B1(_0348_),
    .B2(_1182_),
    .Y(_1639_));
 sky130_fd_sc_hd__nand2_1 _2341_ (.A(\g_telemetry.u_reg_file.bus_err_count[11] ),
    .B(_1180_),
    .Y(_1640_));
 sky130_fd_sc_hd__a22oi_1 _2342_ (.A1(\fault_time[3] ),
    .A2(_1179_),
    .B1(_1571_),
    .B2(\fault_reg[3] ),
    .Y(_1641_));
 sky130_fd_sc_hd__nand2_1 _2343_ (.A(\g_telemetry.u_reg_file.bus_err_count[3] ),
    .B(_1176_),
    .Y(_1642_));
 sky130_fd_sc_hd__a22oi_2 _2344_ (.A1(\clean_run_target[3] ),
    .A2(_0784_),
    .B1(_1161_),
    .B2(\g_telemetry.u_pwm_stats.prev_period[3] ),
    .Y(_1643_));
 sky130_fd_sc_hd__a21oi_1 _2345_ (.A1(\fault_count_run[3] ),
    .A2(_1175_),
    .B1(_1164_),
    .Y(_1644_));
 sky130_fd_sc_hd__nor2_1 _2346_ (.A(_0763_),
    .B(_0771_),
    .Y(_0651_));
 sky130_fd_sc_hd__a22o_1 _2347_ (.A1(\g_telemetry.u_reg_file.hiccup_base[11] ),
    .A2(_0814_),
    .B1(_0987_),
    .B2(\g_telemetry.u_reg_file.wd_restored ),
    .X(_1645_));
 sky130_fd_sc_hd__a221oi_1 _2348_ (.A1(\g_telemetry.u_reg_file.hiccup_base[3] ),
    .A2(_0846_),
    .B1(_1151_),
    .B2(\g_telemetry.u_fault_cause.latch_state ),
    .C1(_1645_),
    .Y(_1646_));
 sky130_fd_sc_hd__a222oi_1 _2349_ (.A1(\g_telemetry.u_reg_file.trip_ss[3] ),
    .A2(_0990_),
    .B1(_1171_),
    .B2(\duty_count[3] ),
    .C1(_1160_),
    .C2(\fault_count_ss[3] ),
    .Y(_1647_));
 sky130_fd_sc_hd__a21boi_0 _2350_ (.A1(\fault_time[19] ),
    .A2(_0714_),
    .B1_N(_1647_),
    .Y(_1648_));
 sky130_fd_sc_hd__nand4_2 _2351_ (.A(_1643_),
    .B(_1644_),
    .C(_1646_),
    .D(_1648_),
    .Y(_1649_));
 sky130_fd_sc_hd__a22o_1 _2352_ (.A1(\cycles_per_step[3] ),
    .A2(_0797_),
    .B1(_0999_),
    .B2(\g_telemetry.u_reg_file.scratch_r[3] ),
    .X(_1650_));
 sky130_fd_sc_hd__a221oi_2 _2353_ (.A1(\fault_time[11] ),
    .A2(_1165_),
    .B1(_1173_),
    .B2(_0356_),
    .C1(_1650_),
    .Y(_1651_));
 sky130_fd_sc_hd__a222oi_1 _2354_ (.A1(\clean_run_target[11] ),
    .A2(_0778_),
    .B1(_0995_),
    .B2(\g_telemetry.u_reg_file.trip_run[3] ),
    .C1(_0863_),
    .C2(\g_telemetry.u_reg_file.max_on_limit[3] ),
    .Y(_1652_));
 sky130_fd_sc_hd__and3_1 _2355_ (.A(_1640_),
    .B(_1641_),
    .C(_1652_),
    .X(_1653_));
 sky130_fd_sc_hd__nand4_1 _2356_ (.A(_1639_),
    .B(_1642_),
    .C(_1651_),
    .D(_1653_),
    .Y(_1654_));
 sky130_fd_sc_hd__a31oi_1 _2357_ (.A1(\g_telemetry.u_fault_cause.latch_state ),
    .A2(_0677_),
    .A3(_0704_),
    .B1(\fault_reg[4] ),
    .Y(_0772_));
 sky130_fd_sc_hd__o21ai_1 _2358_ (.A1(_1649_),
    .A2(_1654_),
    .B1(_1177_),
    .Y(_1655_));
 sky130_fd_sc_hd__a21oi_1 _2359_ (.A1(\g_telemetry.u_spi_slave.tx_shift[2] ),
    .A2(_1141_),
    .B1(_1139_),
    .Y(_1656_));
 sky130_fd_sc_hd__a21oi_1 _2360_ (.A1(_1655_),
    .A2(_1656_),
    .B1(_1638_),
    .Y(_0444_));
 sky130_fd_sc_hd__mux2_1 _2361_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[4] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[4] ),
    .S(_0994_),
    .X(_0355_));
 sky130_fd_sc_hd__nand2_1 _2362_ (.A(_1173_),
    .B(_0355_),
    .Y(_1657_));
 sky130_fd_sc_hd__a22oi_1 _2363_ (.A1(\g_telemetry.u_reg_file.hiccup_base[12] ),
    .A2(_0814_),
    .B1(_1160_),
    .B2(\fault_count_ss[4] ),
    .Y(_1658_));
 sky130_fd_sc_hd__nand2_1 _2364_ (.A(\fault_count_run[4] ),
    .B(_1175_),
    .Y(_1659_));
 sky130_fd_sc_hd__mux2_1 _2365_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[20] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[20] ),
    .S(_0994_),
    .X(_0339_));
 sky130_fd_sc_hd__nand2_1 _2366_ (.A(_1183_),
    .B(_0339_),
    .Y(_1660_));
 sky130_fd_sc_hd__mux2_1 _2367_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[12] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[12] ),
    .S(_0994_),
    .X(_0347_));
 sky130_fd_sc_hd__nor2_1 _2368_ (.A(_0716_),
    .B(_0772_),
    .Y(_0650_));
 sky130_fd_sc_hd__and2_0 _2369_ (.A(_1182_),
    .B(_0347_),
    .X(_1661_));
 sky130_fd_sc_hd__nand2_1 _2370_ (.A(\g_telemetry.u_pwm_stats.prev_period[4] ),
    .B(_1161_),
    .Y(_1662_));
 sky130_fd_sc_hd__nand2_1 _2371_ (.A(\clean_run_target[12] ),
    .B(_0778_),
    .Y(_1663_));
 sky130_fd_sc_hd__a222oi_1 _2372_ (.A1(\fault_time[4] ),
    .A2(_1179_),
    .B1(_1180_),
    .B2(\g_telemetry.u_reg_file.bus_err_count[12] ),
    .C1(\fault_reg[4] ),
    .C2(_1571_),
    .Y(_1664_));
 sky130_fd_sc_hd__a222oi_1 _2373_ (.A1(\g_telemetry.u_reg_file.trip_ss[4] ),
    .A2(_0990_),
    .B1(_1171_),
    .B2(\duty_count[4] ),
    .C1(_0995_),
    .C2(\g_telemetry.u_reg_file.trip_run[4] ),
    .Y(_1665_));
 sky130_fd_sc_hd__nand2_1 _2374_ (.A(_1664_),
    .B(_1665_),
    .Y(_1666_));
 sky130_fd_sc_hd__a22oi_4 _2375_ (.A1(\clean_run_target[4] ),
    .A2(_0784_),
    .B1(_0846_),
    .B2(\g_telemetry.u_reg_file.hiccup_base[4] ),
    .Y(_1667_));
 sky130_fd_sc_hd__a221oi_2 _2376_ (.A1(\fault_time[20] ),
    .A2(_0714_),
    .B1(_0797_),
    .B2(\cycles_per_step[4] ),
    .C1(_1163_),
    .Y(_1668_));
 sky130_fd_sc_hd__nand4_2 _2377_ (.A(_1659_),
    .B(_1662_),
    .C(_1667_),
    .D(_1668_),
    .Y(_1669_));
 sky130_fd_sc_hd__a22oi_1 _2378_ (.A1(\g_telemetry.u_reg_file.max_on_limit[4] ),
    .A2(_0863_),
    .B1(_1151_),
    .B2(en_from_switch_sync_db),
    .Y(_1670_));
 sky130_fd_sc_hd__nand2b_4 _2379_ (.A_N(\g_telemetry.u_reg_file.addr[2] ),
    .B(\g_telemetry.u_reg_file.addr[3] ),
    .Y(_0773_));
 sky130_fd_sc_hd__nand3_2 _2380_ (.A(_1658_),
    .B(_1663_),
    .C(_1670_),
    .Y(_1671_));
 sky130_fd_sc_hd__a222oi_1 _2381_ (.A1(\g_telemetry.u_reg_file.scratch_r[4] ),
    .A2(_0999_),
    .B1(_1165_),
    .B2(\fault_time[12] ),
    .C1(_1176_),
    .C2(\g_telemetry.u_reg_file.bus_err_count[4] ),
    .Y(_1672_));
 sky130_fd_sc_hd__nand3_1 _2382_ (.A(_1657_),
    .B(_1660_),
    .C(_1672_),
    .Y(_1673_));
 sky130_fd_sc_hd__or4_1 _2383_ (.A(_1666_),
    .B(_1669_),
    .C(_1671_),
    .D(_1673_),
    .X(_1674_));
 sky130_fd_sc_hd__o21ai_0 _2384_ (.A1(_1661_),
    .A2(_1674_),
    .B1(_1178_),
    .Y(_1675_));
 sky130_fd_sc_hd__nand2_1 _2385_ (.A(\g_telemetry.u_spi_slave.tx_shift[4] ),
    .B(_1139_),
    .Y(_1676_));
 sky130_fd_sc_hd__nand3_1 _2386_ (.A(\g_telemetry.u_spi_slave.tx_shift[3] ),
    .B(_1138_),
    .C(_1141_),
    .Y(_1677_));
 sky130_fd_sc_hd__nand3_1 _2387_ (.A(_1675_),
    .B(_1676_),
    .C(_1677_),
    .Y(_0443_));
 sky130_fd_sc_hd__mux2_1 _2388_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[5] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[5] ),
    .S(_0994_),
    .X(_0354_));
 sky130_fd_sc_hd__mux2_1 _2389_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[21] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[21] ),
    .S(_0994_),
    .X(_0338_));
 sky130_fd_sc_hd__and3b_1 _2390_ (.A_N(\g_telemetry.u_reg_file.addr[5] ),
    .B(\g_telemetry.u_reg_file.addr[4] ),
    .C(\g_telemetry.u_reg_file.addr[6] ),
    .X(_0774_));
 sky130_fd_sc_hd__mux2_1 _2391_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[13] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[13] ),
    .S(_0994_),
    .X(_0346_));
 sky130_fd_sc_hd__nand2_1 _2392_ (.A(_1182_),
    .B(_0346_),
    .Y(_1678_));
 sky130_fd_sc_hd__a22oi_1 _2393_ (.A1(_1173_),
    .A2(_0354_),
    .B1(_0338_),
    .B2(_1183_),
    .Y(_1679_));
 sky130_fd_sc_hd__nand2_1 _2394_ (.A(\g_telemetry.u_reg_file.scratch_r[5] ),
    .B(_0999_),
    .Y(_1680_));
 sky130_fd_sc_hd__a22oi_1 _2395_ (.A1(\fault_count_ss[5] ),
    .A2(_1160_),
    .B1(_1180_),
    .B2(\g_telemetry.u_reg_file.bus_err_count[13] ),
    .Y(_1681_));
 sky130_fd_sc_hd__a22oi_2 _2396_ (.A1(\clean_run_target[5] ),
    .A2(_0784_),
    .B1(_0995_),
    .B2(\g_telemetry.u_reg_file.trip_run[5] ),
    .Y(_1682_));
 sky130_fd_sc_hd__a22oi_1 _2397_ (.A1(\g_telemetry.u_reg_file.hiccup_base[5] ),
    .A2(_0846_),
    .B1(_1151_),
    .B2(\g_telemetry.u_reg_file.spi_enable ),
    .Y(_1683_));
 sky130_fd_sc_hd__nand4_2 _2398_ (.A(_1680_),
    .B(_1681_),
    .C(_1682_),
    .D(_1683_),
    .Y(_1684_));
 sky130_fd_sc_hd__a222oi_1 _2399_ (.A1(\g_telemetry.u_reg_file.hiccup_base[13] ),
    .A2(_0814_),
    .B1(_1171_),
    .B2(\duty_count[5] ),
    .C1(\clean_run_target[13] ),
    .C2(_0778_),
    .Y(_1685_));
 sky130_fd_sc_hd__a21boi_0 _2400_ (.A1(\fault_time[5] ),
    .A2(_1179_),
    .B1_N(_1685_),
    .Y(_1686_));
 sky130_fd_sc_hd__nand3b_4 _2401_ (.A_N(\g_telemetry.u_reg_file.addr[5] ),
    .B(\g_telemetry.u_reg_file.addr[4] ),
    .C(\g_telemetry.u_reg_file.addr[6] ),
    .Y(_0775_));
 sky130_fd_sc_hd__a22oi_1 _2402_ (.A1(\fault_time[21] ),
    .A2(_0714_),
    .B1(_1161_),
    .B2(\g_telemetry.u_pwm_stats.prev_period[5] ),
    .Y(_1687_));
 sky130_fd_sc_hd__a21oi_2 _2403_ (.A1(\g_telemetry.u_reg_file.trip_ss[5] ),
    .A2(_0990_),
    .B1(_1163_),
    .Y(_1688_));
 sky130_fd_sc_hd__a222oi_1 _2404_ (.A1(\cycles_per_step[5] ),
    .A2(_0797_),
    .B1(_1165_),
    .B2(\fault_time[13] ),
    .C1(\g_telemetry.u_reg_file.bus_err_count[5] ),
    .C2(_1176_),
    .Y(_1689_));
 sky130_fd_sc_hd__and3_1 _2405_ (.A(_1687_),
    .B(_1688_),
    .C(_1689_),
    .X(_1690_));
 sky130_fd_sc_hd__nand4_1 _2406_ (.A(_1678_),
    .B(_1679_),
    .C(_1686_),
    .D(_1690_),
    .Y(_1691_));
 sky130_fd_sc_hd__o21ai_0 _2407_ (.A1(_1684_),
    .A2(_1691_),
    .B1(_1178_),
    .Y(_1692_));
 sky130_fd_sc_hd__nand2_1 _2408_ (.A(\g_telemetry.u_spi_slave.tx_shift[5] ),
    .B(_1139_),
    .Y(_1693_));
 sky130_fd_sc_hd__nand3_1 _2409_ (.A(\g_telemetry.u_spi_slave.tx_shift[4] ),
    .B(_1138_),
    .C(_1141_),
    .Y(_1694_));
 sky130_fd_sc_hd__nand3_1 _2410_ (.A(_1692_),
    .B(_1693_),
    .C(_1694_),
    .Y(_0442_));
 sky130_fd_sc_hd__mux2_1 _2411_ (.A0(_1113_),
    .A1(_1136_),
    .S(\g_telemetry.u_spi_slave.bit_count[0] ),
    .X(_0441_));
 sky130_fd_sc_hd__nand2b_4 _2412_ (.A_N(\g_telemetry.u_reg_file.addr[1] ),
    .B(\g_telemetry.u_reg_file.addr[0] ),
    .Y(_0776_));
 sky130_fd_sc_hd__xor2_1 _2413_ (.A(\g_telemetry.u_spi_slave.bit_count[1] ),
    .B(\g_telemetry.u_spi_slave.bit_count[0] ),
    .X(_1695_));
 sky130_fd_sc_hd__a22o_1 _2414_ (.A1(\g_telemetry.u_spi_slave.bit_count[1] ),
    .A2(_1136_),
    .B1(_1695_),
    .B2(_1113_),
    .X(_0440_));
 sky130_fd_sc_hd__xor2_2 _2415_ (.A(\g_spi_filt.u_mosi_filt.flag_out ),
    .B(\g_telemetry.u_spi_slave.crc[7] ),
    .X(_1696_));
 sky130_fd_sc_hd__a22o_1 _2416_ (.A1(\g_telemetry.u_spi_slave.crc[0] ),
    .A2(_1136_),
    .B1(_1696_),
    .B2(_1113_),
    .X(_0439_));
 sky130_fd_sc_hd__xor2_1 _2417_ (.A(\g_telemetry.u_spi_slave.crc[0] ),
    .B(_1696_),
    .X(_1697_));
 sky130_fd_sc_hd__a22o_1 _2418_ (.A1(\g_telemetry.u_spi_slave.crc[1] ),
    .A2(_1136_),
    .B1(_1697_),
    .B2(_1113_),
    .X(_0438_));
 sky130_fd_sc_hd__xor2_1 _2419_ (.A(\g_telemetry.u_spi_slave.crc[1] ),
    .B(_1696_),
    .X(_1698_));
 sky130_fd_sc_hd__a22o_1 _2420_ (.A1(\g_telemetry.u_spi_slave.crc[2] ),
    .A2(_1136_),
    .B1(_1698_),
    .B2(_1113_),
    .X(_0437_));
 sky130_fd_sc_hd__a22o_1 _2421_ (.A1(\g_telemetry.u_spi_slave.crc[2] ),
    .A2(_1113_),
    .B1(_1136_),
    .B2(\g_telemetry.u_spi_slave.crc[3] ),
    .X(_0436_));
 sky130_fd_sc_hd__a22o_1 _2422_ (.A1(\g_telemetry.u_spi_slave.crc[3] ),
    .A2(_1113_),
    .B1(_1136_),
    .B2(\g_telemetry.u_spi_slave.crc[4] ),
    .X(_0435_));
 sky130_fd_sc_hd__inv_1 _2423_ (.A(\fault_count_ss[2] ),
    .Y(_0672_));
 sky130_fd_sc_hd__or2_4 _2424_ (.A(_0775_),
    .B(_0776_),
    .X(_0777_));
 sky130_fd_sc_hd__a22o_1 _2425_ (.A1(\g_telemetry.u_spi_slave.crc[4] ),
    .A2(_1113_),
    .B1(_1136_),
    .B2(\g_telemetry.u_spi_slave.crc[5] ),
    .X(_0434_));
 sky130_fd_sc_hd__a22o_1 _2426_ (.A1(\g_telemetry.u_spi_slave.crc[5] ),
    .A2(_1113_),
    .B1(_1136_),
    .B2(\g_telemetry.u_spi_slave.crc[6] ),
    .X(_0433_));
 sky130_fd_sc_hd__a21oi_1 _2427_ (.A1(\g_telemetry.u_spi_slave.byte_count[3] ),
    .A2(_1133_),
    .B1(_0708_),
    .Y(_1699_));
 sky130_fd_sc_hd__o21ai_0 _2428_ (.A1(\g_telemetry.u_spi_slave.byte_count[0] ),
    .A2(_0707_),
    .B1(_1112_),
    .Y(_1700_));
 sky130_fd_sc_hd__a21oi_1 _2429_ (.A1(\g_telemetry.u_spi_slave.byte_count[0] ),
    .A2(_1699_),
    .B1(_1700_),
    .Y(_0432_));
 sky130_fd_sc_hd__a21oi_1 _2430_ (.A1(\g_telemetry.u_spi_slave.byte_count[0] ),
    .A2(_0707_),
    .B1(\g_telemetry.u_spi_slave.byte_count[1] ),
    .Y(_1701_));
 sky130_fd_sc_hd__a311oi_1 _2431_ (.A1(\g_telemetry.u_spi_slave.byte_count[1] ),
    .A2(\g_telemetry.u_spi_slave.byte_count[0] ),
    .A3(_1699_),
    .B1(_1701_),
    .C1(_1111_),
    .Y(_0431_));
 sky130_fd_sc_hd__a31oi_1 _2432_ (.A1(\g_telemetry.u_spi_slave.byte_count[1] ),
    .A2(\g_telemetry.u_spi_slave.byte_count[0] ),
    .A3(_0707_),
    .B1(\g_telemetry.u_spi_slave.byte_count[2] ),
    .Y(_1702_));
 sky130_fd_sc_hd__a211oi_1 _2433_ (.A1(_1133_),
    .A2(_1699_),
    .B1(_1702_),
    .C1(_1111_),
    .Y(_0430_));
 sky130_fd_sc_hd__mux2_1 _2434_ (.A0(\g_telemetry.u_reg_file.wdata[0] ),
    .A1(\g_telemetry.u_spi_slave.held_data[0] ),
    .S(_0044_),
    .X(_0429_));
 sky130_fd_sc_hd__nor2_4 _2435_ (.A(_0773_),
    .B(_0777_),
    .Y(_0778_));
 sky130_fd_sc_hd__mux2_1 _2436_ (.A0(\g_telemetry.u_reg_file.wdata[1] ),
    .A1(\g_telemetry.u_spi_slave.held_data[1] ),
    .S(_0044_),
    .X(_0428_));
 sky130_fd_sc_hd__mux2_1 _2437_ (.A0(\g_telemetry.u_reg_file.wdata[2] ),
    .A1(\g_telemetry.u_spi_slave.held_data[2] ),
    .S(_0044_),
    .X(_0427_));
 sky130_fd_sc_hd__mux2_1 _2438_ (.A0(\g_telemetry.u_reg_file.wdata[3] ),
    .A1(\g_telemetry.u_spi_slave.held_data[3] ),
    .S(_0044_),
    .X(_0426_));
 sky130_fd_sc_hd__mux2_1 _2439_ (.A0(\g_telemetry.u_reg_file.wdata[4] ),
    .A1(\g_telemetry.u_spi_slave.held_data[4] ),
    .S(_0044_),
    .X(_0425_));
 sky130_fd_sc_hd__mux2_1 _2440_ (.A0(\g_telemetry.u_reg_file.wdata[5] ),
    .A1(\g_telemetry.u_spi_slave.held_data[5] ),
    .S(_0044_),
    .X(_0424_));
 sky130_fd_sc_hd__mux2_1 _2441_ (.A0(\g_telemetry.u_reg_file.wdata[6] ),
    .A1(\g_telemetry.u_spi_slave.held_data[6] ),
    .S(_0044_),
    .X(_0423_));
 sky130_fd_sc_hd__o21a_1 _2442_ (.A1(_1106_),
    .A2(_1108_),
    .B1(\g_spi_filt.u_sck_filt.disagree_counter[0] ),
    .X(_1703_));
 sky130_fd_sc_hd__o21ba_1 _2443_ (.A1(\g_spi_filt.u_sck_filt.disagree_counter[3] ),
    .A2(_1106_),
    .B1_N(\g_spi_filt.u_sck_filt.disagree_counter[0] ),
    .X(_1704_));
 sky130_fd_sc_hd__nor2_1 _2444_ (.A(_1703_),
    .B(_1704_),
    .Y(_0422_));
 sky130_fd_sc_hd__nor2_1 _2445_ (.A(\g_spi_filt.u_sck_filt.disagree_counter[1] ),
    .B(_1703_),
    .Y(_1705_));
 sky130_fd_sc_hd__nor2_8 _2446_ (.A(\g_telemetry.u_reg_file.integrity_OK ),
    .B(\g_telemetry.u_reg_file.abort ),
    .Y(_0779_));
 sky130_fd_sc_hd__nor2_1 _2447_ (.A(\g_spi_filt.u_sck_filt.disagree_counter[3] ),
    .B(_1107_),
    .Y(_1706_));
 sky130_fd_sc_hd__nor3_1 _2448_ (.A(\g_spi_filt.u_sck_filt.disagree_counter[3] ),
    .B(\g_spi_filt.u_sck_filt.disagree_counter[2] ),
    .C(_1107_),
    .Y(_1707_));
 sky130_fd_sc_hd__nor3_1 _2449_ (.A(_1106_),
    .B(_1705_),
    .C(_1707_),
    .Y(_0421_));
 sky130_fd_sc_hd__nor2_1 _2450_ (.A(\g_spi_filt.u_sck_filt.disagree_counter[2] ),
    .B(_1706_),
    .Y(_1708_));
 sky130_fd_sc_hd__nor2_1 _2451_ (.A(_1106_),
    .B(_1708_),
    .Y(_0420_));
 sky130_fd_sc_hd__nand2_1 _2452_ (.A(\g_spi_filt.u_mosi_filt.flag_out ),
    .B(_0692_),
    .Y(_1709_));
 sky130_fd_sc_hd__nand2_1 _2453_ (.A(\g_telemetry.u_spi_slave.rx_byte[1] ),
    .B(_0693_),
    .Y(_1710_));
 sky130_fd_sc_hd__nand2_1 _2454_ (.A(_1709_),
    .B(_1710_),
    .Y(_0419_));
 sky130_fd_sc_hd__nand2_1 _2455_ (.A(\g_telemetry.u_spi_slave.rx_byte[1] ),
    .B(_0692_),
    .Y(_1711_));
 sky130_fd_sc_hd__o21ai_0 _2456_ (.A1(_0686_),
    .A2(_0692_),
    .B1(_1711_),
    .Y(_0418_));
 sky130_fd_sc_hd__and2_4 _2457_ (.A(\g_telemetry.u_reg_file.wr_en ),
    .B(_0779_),
    .X(_0780_));
 sky130_fd_sc_hd__nand2_1 _2458_ (.A(\g_telemetry.u_spi_slave.rx_byte[3] ),
    .B(_0693_),
    .Y(_1712_));
 sky130_fd_sc_hd__o21ai_0 _2459_ (.A1(_0686_),
    .A2(_0693_),
    .B1(_1712_),
    .Y(_0417_));
 sky130_fd_sc_hd__nand2_1 _2460_ (.A(\g_telemetry.u_spi_slave.rx_byte[3] ),
    .B(_0692_),
    .Y(_1713_));
 sky130_fd_sc_hd__nand2_1 _2461_ (.A(\g_telemetry.u_spi_slave.rx_byte[4] ),
    .B(_0693_),
    .Y(_1714_));
 sky130_fd_sc_hd__nand2_1 _2462_ (.A(_1713_),
    .B(_1714_),
    .Y(_0416_));
 sky130_fd_sc_hd__nand2_1 _2463_ (.A(\g_telemetry.u_spi_slave.rx_byte[4] ),
    .B(_0692_),
    .Y(_1715_));
 sky130_fd_sc_hd__nand2_1 _2464_ (.A(\g_telemetry.u_spi_slave.rx_byte[5] ),
    .B(_0693_),
    .Y(_1716_));
 sky130_fd_sc_hd__nand2_1 _2465_ (.A(_1715_),
    .B(_1716_),
    .Y(_0415_));
 sky130_fd_sc_hd__nand2_1 _2466_ (.A(\g_telemetry.u_spi_slave.rx_byte[5] ),
    .B(_0692_),
    .Y(_1717_));
 sky130_fd_sc_hd__nand2_1 _2467_ (.A(\g_telemetry.u_spi_slave.rx_byte[6] ),
    .B(_0693_),
    .Y(_1718_));
 sky130_fd_sc_hd__nand2_4 _2468_ (.A(_0778_),
    .B(_0780_),
    .Y(_0781_));
 sky130_fd_sc_hd__nand2_1 _2469_ (.A(_1717_),
    .B(_1718_),
    .Y(_0414_));
 sky130_fd_sc_hd__mux2_1 _2470_ (.A0(_1075_),
    .A1(_1102_),
    .S(\g_telemetry.u_reg_file.strike_level[0] ),
    .X(_0413_));
 sky130_fd_sc_hd__a21boi_0 _2471_ (.A1(_1048_),
    .A2(_1058_),
    .B1_N(\u_latch_stat_sync_db.disagree_counter[0] ),
    .Y(_1719_));
 sky130_fd_sc_hd__nor2_1 _2472_ (.A(_1047_),
    .B(_1058_),
    .Y(_1720_));
 sky130_fd_sc_hd__nor2_1 _2473_ (.A(\u_latch_stat_sync_db.disagree_counter[0] ),
    .B(_1720_),
    .Y(_1721_));
 sky130_fd_sc_hd__nor2_1 _2474_ (.A(_1719_),
    .B(_1721_),
    .Y(_0412_));
 sky130_fd_sc_hd__o21ai_0 _2475_ (.A1(\u_latch_stat_sync_db.disagree_counter[1] ),
    .A2(_1719_),
    .B1(_1048_),
    .Y(_1722_));
 sky130_fd_sc_hd__nor2_1 _2476_ (.A(_1059_),
    .B(_1722_),
    .Y(_0411_));
 sky130_fd_sc_hd__a21oi_1 _2477_ (.A1(\u_latch_stat_sync_db.disagree_counter[2] ),
    .A2(_1059_),
    .B1(_1047_),
    .Y(_1723_));
 sky130_fd_sc_hd__o21a_1 _2478_ (.A1(\u_latch_stat_sync_db.disagree_counter[2] ),
    .A2(_1059_),
    .B1(_1723_),
    .X(_0410_));
 sky130_fd_sc_hd__mux2_1 _2479_ (.A0(\g_telemetry.u_reg_file.wdata[7] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_1[7] ),
    .S(_0781_),
    .X(_0649_));
 sky130_fd_sc_hd__a21oi_1 _2480_ (.A1(\u_latch_stat_sync_db.disagree_counter[2] ),
    .A2(_1059_),
    .B1(\u_latch_stat_sync_db.disagree_counter[3] ),
    .Y(_1724_));
 sky130_fd_sc_hd__nor3_1 _2481_ (.A(_1047_),
    .B(_1060_),
    .C(_1724_),
    .Y(_0409_));
 sky130_fd_sc_hd__o21ai_0 _2482_ (.A1(\u_latch_stat_sync_db.disagree_counter[4] ),
    .A2(_1060_),
    .B1(_1048_),
    .Y(_1725_));
 sky130_fd_sc_hd__nor2_1 _2483_ (.A(_1061_),
    .B(_1725_),
    .Y(_0408_));
 sky130_fd_sc_hd__a21oi_1 _2484_ (.A1(\u_latch_stat_sync_db.disagree_counter[5] ),
    .A2(_1061_),
    .B1(_1047_),
    .Y(_1726_));
 sky130_fd_sc_hd__o21a_1 _2485_ (.A1(\u_latch_stat_sync_db.disagree_counter[5] ),
    .A2(_1061_),
    .B1(_1726_),
    .X(_0407_));
 sky130_fd_sc_hd__a21oi_1 _2486_ (.A1(\u_latch_stat_sync_db.disagree_counter[5] ),
    .A2(_1061_),
    .B1(\u_latch_stat_sync_db.disagree_counter[6] ),
    .Y(_1727_));
 sky130_fd_sc_hd__nor3_1 _2487_ (.A(_1047_),
    .B(_1062_),
    .C(_1727_),
    .Y(_0406_));
 sky130_fd_sc_hd__o21ai_0 _2488_ (.A1(\u_latch_stat_sync_db.disagree_counter[7] ),
    .A2(_1062_),
    .B1(_1048_),
    .Y(_1728_));
 sky130_fd_sc_hd__nor2_1 _2489_ (.A(_1063_),
    .B(_1728_),
    .Y(_0405_));
 sky130_fd_sc_hd__xnor2_2 _2490_ (.A(\g_spi_filt.u_mosi_filt.flag_out ),
    .B(\g_spi_filt.u_mosi_filt.flag_in ),
    .Y(_0782_));
 sky130_fd_sc_hd__nor2_1 _2491_ (.A(\u_latch_stat_sync_db.disagree_counter[8] ),
    .B(_1063_),
    .Y(_1729_));
 sky130_fd_sc_hd__nor3_1 _2492_ (.A(_1047_),
    .B(_1064_),
    .C(_1729_),
    .Y(_0404_));
 sky130_fd_sc_hd__a21oi_1 _2493_ (.A1(\u_latch_stat_sync_db.disagree_counter[9] ),
    .A2(_1064_),
    .B1(_1047_),
    .Y(_1730_));
 sky130_fd_sc_hd__o21a_1 _2494_ (.A1(\u_latch_stat_sync_db.disagree_counter[9] ),
    .A2(_1064_),
    .B1(_1730_),
    .X(_0403_));
 sky130_fd_sc_hd__a21oi_1 _2495_ (.A1(\u_latch_stat_sync_db.disagree_counter[9] ),
    .A2(_1064_),
    .B1(\u_latch_stat_sync_db.disagree_counter[10] ),
    .Y(_1731_));
 sky130_fd_sc_hd__nor3_1 _2496_ (.A(_1047_),
    .B(_1065_),
    .C(_1731_),
    .Y(_0402_));
 sky130_fd_sc_hd__o21ai_0 _2497_ (.A1(\u_latch_stat_sync_db.disagree_counter[11] ),
    .A2(_1065_),
    .B1(_1048_),
    .Y(_1732_));
 sky130_fd_sc_hd__a21oi_1 _2498_ (.A1(\u_latch_stat_sync_db.disagree_counter[11] ),
    .A2(_1065_),
    .B1(_1732_),
    .Y(_0401_));
 sky130_fd_sc_hd__a21oi_1 _2499_ (.A1(\u_latch_stat_sync_db.disagree_counter[11] ),
    .A2(_1065_),
    .B1(\u_latch_stat_sync_db.disagree_counter[12] ),
    .Y(_1733_));
 sky130_fd_sc_hd__nor3_1 _2500_ (.A(_1047_),
    .B(_1066_),
    .C(_1733_),
    .Y(_0400_));
 sky130_fd_sc_hd__nor2b_1 _2501_ (.A(_0782_),
    .B_N(\g_spi_filt.u_mosi_filt.disagree_counter[3] ),
    .Y(_0648_));
 sky130_fd_sc_hd__nor2_1 _2502_ (.A(_1027_),
    .B(_1038_),
    .Y(_1734_));
 sky130_fd_sc_hd__nor2_1 _2503_ (.A(\u_UVLO_sync_db.disagree_counter[0] ),
    .B(_1734_),
    .Y(_1735_));
 sky130_fd_sc_hd__a21oi_1 _2504_ (.A1(\u_UVLO_sync_db.disagree_counter[0] ),
    .A2(_1044_),
    .B1(_1735_),
    .Y(_0399_));
 sky130_fd_sc_hd__a21oi_1 _2505_ (.A1(\u_UVLO_sync_db.disagree_counter[0] ),
    .A2(_1044_),
    .B1(\u_UVLO_sync_db.disagree_counter[1] ),
    .Y(_1736_));
 sky130_fd_sc_hd__nor2_1 _2506_ (.A(_1028_),
    .B(_1038_),
    .Y(_1737_));
 sky130_fd_sc_hd__nor3_1 _2507_ (.A(_1027_),
    .B(_1736_),
    .C(_1737_),
    .Y(_0398_));
 sky130_fd_sc_hd__xnor2_1 _2508_ (.A(\u_UVLO_sync_db.disagree_counter[2] ),
    .B(_1737_),
    .Y(_1738_));
 sky130_fd_sc_hd__nor2_1 _2509_ (.A(_1027_),
    .B(_1738_),
    .Y(_0397_));
 sky130_fd_sc_hd__a21oi_1 _2510_ (.A1(_1029_),
    .A2(_1044_),
    .B1(\u_UVLO_sync_db.disagree_counter[3] ),
    .Y(_1739_));
 sky130_fd_sc_hd__and2_0 _2511_ (.A(_1030_),
    .B(_1044_),
    .X(_1740_));
 sky130_fd_sc_hd__nand2_8 _2512_ (.A(_0709_),
    .B(_0774_),
    .Y(_0783_));
 sky130_fd_sc_hd__nor3_1 _2513_ (.A(_1027_),
    .B(_1739_),
    .C(_1740_),
    .Y(_0396_));
 sky130_fd_sc_hd__nor2_1 _2514_ (.A(\u_UVLO_sync_db.disagree_counter[4] ),
    .B(_1740_),
    .Y(_1741_));
 sky130_fd_sc_hd__nor3_1 _2515_ (.A(_1027_),
    .B(_1039_),
    .C(_1741_),
    .Y(_0395_));
 sky130_fd_sc_hd__nor2_1 _2516_ (.A(\u_UVLO_sync_db.disagree_counter[5] ),
    .B(_1039_),
    .Y(_1742_));
 sky130_fd_sc_hd__and2_1 _2517_ (.A(\u_UVLO_sync_db.disagree_counter[5] ),
    .B(_1039_),
    .X(_1743_));
 sky130_fd_sc_hd__nor3_1 _2518_ (.A(_1027_),
    .B(_1742_),
    .C(_1743_),
    .Y(_0394_));
 sky130_fd_sc_hd__a21oi_1 _2519_ (.A1(\u_UVLO_sync_db.disagree_counter[6] ),
    .A2(_1743_),
    .B1(_1027_),
    .Y(_1744_));
 sky130_fd_sc_hd__o21a_1 _2520_ (.A1(\u_UVLO_sync_db.disagree_counter[6] ),
    .A2(_1743_),
    .B1(_1744_),
    .X(_0393_));
 sky130_fd_sc_hd__a21oi_1 _2521_ (.A1(\u_UVLO_sync_db.disagree_counter[6] ),
    .A2(_1743_),
    .B1(\u_UVLO_sync_db.disagree_counter[7] ),
    .Y(_1745_));
 sky130_fd_sc_hd__and3_1 _2522_ (.A(\u_UVLO_sync_db.disagree_counter[7] ),
    .B(\u_UVLO_sync_db.disagree_counter[6] ),
    .C(_1743_),
    .X(_1746_));
 sky130_fd_sc_hd__nor2_8 _2523_ (.A(_0773_),
    .B(_0783_),
    .Y(_0784_));
 sky130_fd_sc_hd__nor3_1 _2524_ (.A(_1027_),
    .B(_1745_),
    .C(_1746_),
    .Y(_0392_));
 sky130_fd_sc_hd__nor2_1 _2525_ (.A(\u_UVLO_sync_db.disagree_counter[8] ),
    .B(_1746_),
    .Y(_1747_));
 sky130_fd_sc_hd__nor2_2 _2526_ (.A(_1038_),
    .B(_1042_),
    .Y(_1748_));
 sky130_fd_sc_hd__nor3_1 _2527_ (.A(_1027_),
    .B(_1747_),
    .C(_1748_),
    .Y(_0391_));
 sky130_fd_sc_hd__nor2_1 _2528_ (.A(\u_UVLO_sync_db.disagree_counter[9] ),
    .B(_1748_),
    .Y(_1749_));
 sky130_fd_sc_hd__a211oi_1 _2529_ (.A1(\u_UVLO_sync_db.disagree_counter[9] ),
    .A2(_1748_),
    .B1(_1749_),
    .C1(_1027_),
    .Y(_0390_));
 sky130_fd_sc_hd__a21oi_1 _2530_ (.A1(\u_UVLO_sync_db.disagree_counter[9] ),
    .A2(_1748_),
    .B1(\u_UVLO_sync_db.disagree_counter[10] ),
    .Y(_1750_));
 sky130_fd_sc_hd__and3_1 _2531_ (.A(\u_UVLO_sync_db.disagree_counter[9] ),
    .B(\u_UVLO_sync_db.disagree_counter[10] ),
    .C(_1748_),
    .X(_1751_));
 sky130_fd_sc_hd__nor3_1 _2532_ (.A(_1027_),
    .B(_1750_),
    .C(_1751_),
    .Y(_0389_));
 sky130_fd_sc_hd__nor2_1 _2533_ (.A(\u_UVLO_sync_db.disagree_counter[11] ),
    .B(_1751_),
    .Y(_1752_));
 sky130_fd_sc_hd__inv_1 _2534_ (.A(latch_stat_sync),
    .Y(_0673_));
 sky130_fd_sc_hd__nand2_4 _2535_ (.A(_0780_),
    .B(_0784_),
    .Y(_0785_));
 sky130_fd_sc_hd__and4_1 _2536_ (.A(\u_UVLO_sync_db.disagree_counter[9] ),
    .B(\u_UVLO_sync_db.disagree_counter[11] ),
    .C(\u_UVLO_sync_db.disagree_counter[10] ),
    .D(_1748_),
    .X(_1753_));
 sky130_fd_sc_hd__nor3_1 _2537_ (.A(_1027_),
    .B(_1752_),
    .C(_1753_),
    .Y(_0388_));
 sky130_fd_sc_hd__xnor2_1 _2538_ (.A(\u_UVLO_sync_db.disagree_counter[12] ),
    .B(_1753_),
    .Y(_1754_));
 sky130_fd_sc_hd__nor2_1 _2539_ (.A(_1027_),
    .B(_1754_),
    .Y(_0387_));
 sky130_fd_sc_hd__nor2_1 _2540_ (.A(\u_OTP_sync_db.disagree_counter[0] ),
    .B(_1012_),
    .Y(_1755_));
 sky130_fd_sc_hd__nor3_1 _2541_ (.A(_1002_),
    .B(_1013_),
    .C(_1755_),
    .Y(_0386_));
 sky130_fd_sc_hd__o21bai_1 _2542_ (.A1(\u_OTP_sync_db.disagree_counter[1] ),
    .A2(_1013_),
    .B1_N(_1002_),
    .Y(_1756_));
 sky130_fd_sc_hd__a21oi_1 _2543_ (.A1(\u_OTP_sync_db.disagree_counter[1] ),
    .A2(_1013_),
    .B1(_1756_),
    .Y(_0385_));
 sky130_fd_sc_hd__a21oi_1 _2544_ (.A1(\u_OTP_sync_db.disagree_counter[1] ),
    .A2(_1013_),
    .B1(\u_OTP_sync_db.disagree_counter[2] ),
    .Y(_1757_));
 sky130_fd_sc_hd__nor3_1 _2545_ (.A(_1002_),
    .B(_1014_),
    .C(_1757_),
    .Y(_0384_));
 sky130_fd_sc_hd__mux2_1 _2546_ (.A0(\g_telemetry.u_reg_file.wdata[7] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_0[7] ),
    .S(_0785_),
    .X(_0647_));
 sky130_fd_sc_hd__nor2_1 _2547_ (.A(\u_OTP_sync_db.disagree_counter[3] ),
    .B(_1014_),
    .Y(_1758_));
 sky130_fd_sc_hd__nor3_1 _2548_ (.A(_1002_),
    .B(_1015_),
    .C(_1758_),
    .Y(_0383_));
 sky130_fd_sc_hd__nor2_1 _2549_ (.A(\u_OTP_sync_db.disagree_counter[4] ),
    .B(_1015_),
    .Y(_1759_));
 sky130_fd_sc_hd__nor3_1 _2550_ (.A(_1002_),
    .B(_1016_),
    .C(_1759_),
    .Y(_0382_));
 sky130_fd_sc_hd__nor2_1 _2551_ (.A(\u_OTP_sync_db.disagree_counter[5] ),
    .B(_1016_),
    .Y(_1760_));
 sky130_fd_sc_hd__nor3_1 _2552_ (.A(_1002_),
    .B(_1017_),
    .C(_1760_),
    .Y(_0381_));
 sky130_fd_sc_hd__a21oi_1 _2553_ (.A1(\u_OTP_sync_db.disagree_counter[6] ),
    .A2(_1017_),
    .B1(_1002_),
    .Y(_1761_));
 sky130_fd_sc_hd__o21a_1 _2554_ (.A1(\u_OTP_sync_db.disagree_counter[6] ),
    .A2(_1017_),
    .B1(_1761_),
    .X(_0380_));
 sky130_fd_sc_hd__a21oi_1 _2555_ (.A1(\u_OTP_sync_db.disagree_counter[6] ),
    .A2(_1017_),
    .B1(\u_OTP_sync_db.disagree_counter[7] ),
    .Y(_1762_));
 sky130_fd_sc_hd__nor3_1 _2556_ (.A(_1002_),
    .B(_1018_),
    .C(_1762_),
    .Y(_0379_));
 sky130_fd_sc_hd__nand4_2 _2557_ (.A(\g_telemetry.u_reg_file.bus_err_count[3] ),
    .B(\g_telemetry.u_reg_file.bus_err_count[0] ),
    .C(\g_telemetry.u_reg_file.bus_err_count[2] ),
    .D(\g_telemetry.u_reg_file.bus_err_count[1] ),
    .Y(_0786_));
 sky130_fd_sc_hd__nor2_1 _2558_ (.A(\u_OTP_sync_db.disagree_counter[8] ),
    .B(_1018_),
    .Y(_1763_));
 sky130_fd_sc_hd__nor3_1 _2559_ (.A(_1002_),
    .B(_1021_),
    .C(_1763_),
    .Y(_0378_));
 sky130_fd_sc_hd__xnor2_1 _2560_ (.A(\u_OTP_sync_db.disagree_counter[9] ),
    .B(_1021_),
    .Y(_1764_));
 sky130_fd_sc_hd__nor2_1 _2561_ (.A(_1002_),
    .B(_1764_),
    .Y(_0377_));
 sky130_fd_sc_hd__a21oi_1 _2562_ (.A1(\u_OTP_sync_db.disagree_counter[9] ),
    .A2(_1021_),
    .B1(\u_OTP_sync_db.disagree_counter[10] ),
    .Y(_1765_));
 sky130_fd_sc_hd__nor3_1 _2563_ (.A(_1002_),
    .B(_1019_),
    .C(_1765_),
    .Y(_0376_));
 sky130_fd_sc_hd__nor2_1 _2564_ (.A(\u_OTP_sync_db.disagree_counter[11] ),
    .B(_1019_),
    .Y(_1766_));
 sky130_fd_sc_hd__nor3_1 _2565_ (.A(_1002_),
    .B(_1020_),
    .C(_1766_),
    .Y(_0375_));
 sky130_fd_sc_hd__nor2_1 _2566_ (.A(\u_OTP_sync_db.disagree_counter[12] ),
    .B(_1020_),
    .Y(_1767_));
 sky130_fd_sc_hd__a211oi_1 _2567_ (.A1(\u_OTP_sync_db.disagree_counter[12] ),
    .A2(_1020_),
    .B1(_1767_),
    .C1(_1002_),
    .Y(_0374_));
 sky130_fd_sc_hd__nand3_1 _2568_ (.A(\g_telemetry.u_reg_file.bus_err_count[9] ),
    .B(\g_telemetry.u_reg_file.bus_err_count[8] ),
    .C(\g_telemetry.u_reg_file.bus_err_count[10] ),
    .Y(_0787_));
 sky130_fd_sc_hd__mux2_1 _2569_ (.A0(\g_telemetry.u_reg_file.wdata[0] ),
    .A1(\g_telemetry.u_reg_file.scratch_r[0] ),
    .S(_1000_),
    .X(_0373_));
 sky130_fd_sc_hd__mux2_1 _2570_ (.A0(\g_telemetry.u_reg_file.wdata[1] ),
    .A1(\g_telemetry.u_reg_file.scratch_r[1] ),
    .S(_1000_),
    .X(_0372_));
 sky130_fd_sc_hd__mux2_1 _2571_ (.A0(\g_telemetry.u_reg_file.wdata[2] ),
    .A1(\g_telemetry.u_reg_file.scratch_r[2] ),
    .S(_1000_),
    .X(_0371_));
 sky130_fd_sc_hd__mux2_1 _2572_ (.A0(\g_telemetry.u_reg_file.wdata[3] ),
    .A1(\g_telemetry.u_reg_file.scratch_r[3] ),
    .S(_1000_),
    .X(_0370_));
 sky130_fd_sc_hd__mux2_1 _2573_ (.A0(\g_telemetry.u_reg_file.wdata[4] ),
    .A1(\g_telemetry.u_reg_file.scratch_r[4] ),
    .S(_1000_),
    .X(_0369_));
 sky130_fd_sc_hd__mux2_1 _2574_ (.A0(\g_telemetry.u_reg_file.wdata[5] ),
    .A1(\g_telemetry.u_reg_file.scratch_r[5] ),
    .S(_1000_),
    .X(_0368_));
 sky130_fd_sc_hd__mux2_1 _2575_ (.A0(\g_telemetry.u_reg_file.wdata[6] ),
    .A1(\g_telemetry.u_reg_file.scratch_r[6] ),
    .S(_1000_),
    .X(_0367_));
 sky130_fd_sc_hd__mux2_1 _2576_ (.A0(\g_telemetry.u_reg_file.wdata[0] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_run[0] ),
    .S(_0996_),
    .X(_0366_));
 sky130_fd_sc_hd__mux2_1 _2577_ (.A0(\g_telemetry.u_reg_file.wdata[1] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_run[1] ),
    .S(_0996_),
    .X(_0365_));
 sky130_fd_sc_hd__mux2_1 _2578_ (.A0(\g_telemetry.u_reg_file.wdata[2] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_run[2] ),
    .S(_0996_),
    .X(_0364_));
 sky130_fd_sc_hd__nand4_2 _2579_ (.A(\g_telemetry.u_reg_file.bus_err_count[5] ),
    .B(\g_telemetry.u_reg_file.bus_err_count[7] ),
    .C(\g_telemetry.u_reg_file.bus_err_count[6] ),
    .D(\g_telemetry.u_reg_file.bus_err_count[4] ),
    .Y(_0788_));
 sky130_fd_sc_hd__mux2_1 _2580_ (.A0(\g_telemetry.u_reg_file.wdata[3] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_run[3] ),
    .S(_0996_),
    .X(_0363_));
 sky130_fd_sc_hd__mux2_1 _2581_ (.A0(\g_telemetry.u_reg_file.wdata[4] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_run[4] ),
    .S(_0996_),
    .X(_0362_));
 sky130_fd_sc_hd__mux2_1 _2582_ (.A0(\g_telemetry.u_reg_file.wdata[5] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_run[5] ),
    .S(_0996_),
    .X(_0361_));
 sky130_fd_sc_hd__mux2_1 _2583_ (.A0(\g_telemetry.u_reg_file.wdata[6] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_run[6] ),
    .S(_0996_),
    .X(_0360_));
 sky130_fd_sc_hd__mux2_1 _2584_ (.A0(\g_telemetry.u_reg_file.wdata[0] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_ss[0] ),
    .S(_0991_),
    .X(_0336_));
 sky130_fd_sc_hd__mux2_1 _2585_ (.A0(\g_telemetry.u_reg_file.wdata[1] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_ss[1] ),
    .S(_0991_),
    .X(_0335_));
 sky130_fd_sc_hd__mux2_1 _2586_ (.A0(\g_telemetry.u_reg_file.wdata[2] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_ss[2] ),
    .S(_0991_),
    .X(_0334_));
 sky130_fd_sc_hd__mux2_1 _2587_ (.A0(\g_telemetry.u_reg_file.wdata[3] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_ss[3] ),
    .S(_0991_),
    .X(_0333_));
 sky130_fd_sc_hd__mux2_1 _2588_ (.A0(\g_telemetry.u_reg_file.wdata[4] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_ss[4] ),
    .S(_0991_),
    .X(_0332_));
 sky130_fd_sc_hd__mux2_1 _2589_ (.A0(\g_telemetry.u_reg_file.wdata[5] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_ss[5] ),
    .S(_0991_),
    .X(_0331_));
 sky130_fd_sc_hd__nand3_1 _2590_ (.A(\g_telemetry.u_reg_file.bus_err_count[11] ),
    .B(\g_telemetry.u_reg_file.bus_err_count[12] ),
    .C(\g_telemetry.u_reg_file.bus_err_count[13] ),
    .Y(_0789_));
 sky130_fd_sc_hd__mux2_1 _2591_ (.A0(\g_telemetry.u_reg_file.wdata[6] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_ss[6] ),
    .S(_0991_),
    .X(_0330_));
 sky130_fd_sc_hd__mux2_1 _2592_ (.A0(\g_telemetry.u_reg_file.wdata[0] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_2[0] ),
    .S(_0823_),
    .X(_0329_));
 sky130_fd_sc_hd__mux2_1 _2593_ (.A0(\g_telemetry.u_reg_file.wdata[1] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_2[1] ),
    .S(_0823_),
    .X(_0328_));
 sky130_fd_sc_hd__mux2_1 _2594_ (.A0(\g_telemetry.u_reg_file.wdata[2] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_2[2] ),
    .S(_0823_),
    .X(_0327_));
 sky130_fd_sc_hd__mux2_1 _2595_ (.A0(\g_telemetry.u_reg_file.wdata[3] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_2[3] ),
    .S(_0823_),
    .X(_0326_));
 sky130_fd_sc_hd__mux2_1 _2596_ (.A0(\g_telemetry.u_reg_file.wdata[4] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_2[4] ),
    .S(_0823_),
    .X(_0325_));
 sky130_fd_sc_hd__mux2_1 _2597_ (.A0(\g_telemetry.u_reg_file.wdata[5] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_2[5] ),
    .S(_0823_),
    .X(_0324_));
 sky130_fd_sc_hd__mux2_1 _2598_ (.A0(\g_telemetry.u_reg_file.wdata[6] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_2[6] ),
    .S(_0823_),
    .X(_0323_));
 sky130_fd_sc_hd__mux2_1 _2599_ (.A0(\g_telemetry.u_reg_file.wdata[0] ),
    .A1(\g_telemetry.u_reg_file.temp_max_strk[0] ),
    .S(_0873_),
    .X(_0322_));
 sky130_fd_sc_hd__mux2_1 _2600_ (.A0(\g_telemetry.u_reg_file.wdata[1] ),
    .A1(\g_telemetry.u_reg_file.temp_max_strk[1] ),
    .S(_0873_),
    .X(_0321_));
 sky130_fd_sc_hd__nor4_2 _2601_ (.A(_0786_),
    .B(_0787_),
    .C(_0788_),
    .D(_0789_),
    .Y(_0790_));
 sky130_fd_sc_hd__mux2_1 _2602_ (.A0(\g_telemetry.u_reg_file.wdata[2] ),
    .A1(\g_telemetry.u_reg_file.temp_max_strk[2] ),
    .S(_0873_),
    .X(_0320_));
 sky130_fd_sc_hd__mux2_1 _2603_ (.A0(\g_telemetry.u_reg_file.wdata[3] ),
    .A1(\g_telemetry.u_reg_file.temp_max_strk[3] ),
    .S(_0873_),
    .X(_0319_));
 sky130_fd_sc_hd__mux2_1 _2604_ (.A0(\g_telemetry.u_reg_file.wdata[4] ),
    .A1(\g_telemetry.u_reg_file.temp_max_strk[4] ),
    .S(_0873_),
    .X(_0318_));
 sky130_fd_sc_hd__mux2_1 _2605_ (.A0(\g_telemetry.u_reg_file.wdata[5] ),
    .A1(\g_telemetry.u_reg_file.temp_max_strk[5] ),
    .S(_0873_),
    .X(_0317_));
 sky130_fd_sc_hd__mux2_1 _2606_ (.A0(\g_telemetry.u_reg_file.wdata[6] ),
    .A1(\g_telemetry.u_reg_file.temp_max_strk[6] ),
    .S(_0873_),
    .X(_0316_));
 sky130_fd_sc_hd__nand2_1 _2607_ (.A(\cycles_per_step[0] ),
    .B(_0870_),
    .Y(_1768_));
 sky130_fd_sc_hd__nor3_1 _2608_ (.A(\g_telemetry.u_reg_file.temp_cyc_step[4] ),
    .B(\g_telemetry.u_reg_file.temp_cyc_step[2] ),
    .C(\g_telemetry.u_reg_file.temp_cyc_step[3] ),
    .Y(_1769_));
 sky130_fd_sc_hd__nor4_1 _2609_ (.A(\g_telemetry.u_reg_file.temp_cyc_step[7] ),
    .B(\g_telemetry.u_reg_file.temp_cyc_step[0] ),
    .C(\g_telemetry.u_reg_file.temp_cyc_step[1] ),
    .D(\g_telemetry.u_reg_file.temp_cyc_step[5] ),
    .Y(_1770_));
 sky130_fd_sc_hd__nand2_1 _2610_ (.A(_1769_),
    .B(_1770_),
    .Y(_1771_));
 sky130_fd_sc_hd__nor2_1 _2611_ (.A(\g_telemetry.u_reg_file.temp_cyc_step[6] ),
    .B(_1771_),
    .Y(_1772_));
 sky130_fd_sc_hd__nand3_1 _2612_ (.A(\g_telemetry.u_reg_file.bus_err_count[14] ),
    .B(\g_telemetry.u_reg_file.abort ),
    .C(_0790_),
    .Y(_0791_));
 sky130_fd_sc_hd__o21bai_4 _2613_ (.A1(_0870_),
    .A2(_1771_),
    .B1_N(_0871_),
    .Y(_1773_));
 sky130_fd_sc_hd__o21ai_0 _2614_ (.A1(\g_telemetry.u_reg_file.temp_cyc_step[0] ),
    .A2(_1772_),
    .B1(_1773_),
    .Y(_1774_));
 sky130_fd_sc_hd__nand2_1 _2615_ (.A(_1768_),
    .B(_1774_),
    .Y(_0315_));
 sky130_fd_sc_hd__a22o_1 _2616_ (.A1(\cycles_per_step[1] ),
    .A2(_0870_),
    .B1(_1773_),
    .B2(\g_telemetry.u_reg_file.temp_cyc_step[1] ),
    .X(_0314_));
 sky130_fd_sc_hd__a22o_1 _2617_ (.A1(\cycles_per_step[2] ),
    .A2(_0870_),
    .B1(_1773_),
    .B2(\g_telemetry.u_reg_file.temp_cyc_step[2] ),
    .X(_0313_));
 sky130_fd_sc_hd__a22o_1 _2618_ (.A1(\cycles_per_step[3] ),
    .A2(_0870_),
    .B1(_1773_),
    .B2(\g_telemetry.u_reg_file.temp_cyc_step[3] ),
    .X(_0312_));
 sky130_fd_sc_hd__a22o_1 _2619_ (.A1(\cycles_per_step[4] ),
    .A2(_0870_),
    .B1(_1773_),
    .B2(\g_telemetry.u_reg_file.temp_cyc_step[4] ),
    .X(_0311_));
 sky130_fd_sc_hd__a22o_1 _2620_ (.A1(\cycles_per_step[5] ),
    .A2(_0870_),
    .B1(_1773_),
    .B2(\g_telemetry.u_reg_file.temp_cyc_step[5] ),
    .X(_0310_));
 sky130_fd_sc_hd__nand2_1 _2621_ (.A(\g_telemetry.u_reg_file.max_on_limit[0] ),
    .B(_0866_),
    .Y(_1775_));
 sky130_fd_sc_hd__nor2_1 _2622_ (.A(\g_telemetry.u_reg_file.temp_max_on[2] ),
    .B(\g_telemetry.u_reg_file.temp_max_on[3] ),
    .Y(_1776_));
 sky130_fd_sc_hd__nand2b_1 _2623_ (.A_N(\g_telemetry.u_reg_file.bus_err_count[15] ),
    .B(_0791_),
    .Y(_0646_));
 sky130_fd_sc_hd__a21oi_1 _2624_ (.A1(_0868_),
    .A2(_1776_),
    .B1(\g_telemetry.u_reg_file.temp_max_on[0] ),
    .Y(_1777_));
 sky130_fd_sc_hd__nor2_1 _2625_ (.A(\g_telemetry.u_reg_file.temp_max_on[0] ),
    .B(\g_telemetry.u_reg_file.temp_max_on[1] ),
    .Y(_1778_));
 sky130_fd_sc_hd__nand2_1 _2626_ (.A(_1776_),
    .B(_1778_),
    .Y(_1779_));
 sky130_fd_sc_hd__a21o_1 _2627_ (.A1(\g_telemetry.u_reg_file.temp_max_on[4] ),
    .A2(_1779_),
    .B1(_0867_),
    .X(_1780_));
 sky130_fd_sc_hd__a21oi_1 _2628_ (.A1(\g_telemetry.u_reg_file.temp_max_on[4] ),
    .A2(_1779_),
    .B1(_0867_),
    .Y(_1781_));
 sky130_fd_sc_hd__o21ai_0 _2629_ (.A1(_1777_),
    .A2(_1780_),
    .B1(_1775_),
    .Y(_0309_));
 sky130_fd_sc_hd__nand2_1 _2630_ (.A(\g_telemetry.u_reg_file.max_on_limit[1] ),
    .B(_0866_),
    .Y(_1782_));
 sky130_fd_sc_hd__a21oi_1 _2631_ (.A1(_0868_),
    .A2(_1776_),
    .B1(\g_telemetry.u_reg_file.temp_max_on[1] ),
    .Y(_1783_));
 sky130_fd_sc_hd__o21ai_0 _2632_ (.A1(_1780_),
    .A2(_1783_),
    .B1(_1782_),
    .Y(_0308_));
 sky130_fd_sc_hd__a22o_1 _2633_ (.A1(\g_telemetry.u_reg_file.max_on_limit[2] ),
    .A2(_0866_),
    .B1(_1781_),
    .B2(\g_telemetry.u_reg_file.temp_max_on[2] ),
    .X(_0307_));
 sky130_fd_sc_hd__nand2_1 _2634_ (.A(\g_spi_filt.u_mosi_filt.disagree_counter[1] ),
    .B(\g_spi_filt.u_mosi_filt.disagree_counter[0] ),
    .Y(_0792_));
 sky130_fd_sc_hd__a22o_1 _2635_ (.A1(\g_telemetry.u_reg_file.max_on_limit[3] ),
    .A2(_0866_),
    .B1(_1781_),
    .B2(\g_telemetry.u_reg_file.temp_max_on[3] ),
    .X(_0306_));
 sky130_fd_sc_hd__nand2_1 _2636_ (.A(\g_telemetry.u_reg_file.trip_run[0] ),
    .B(_0865_),
    .Y(_1784_));
 sky130_fd_sc_hd__or4_2 _2637_ (.A(\g_telemetry.u_reg_file.temp_trip_run[7] ),
    .B(\g_telemetry.u_reg_file.temp_trip_run[4] ),
    .C(\g_telemetry.u_reg_file.temp_trip_run[5] ),
    .D(\g_telemetry.u_reg_file.temp_trip_run[6] ),
    .X(_1785_));
 sky130_fd_sc_hd__nor2_2 _2638_ (.A(_0865_),
    .B(_1785_),
    .Y(_1786_));
 sky130_fd_sc_hd__nor3_1 _2639_ (.A(\g_telemetry.u_reg_file.temp_trip_run[1] ),
    .B(\g_telemetry.u_reg_file.temp_trip_run[2] ),
    .C(\g_telemetry.u_reg_file.temp_trip_run[3] ),
    .Y(_1787_));
 sky130_fd_sc_hd__o21ai_0 _2640_ (.A1(\g_telemetry.u_reg_file.temp_trip_run[0] ),
    .A2(_1787_),
    .B1(_1786_),
    .Y(_1788_));
 sky130_fd_sc_hd__nand2_1 _2641_ (.A(_1784_),
    .B(_1788_),
    .Y(_0305_));
 sky130_fd_sc_hd__a22o_1 _2642_ (.A1(\g_telemetry.u_reg_file.trip_run[1] ),
    .A2(_0865_),
    .B1(_1786_),
    .B2(\g_telemetry.u_reg_file.temp_trip_run[1] ),
    .X(_0304_));
 sky130_fd_sc_hd__a22o_1 _2643_ (.A1(\g_telemetry.u_reg_file.trip_run[2] ),
    .A2(_0865_),
    .B1(_1786_),
    .B2(\g_telemetry.u_reg_file.temp_trip_run[2] ),
    .X(_0303_));
 sky130_fd_sc_hd__a22o_1 _2644_ (.A1(\g_telemetry.u_reg_file.trip_run[3] ),
    .A2(_0865_),
    .B1(_1786_),
    .B2(\g_telemetry.u_reg_file.temp_trip_run[3] ),
    .X(_0302_));
 sky130_fd_sc_hd__inv_1 _2645_ (.A(\u_pwm_mask.run_counter[2] ),
    .Y(_0674_));
 sky130_fd_sc_hd__a31oi_1 _2646_ (.A1(\g_spi_filt.u_mosi_filt.disagree_counter[1] ),
    .A2(\g_spi_filt.u_mosi_filt.disagree_counter[0] ),
    .A3(\g_spi_filt.u_mosi_filt.disagree_counter[2] ),
    .B1(\g_spi_filt.u_mosi_filt.disagree_counter[3] ),
    .Y(_0793_));
 sky130_fd_sc_hd__a21oi_1 _2647_ (.A1(_0687_),
    .A2(_0865_),
    .B1(_1786_),
    .Y(_0301_));
 sky130_fd_sc_hd__mux2_1 _2648_ (.A0(\g_telemetry.u_reg_file.wdata[0] ),
    .A1(\g_telemetry.u_reg_file.temp_max_on[0] ),
    .S(_0864_),
    .X(_0300_));
 sky130_fd_sc_hd__mux2_1 _2649_ (.A0(\g_telemetry.u_reg_file.wdata[1] ),
    .A1(\g_telemetry.u_reg_file.temp_max_on[1] ),
    .S(_0864_),
    .X(_0299_));
 sky130_fd_sc_hd__mux2_1 _2650_ (.A0(\g_telemetry.u_reg_file.wdata[2] ),
    .A1(\g_telemetry.u_reg_file.temp_max_on[2] ),
    .S(_0864_),
    .X(_0298_));
 sky130_fd_sc_hd__mux2_1 _2651_ (.A0(\g_telemetry.u_reg_file.wdata[3] ),
    .A1(\g_telemetry.u_reg_file.temp_max_on[3] ),
    .S(_0864_),
    .X(_0297_));
 sky130_fd_sc_hd__mux2_1 _2652_ (.A0(\g_telemetry.u_reg_file.wdata[4] ),
    .A1(\g_telemetry.u_reg_file.temp_max_on[4] ),
    .S(_0864_),
    .X(_0296_));
 sky130_fd_sc_hd__mux2_1 _2653_ (.A0(\g_telemetry.u_reg_file.wdata[5] ),
    .A1(\g_telemetry.u_reg_file.temp_max_on[5] ),
    .S(_0864_),
    .X(_0295_));
 sky130_fd_sc_hd__mux2_1 _2654_ (.A0(\g_telemetry.u_reg_file.wdata[6] ),
    .A1(\g_telemetry.u_reg_file.temp_max_on[6] ),
    .S(_0864_),
    .X(_0294_));
 sky130_fd_sc_hd__nor3_1 _2655_ (.A(\g_telemetry.u_reg_file.temp_trip_ss[3] ),
    .B(\g_telemetry.u_reg_file.temp_trip_ss[1] ),
    .C(\g_telemetry.u_reg_file.temp_trip_ss[0] ),
    .Y(_1789_));
 sky130_fd_sc_hd__nor4_1 _2656_ (.A(\g_telemetry.u_reg_file.temp_trip_ss[7] ),
    .B(\g_telemetry.u_reg_file.temp_trip_ss[4] ),
    .C(\g_telemetry.u_reg_file.temp_trip_ss[2] ),
    .D(\g_telemetry.u_reg_file.temp_trip_ss[6] ),
    .Y(_1790_));
 sky130_fd_sc_hd__mux2_1 _2657_ (.A0(\g_spi_filt.u_mosi_filt.flag_in ),
    .A1(\g_spi_filt.u_mosi_filt.flag_out ),
    .S(_0793_),
    .X(_0645_));
 sky130_fd_sc_hd__nand2_1 _2658_ (.A(_1789_),
    .B(_1790_),
    .Y(_1791_));
 sky130_fd_sc_hd__nor2_1 _2659_ (.A(\g_telemetry.u_reg_file.temp_trip_ss[5] ),
    .B(_1791_),
    .Y(_1792_));
 sky130_fd_sc_hd__a21oi_1 _2660_ (.A1(\g_telemetry.u_reg_file.temp_trip_ss[0] ),
    .A2(_0861_),
    .B1(_1792_),
    .Y(_1793_));
 sky130_fd_sc_hd__nand2_1 _2661_ (.A(\g_telemetry.u_reg_file.trip_ss[0] ),
    .B(_0860_),
    .Y(_1794_));
 sky130_fd_sc_hd__o21ai_0 _2662_ (.A1(_0860_),
    .A2(_1793_),
    .B1(_1794_),
    .Y(_0293_));
 sky130_fd_sc_hd__a22o_1 _2663_ (.A1(\g_telemetry.u_reg_file.trip_ss[1] ),
    .A2(_0860_),
    .B1(_0862_),
    .B2(\g_telemetry.u_reg_file.temp_trip_ss[1] ),
    .X(_0292_));
 sky130_fd_sc_hd__a22o_1 _2664_ (.A1(\g_telemetry.u_reg_file.trip_ss[2] ),
    .A2(_0860_),
    .B1(_0862_),
    .B2(\g_telemetry.u_reg_file.temp_trip_ss[2] ),
    .X(_0291_));
 sky130_fd_sc_hd__a21oi_1 _2665_ (.A1(\g_telemetry.u_reg_file.temp_trip_ss[3] ),
    .A2(_0861_),
    .B1(_0860_),
    .Y(_1795_));
 sky130_fd_sc_hd__a21oi_1 _2666_ (.A1(\g_telemetry.u_reg_file.temp_dirty[1] ),
    .A2(_0831_),
    .B1(\g_telemetry.u_reg_file.trip_ss[3] ),
    .Y(_1796_));
 sky130_fd_sc_hd__nor2_1 _2667_ (.A(_1795_),
    .B(_1796_),
    .Y(_0290_));
 sky130_fd_sc_hd__nand2_8 _2668_ (.A(\g_telemetry.u_reg_file.addr[1] ),
    .B(\g_telemetry.u_reg_file.addr[0] ),
    .Y(_0794_));
 sky130_fd_sc_hd__a22o_1 _2669_ (.A1(\g_telemetry.u_reg_file.trip_ss[4] ),
    .A2(_0860_),
    .B1(_0862_),
    .B2(\g_telemetry.u_reg_file.temp_trip_ss[4] ),
    .X(_0289_));
 sky130_fd_sc_hd__a21oi_1 _2670_ (.A1(\g_telemetry.u_reg_file.temp_dirty[2] ),
    .A2(_0831_),
    .B1(\g_telemetry.u_reg_file.max_strikes[0] ),
    .Y(_1797_));
 sky130_fd_sc_hd__nor2_1 _2671_ (.A(\g_telemetry.u_reg_file.temp_max_strk[0] ),
    .B(_0855_),
    .Y(_1798_));
 sky130_fd_sc_hd__a31oi_1 _2672_ (.A1(\g_telemetry.u_reg_file.temp_max_strk[1] ),
    .A2(_0857_),
    .A3(_1798_),
    .B1(_1797_),
    .Y(_0288_));
 sky130_fd_sc_hd__mux2_1 _2673_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[0] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[0] ),
    .S(_0854_),
    .X(_0287_));
 sky130_fd_sc_hd__nor2_1 _2674_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[1] ),
    .B(_0854_),
    .Y(_1799_));
 sky130_fd_sc_hd__a21oi_1 _2675_ (.A1(_0689_),
    .A2(_0854_),
    .B1(_1799_),
    .Y(_0286_));
 sky130_fd_sc_hd__mux2_1 _2676_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[2] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[2] ),
    .S(_0854_),
    .X(_0285_));
 sky130_fd_sc_hd__mux2_1 _2677_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[3] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[3] ),
    .S(_0854_),
    .X(_0284_));
 sky130_fd_sc_hd__mux2_1 _2678_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[4] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[4] ),
    .S(_0854_),
    .X(_0283_));
 sky130_fd_sc_hd__nand2b_4 _2679_ (.A_N(\g_telemetry.u_reg_file.addr[3] ),
    .B(\g_telemetry.u_reg_file.addr[2] ),
    .Y(_0795_));
 sky130_fd_sc_hd__mux2_1 _2680_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[5] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[5] ),
    .S(_0854_),
    .X(_0282_));
 sky130_fd_sc_hd__mux2_1 _2681_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[6] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[6] ),
    .S(_0854_),
    .X(_0281_));
 sky130_fd_sc_hd__mux2_1 _2682_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[7] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[7] ),
    .S(_0854_),
    .X(_0280_));
 sky130_fd_sc_hd__mux2_1 _2683_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[8] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[8] ),
    .S(_0854_),
    .X(_0279_));
 sky130_fd_sc_hd__mux2_1 _2684_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[9] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[9] ),
    .S(_0854_),
    .X(_0278_));
 sky130_fd_sc_hd__mux2_1 _2685_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[10] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[10] ),
    .S(_0854_),
    .X(_0277_));
 sky130_fd_sc_hd__mux2_1 _2686_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[11] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[11] ),
    .S(_0854_),
    .X(_0276_));
 sky130_fd_sc_hd__mux2_1 _2687_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[12] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[12] ),
    .S(_0854_),
    .X(_0275_));
 sky130_fd_sc_hd__mux2_1 _2688_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[13] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[13] ),
    .S(_0854_),
    .X(_0274_));
 sky130_fd_sc_hd__mux2_1 _2689_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[14] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[14] ),
    .S(_0854_),
    .X(_0273_));
 sky130_fd_sc_hd__and3_1 _2690_ (.A(\g_telemetry.u_reg_file.addr[2] ),
    .B(\g_telemetry.u_reg_file.addr[1] ),
    .C(\g_telemetry.u_reg_file.addr[0] ),
    .X(_0796_));
 sky130_fd_sc_hd__mux2_1 _2691_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[15] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[15] ),
    .S(_0854_),
    .X(_0272_));
 sky130_fd_sc_hd__mux2_1 _2692_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[16] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[16] ),
    .S(_0854_),
    .X(_0271_));
 sky130_fd_sc_hd__mux2_1 _2693_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[17] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[17] ),
    .S(_0854_),
    .X(_0270_));
 sky130_fd_sc_hd__mux2_1 _2694_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[18] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[18] ),
    .S(_0854_),
    .X(_0269_));
 sky130_fd_sc_hd__mux2_1 _2695_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[19] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[19] ),
    .S(_0854_),
    .X(_0268_));
 sky130_fd_sc_hd__mux2_1 _2696_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[20] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[20] ),
    .S(_0854_),
    .X(_0267_));
 sky130_fd_sc_hd__mux2_1 _2697_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[21] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[21] ),
    .S(_0854_),
    .X(_0266_));
 sky130_fd_sc_hd__mux2_1 _2698_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[22] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[22] ),
    .S(_0854_),
    .X(_0265_));
 sky130_fd_sc_hd__nor2_1 _2699_ (.A(\g_telemetry.u_reg_file.temp_clean_2[0] ),
    .B(_0851_),
    .Y(_1800_));
 sky130_fd_sc_hd__nor4_1 _2700_ (.A(\g_telemetry.u_reg_file.temp_clean_2[0] ),
    .B(\g_telemetry.u_reg_file.temp_clean_2[2] ),
    .C(\g_telemetry.u_reg_file.temp_clean_2[1] ),
    .D(_0851_),
    .Y(_1801_));
 sky130_fd_sc_hd__nor3_4 _2701_ (.A(_0775_),
    .B(_0794_),
    .C(_0795_),
    .Y(_0797_));
 sky130_fd_sc_hd__nor3_1 _2702_ (.A(\g_telemetry.u_reg_file.temp_clean_0[3] ),
    .B(\g_telemetry.u_reg_file.temp_clean_0[5] ),
    .C(\g_telemetry.u_reg_file.temp_clean_0[4] ),
    .Y(_1802_));
 sky130_fd_sc_hd__nand3_1 _2703_ (.A(\g_telemetry.u_reg_file.temp_clean_0[6] ),
    .B(\g_telemetry.u_reg_file.temp_clean_1[0] ),
    .C(\g_telemetry.u_reg_file.temp_clean_1[3] ),
    .Y(_1803_));
 sky130_fd_sc_hd__nand3_1 _2704_ (.A(\g_telemetry.u_reg_file.temp_clean_0[7] ),
    .B(\g_telemetry.u_reg_file.temp_clean_1[1] ),
    .C(\g_telemetry.u_reg_file.temp_clean_1[2] ),
    .Y(_1804_));
 sky130_fd_sc_hd__nor3_1 _2705_ (.A(_1802_),
    .B(_1803_),
    .C(_1804_),
    .Y(_1805_));
 sky130_fd_sc_hd__o21a_1 _2706_ (.A1(\g_telemetry.u_reg_file.temp_clean_1[4] ),
    .A2(_1805_),
    .B1(\g_telemetry.u_reg_file.temp_clean_1[5] ),
    .X(_1806_));
 sky130_fd_sc_hd__o21ai_0 _2707_ (.A1(\g_telemetry.u_reg_file.temp_clean_1[6] ),
    .A2(_1806_),
    .B1(\g_telemetry.u_reg_file.temp_clean_1[7] ),
    .Y(_1807_));
 sky130_fd_sc_hd__nand2_2 _2708_ (.A(_1801_),
    .B(_1807_),
    .Y(_1808_));
 sky130_fd_sc_hd__o21ai_0 _2709_ (.A1(\g_telemetry.u_reg_file.temp_clean_0[0] ),
    .A2(_0851_),
    .B1(_1808_),
    .Y(_1809_));
 sky130_fd_sc_hd__nor2_1 _2710_ (.A(\clean_run_target[0] ),
    .B(_0848_),
    .Y(_1810_));
 sky130_fd_sc_hd__a21oi_1 _2711_ (.A1(_0848_),
    .A2(_1809_),
    .B1(_1810_),
    .Y(_0264_));
 sky130_fd_sc_hd__and2_4 _2712_ (.A(_0780_),
    .B(_0797_),
    .X(_0798_));
 sky130_fd_sc_hd__o21ai_0 _2713_ (.A1(\g_telemetry.u_reg_file.temp_clean_0[1] ),
    .A2(_0851_),
    .B1(_1808_),
    .Y(_1811_));
 sky130_fd_sc_hd__nor2_1 _2714_ (.A(\clean_run_target[1] ),
    .B(_0848_),
    .Y(_1812_));
 sky130_fd_sc_hd__a21oi_1 _2715_ (.A1(_0848_),
    .A2(_1811_),
    .B1(_1812_),
    .Y(_0263_));
 sky130_fd_sc_hd__o211ai_1 _2716_ (.A1(\g_telemetry.u_reg_file.temp_clean_0[2] ),
    .A2(_0851_),
    .B1(_1808_),
    .C1(_0848_),
    .Y(_1813_));
 sky130_fd_sc_hd__o21ai_0 _2717_ (.A1(_0690_),
    .A2(_0848_),
    .B1(_1813_),
    .Y(_0262_));
 sky130_fd_sc_hd__nand3_4 _2718_ (.A(_0848_),
    .B(_0852_),
    .C(_1808_),
    .Y(_1814_));
 sky130_fd_sc_hd__o22a_1 _2719_ (.A1(\clean_run_target[3] ),
    .A2(_0848_),
    .B1(_1814_),
    .B2(\g_telemetry.u_reg_file.temp_clean_0[3] ),
    .X(_0261_));
 sky130_fd_sc_hd__o21ai_0 _2720_ (.A1(\g_telemetry.u_reg_file.temp_clean_0[4] ),
    .A2(_0851_),
    .B1(_1808_),
    .Y(_1815_));
 sky130_fd_sc_hd__nor2_1 _2721_ (.A(\clean_run_target[4] ),
    .B(_0848_),
    .Y(_1816_));
 sky130_fd_sc_hd__a21oi_1 _2722_ (.A1(_0848_),
    .A2(_1815_),
    .B1(_1816_),
    .Y(_0260_));
 sky130_fd_sc_hd__mux2_1 _2723_ (.A0(\g_telemetry.u_reg_file.temp_cyc_step[7] ),
    .A1(\g_telemetry.u_reg_file.wdata[7] ),
    .S(_0798_),
    .X(_0644_));
 sky130_fd_sc_hd__o21ai_0 _2724_ (.A1(\g_telemetry.u_reg_file.temp_clean_0[5] ),
    .A2(_0851_),
    .B1(_1808_),
    .Y(_1817_));
 sky130_fd_sc_hd__nor2_1 _2725_ (.A(\clean_run_target[5] ),
    .B(_0848_),
    .Y(_1818_));
 sky130_fd_sc_hd__a21oi_1 _2726_ (.A1(_0848_),
    .A2(_1817_),
    .B1(_1818_),
    .Y(_0259_));
 sky130_fd_sc_hd__o22a_1 _2727_ (.A1(\clean_run_target[6] ),
    .A2(_0848_),
    .B1(_1814_),
    .B2(\g_telemetry.u_reg_file.temp_clean_0[6] ),
    .X(_0258_));
 sky130_fd_sc_hd__o22a_1 _2728_ (.A1(\clean_run_target[7] ),
    .A2(_0848_),
    .B1(_1814_),
    .B2(\g_telemetry.u_reg_file.temp_clean_0[7] ),
    .X(_0257_));
 sky130_fd_sc_hd__o22a_1 _2729_ (.A1(\clean_run_target[8] ),
    .A2(_0848_),
    .B1(_1814_),
    .B2(\g_telemetry.u_reg_file.temp_clean_1[0] ),
    .X(_0256_));
 sky130_fd_sc_hd__o22a_1 _2730_ (.A1(\clean_run_target[9] ),
    .A2(_0848_),
    .B1(_1814_),
    .B2(\g_telemetry.u_reg_file.temp_clean_1[1] ),
    .X(_0255_));
 sky130_fd_sc_hd__o22a_1 _2731_ (.A1(\clean_run_target[10] ),
    .A2(_0848_),
    .B1(_1814_),
    .B2(\g_telemetry.u_reg_file.temp_clean_1[2] ),
    .X(_0254_));
 sky130_fd_sc_hd__o22a_1 _2732_ (.A1(\clean_run_target[11] ),
    .A2(_0848_),
    .B1(_1814_),
    .B2(\g_telemetry.u_reg_file.temp_clean_1[3] ),
    .X(_0253_));
 sky130_fd_sc_hd__o21ai_0 _2733_ (.A1(\g_telemetry.u_reg_file.temp_clean_1[4] ),
    .A2(_0851_),
    .B1(_1808_),
    .Y(_1819_));
 sky130_fd_sc_hd__nand2b_4 _2734_ (.A_N(\g_telemetry.u_reg_file.addr[0] ),
    .B(\g_telemetry.u_reg_file.addr[1] ),
    .Y(_0799_));
 sky130_fd_sc_hd__nor2_1 _2735_ (.A(\clean_run_target[12] ),
    .B(_0848_),
    .Y(_1820_));
 sky130_fd_sc_hd__a21oi_1 _2736_ (.A1(_0848_),
    .A2(_1819_),
    .B1(_1820_),
    .Y(_0252_));
 sky130_fd_sc_hd__o22a_1 _2737_ (.A1(\clean_run_target[13] ),
    .A2(_0848_),
    .B1(_1814_),
    .B2(\g_telemetry.u_reg_file.temp_clean_1[5] ),
    .X(_0251_));
 sky130_fd_sc_hd__o21ai_0 _2738_ (.A1(\g_telemetry.u_reg_file.temp_clean_1[6] ),
    .A2(_0851_),
    .B1(_1808_),
    .Y(_1821_));
 sky130_fd_sc_hd__nor2_1 _2739_ (.A(\clean_run_target[14] ),
    .B(_0848_),
    .Y(_1822_));
 sky130_fd_sc_hd__a21oi_1 _2740_ (.A1(_0848_),
    .A2(_1821_),
    .B1(_1822_),
    .Y(_0250_));
 sky130_fd_sc_hd__o32a_1 _2741_ (.A1(\g_telemetry.u_reg_file.temp_clean_1[7] ),
    .A2(_0853_),
    .A3(_1801_),
    .B1(\clean_run_target[15] ),
    .B2(_0848_),
    .X(_0249_));
 sky130_fd_sc_hd__nor2_1 _2742_ (.A(\clean_run_target[16] ),
    .B(_0848_),
    .Y(_1823_));
 sky130_fd_sc_hd__a21oi_1 _2743_ (.A1(_0848_),
    .A2(_1800_),
    .B1(_1823_),
    .Y(_0248_));
 sky130_fd_sc_hd__o22a_1 _2744_ (.A1(\clean_run_target[17] ),
    .A2(_0848_),
    .B1(_0853_),
    .B2(\g_telemetry.u_reg_file.temp_clean_2[1] ),
    .X(_0247_));
 sky130_fd_sc_hd__or2_2 _2745_ (.A(_0775_),
    .B(_0799_),
    .X(_0800_));
 sky130_fd_sc_hd__mux2_1 _2746_ (.A0(\g_telemetry.u_reg_file.wdata[0] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_0[0] ),
    .S(_0847_),
    .X(_0246_));
 sky130_fd_sc_hd__mux2_1 _2747_ (.A0(\g_telemetry.u_reg_file.wdata[1] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_0[1] ),
    .S(_0847_),
    .X(_0245_));
 sky130_fd_sc_hd__mux2_1 _2748_ (.A0(\g_telemetry.u_reg_file.wdata[2] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_0[2] ),
    .S(_0847_),
    .X(_0244_));
 sky130_fd_sc_hd__mux2_1 _2749_ (.A0(\g_telemetry.u_reg_file.wdata[3] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_0[3] ),
    .S(_0847_),
    .X(_0243_));
 sky130_fd_sc_hd__mux2_1 _2750_ (.A0(\g_telemetry.u_reg_file.wdata[4] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_0[4] ),
    .S(_0847_),
    .X(_0242_));
 sky130_fd_sc_hd__mux2_1 _2751_ (.A0(\g_telemetry.u_reg_file.wdata[5] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_0[5] ),
    .S(_0847_),
    .X(_0241_));
 sky130_fd_sc_hd__mux2_1 _2752_ (.A0(\g_telemetry.u_reg_file.wdata[6] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_0[6] ),
    .S(_0847_),
    .X(_0240_));
 sky130_fd_sc_hd__nor2_1 _2753_ (.A(\g_telemetry.u_reg_file.temp_hiccup_0[4] ),
    .B(\g_telemetry.u_reg_file.temp_hiccup_0[5] ),
    .Y(_1824_));
 sky130_fd_sc_hd__nor4_1 _2754_ (.A(\g_telemetry.u_reg_file.temp_hiccup_0[0] ),
    .B(\g_telemetry.u_reg_file.temp_hiccup_0[1] ),
    .C(\g_telemetry.u_reg_file.temp_hiccup_0[2] ),
    .D(\g_telemetry.u_reg_file.temp_hiccup_0[3] ),
    .Y(_1825_));
 sky130_fd_sc_hd__nand2_1 _2755_ (.A(_1824_),
    .B(_1825_),
    .Y(_1826_));
 sky130_fd_sc_hd__inv_1 _2756_ (.A(\u_pwm_mask.run_counter[4] ),
    .Y(_0675_));
 sky130_fd_sc_hd__nor2_4 _2757_ (.A(_0795_),
    .B(_0800_),
    .Y(_0801_));
 sky130_fd_sc_hd__a21o_1 _2758_ (.A1(\g_telemetry.u_reg_file.temp_hiccup_0[6] ),
    .A2(_1826_),
    .B1(\g_telemetry.u_reg_file.temp_hiccup_0[7] ),
    .X(_1827_));
 sky130_fd_sc_hd__nor2_1 _2759_ (.A(\g_telemetry.u_reg_file.temp_hiccup_0[7] ),
    .B(\g_telemetry.u_reg_file.temp_hiccup_0[6] ),
    .Y(_1828_));
 sky130_fd_sc_hd__a21oi_1 _2760_ (.A1(\g_telemetry.u_reg_file.temp_hiccup_1[0] ),
    .A2(_1827_),
    .B1(\g_telemetry.u_reg_file.temp_hiccup_1[1] ),
    .Y(_1829_));
 sky130_fd_sc_hd__nand2_1 _2761_ (.A(\g_telemetry.u_reg_file.temp_hiccup_1[3] ),
    .B(\g_telemetry.u_reg_file.temp_hiccup_1[2] ),
    .Y(_1830_));
 sky130_fd_sc_hd__nor4_1 _2762_ (.A(\g_telemetry.u_reg_file.temp_hiccup_1[4] ),
    .B(\g_telemetry.u_reg_file.temp_hiccup_1[7] ),
    .C(\g_telemetry.u_reg_file.temp_hiccup_1[5] ),
    .D(\g_telemetry.u_reg_file.temp_hiccup_1[6] ),
    .Y(_1831_));
 sky130_fd_sc_hd__o21ai_1 _2763_ (.A1(_1829_),
    .A2(_1830_),
    .B1(_1831_),
    .Y(_1832_));
 sky130_fd_sc_hd__a31oi_4 _2764_ (.A1(\g_telemetry.u_reg_file.temp_hiccup_2[0] ),
    .A2(\g_telemetry.u_reg_file.temp_hiccup_2[1] ),
    .A3(_1832_),
    .B1(_0844_),
    .Y(_1833_));
 sky130_fd_sc_hd__clkinv_1 _2765_ (.A(_1833_),
    .Y(_1834_));
 sky130_fd_sc_hd__nand3_1 _2766_ (.A(\g_telemetry.u_reg_file.temp_hiccup_1[1] ),
    .B(\g_telemetry.u_reg_file.temp_hiccup_1[2] ),
    .C(\g_telemetry.u_reg_file.temp_hiccup_1[0] ),
    .Y(_1835_));
 sky130_fd_sc_hd__a21oi_1 _2767_ (.A1(_1824_),
    .A2(_1828_),
    .B1(_1835_),
    .Y(_1836_));
 sky130_fd_sc_hd__nand2_4 _2768_ (.A(_0780_),
    .B(_0801_),
    .Y(_0802_));
 sky130_fd_sc_hd__o31ai_1 _2769_ (.A1(\g_telemetry.u_reg_file.temp_hiccup_1[4] ),
    .A2(\g_telemetry.u_reg_file.temp_hiccup_1[3] ),
    .A3(_1836_),
    .B1(\g_telemetry.u_reg_file.temp_hiccup_1[5] ),
    .Y(_1837_));
 sky130_fd_sc_hd__nor2_1 _2770_ (.A(\g_telemetry.u_reg_file.temp_hiccup_2[0] ),
    .B(_0844_),
    .Y(_1838_));
 sky130_fd_sc_hd__nor3_1 _2771_ (.A(\g_telemetry.u_reg_file.temp_hiccup_1[7] ),
    .B(\g_telemetry.u_reg_file.temp_hiccup_2[1] ),
    .C(\g_telemetry.u_reg_file.temp_hiccup_1[6] ),
    .Y(_1839_));
 sky130_fd_sc_hd__nand3_1 _2772_ (.A(_1837_),
    .B(_1838_),
    .C(_1839_),
    .Y(_1840_));
 sky130_fd_sc_hd__nand2_2 _2773_ (.A(_0839_),
    .B(_1840_),
    .Y(_1841_));
 sky130_fd_sc_hd__nor2_2 _2774_ (.A(_1834_),
    .B(_1841_),
    .Y(_1842_));
 sky130_fd_sc_hd__a22o_1 _2775_ (.A1(\g_telemetry.u_reg_file.hiccup_base[0] ),
    .A2(_0840_),
    .B1(_1842_),
    .B2(\g_telemetry.u_reg_file.temp_hiccup_0[0] ),
    .X(_0239_));
 sky130_fd_sc_hd__a22o_1 _2776_ (.A1(\g_telemetry.u_reg_file.hiccup_base[1] ),
    .A2(_0840_),
    .B1(_1842_),
    .B2(\g_telemetry.u_reg_file.temp_hiccup_0[1] ),
    .X(_0238_));
 sky130_fd_sc_hd__a22o_1 _2777_ (.A1(\g_telemetry.u_reg_file.hiccup_base[2] ),
    .A2(_0840_),
    .B1(_1842_),
    .B2(\g_telemetry.u_reg_file.temp_hiccup_0[2] ),
    .X(_0237_));
 sky130_fd_sc_hd__a22o_1 _2778_ (.A1(\g_telemetry.u_reg_file.hiccup_base[3] ),
    .A2(_0840_),
    .B1(_1842_),
    .B2(\g_telemetry.u_reg_file.temp_hiccup_0[3] ),
    .X(_0236_));
 sky130_fd_sc_hd__mux2_1 _2779_ (.A0(\g_telemetry.u_reg_file.wdata[7] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_2[7] ),
    .S(_0802_),
    .X(_0643_));
 sky130_fd_sc_hd__a21oi_1 _2780_ (.A1(\g_telemetry.u_reg_file.temp_hiccup_0[4] ),
    .A2(_1833_),
    .B1(_1841_),
    .Y(_1843_));
 sky130_fd_sc_hd__nor2_1 _2781_ (.A(\g_telemetry.u_reg_file.hiccup_base[4] ),
    .B(_0839_),
    .Y(_1844_));
 sky130_fd_sc_hd__nor2_1 _2782_ (.A(_1843_),
    .B(_1844_),
    .Y(_0235_));
 sky130_fd_sc_hd__a22o_1 _2783_ (.A1(\g_telemetry.u_reg_file.hiccup_base[5] ),
    .A2(_0840_),
    .B1(_1842_),
    .B2(\g_telemetry.u_reg_file.temp_hiccup_0[5] ),
    .X(_0234_));
 sky130_fd_sc_hd__nand2_1 _2784_ (.A(\g_telemetry.u_reg_file.hiccup_base[6] ),
    .B(_0840_),
    .Y(_1845_));
 sky130_fd_sc_hd__nor2_1 _2785_ (.A(\g_telemetry.u_reg_file.temp_hiccup_0[6] ),
    .B(_1834_),
    .Y(_1846_));
 sky130_fd_sc_hd__o21ai_0 _2786_ (.A1(_1841_),
    .A2(_1846_),
    .B1(_1845_),
    .Y(_0233_));
 sky130_fd_sc_hd__a22o_1 _2787_ (.A1(\g_telemetry.u_reg_file.hiccup_base[7] ),
    .A2(_0840_),
    .B1(_1842_),
    .B2(\g_telemetry.u_reg_file.temp_hiccup_0[7] ),
    .X(_0232_));
 sky130_fd_sc_hd__o32a_1 _2788_ (.A1(\g_telemetry.u_reg_file.temp_hiccup_1[0] ),
    .A2(_1834_),
    .A3(_1841_),
    .B1(_0839_),
    .B2(\g_telemetry.u_reg_file.hiccup_base[8] ),
    .X(_0231_));
 sky130_fd_sc_hd__a21oi_1 _2789_ (.A1(\g_telemetry.u_reg_file.temp_hiccup_1[1] ),
    .A2(_1833_),
    .B1(_1841_),
    .Y(_1847_));
 sky130_fd_sc_hd__and4_1 _2790_ (.A(\u_en_from_switch_db.disagree_counter[3] ),
    .B(\u_en_from_switch_db.disagree_counter[0] ),
    .C(\u_en_from_switch_db.disagree_counter[1] ),
    .D(\u_en_from_switch_db.disagree_counter[2] ),
    .X(_0803_));
 sky130_fd_sc_hd__nor2_1 _2791_ (.A(\g_telemetry.u_reg_file.hiccup_base[9] ),
    .B(_0839_),
    .Y(_1848_));
 sky130_fd_sc_hd__nor2_1 _2792_ (.A(_1847_),
    .B(_1848_),
    .Y(_0230_));
 sky130_fd_sc_hd__o32a_1 _2793_ (.A1(\g_telemetry.u_reg_file.temp_hiccup_1[2] ),
    .A2(_1834_),
    .A3(_1841_),
    .B1(_0839_),
    .B2(\g_telemetry.u_reg_file.hiccup_base[10] ),
    .X(_0229_));
 sky130_fd_sc_hd__nand2_1 _2794_ (.A(\g_telemetry.u_reg_file.hiccup_base[11] ),
    .B(_0840_),
    .Y(_1849_));
 sky130_fd_sc_hd__nor2_1 _2795_ (.A(\g_telemetry.u_reg_file.temp_hiccup_1[3] ),
    .B(_1834_),
    .Y(_1850_));
 sky130_fd_sc_hd__o21ai_0 _2796_ (.A1(_1841_),
    .A2(_1850_),
    .B1(_1849_),
    .Y(_0228_));
 sky130_fd_sc_hd__a22o_1 _2797_ (.A1(\g_telemetry.u_reg_file.hiccup_base[12] ),
    .A2(_0840_),
    .B1(_1842_),
    .B2(\g_telemetry.u_reg_file.temp_hiccup_1[4] ),
    .X(_0227_));
 sky130_fd_sc_hd__a21oi_1 _2798_ (.A1(\g_telemetry.u_reg_file.temp_hiccup_1[5] ),
    .A2(_1833_),
    .B1(_1841_),
    .Y(_1851_));
 sky130_fd_sc_hd__nor2_1 _2799_ (.A(\g_telemetry.u_reg_file.hiccup_base[13] ),
    .B(_0839_),
    .Y(_1852_));
 sky130_fd_sc_hd__nor2_1 _2800_ (.A(_1851_),
    .B(_1852_),
    .Y(_0226_));
 sky130_fd_sc_hd__and3_1 _2801_ (.A(\u_en_from_switch_db.disagree_counter[5] ),
    .B(\u_en_from_switch_db.disagree_counter[4] ),
    .C(_0803_),
    .X(_0804_));
 sky130_fd_sc_hd__a21oi_1 _2802_ (.A1(\g_telemetry.u_reg_file.temp_hiccup_1[6] ),
    .A2(_1833_),
    .B1(_0840_),
    .Y(_1853_));
 sky130_fd_sc_hd__nor2_1 _2803_ (.A(\g_telemetry.u_reg_file.hiccup_base[14] ),
    .B(_0839_),
    .Y(_1854_));
 sky130_fd_sc_hd__nor2_1 _2804_ (.A(_1853_),
    .B(_1854_),
    .Y(_0225_));
 sky130_fd_sc_hd__a21oi_1 _2805_ (.A1(\g_telemetry.u_reg_file.temp_hiccup_1[7] ),
    .A2(_1833_),
    .B1(_0840_),
    .Y(_1855_));
 sky130_fd_sc_hd__nor2_1 _2806_ (.A(\g_telemetry.u_reg_file.hiccup_base[15] ),
    .B(_0839_),
    .Y(_1856_));
 sky130_fd_sc_hd__nor2_1 _2807_ (.A(_1855_),
    .B(_1856_),
    .Y(_0224_));
 sky130_fd_sc_hd__nor2_1 _2808_ (.A(\g_telemetry.u_reg_file.hiccup_base[16] ),
    .B(_0839_),
    .Y(_1857_));
 sky130_fd_sc_hd__a21oi_1 _2809_ (.A1(_0839_),
    .A2(_1838_),
    .B1(_1857_),
    .Y(_0223_));
 sky130_fd_sc_hd__a21oi_1 _2810_ (.A1(\u_en_from_switch_db.disagree_counter[0] ),
    .A2(_0811_),
    .B1(_0821_),
    .Y(_1858_));
 sky130_fd_sc_hd__o21a_1 _2811_ (.A1(\u_en_from_switch_db.disagree_counter[0] ),
    .A2(_0811_),
    .B1(_1858_),
    .X(_0222_));
 sky130_fd_sc_hd__nor2_1 _2812_ (.A(\u_en_from_switch_db.disagree_counter[6] ),
    .B(_0804_),
    .Y(_0805_));
 sky130_fd_sc_hd__a21oi_1 _2813_ (.A1(\u_en_from_switch_db.disagree_counter[0] ),
    .A2(_0811_),
    .B1(\u_en_from_switch_db.disagree_counter[1] ),
    .Y(_1859_));
 sky130_fd_sc_hd__and3_1 _2814_ (.A(\u_en_from_switch_db.disagree_counter[0] ),
    .B(\u_en_from_switch_db.disagree_counter[1] ),
    .C(_0811_),
    .X(_1860_));
 sky130_fd_sc_hd__nor3_1 _2815_ (.A(_0821_),
    .B(_1859_),
    .C(_1860_),
    .Y(_0221_));
 sky130_fd_sc_hd__a21oi_1 _2816_ (.A1(\u_en_from_switch_db.disagree_counter[2] ),
    .A2(_1860_),
    .B1(_0821_),
    .Y(_1861_));
 sky130_fd_sc_hd__o21a_1 _2817_ (.A1(\u_en_from_switch_db.disagree_counter[2] ),
    .A2(_1860_),
    .B1(_1861_),
    .X(_0220_));
 sky130_fd_sc_hd__a21oi_1 _2818_ (.A1(\u_en_from_switch_db.disagree_counter[2] ),
    .A2(_1860_),
    .B1(\u_en_from_switch_db.disagree_counter[3] ),
    .Y(_1862_));
 sky130_fd_sc_hd__or2_2 _2819_ (.A(_0811_),
    .B(_0821_),
    .X(_1863_));
 sky130_fd_sc_hd__a211oi_1 _2820_ (.A1(_0803_),
    .A2(_0811_),
    .B1(_0821_),
    .C1(_1862_),
    .Y(_0219_));
 sky130_fd_sc_hd__a21oi_1 _2821_ (.A1(_0803_),
    .A2(_1863_),
    .B1(\u_en_from_switch_db.disagree_counter[4] ),
    .Y(_1864_));
 sky130_fd_sc_hd__and3_1 _2822_ (.A(\u_en_from_switch_db.disagree_counter[4] ),
    .B(_0803_),
    .C(_1863_),
    .X(_1865_));
 sky130_fd_sc_hd__nor3_1 _2823_ (.A(\u_en_from_switch_db.disagree_counter[7] ),
    .B(\u_en_from_switch_db.disagree_counter[6] ),
    .C(_0804_),
    .Y(_0806_));
 sky130_fd_sc_hd__nor3_1 _2824_ (.A(_0821_),
    .B(_1864_),
    .C(_1865_),
    .Y(_0218_));
 sky130_fd_sc_hd__nor2_1 _2825_ (.A(\u_en_from_switch_db.disagree_counter[5] ),
    .B(_1865_),
    .Y(_1866_));
 sky130_fd_sc_hd__a211oi_1 _2826_ (.A1(_0804_),
    .A2(_0811_),
    .B1(_0821_),
    .C1(_1866_),
    .Y(_0217_));
 sky130_fd_sc_hd__o21ai_0 _2827_ (.A1(_0805_),
    .A2(_0816_),
    .B1(_0811_),
    .Y(_1867_));
 sky130_fd_sc_hd__o21ai_0 _2828_ (.A1(\u_en_from_switch_db.disagree_counter[6] ),
    .A2(_0811_),
    .B1(_1867_),
    .Y(_1868_));
 sky130_fd_sc_hd__nor2_1 _2829_ (.A(_0821_),
    .B(_1868_),
    .Y(_0216_));
 sky130_fd_sc_hd__a21oi_1 _2830_ (.A1(_0816_),
    .A2(_1863_),
    .B1(\u_en_from_switch_db.disagree_counter[7] ),
    .Y(_1869_));
 sky130_fd_sc_hd__and3_1 _2831_ (.A(\u_en_from_switch_db.disagree_counter[7] ),
    .B(_0811_),
    .C(_0816_),
    .X(_1870_));
 sky130_fd_sc_hd__nor3_1 _2832_ (.A(_0821_),
    .B(_1869_),
    .C(_1870_),
    .Y(_0215_));
 sky130_fd_sc_hd__nor2_1 _2833_ (.A(\u_en_from_switch_db.disagree_counter[8] ),
    .B(_1870_),
    .Y(_1871_));
 sky130_fd_sc_hd__nand3_1 _2834_ (.A(\u_en_from_switch_db.disagree_counter[11] ),
    .B(\u_en_from_switch_db.disagree_counter[8] ),
    .C(\u_en_from_switch_db.disagree_counter[10] ),
    .Y(_0807_));
 sky130_fd_sc_hd__a211oi_1 _2835_ (.A1(_0811_),
    .A2(_0817_),
    .B1(_0821_),
    .C1(_1871_),
    .Y(_0214_));
 sky130_fd_sc_hd__a21oi_1 _2836_ (.A1(_0811_),
    .A2(_0817_),
    .B1(\u_en_from_switch_db.disagree_counter[9] ),
    .Y(_1872_));
 sky130_fd_sc_hd__and3_1 _2837_ (.A(\u_en_from_switch_db.disagree_counter[9] ),
    .B(_0817_),
    .C(_1863_),
    .X(_1873_));
 sky130_fd_sc_hd__nor3_1 _2838_ (.A(_0821_),
    .B(_1872_),
    .C(_1873_),
    .Y(_0213_));
 sky130_fd_sc_hd__a21oi_1 _2839_ (.A1(\u_en_from_switch_db.disagree_counter[10] ),
    .A2(_1873_),
    .B1(_0821_),
    .Y(_1874_));
 sky130_fd_sc_hd__o21a_1 _2840_ (.A1(\u_en_from_switch_db.disagree_counter[10] ),
    .A2(_1873_),
    .B1(_1874_),
    .X(_0212_));
 sky130_fd_sc_hd__a21oi_1 _2841_ (.A1(\u_en_from_switch_db.disagree_counter[10] ),
    .A2(_1873_),
    .B1(\u_en_from_switch_db.disagree_counter[11] ),
    .Y(_1875_));
 sky130_fd_sc_hd__and3_1 _2842_ (.A(_0809_),
    .B(_0811_),
    .C(_0817_),
    .X(_1876_));
 sky130_fd_sc_hd__nor3_1 _2843_ (.A(_0821_),
    .B(_1875_),
    .C(_1876_),
    .Y(_0211_));
 sky130_fd_sc_hd__a21oi_1 _2844_ (.A1(\u_en_from_switch_db.disagree_counter[12] ),
    .A2(_1876_),
    .B1(_0821_),
    .Y(_1877_));
 sky130_fd_sc_hd__nor3_1 _2845_ (.A(\u_en_from_switch_db.disagree_counter[9] ),
    .B(_0806_),
    .C(_0807_),
    .Y(_0808_));
 sky130_fd_sc_hd__o21a_1 _2846_ (.A1(\u_en_from_switch_db.disagree_counter[12] ),
    .A2(_1876_),
    .B1(_1877_),
    .X(_0210_));
 sky130_fd_sc_hd__and2_0 _2847_ (.A(_0818_),
    .B(_1863_),
    .X(_1878_));
 sky130_fd_sc_hd__a21oi_1 _2848_ (.A1(\u_en_from_switch_db.disagree_counter[13] ),
    .A2(_1878_),
    .B1(_0821_),
    .Y(_1879_));
 sky130_fd_sc_hd__o21a_1 _2849_ (.A1(\u_en_from_switch_db.disagree_counter[13] ),
    .A2(_1878_),
    .B1(_1879_),
    .X(_0209_));
 sky130_fd_sc_hd__a21oi_1 _2850_ (.A1(\u_en_from_switch_db.disagree_counter[13] ),
    .A2(_1878_),
    .B1(\u_en_from_switch_db.disagree_counter[14] ),
    .Y(_1880_));
 sky130_fd_sc_hd__and3_1 _2851_ (.A(\u_en_from_switch_db.disagree_counter[14] ),
    .B(\u_en_from_switch_db.disagree_counter[13] ),
    .C(_1878_),
    .X(_1881_));
 sky130_fd_sc_hd__nor3_1 _2852_ (.A(_0821_),
    .B(_1880_),
    .C(_1881_),
    .Y(_0208_));
 sky130_fd_sc_hd__nor2_1 _2853_ (.A(\u_en_from_switch_db.disagree_counter[15] ),
    .B(_1881_),
    .Y(_1882_));
 sky130_fd_sc_hd__a211oi_1 _2854_ (.A1(_0811_),
    .A2(_0819_),
    .B1(_0821_),
    .C1(_1882_),
    .Y(_0207_));
 sky130_fd_sc_hd__xnor2_1 _2855_ (.A(\u_en_from_switch_db.disagree_counter[16] ),
    .B(_0819_),
    .Y(_1883_));
 sky130_fd_sc_hd__and3_1 _2856_ (.A(\u_en_from_switch_db.disagree_counter[11] ),
    .B(\u_en_from_switch_db.disagree_counter[9] ),
    .C(\u_en_from_switch_db.disagree_counter[10] ),
    .X(_0809_));
 sky130_fd_sc_hd__o21ai_0 _2857_ (.A1(_0821_),
    .A2(_1883_),
    .B1(_1863_),
    .Y(_0206_));
 sky130_fd_sc_hd__mux2_1 _2858_ (.A0(\g_telemetry.u_reg_file.wdata[0] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_1[0] ),
    .S(_0815_),
    .X(_0205_));
 sky130_fd_sc_hd__mux2_1 _2859_ (.A0(\g_telemetry.u_reg_file.wdata[1] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_1[1] ),
    .S(_0815_),
    .X(_0204_));
 sky130_fd_sc_hd__mux2_1 _2860_ (.A0(\g_telemetry.u_reg_file.wdata[2] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_1[2] ),
    .S(_0815_),
    .X(_0203_));
 sky130_fd_sc_hd__mux2_1 _2861_ (.A0(\g_telemetry.u_reg_file.wdata[3] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_1[3] ),
    .S(_0815_),
    .X(_0202_));
 sky130_fd_sc_hd__mux2_1 _2862_ (.A0(\g_telemetry.u_reg_file.wdata[4] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_1[4] ),
    .S(_0815_),
    .X(_0201_));
 sky130_fd_sc_hd__mux2_1 _2863_ (.A0(\g_telemetry.u_reg_file.wdata[5] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_1[5] ),
    .S(_0815_),
    .X(_0200_));
 sky130_fd_sc_hd__mux2_1 _2864_ (.A0(\g_telemetry.u_reg_file.wdata[6] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_1[6] ),
    .S(_0815_),
    .X(_0199_));
 sky130_fd_sc_hd__nor2b_1 _2865_ (.A(\g_spi_filt.u_cs_filt.disagree_counter[0] ),
    .B_N(\g_spi_filt.u_cs_filt.disagree_counter[3] ),
    .Y(_1884_));
 sky130_fd_sc_hd__a211oi_1 _2866_ (.A1(\g_spi_filt.u_cs_filt.disagree_counter[0] ),
    .A2(_1025_),
    .B1(_1884_),
    .C1(_0813_),
    .Y(_0198_));
 sky130_fd_sc_hd__inv_1 _2867_ (.A(\u_strike_counter.clean_counter[6] ),
    .Y(_0676_));
 sky130_fd_sc_hd__or4_1 _2868_ (.A(\u_en_from_switch_db.disagree_counter[14] ),
    .B(\u_en_from_switch_db.disagree_counter[15] ),
    .C(\u_en_from_switch_db.disagree_counter[13] ),
    .D(\u_en_from_switch_db.disagree_counter[12] ),
    .X(_0810_));
 sky130_fd_sc_hd__a21oi_1 _2869_ (.A1(\g_spi_filt.u_cs_filt.disagree_counter[0] ),
    .A2(_1025_),
    .B1(\g_spi_filt.u_cs_filt.disagree_counter[1] ),
    .Y(_1885_));
 sky130_fd_sc_hd__nor2_1 _2870_ (.A(\g_spi_filt.u_cs_filt.disagree_counter[3] ),
    .B(_1024_),
    .Y(_1886_));
 sky130_fd_sc_hd__nor3_1 _2871_ (.A(\g_spi_filt.u_cs_filt.disagree_counter[3] ),
    .B(\g_spi_filt.u_cs_filt.disagree_counter[2] ),
    .C(_1024_),
    .Y(_1887_));
 sky130_fd_sc_hd__nor3_1 _2872_ (.A(_0813_),
    .B(_1885_),
    .C(_1887_),
    .Y(_0197_));
 sky130_fd_sc_hd__nor2_1 _2873_ (.A(\g_spi_filt.u_cs_filt.disagree_counter[2] ),
    .B(_1886_),
    .Y(_1888_));
 sky130_fd_sc_hd__nor2_1 _2874_ (.A(_0813_),
    .B(_1888_),
    .Y(_0196_));
 sky130_fd_sc_hd__mux2_1 _2875_ (.A0(\g_telemetry.u_reg_file.wdata[0] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_2[0] ),
    .S(_0802_),
    .X(_0195_));
 sky130_fd_sc_hd__mux2_1 _2876_ (.A0(\g_telemetry.u_reg_file.wdata[1] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_2[1] ),
    .S(_0802_),
    .X(_0194_));
 sky130_fd_sc_hd__mux2_1 _2877_ (.A0(\g_telemetry.u_reg_file.wdata[2] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_2[2] ),
    .S(_0802_),
    .X(_0193_));
 sky130_fd_sc_hd__mux2_1 _2878_ (.A0(\g_telemetry.u_reg_file.wdata[3] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_2[3] ),
    .S(_0802_),
    .X(_0192_));
 sky130_fd_sc_hd__o311ai_4 _2879_ (.A1(_0808_),
    .A2(_0809_),
    .A3(_0810_),
    .B1(\u_en_from_switch_db.disagree_counter[16] ),
    .C1(\u_en_from_switch_db.disagree_counter[17] ),
    .Y(_0811_));
 sky130_fd_sc_hd__mux2_1 _2880_ (.A0(\g_telemetry.u_reg_file.wdata[4] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_2[4] ),
    .S(_0802_),
    .X(_0191_));
 sky130_fd_sc_hd__mux2_1 _2881_ (.A0(\g_telemetry.u_reg_file.wdata[5] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_2[5] ),
    .S(_0802_),
    .X(_0190_));
 sky130_fd_sc_hd__mux2_1 _2882_ (.A0(\g_telemetry.u_reg_file.wdata[6] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_2[6] ),
    .S(_0802_),
    .X(_0189_));
 sky130_fd_sc_hd__mux2_1 _2883_ (.A0(\g_telemetry.u_reg_file.temp_cyc_step[0] ),
    .A1(\g_telemetry.u_reg_file.wdata[0] ),
    .S(_0798_),
    .X(_0188_));
 sky130_fd_sc_hd__mux2_1 _2884_ (.A0(\g_telemetry.u_reg_file.temp_cyc_step[1] ),
    .A1(\g_telemetry.u_reg_file.wdata[1] ),
    .S(_0798_),
    .X(_0187_));
 sky130_fd_sc_hd__mux2_1 _2885_ (.A0(\g_telemetry.u_reg_file.temp_cyc_step[2] ),
    .A1(\g_telemetry.u_reg_file.wdata[2] ),
    .S(_0798_),
    .X(_0186_));
 sky130_fd_sc_hd__mux2_1 _2886_ (.A0(\g_telemetry.u_reg_file.temp_cyc_step[3] ),
    .A1(\g_telemetry.u_reg_file.wdata[3] ),
    .S(_0798_),
    .X(_0185_));
 sky130_fd_sc_hd__mux2_1 _2887_ (.A0(\g_telemetry.u_reg_file.temp_cyc_step[4] ),
    .A1(\g_telemetry.u_reg_file.wdata[4] ),
    .S(_0798_),
    .X(_0184_));
 sky130_fd_sc_hd__mux2_1 _2888_ (.A0(\g_telemetry.u_reg_file.temp_cyc_step[5] ),
    .A1(\g_telemetry.u_reg_file.wdata[5] ),
    .S(_0798_),
    .X(_0183_));
 sky130_fd_sc_hd__mux2_1 _2889_ (.A0(\g_telemetry.u_reg_file.temp_cyc_step[6] ),
    .A1(\g_telemetry.u_reg_file.wdata[6] ),
    .S(_0798_),
    .X(_0182_));
 sky130_fd_sc_hd__nor2_1 _2890_ (.A(en_from_switch_sync),
    .B(_0811_),
    .Y(_0812_));
 sky130_fd_sc_hd__nand3_1 _2891_ (.A(\g_telemetry.u_reg_file.bus_err_count[15] ),
    .B(\g_telemetry.u_reg_file.bus_err_count[14] ),
    .C(_0790_),
    .Y(_1889_));
 sky130_fd_sc_hd__nand2_1 _2892_ (.A(\g_telemetry.u_reg_file.abort ),
    .B(_1889_),
    .Y(_1890_));
 sky130_fd_sc_hd__and3_1 _2893_ (.A(\g_telemetry.u_reg_file.bus_err_count[0] ),
    .B(\g_telemetry.u_reg_file.abort ),
    .C(_1889_),
    .X(_1891_));
 sky130_fd_sc_hd__a21oi_1 _2894_ (.A1(\g_telemetry.u_reg_file.abort ),
    .A2(_1889_),
    .B1(\g_telemetry.u_reg_file.bus_err_count[0] ),
    .Y(_1892_));
 sky130_fd_sc_hd__nor2_1 _2895_ (.A(_1891_),
    .B(_1892_),
    .Y(_0181_));
 sky130_fd_sc_hd__nand2_1 _2896_ (.A(\g_telemetry.u_reg_file.bus_err_count[1] ),
    .B(_1891_),
    .Y(_1893_));
 sky130_fd_sc_hd__xor2_1 _2897_ (.A(\g_telemetry.u_reg_file.bus_err_count[1] ),
    .B(_1891_),
    .X(_0180_));
 sky130_fd_sc_hd__xnor2_1 _2898_ (.A(\g_telemetry.u_reg_file.bus_err_count[2] ),
    .B(_1893_),
    .Y(_0179_));
 sky130_fd_sc_hd__a31oi_1 _2899_ (.A1(\g_telemetry.u_reg_file.bus_err_count[2] ),
    .A2(\g_telemetry.u_reg_file.bus_err_count[1] ),
    .A3(_1891_),
    .B1(\g_telemetry.u_reg_file.bus_err_count[3] ),
    .Y(_1894_));
 sky130_fd_sc_hd__nor2_1 _2900_ (.A(_0786_),
    .B(_1890_),
    .Y(_1895_));
 sky130_fd_sc_hd__a21oi_1 _2901_ (.A1(_0664_),
    .A2(_0811_),
    .B1(_0812_),
    .Y(_0642_));
 sky130_fd_sc_hd__nor2_1 _2902_ (.A(_1894_),
    .B(_1895_),
    .Y(_0178_));
 sky130_fd_sc_hd__xor2_1 _2903_ (.A(\g_telemetry.u_reg_file.bus_err_count[4] ),
    .B(_1895_),
    .X(_0177_));
 sky130_fd_sc_hd__and3_1 _2904_ (.A(\g_telemetry.u_reg_file.bus_err_count[5] ),
    .B(\g_telemetry.u_reg_file.bus_err_count[4] ),
    .C(_1895_),
    .X(_1896_));
 sky130_fd_sc_hd__a21oi_1 _2905_ (.A1(\g_telemetry.u_reg_file.bus_err_count[4] ),
    .A2(_1895_),
    .B1(\g_telemetry.u_reg_file.bus_err_count[5] ),
    .Y(_1897_));
 sky130_fd_sc_hd__nor2_1 _2906_ (.A(_1896_),
    .B(_1897_),
    .Y(_0176_));
 sky130_fd_sc_hd__xor2_1 _2907_ (.A(\g_telemetry.u_reg_file.bus_err_count[6] ),
    .B(_1896_),
    .X(_0175_));
 sky130_fd_sc_hd__a21oi_1 _2908_ (.A1(\g_telemetry.u_reg_file.bus_err_count[6] ),
    .A2(_1896_),
    .B1(\g_telemetry.u_reg_file.bus_err_count[7] ),
    .Y(_1898_));
 sky130_fd_sc_hd__nor3_2 _2909_ (.A(_0786_),
    .B(_0788_),
    .C(_1890_),
    .Y(_1899_));
 sky130_fd_sc_hd__nor2_1 _2910_ (.A(_1898_),
    .B(_1899_),
    .Y(_0174_));
 sky130_fd_sc_hd__nand2_1 _2911_ (.A(\g_telemetry.u_reg_file.bus_err_count[8] ),
    .B(_1899_),
    .Y(_1900_));
 sky130_fd_sc_hd__xnor2_1 _2912_ (.A(cs_n_filt),
    .B(cs_n_sync),
    .Y(_0813_));
 sky130_fd_sc_hd__xor2_1 _2913_ (.A(\g_telemetry.u_reg_file.bus_err_count[8] ),
    .B(_1899_),
    .X(_0173_));
 sky130_fd_sc_hd__xnor2_1 _2914_ (.A(\g_telemetry.u_reg_file.bus_err_count[9] ),
    .B(_1900_),
    .Y(_0172_));
 sky130_fd_sc_hd__nor2b_1 _2915_ (.A(_0787_),
    .B_N(_1899_),
    .Y(_1901_));
 sky130_fd_sc_hd__a31oi_1 _2916_ (.A1(\g_telemetry.u_reg_file.bus_err_count[9] ),
    .A2(\g_telemetry.u_reg_file.bus_err_count[8] ),
    .A3(_1899_),
    .B1(\g_telemetry.u_reg_file.bus_err_count[10] ),
    .Y(_1902_));
 sky130_fd_sc_hd__nor2_1 _2917_ (.A(_1901_),
    .B(_1902_),
    .Y(_0171_));
 sky130_fd_sc_hd__xor2_1 _2918_ (.A(\g_telemetry.u_reg_file.bus_err_count[11] ),
    .B(_1901_),
    .X(_0170_));
 sky130_fd_sc_hd__a21oi_1 _2919_ (.A1(\g_telemetry.u_reg_file.bus_err_count[11] ),
    .A2(_1901_),
    .B1(\g_telemetry.u_reg_file.bus_err_count[12] ),
    .Y(_1903_));
 sky130_fd_sc_hd__nand3_1 _2920_ (.A(\g_telemetry.u_reg_file.bus_err_count[11] ),
    .B(\g_telemetry.u_reg_file.bus_err_count[12] ),
    .C(_1901_),
    .Y(_1904_));
 sky130_fd_sc_hd__nor2b_1 _2921_ (.A(_1903_),
    .B_N(_1904_),
    .Y(_0169_));
 sky130_fd_sc_hd__xnor2_1 _2922_ (.A(\g_telemetry.u_reg_file.bus_err_count[13] ),
    .B(_1904_),
    .Y(_0168_));
 sky130_fd_sc_hd__nor2b_1 _2923_ (.A(_0813_),
    .B_N(\g_spi_filt.u_cs_filt.disagree_counter[3] ),
    .Y(_0641_));
 sky130_fd_sc_hd__a21oi_1 _2924_ (.A1(\g_telemetry.u_reg_file.abort ),
    .A2(_0790_),
    .B1(\g_telemetry.u_reg_file.bus_err_count[14] ),
    .Y(_1905_));
 sky130_fd_sc_hd__nor2_1 _2925_ (.A(\g_telemetry.u_reg_file.bus_err_count[15] ),
    .B(_0791_),
    .Y(_1906_));
 sky130_fd_sc_hd__nor2_1 _2926_ (.A(_1905_),
    .B(_1906_),
    .Y(_0167_));
 sky130_fd_sc_hd__mux2_1 _2927_ (.A0(\g_telemetry.u_reg_file.wdata[0] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_0[0] ),
    .S(_0785_),
    .X(_0166_));
 sky130_fd_sc_hd__mux2_1 _2928_ (.A0(\g_telemetry.u_reg_file.wdata[1] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_0[1] ),
    .S(_0785_),
    .X(_0165_));
 sky130_fd_sc_hd__mux2_1 _2929_ (.A0(\g_telemetry.u_reg_file.wdata[2] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_0[2] ),
    .S(_0785_),
    .X(_0164_));
 sky130_fd_sc_hd__mux2_1 _2930_ (.A0(\g_telemetry.u_reg_file.wdata[3] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_0[3] ),
    .S(_0785_),
    .X(_0163_));
 sky130_fd_sc_hd__mux2_1 _2931_ (.A0(\g_telemetry.u_reg_file.wdata[4] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_0[4] ),
    .S(_0785_),
    .X(_0162_));
 sky130_fd_sc_hd__mux2_1 _2932_ (.A0(\g_telemetry.u_reg_file.wdata[5] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_0[5] ),
    .S(_0785_),
    .X(_0161_));
 sky130_fd_sc_hd__mux2_1 _2933_ (.A0(\g_telemetry.u_reg_file.wdata[6] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_0[6] ),
    .S(_0785_),
    .X(_0160_));
 sky130_fd_sc_hd__nor2_8 _2934_ (.A(_0777_),
    .B(_0795_),
    .Y(_0814_));
 sky130_fd_sc_hd__o21a_1 _2935_ (.A1(_0782_),
    .A2(_0793_),
    .B1(\g_spi_filt.u_mosi_filt.disagree_counter[0] ),
    .X(_1907_));
 sky130_fd_sc_hd__o21ba_1 _2936_ (.A1(\g_spi_filt.u_mosi_filt.disagree_counter[3] ),
    .A2(_0782_),
    .B1_N(\g_spi_filt.u_mosi_filt.disagree_counter[0] ),
    .X(_1908_));
 sky130_fd_sc_hd__nor2_1 _2937_ (.A(_1907_),
    .B(_1908_),
    .Y(_0159_));
 sky130_fd_sc_hd__nor2_1 _2938_ (.A(\g_spi_filt.u_mosi_filt.disagree_counter[1] ),
    .B(_1907_),
    .Y(_1909_));
 sky130_fd_sc_hd__nor2_1 _2939_ (.A(\g_spi_filt.u_mosi_filt.disagree_counter[3] ),
    .B(_0792_),
    .Y(_1910_));
 sky130_fd_sc_hd__nor3_1 _2940_ (.A(\g_spi_filt.u_mosi_filt.disagree_counter[3] ),
    .B(\g_spi_filt.u_mosi_filt.disagree_counter[2] ),
    .C(_0792_),
    .Y(_1911_));
 sky130_fd_sc_hd__nor3_1 _2941_ (.A(_0782_),
    .B(_1909_),
    .C(_1911_),
    .Y(_0158_));
 sky130_fd_sc_hd__nor2_1 _2942_ (.A(\g_spi_filt.u_mosi_filt.disagree_counter[2] ),
    .B(_1910_),
    .Y(_1912_));
 sky130_fd_sc_hd__nor2_1 _2943_ (.A(_0782_),
    .B(_1912_),
    .Y(_0157_));
 sky130_fd_sc_hd__mux2_1 _2944_ (.A0(\g_telemetry.u_reg_file.wdata[0] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_1[0] ),
    .S(_0781_),
    .X(_0156_));
 sky130_fd_sc_hd__nand2_4 _2945_ (.A(_0780_),
    .B(_0814_),
    .Y(_0815_));
 sky130_fd_sc_hd__mux2_1 _2946_ (.A0(\g_telemetry.u_reg_file.wdata[1] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_1[1] ),
    .S(_0781_),
    .X(_0155_));
 sky130_fd_sc_hd__mux2_1 _2947_ (.A0(\g_telemetry.u_reg_file.wdata[2] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_1[2] ),
    .S(_0781_),
    .X(_0154_));
 sky130_fd_sc_hd__mux2_1 _2948_ (.A0(\g_telemetry.u_reg_file.wdata[3] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_1[3] ),
    .S(_0781_),
    .X(_0153_));
 sky130_fd_sc_hd__mux2_1 _2949_ (.A0(\g_telemetry.u_reg_file.wdata[4] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_1[4] ),
    .S(_0781_),
    .X(_0152_));
 sky130_fd_sc_hd__mux2_1 _2950_ (.A0(\g_telemetry.u_reg_file.wdata[5] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_1[5] ),
    .S(_0781_),
    .X(_0151_));
 sky130_fd_sc_hd__mux2_1 _2951_ (.A0(\g_telemetry.u_reg_file.wdata[6] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_1[6] ),
    .S(_0781_),
    .X(_0150_));
 sky130_fd_sc_hd__nand4_2 _2952_ (.A(\g_telemetry.u_pwm_stats.period_counter[5] ),
    .B(\g_telemetry.u_pwm_stats.period_counter[4] ),
    .C(_0764_),
    .D(_0770_),
    .Y(_1913_));
 sky130_fd_sc_hd__o21ai_0 _2953_ (.A1(\g_telemetry.u_pwm_stats.period_counter[0] ),
    .A2(_0763_),
    .B1(_1913_),
    .Y(_0149_));
 sky130_fd_sc_hd__a21oi_1 _2954_ (.A1(\g_telemetry.u_pwm_stats.period_counter[0] ),
    .A2(\g_telemetry.u_pwm_stats.period_counter[1] ),
    .B1(_0763_),
    .Y(_1914_));
 sky130_fd_sc_hd__o21ai_0 _2955_ (.A1(\g_telemetry.u_pwm_stats.period_counter[0] ),
    .A2(\g_telemetry.u_pwm_stats.period_counter[1] ),
    .B1(_1914_),
    .Y(_1915_));
 sky130_fd_sc_hd__mux2_1 _2956_ (.A0(\g_telemetry.u_reg_file.wdata[7] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_1[7] ),
    .S(_0815_),
    .X(_0640_));
 sky130_fd_sc_hd__nand2_1 _2957_ (.A(_1913_),
    .B(_1915_),
    .Y(_0148_));
 sky130_fd_sc_hd__a21oi_1 _2958_ (.A1(\g_telemetry.u_pwm_stats.period_counter[0] ),
    .A2(\g_telemetry.u_pwm_stats.period_counter[1] ),
    .B1(\g_telemetry.u_pwm_stats.period_counter[2] ),
    .Y(_1916_));
 sky130_fd_sc_hd__o31ai_1 _2959_ (.A1(_0763_),
    .A2(_0769_),
    .A3(_1916_),
    .B1(_1913_),
    .Y(_0147_));
 sky130_fd_sc_hd__nor2_1 _2960_ (.A(\g_telemetry.u_pwm_stats.period_counter[3] ),
    .B(_0769_),
    .Y(_1917_));
 sky130_fd_sc_hd__o31ai_1 _2961_ (.A1(_0763_),
    .A2(_0770_),
    .A3(_1917_),
    .B1(_1913_),
    .Y(_0146_));
 sky130_fd_sc_hd__o21ai_0 _2962_ (.A1(\g_telemetry.u_pwm_stats.period_counter[4] ),
    .A2(_0770_),
    .B1(_0764_),
    .Y(_1918_));
 sky130_fd_sc_hd__a31oi_1 _2963_ (.A1(_0663_),
    .A2(\g_telemetry.u_pwm_stats.period_counter[4] ),
    .A3(_0770_),
    .B1(_1918_),
    .Y(_0145_));
 sky130_fd_sc_hd__nand2_1 _2964_ (.A(\g_telemetry.u_pwm_stats.period_counter[0] ),
    .B(_0766_),
    .Y(_1919_));
 sky130_fd_sc_hd__nand2_1 _2965_ (.A(\duty_count[0] ),
    .B(_0767_),
    .Y(_1920_));
 sky130_fd_sc_hd__nand2_1 _2966_ (.A(_1919_),
    .B(_1920_),
    .Y(_0144_));
 sky130_fd_sc_hd__and2_0 _2967_ (.A(\u_en_from_switch_db.disagree_counter[6] ),
    .B(_0804_),
    .X(_0816_));
 sky130_fd_sc_hd__nand2_1 _2968_ (.A(\g_telemetry.u_pwm_stats.period_counter[1] ),
    .B(_0766_),
    .Y(_1921_));
 sky130_fd_sc_hd__nand2_1 _2969_ (.A(\duty_count[1] ),
    .B(_0767_),
    .Y(_1922_));
 sky130_fd_sc_hd__nand2_1 _2970_ (.A(_1921_),
    .B(_1922_),
    .Y(_0143_));
 sky130_fd_sc_hd__nand2_1 _2971_ (.A(\g_telemetry.u_pwm_stats.period_counter[2] ),
    .B(_0766_),
    .Y(_1923_));
 sky130_fd_sc_hd__nand2_1 _2972_ (.A(\duty_count[2] ),
    .B(_0767_),
    .Y(_1924_));
 sky130_fd_sc_hd__nand2_1 _2973_ (.A(_1923_),
    .B(_1924_),
    .Y(_0142_));
 sky130_fd_sc_hd__nand2_1 _2974_ (.A(\g_telemetry.u_pwm_stats.period_counter[3] ),
    .B(_0766_),
    .Y(_1925_));
 sky130_fd_sc_hd__nand2_1 _2975_ (.A(\duty_count[3] ),
    .B(_0767_),
    .Y(_1926_));
 sky130_fd_sc_hd__nand2_1 _2976_ (.A(_1925_),
    .B(_1926_),
    .Y(_0141_));
 sky130_fd_sc_hd__nand2_1 _2977_ (.A(\g_telemetry.u_pwm_stats.period_counter[4] ),
    .B(_0766_),
    .Y(_1927_));
 sky130_fd_sc_hd__inv_1 _2978_ (.A(latch_out),
    .Y(_0677_));
 sky130_fd_sc_hd__and3_1 _2979_ (.A(\u_en_from_switch_db.disagree_counter[7] ),
    .B(\u_en_from_switch_db.disagree_counter[8] ),
    .C(_0816_),
    .X(_0817_));
 sky130_fd_sc_hd__nand2_1 _2980_ (.A(\duty_count[4] ),
    .B(_0767_),
    .Y(_1928_));
 sky130_fd_sc_hd__nand2_1 _2981_ (.A(_1927_),
    .B(_1928_),
    .Y(_0140_));
 sky130_fd_sc_hd__nand2_1 _2982_ (.A(\g_telemetry.u_pwm_stats.period_counter[0] ),
    .B(_0763_),
    .Y(_1929_));
 sky130_fd_sc_hd__nand2_1 _2983_ (.A(\g_telemetry.u_pwm_stats.prev_period[0] ),
    .B(_0764_),
    .Y(_1930_));
 sky130_fd_sc_hd__nand2_1 _2984_ (.A(_1929_),
    .B(_1930_),
    .Y(_0139_));
 sky130_fd_sc_hd__nand2_1 _2985_ (.A(\g_telemetry.u_pwm_stats.period_counter[1] ),
    .B(_0763_),
    .Y(_1931_));
 sky130_fd_sc_hd__nand2_1 _2986_ (.A(\g_telemetry.u_pwm_stats.prev_period[1] ),
    .B(_0764_),
    .Y(_1932_));
 sky130_fd_sc_hd__nand2_1 _2987_ (.A(_1931_),
    .B(_1932_),
    .Y(_0138_));
 sky130_fd_sc_hd__nand2_1 _2988_ (.A(\g_telemetry.u_pwm_stats.period_counter[2] ),
    .B(_0763_),
    .Y(_1933_));
 sky130_fd_sc_hd__nand2_1 _2989_ (.A(\g_telemetry.u_pwm_stats.prev_period[2] ),
    .B(_0764_),
    .Y(_1934_));
 sky130_fd_sc_hd__and3_1 _2990_ (.A(\u_en_from_switch_db.disagree_counter[12] ),
    .B(_0809_),
    .C(_0817_),
    .X(_0818_));
 sky130_fd_sc_hd__nand2_1 _2991_ (.A(_1933_),
    .B(_1934_),
    .Y(_0137_));
 sky130_fd_sc_hd__nand2_1 _2992_ (.A(\g_telemetry.u_pwm_stats.period_counter[3] ),
    .B(_0763_),
    .Y(_1935_));
 sky130_fd_sc_hd__nand2_1 _2993_ (.A(\g_telemetry.u_pwm_stats.prev_period[3] ),
    .B(_0764_),
    .Y(_1936_));
 sky130_fd_sc_hd__nand2_1 _2994_ (.A(_1935_),
    .B(_1936_),
    .Y(_0136_));
 sky130_fd_sc_hd__nand2_1 _2995_ (.A(\g_telemetry.u_pwm_stats.period_counter[4] ),
    .B(_0763_),
    .Y(_1937_));
 sky130_fd_sc_hd__nand2_1 _2996_ (.A(\g_telemetry.u_pwm_stats.prev_period[4] ),
    .B(_0764_),
    .Y(_1938_));
 sky130_fd_sc_hd__nand2_1 _2997_ (.A(_1937_),
    .B(_1938_),
    .Y(_0135_));
 sky130_fd_sc_hd__a22o_1 _2998_ (.A1(\fault_time[0] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[0] ),
    .X(_0134_));
 sky130_fd_sc_hd__a22o_1 _2999_ (.A1(\fault_time[1] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[1] ),
    .X(_0133_));
 sky130_fd_sc_hd__a22o_1 _3000_ (.A1(\fault_time[2] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[2] ),
    .X(_0132_));
 sky130_fd_sc_hd__and4_1 _3001_ (.A(\u_en_from_switch_db.disagree_counter[14] ),
    .B(\u_en_from_switch_db.disagree_counter[15] ),
    .C(\u_en_from_switch_db.disagree_counter[13] ),
    .D(_0818_),
    .X(_0819_));
 sky130_fd_sc_hd__a22o_1 _3002_ (.A1(\fault_time[3] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[3] ),
    .X(_0131_));
 sky130_fd_sc_hd__a22o_1 _3003_ (.A1(\fault_time[4] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[4] ),
    .X(_0130_));
 sky130_fd_sc_hd__a22o_1 _3004_ (.A1(\fault_time[5] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[5] ),
    .X(_0129_));
 sky130_fd_sc_hd__a22o_1 _3005_ (.A1(\fault_time[6] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[6] ),
    .X(_0128_));
 sky130_fd_sc_hd__a22o_1 _3006_ (.A1(\fault_time[7] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[7] ),
    .X(_0127_));
 sky130_fd_sc_hd__a22o_1 _3007_ (.A1(\fault_time[8] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[8] ),
    .X(_0126_));
 sky130_fd_sc_hd__a22o_1 _3008_ (.A1(\fault_time[9] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[9] ),
    .X(_0125_));
 sky130_fd_sc_hd__a22o_1 _3009_ (.A1(\fault_time[10] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[10] ),
    .X(_0124_));
 sky130_fd_sc_hd__a22o_1 _3010_ (.A1(\fault_time[11] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[11] ),
    .X(_0123_));
 sky130_fd_sc_hd__a22o_1 _3011_ (.A1(\fault_time[12] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[12] ),
    .X(_0122_));
 sky130_fd_sc_hd__a21oi_1 _3012_ (.A1(\u_en_from_switch_db.disagree_counter[16] ),
    .A2(_0819_),
    .B1(\u_en_from_switch_db.disagree_counter[17] ),
    .Y(_0820_));
 sky130_fd_sc_hd__a22o_1 _3013_ (.A1(\fault_time[13] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[13] ),
    .X(_0121_));
 sky130_fd_sc_hd__a22o_1 _3014_ (.A1(\fault_time[14] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[14] ),
    .X(_0120_));
 sky130_fd_sc_hd__a22o_1 _3015_ (.A1(\fault_time[15] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[15] ),
    .X(_0119_));
 sky130_fd_sc_hd__a22o_1 _3016_ (.A1(\fault_time[16] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[16] ),
    .X(_0118_));
 sky130_fd_sc_hd__a22o_1 _3017_ (.A1(\fault_time[17] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[17] ),
    .X(_0117_));
 sky130_fd_sc_hd__a22o_1 _3018_ (.A1(\fault_time[18] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[18] ),
    .X(_0116_));
 sky130_fd_sc_hd__a22o_1 _3019_ (.A1(\fault_time[19] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[19] ),
    .X(_0115_));
 sky130_fd_sc_hd__a22o_1 _3020_ (.A1(\fault_time[20] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[20] ),
    .X(_0114_));
 sky130_fd_sc_hd__a22o_1 _3021_ (.A1(\fault_time[21] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[21] ),
    .X(_0113_));
 sky130_fd_sc_hd__a22o_1 _3022_ (.A1(\fault_time[22] ),
    .A2(_0760_),
    .B1(_0761_),
    .B2(\g_telemetry.u_fault_cause.timestamp_ms[22] ),
    .X(_0112_));
 sky130_fd_sc_hd__xnor2_4 _3023_ (.A(en_from_switch_sync_db),
    .B(en_from_switch_sync),
    .Y(_0821_));
 sky130_fd_sc_hd__nor2_1 _3024_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[0] ),
    .B(_0725_),
    .Y(_1939_));
 sky130_fd_sc_hd__and2_1 _3025_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[0] ),
    .B(_0725_),
    .X(_1940_));
 sky130_fd_sc_hd__nor2_1 _3026_ (.A(_1939_),
    .B(_1940_),
    .Y(_0111_));
 sky130_fd_sc_hd__nand2_1 _3027_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[1] ),
    .B(_1940_),
    .Y(_1941_));
 sky130_fd_sc_hd__xor2_1 _3028_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[1] ),
    .B(_1940_),
    .X(_0110_));
 sky130_fd_sc_hd__xnor2_1 _3029_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[2] ),
    .B(_1941_),
    .Y(_0109_));
 sky130_fd_sc_hd__a31oi_1 _3030_ (.A1(\g_telemetry.u_fault_cause.timestamp_ms[2] ),
    .A2(\g_telemetry.u_fault_cause.timestamp_ms[1] ),
    .A3(_1940_),
    .B1(\g_telemetry.u_fault_cause.timestamp_ms[3] ),
    .Y(_1942_));
 sky130_fd_sc_hd__nor2_1 _3031_ (.A(_0726_),
    .B(_1942_),
    .Y(_0108_));
 sky130_fd_sc_hd__xor2_1 _3032_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[4] ),
    .B(_0726_),
    .X(_0107_));
 sky130_fd_sc_hd__a21oi_1 _3033_ (.A1(\g_telemetry.u_fault_cause.timestamp_ms[4] ),
    .A2(_0726_),
    .B1(\g_telemetry.u_fault_cause.timestamp_ms[5] ),
    .Y(_1943_));
 sky130_fd_sc_hd__nor2_1 _3034_ (.A(_0820_),
    .B(_0821_),
    .Y(_0639_));
 sky130_fd_sc_hd__nand3_1 _3035_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[5] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[4] ),
    .C(_0726_),
    .Y(_1944_));
 sky130_fd_sc_hd__nor2b_1 _3036_ (.A(_1943_),
    .B_N(_1944_),
    .Y(_0106_));
 sky130_fd_sc_hd__xnor2_1 _3037_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[6] ),
    .B(_1944_),
    .Y(_0105_));
 sky130_fd_sc_hd__xor2_1 _3038_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[7] ),
    .B(_0727_),
    .X(_0104_));
 sky130_fd_sc_hd__a21oi_1 _3039_ (.A1(\g_telemetry.u_fault_cause.timestamp_ms[7] ),
    .A2(_0727_),
    .B1(\g_telemetry.u_fault_cause.timestamp_ms[8] ),
    .Y(_1945_));
 sky130_fd_sc_hd__and3_1 _3040_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[7] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[8] ),
    .C(_0727_),
    .X(_1946_));
 sky130_fd_sc_hd__nor2_1 _3041_ (.A(_1945_),
    .B(_1946_),
    .Y(_0103_));
 sky130_fd_sc_hd__nand2_1 _3042_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[9] ),
    .B(_1946_),
    .Y(_1947_));
 sky130_fd_sc_hd__xor2_1 _3043_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[9] ),
    .B(_1946_),
    .X(_0102_));
 sky130_fd_sc_hd__xnor2_1 _3044_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[10] ),
    .B(_1947_),
    .Y(_0101_));
 sky130_fd_sc_hd__nor2_4 _3045_ (.A(_0773_),
    .B(_0800_),
    .Y(_0822_));
 sky130_fd_sc_hd__a31oi_1 _3046_ (.A1(\g_telemetry.u_fault_cause.timestamp_ms[10] ),
    .A2(\g_telemetry.u_fault_cause.timestamp_ms[9] ),
    .A3(_1946_),
    .B1(\g_telemetry.u_fault_cause.timestamp_ms[11] ),
    .Y(_1948_));
 sky130_fd_sc_hd__and4_1 _3047_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[10] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[9] ),
    .C(\g_telemetry.u_fault_cause.timestamp_ms[11] ),
    .D(_1946_),
    .X(_1949_));
 sky130_fd_sc_hd__nor2_1 _3048_ (.A(_1948_),
    .B(_1949_),
    .Y(_0100_));
 sky130_fd_sc_hd__nand2_1 _3049_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[12] ),
    .B(_1949_),
    .Y(_1950_));
 sky130_fd_sc_hd__xor2_1 _3050_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[12] ),
    .B(_1949_),
    .X(_0099_));
 sky130_fd_sc_hd__xnor2_1 _3051_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[13] ),
    .B(_1950_),
    .Y(_0098_));
 sky130_fd_sc_hd__a31oi_1 _3052_ (.A1(\g_telemetry.u_fault_cause.timestamp_ms[13] ),
    .A2(\g_telemetry.u_fault_cause.timestamp_ms[12] ),
    .A3(_1949_),
    .B1(\g_telemetry.u_fault_cause.timestamp_ms[14] ),
    .Y(_1951_));
 sky130_fd_sc_hd__nand4_1 _3053_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[14] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[13] ),
    .C(\g_telemetry.u_fault_cause.timestamp_ms[12] ),
    .D(_1949_),
    .Y(_1952_));
 sky130_fd_sc_hd__nor2b_1 _3054_ (.A(_1951_),
    .B_N(_1952_),
    .Y(_0097_));
 sky130_fd_sc_hd__xnor2_1 _3055_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[15] ),
    .B(_1952_),
    .Y(_0096_));
 sky130_fd_sc_hd__nand2_8 _3056_ (.A(_0780_),
    .B(_0822_),
    .Y(_0823_));
 sky130_fd_sc_hd__xor2_1 _3057_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[16] ),
    .B(_0731_),
    .X(_0095_));
 sky130_fd_sc_hd__a21oi_1 _3058_ (.A1(\g_telemetry.u_fault_cause.timestamp_ms[16] ),
    .A2(_0731_),
    .B1(\g_telemetry.u_fault_cause.timestamp_ms[17] ),
    .Y(_1953_));
 sky130_fd_sc_hd__nor2_1 _3059_ (.A(_0732_),
    .B(_1953_),
    .Y(_0094_));
 sky130_fd_sc_hd__xor2_1 _3060_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[18] ),
    .B(_0732_),
    .X(_0093_));
 sky130_fd_sc_hd__a21oi_1 _3061_ (.A1(\g_telemetry.u_fault_cause.timestamp_ms[18] ),
    .A2(_0732_),
    .B1(\g_telemetry.u_fault_cause.timestamp_ms[19] ),
    .Y(_1954_));
 sky130_fd_sc_hd__nor2_1 _3062_ (.A(_0733_),
    .B(_1954_),
    .Y(_0092_));
 sky130_fd_sc_hd__xor2_1 _3063_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[20] ),
    .B(_0733_),
    .X(_0091_));
 sky130_fd_sc_hd__xnor2_1 _3064_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[21] ),
    .B(_0734_),
    .Y(_0090_));
 sky130_fd_sc_hd__xnor2_1 _3065_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[22] ),
    .B(_0735_),
    .Y(_0089_));
 sky130_fd_sc_hd__a21oi_1 _3066_ (.A1(\g_telemetry.u_spi_slave.idle_counter[12] ),
    .A2(_1201_),
    .B1(\g_telemetry.u_spi_slave.idle_counter[13] ),
    .Y(_1955_));
 sky130_fd_sc_hd__nand2_1 _3067_ (.A(\g_telemetry.u_reg_file.temp_dirty[10] ),
    .B(_0779_),
    .Y(_0824_));
 sky130_fd_sc_hd__nor3_1 _3068_ (.A(_0696_),
    .B(_1200_),
    .C(_1955_),
    .Y(_0004_));
 sky130_fd_sc_hd__nor2_1 _3069_ (.A(\g_telemetry.u_spi_slave.idle_counter[11] ),
    .B(_1199_),
    .Y(_1956_));
 sky130_fd_sc_hd__nor3_1 _3070_ (.A(_1201_),
    .B(_1207_),
    .C(_1956_),
    .Y(_0002_));
 sky130_fd_sc_hd__nor2_1 _3071_ (.A(\g_telemetry.u_spi_slave.idle_counter[10] ),
    .B(_1198_),
    .Y(_1957_));
 sky130_fd_sc_hd__nor3_1 _3072_ (.A(_1199_),
    .B(_1207_),
    .C(_1957_),
    .Y(_0001_));
 sky130_fd_sc_hd__a21oi_1 _3073_ (.A1(\g_telemetry.u_spi_slave.idle_counter[8] ),
    .A2(_1197_),
    .B1(\g_telemetry.u_spi_slave.idle_counter[9] ),
    .Y(_1958_));
 sky130_fd_sc_hd__nor3_1 _3074_ (.A(_1198_),
    .B(_1207_),
    .C(_1958_),
    .Y(_0014_));
 sky130_fd_sc_hd__o21ai_0 _3075_ (.A1(\g_telemetry.u_spi_slave.idle_counter[12] ),
    .A2(_1201_),
    .B1(_0695_),
    .Y(_1959_));
 sky130_fd_sc_hd__a21oi_1 _3076_ (.A1(\g_telemetry.u_spi_slave.idle_counter[12] ),
    .A2(_1201_),
    .B1(_1959_),
    .Y(_0003_));
 sky130_fd_sc_hd__o21ai_0 _3077_ (.A1(\g_telemetry.u_spi_slave.idle_counter[6] ),
    .A2(_1196_),
    .B1(_0695_),
    .Y(_1960_));
 sky130_fd_sc_hd__nand2_1 _3078_ (.A(_0823_),
    .B(_0824_),
    .Y(_0638_));
 sky130_fd_sc_hd__a21oi_1 _3079_ (.A1(\g_telemetry.u_spi_slave.idle_counter[6] ),
    .A2(_1196_),
    .B1(_1960_),
    .Y(_0011_));
 sky130_fd_sc_hd__nor2_1 _3080_ (.A(\g_telemetry.u_spi_slave.idle_counter[5] ),
    .B(_1195_),
    .Y(_1961_));
 sky130_fd_sc_hd__nor3_1 _3081_ (.A(_1196_),
    .B(_1207_),
    .C(_1961_),
    .Y(_0010_));
 sky130_fd_sc_hd__o21ai_0 _3082_ (.A1(\g_telemetry.u_spi_slave.idle_counter[8] ),
    .A2(_1197_),
    .B1(_0695_),
    .Y(_1962_));
 sky130_fd_sc_hd__a21oi_1 _3083_ (.A1(\g_telemetry.u_spi_slave.idle_counter[8] ),
    .A2(_1197_),
    .B1(_1962_),
    .Y(_0013_));
 sky130_fd_sc_hd__nand4_2 _3084_ (.A(\g_telemetry.u_reg_file.spi_enable ),
    .B(en_from_switch_sync_db),
    .C(_0738_),
    .D(_0739_),
    .Y(_1963_));
 sky130_fd_sc_hd__nor2_1 _3085_ (.A(_0703_),
    .B(_1963_),
    .Y(En));
 sky130_fd_sc_hd__a311oi_1 _3086_ (.A1(SS_done),
    .A2(_0699_),
    .A3(_0755_),
    .B1(_1318_),
    .C1(_1963_),
    .Y(\u_supervisor.next_state[0] ));
 sky130_fd_sc_hd__and2_0 _3087_ (.A(\u_fault_arbiter.cp_delay[2] ),
    .B(_0704_),
    .X(_0085_));
 sky130_fd_sc_hd__and2_0 _3088_ (.A(\u_fault_arbiter.cp_delay[1] ),
    .B(_0704_),
    .X(_0084_));
 sky130_fd_sc_hd__inv_1 _3089_ (.A(\fault_count_run[1] ),
    .Y(_0678_));
 sky130_fd_sc_hd__or3_1 _3090_ (.A(\g_telemetry.u_reg_file.temp_dirty[6] ),
    .B(\g_telemetry.u_reg_file.temp_dirty[4] ),
    .C(\g_telemetry.u_reg_file.temp_dirty[5] ),
    .X(_0825_));
 sky130_fd_sc_hd__and2_0 _3091_ (.A(\u_fault_arbiter.cp_delay[0] ),
    .B(_0704_),
    .X(_0083_));
 sky130_fd_sc_hd__nor2_1 _3092_ (.A(_0691_),
    .B(_1126_),
    .Y(_1964_));
 sky130_fd_sc_hd__and3_1 _3093_ (.A(\u_fault_LED.blink_counter[6] ),
    .B(\u_fault_LED.blink_counter[5] ),
    .C(_1964_),
    .X(_1965_));
 sky130_fd_sc_hd__and2_1 _3094_ (.A(\u_fault_LED.blink_counter[7] ),
    .B(_1965_),
    .X(_1966_));
 sky130_fd_sc_hd__and3_1 _3095_ (.A(\u_fault_LED.blink_counter[9] ),
    .B(\u_fault_LED.blink_counter[8] ),
    .C(_1966_),
    .X(_1967_));
 sky130_fd_sc_hd__and3_1 _3096_ (.A(\u_fault_LED.blink_counter[11] ),
    .B(\u_fault_LED.blink_counter[10] ),
    .C(_1967_),
    .X(_1968_));
 sky130_fd_sc_hd__and3_1 _3097_ (.A(\u_fault_LED.blink_counter[13] ),
    .B(\u_fault_LED.blink_counter[12] ),
    .C(_1968_),
    .X(_1969_));
 sky130_fd_sc_hd__nand2_1 _3098_ (.A(\u_fault_LED.blink_counter[14] ),
    .B(_1969_),
    .Y(_1970_));
 sky130_fd_sc_hd__and4_1 _3099_ (.A(\u_fault_LED.blink_counter[16] ),
    .B(\u_fault_LED.blink_counter[15] ),
    .C(\u_fault_LED.blink_counter[14] ),
    .D(_1969_),
    .X(_1971_));
 sky130_fd_sc_hd__nand2_1 _3100_ (.A(\u_fault_LED.blink_counter[17] ),
    .B(_1971_),
    .Y(_1972_));
 sky130_fd_sc_hd__or3_1 _3101_ (.A(\g_telemetry.u_reg_file.temp_dirty[10] ),
    .B(\g_telemetry.u_reg_file.temp_dirty[8] ),
    .C(\g_telemetry.u_reg_file.temp_dirty[9] ),
    .X(_0826_));
 sky130_fd_sc_hd__nand3_1 _3102_ (.A(\u_fault_LED.blink_counter[18] ),
    .B(\u_fault_LED.blink_counter[17] ),
    .C(_1971_),
    .Y(_1973_));
 sky130_fd_sc_hd__nand4_1 _3103_ (.A(\u_fault_LED.blink_counter[19] ),
    .B(\u_fault_LED.blink_counter[18] ),
    .C(\u_fault_LED.blink_counter[17] ),
    .D(_1971_),
    .Y(_1974_));
 sky130_fd_sc_hd__xnor2_1 _3104_ (.A(\u_fault_LED.blink_counter[19] ),
    .B(_1973_),
    .Y(_0071_));
 sky130_fd_sc_hd__xnor2_1 _3105_ (.A(\u_fault_LED.blink_counter[18] ),
    .B(_1972_),
    .Y(_0070_));
 sky130_fd_sc_hd__nor2_1 _3106_ (.A(\u_fault_LED.blink_counter[17] ),
    .B(_1971_),
    .Y(_1975_));
 sky130_fd_sc_hd__a211oi_1 _3107_ (.A1(\u_fault_LED.blink_counter[17] ),
    .A2(_1971_),
    .B1(_1975_),
    .C1(_1130_),
    .Y(_0069_));
 sky130_fd_sc_hd__a31oi_1 _3108_ (.A1(\u_fault_LED.blink_counter[15] ),
    .A2(\u_fault_LED.blink_counter[14] ),
    .A3(_1969_),
    .B1(\u_fault_LED.blink_counter[16] ),
    .Y(_1976_));
 sky130_fd_sc_hd__nor3_1 _3109_ (.A(_1130_),
    .B(_1971_),
    .C(_1976_),
    .Y(_0068_));
 sky130_fd_sc_hd__xnor2_1 _3110_ (.A(\u_fault_LED.blink_counter[15] ),
    .B(_1970_),
    .Y(_0067_));
 sky130_fd_sc_hd__xor2_1 _3111_ (.A(\u_fault_LED.blink_counter[14] ),
    .B(_1969_),
    .X(_0066_));
 sky130_fd_sc_hd__nor3_1 _3112_ (.A(\g_telemetry.u_reg_file.temp_dirty[2] ),
    .B(\g_telemetry.u_reg_file.temp_dirty[7] ),
    .C(_0826_),
    .Y(_0827_));
 sky130_fd_sc_hd__a21oi_1 _3113_ (.A1(\u_fault_LED.blink_counter[12] ),
    .A2(_1968_),
    .B1(\u_fault_LED.blink_counter[13] ),
    .Y(_1977_));
 sky130_fd_sc_hd__nor2_1 _3114_ (.A(_1969_),
    .B(_1977_),
    .Y(_0065_));
 sky130_fd_sc_hd__nor2_1 _3115_ (.A(\u_fault_LED.blink_counter[12] ),
    .B(_1968_),
    .Y(_1978_));
 sky130_fd_sc_hd__a211oi_1 _3116_ (.A1(\u_fault_LED.blink_counter[12] ),
    .A2(_1968_),
    .B1(_1978_),
    .C1(_1130_),
    .Y(_0064_));
 sky130_fd_sc_hd__a21oi_1 _3117_ (.A1(\u_fault_LED.blink_counter[10] ),
    .A2(_1967_),
    .B1(\u_fault_LED.blink_counter[11] ),
    .Y(_1979_));
 sky130_fd_sc_hd__nor2_1 _3118_ (.A(_1968_),
    .B(_1979_),
    .Y(_0063_));
 sky130_fd_sc_hd__xor2_1 _3119_ (.A(\u_fault_LED.blink_counter[10] ),
    .B(_1967_),
    .X(_0062_));
 sky130_fd_sc_hd__a21oi_1 _3120_ (.A1(\u_fault_LED.blink_counter[8] ),
    .A2(_1966_),
    .B1(\u_fault_LED.blink_counter[9] ),
    .Y(_1980_));
 sky130_fd_sc_hd__nor3_1 _3121_ (.A(_1130_),
    .B(_1967_),
    .C(_1980_),
    .Y(_0081_));
 sky130_fd_sc_hd__xor2_1 _3122_ (.A(\u_fault_LED.blink_counter[8] ),
    .B(_1966_),
    .X(_0080_));
 sky130_fd_sc_hd__nor4_1 _3123_ (.A(\g_telemetry.u_reg_file.temp_dirty[0] ),
    .B(\g_telemetry.u_reg_file.temp_dirty[1] ),
    .C(\g_telemetry.u_reg_file.temp_dirty[3] ),
    .D(_0825_),
    .Y(_0828_));
 sky130_fd_sc_hd__nor2_1 _3124_ (.A(\u_fault_LED.blink_counter[7] ),
    .B(_1965_),
    .Y(_1981_));
 sky130_fd_sc_hd__nor3_1 _3125_ (.A(_1130_),
    .B(_1966_),
    .C(_1981_),
    .Y(_0079_));
 sky130_fd_sc_hd__a21oi_1 _3126_ (.A1(\u_fault_LED.blink_counter[5] ),
    .A2(_1964_),
    .B1(\u_fault_LED.blink_counter[6] ),
    .Y(_1982_));
 sky130_fd_sc_hd__nor3_1 _3127_ (.A(_1130_),
    .B(_1965_),
    .C(_1982_),
    .Y(_0078_));
 sky130_fd_sc_hd__xor2_1 _3128_ (.A(\u_fault_LED.blink_counter[5] ),
    .B(_1964_),
    .X(_0077_));
 sky130_fd_sc_hd__and2_0 _3129_ (.A(_0691_),
    .B(_1126_),
    .X(_1983_));
 sky130_fd_sc_hd__nor3_1 _3130_ (.A(_1130_),
    .B(_1964_),
    .C(_1983_),
    .Y(_0076_));
 sky130_fd_sc_hd__xnor2_1 _3131_ (.A(\u_fault_LED.blink_counter[3] ),
    .B(_1125_),
    .Y(_0075_));
 sky130_fd_sc_hd__xnor2_1 _3132_ (.A(\u_fault_LED.blink_counter[2] ),
    .B(_1124_),
    .Y(_0074_));
 sky130_fd_sc_hd__xor2_1 _3133_ (.A(\u_fault_LED.blink_counter[1] ),
    .B(\u_fault_LED.blink_counter[0] ),
    .X(_0072_));
 sky130_fd_sc_hd__nand2_1 _3134_ (.A(_0827_),
    .B(_0828_),
    .Y(_0829_));
 sky130_fd_sc_hd__nor2b_1 _3135_ (.A(\g_telemetry.u_spi_slave.cs_n_d ),
    .B_N(cs_n_filt),
    .Y(_1984_));
 sky130_fd_sc_hd__o21ai_0 _3136_ (.A1(\g_telemetry.u_spi_slave.rx_byte[7] ),
    .A2(_0708_),
    .B1(_1109_),
    .Y(_1985_));
 sky130_fd_sc_hd__nand2_1 _3137_ (.A(_0708_),
    .B(_0992_),
    .Y(_1986_));
 sky130_fd_sc_hd__o31a_1 _3138_ (.A1(\g_telemetry.u_spi_slave.spi_state[0] ),
    .A2(\g_telemetry.u_spi_slave.spi_state[1] ),
    .A3(\g_telemetry.u_spi_slave.spi_state[2] ),
    .B1(\g_telemetry.u_spi_slave.sck_timeout ),
    .X(_1987_));
 sky130_fd_sc_hd__o21a_1 _3139_ (.A1(\g_telemetry.u_spi_slave.spi_state[0] ),
    .A2(\g_telemetry.u_spi_slave.spi_state[1] ),
    .B1(\g_telemetry.u_spi_slave.spi_state[2] ),
    .X(_1988_));
 sky130_fd_sc_hd__nor2_1 _3140_ (.A(_1987_),
    .B(_1988_),
    .Y(_1989_));
 sky130_fd_sc_hd__a41oi_1 _3141_ (.A1(_1112_),
    .A2(_1985_),
    .A3(_1986_),
    .A4(_1989_),
    .B1(_1984_),
    .Y(\g_telemetry.u_spi_slave.spi_state_next[0] ));
 sky130_fd_sc_hd__nand3_1 _3142_ (.A(\g_telemetry.u_reg_file.addr[4] ),
    .B(\g_telemetry.u_reg_file.addr[5] ),
    .C(_1156_),
    .Y(_1990_));
 sky130_fd_sc_hd__a21o_1 _3143_ (.A1(\g_telemetry.u_reg_file.addr[4] ),
    .A2(_1156_),
    .B1(\g_telemetry.u_reg_file.addr[5] ),
    .X(_1991_));
 sky130_fd_sc_hd__nand2_1 _3144_ (.A(_1990_),
    .B(_1991_),
    .Y(_1992_));
 sky130_fd_sc_hd__a21oi_1 _3145_ (.A1(\g_telemetry.u_reg_file.integrity_OK ),
    .A2(_0829_),
    .B1(\g_telemetry.u_reg_file.write_rejected ),
    .Y(_0830_));
 sky130_fd_sc_hd__and3_1 _3146_ (.A(_0707_),
    .B(_0715_),
    .C(_1112_),
    .X(_1993_));
 sky130_fd_sc_hd__nand2_1 _3147_ (.A(_0715_),
    .B(_1114_),
    .Y(_1994_));
 sky130_fd_sc_hd__nor2_2 _3148_ (.A(_1116_),
    .B(_1993_),
    .Y(_1995_));
 sky130_fd_sc_hd__o21ai_0 _3149_ (.A1(\g_telemetry.u_reg_file.wr_en ),
    .A2(\g_telemetry.u_reg_file.addr[5] ),
    .B1(_1995_),
    .Y(_1996_));
 sky130_fd_sc_hd__a21oi_1 _3150_ (.A1(\g_telemetry.u_reg_file.wr_en ),
    .A2(_1992_),
    .B1(_1996_),
    .Y(_1997_));
 sky130_fd_sc_hd__a21oi_1 _3151_ (.A1(\g_telemetry.u_spi_slave.rx_byte[5] ),
    .A2(_1116_),
    .B1(_1997_),
    .Y(_1998_));
 sky130_fd_sc_hd__o21ai_0 _3152_ (.A1(_1992_),
    .A2(_1994_),
    .B1(_1998_),
    .Y(_0040_));
 sky130_fd_sc_hd__xnor2_1 _3153_ (.A(\g_telemetry.u_reg_file.addr[4] ),
    .B(_1156_),
    .Y(_1999_));
 sky130_fd_sc_hd__nor2_1 _3154_ (.A(\g_telemetry.u_reg_file.wr_en ),
    .B(\g_telemetry.u_reg_file.addr[4] ),
    .Y(_2000_));
 sky130_fd_sc_hd__a21oi_1 _3155_ (.A1(\g_telemetry.u_reg_file.wr_en ),
    .A2(_1999_),
    .B1(_2000_),
    .Y(_2001_));
 sky130_fd_sc_hd__and2_4 _3156_ (.A(\g_telemetry.u_reg_file.unlock_armed ),
    .B(\g_telemetry.u_reg_file.integrity_OK ),
    .X(_0831_));
 sky130_fd_sc_hd__nor2_1 _3157_ (.A(_1994_),
    .B(_1999_),
    .Y(_2002_));
 sky130_fd_sc_hd__a221o_1 _3158_ (.A1(\g_telemetry.u_spi_slave.rx_byte[4] ),
    .A2(_1116_),
    .B1(_1995_),
    .B2(_2001_),
    .C1(_2002_),
    .X(_0039_));
 sky130_fd_sc_hd__nand2_1 _3159_ (.A(\g_telemetry.u_reg_file.wr_en ),
    .B(_0796_),
    .Y(_2003_));
 sky130_fd_sc_hd__xnor2_1 _3160_ (.A(\g_telemetry.u_reg_file.addr[3] ),
    .B(_2003_),
    .Y(_2004_));
 sky130_fd_sc_hd__o21ai_0 _3161_ (.A1(\g_telemetry.u_reg_file.addr[3] ),
    .A2(_0796_),
    .B1(_1993_),
    .Y(_2005_));
 sky130_fd_sc_hd__a22oi_1 _3162_ (.A1(\g_telemetry.u_spi_slave.rx_byte[3] ),
    .A2(_1116_),
    .B1(_1995_),
    .B2(_2004_),
    .Y(_2006_));
 sky130_fd_sc_hd__o21ai_0 _3163_ (.A1(_1156_),
    .A2(_2005_),
    .B1(_2006_),
    .Y(_0038_));
 sky130_fd_sc_hd__nor2_1 _3164_ (.A(\g_telemetry.u_reg_file.wr_en ),
    .B(_1993_),
    .Y(_2007_));
 sky130_fd_sc_hd__nor2_1 _3165_ (.A(_0794_),
    .B(_2007_),
    .Y(_2008_));
 sky130_fd_sc_hd__nor3_1 _3166_ (.A(_0796_),
    .B(_1109_),
    .C(_1115_),
    .Y(_2009_));
 sky130_fd_sc_hd__nand2_4 _3167_ (.A(\g_telemetry.u_reg_file.unlock_armed ),
    .B(\g_telemetry.u_reg_file.integrity_OK ),
    .Y(_0832_));
 sky130_fd_sc_hd__o221ai_1 _3168_ (.A1(\g_telemetry.u_reg_file.addr[2] ),
    .A2(_2008_),
    .B1(_2009_),
    .B2(_1995_),
    .C1(_2003_),
    .Y(_2010_));
 sky130_fd_sc_hd__o21ai_0 _3169_ (.A1(_0686_),
    .A2(_1117_),
    .B1(_2010_),
    .Y(_0037_));
 sky130_fd_sc_hd__nor2_1 _3170_ (.A(_1116_),
    .B(_2007_),
    .Y(_2011_));
 sky130_fd_sc_hd__nand3_1 _3171_ (.A(\g_telemetry.u_reg_file.addr[1] ),
    .B(_1117_),
    .C(_2007_),
    .Y(_2012_));
 sky130_fd_sc_hd__a32oi_1 _3172_ (.A1(_0710_),
    .A2(_0794_),
    .A3(_2011_),
    .B1(_1116_),
    .B2(\g_telemetry.u_spi_slave.rx_byte[1] ),
    .Y(_2013_));
 sky130_fd_sc_hd__nand2_1 _3173_ (.A(_2012_),
    .B(_2013_),
    .Y(_0036_));
 sky130_fd_sc_hd__nand2_1 _3174_ (.A(\g_telemetry.u_reg_file.addr[0] ),
    .B(_1995_),
    .Y(_2014_));
 sky130_fd_sc_hd__nor3_1 _3175_ (.A(\g_telemetry.u_reg_file.addr[0] ),
    .B(_1116_),
    .C(_2007_),
    .Y(_2015_));
 sky130_fd_sc_hd__a21oi_1 _3176_ (.A1(\g_spi_filt.u_mosi_filt.flag_out ),
    .A2(_1116_),
    .B1(_2015_),
    .Y(_2016_));
 sky130_fd_sc_hd__o21ai_0 _3177_ (.A1(\g_telemetry.u_reg_file.wr_en ),
    .A2(_2014_),
    .B1(_2016_),
    .Y(_0035_));
 sky130_fd_sc_hd__nor2_4 _3178_ (.A(\g_telemetry.u_reg_file.sup_state[0] ),
    .B(\g_telemetry.u_reg_file.sup_state[1] ),
    .Y(_0833_));
 sky130_fd_sc_hd__and3_1 _3179_ (.A(\g_telemetry.u_reg_file.arm_timer[2] ),
    .B(\g_telemetry.u_reg_file.arm_timer[1] ),
    .C(\g_telemetry.u_reg_file.arm_timer[0] ),
    .X(_2017_));
 sky130_fd_sc_hd__and3_1 _3180_ (.A(\g_telemetry.u_reg_file.arm_timer[4] ),
    .B(\g_telemetry.u_reg_file.arm_timer[3] ),
    .C(_2017_),
    .X(_2018_));
 sky130_fd_sc_hd__and2_1 _3181_ (.A(\g_telemetry.u_reg_file.arm_timer[5] ),
    .B(_2018_),
    .X(_2019_));
 sky130_fd_sc_hd__and3_1 _3182_ (.A(\g_telemetry.u_reg_file.arm_timer[7] ),
    .B(\g_telemetry.u_reg_file.arm_timer[6] ),
    .C(_2019_),
    .X(_2020_));
 sky130_fd_sc_hd__and2_1 _3183_ (.A(\g_telemetry.u_reg_file.arm_timer[8] ),
    .B(_2020_),
    .X(_2021_));
 sky130_fd_sc_hd__and3_1 _3184_ (.A(\g_telemetry.u_reg_file.arm_timer[10] ),
    .B(\g_telemetry.u_reg_file.arm_timer[9] ),
    .C(_2021_),
    .X(_2022_));
 sky130_fd_sc_hd__and2_1 _3185_ (.A(\g_telemetry.u_reg_file.arm_timer[11] ),
    .B(_2022_),
    .X(_2023_));
 sky130_fd_sc_hd__and3_1 _3186_ (.A(\g_telemetry.u_reg_file.arm_timer[13] ),
    .B(\g_telemetry.u_reg_file.arm_timer[12] ),
    .C(_2023_),
    .X(_2024_));
 sky130_fd_sc_hd__and2_1 _3187_ (.A(\g_telemetry.u_reg_file.arm_timer[14] ),
    .B(_2024_),
    .X(_2025_));
 sky130_fd_sc_hd__nor2_4 _3188_ (.A(\g_telemetry.u_reg_file.unlock_armed ),
    .B(\g_telemetry.u_reg_file.disable_armed ),
    .Y(_2026_));
 sky130_fd_sc_hd__nand4_4 _3189_ (.A(\g_telemetry.u_reg_file.temp_dirty[10] ),
    .B(\g_telemetry.u_reg_file.temp_dirty[8] ),
    .C(\g_telemetry.u_reg_file.temp_dirty[9] ),
    .D(_0833_),
    .Y(_0834_));
 sky130_fd_sc_hd__nor2_1 _3190_ (.A(\g_telemetry.u_reg_file.arm_timer[14] ),
    .B(_2024_),
    .Y(_2027_));
 sky130_fd_sc_hd__nor3_1 _3191_ (.A(_2025_),
    .B(_2026_),
    .C(_2027_),
    .Y(_0021_));
 sky130_fd_sc_hd__a21oi_1 _3192_ (.A1(\g_telemetry.u_reg_file.arm_timer[12] ),
    .A2(_2023_),
    .B1(\g_telemetry.u_reg_file.arm_timer[13] ),
    .Y(_2028_));
 sky130_fd_sc_hd__nor3_1 _3193_ (.A(_2024_),
    .B(_2026_),
    .C(_2028_),
    .Y(_0020_));
 sky130_fd_sc_hd__o22ai_1 _3194_ (.A1(\g_telemetry.u_reg_file.unlock_armed ),
    .A2(\g_telemetry.u_reg_file.disable_armed ),
    .B1(_2023_),
    .B2(\g_telemetry.u_reg_file.arm_timer[12] ),
    .Y(_2029_));
 sky130_fd_sc_hd__a21oi_1 _3195_ (.A1(\g_telemetry.u_reg_file.arm_timer[12] ),
    .A2(_2023_),
    .B1(_2029_),
    .Y(_0019_));
 sky130_fd_sc_hd__nor2_1 _3196_ (.A(\g_telemetry.u_reg_file.arm_timer[11] ),
    .B(_2022_),
    .Y(_2030_));
 sky130_fd_sc_hd__nor3_1 _3197_ (.A(_2023_),
    .B(_2026_),
    .C(_2030_),
    .Y(_0018_));
 sky130_fd_sc_hd__a21oi_1 _3198_ (.A1(\g_telemetry.u_reg_file.arm_timer[9] ),
    .A2(_2021_),
    .B1(\g_telemetry.u_reg_file.arm_timer[10] ),
    .Y(_2031_));
 sky130_fd_sc_hd__nor3_1 _3199_ (.A(_2022_),
    .B(_2026_),
    .C(_2031_),
    .Y(_0017_));
 sky130_fd_sc_hd__inv_1 _3200_ (.A(OTP_sync),
    .Y(_0661_));
 sky130_fd_sc_hd__inv_1 _3201_ (.A(\fault_count_ss[1] ),
    .Y(_0679_));
 sky130_fd_sc_hd__nor2b_1 _3202_ (.A(_0833_),
    .B_N(\g_telemetry.u_reg_file.temp_dirty[7] ),
    .Y(_0835_));
 sky130_fd_sc_hd__o22ai_1 _3203_ (.A1(\g_telemetry.u_reg_file.unlock_armed ),
    .A2(\g_telemetry.u_reg_file.disable_armed ),
    .B1(_2021_),
    .B2(\g_telemetry.u_reg_file.arm_timer[9] ),
    .Y(_2032_));
 sky130_fd_sc_hd__a21oi_1 _3204_ (.A1(\g_telemetry.u_reg_file.arm_timer[9] ),
    .A2(_2021_),
    .B1(_2032_),
    .Y(_0031_));
 sky130_fd_sc_hd__nor2_1 _3205_ (.A(\g_telemetry.u_reg_file.arm_timer[8] ),
    .B(_2020_),
    .Y(_2033_));
 sky130_fd_sc_hd__nor3_1 _3206_ (.A(_2021_),
    .B(_2026_),
    .C(_2033_),
    .Y(_0030_));
 sky130_fd_sc_hd__a21oi_1 _3207_ (.A1(\g_telemetry.u_reg_file.arm_timer[6] ),
    .A2(_2019_),
    .B1(\g_telemetry.u_reg_file.arm_timer[7] ),
    .Y(_2034_));
 sky130_fd_sc_hd__nor3_1 _3208_ (.A(_2020_),
    .B(_2026_),
    .C(_2034_),
    .Y(_0029_));
 sky130_fd_sc_hd__o22ai_1 _3209_ (.A1(\g_telemetry.u_reg_file.unlock_armed ),
    .A2(\g_telemetry.u_reg_file.disable_armed ),
    .B1(_2019_),
    .B2(\g_telemetry.u_reg_file.arm_timer[6] ),
    .Y(_2035_));
 sky130_fd_sc_hd__a21oi_1 _3210_ (.A1(\g_telemetry.u_reg_file.arm_timer[6] ),
    .A2(_2019_),
    .B1(_2035_),
    .Y(_0028_));
 sky130_fd_sc_hd__nor2_1 _3211_ (.A(\g_telemetry.u_reg_file.arm_timer[5] ),
    .B(_2018_),
    .Y(_2036_));
 sky130_fd_sc_hd__nor3_1 _3212_ (.A(_2019_),
    .B(_2026_),
    .C(_2036_),
    .Y(_0027_));
 sky130_fd_sc_hd__nand4_4 _3213_ (.A(\g_telemetry.u_reg_file.temp_dirty[6] ),
    .B(\g_telemetry.u_reg_file.temp_dirty[4] ),
    .C(\g_telemetry.u_reg_file.temp_dirty[5] ),
    .D(_0833_),
    .Y(_0836_));
 sky130_fd_sc_hd__a21oi_1 _3214_ (.A1(\g_telemetry.u_reg_file.arm_timer[3] ),
    .A2(_2017_),
    .B1(\g_telemetry.u_reg_file.arm_timer[4] ),
    .Y(_2037_));
 sky130_fd_sc_hd__nor3_1 _3215_ (.A(_2018_),
    .B(_2026_),
    .C(_2037_),
    .Y(_0026_));
 sky130_fd_sc_hd__o22ai_1 _3216_ (.A1(\g_telemetry.u_reg_file.unlock_armed ),
    .A2(\g_telemetry.u_reg_file.disable_armed ),
    .B1(_2017_),
    .B2(\g_telemetry.u_reg_file.arm_timer[3] ),
    .Y(_2038_));
 sky130_fd_sc_hd__a21oi_1 _3217_ (.A1(\g_telemetry.u_reg_file.arm_timer[3] ),
    .A2(_2017_),
    .B1(_2038_),
    .Y(_0025_));
 sky130_fd_sc_hd__a21oi_1 _3218_ (.A1(\g_telemetry.u_reg_file.arm_timer[1] ),
    .A2(\g_telemetry.u_reg_file.arm_timer[0] ),
    .B1(\g_telemetry.u_reg_file.arm_timer[2] ),
    .Y(_2039_));
 sky130_fd_sc_hd__nor3_1 _3219_ (.A(_2017_),
    .B(_2026_),
    .C(_2039_),
    .Y(_0024_));
 sky130_fd_sc_hd__o22ai_1 _3220_ (.A1(\g_telemetry.u_reg_file.arm_timer[1] ),
    .A2(\g_telemetry.u_reg_file.arm_timer[0] ),
    .B1(\g_telemetry.u_reg_file.disable_armed ),
    .B2(\g_telemetry.u_reg_file.unlock_armed ),
    .Y(_2040_));
 sky130_fd_sc_hd__a21oi_1 _3221_ (.A1(\g_telemetry.u_reg_file.arm_timer[1] ),
    .A2(\g_telemetry.u_reg_file.arm_timer[0] ),
    .B1(_2040_),
    .Y(_0023_));
 sky130_fd_sc_hd__nor2_1 _3222_ (.A(\g_telemetry.u_reg_file.arm_timer[0] ),
    .B(_2026_),
    .Y(_0016_));
 sky130_fd_sc_hd__and2_1 _3223_ (.A(\g_timestamp.u_timestamp.prescalar[4] ),
    .B(_0718_),
    .X(_2041_));
 sky130_fd_sc_hd__a221oi_1 _3224_ (.A1(_0826_),
    .A2(_0834_),
    .B1(_0836_),
    .B2(_0825_),
    .C1(_0835_),
    .Y(_0837_));
 sky130_fd_sc_hd__nand2_1 _3225_ (.A(\g_timestamp.u_timestamp.prescalar[5] ),
    .B(_2041_),
    .Y(_2042_));
 sky130_fd_sc_hd__and4_1 _3226_ (.A(\g_timestamp.u_timestamp.prescalar[7] ),
    .B(\g_timestamp.u_timestamp.prescalar[6] ),
    .C(\g_timestamp.u_timestamp.prescalar[5] ),
    .D(_2041_),
    .X(_2043_));
 sky130_fd_sc_hd__and2_0 _3227_ (.A(\g_timestamp.u_timestamp.prescalar[8] ),
    .B(_2043_),
    .X(_2044_));
 sky130_fd_sc_hd__nor2b_1 _3228_ (.A(_0722_),
    .B_N(_2043_),
    .Y(_2045_));
 sky130_fd_sc_hd__and2_1 _3229_ (.A(\g_timestamp.u_timestamp.prescalar[10] ),
    .B(_2045_),
    .X(_2046_));
 sky130_fd_sc_hd__nand2_1 _3230_ (.A(\g_timestamp.u_timestamp.prescalar[11] ),
    .B(_2046_),
    .Y(_2047_));
 sky130_fd_sc_hd__xnor2_1 _3231_ (.A(\g_timestamp.u_timestamp.prescalar[12] ),
    .B(_2047_),
    .Y(_0048_));
 sky130_fd_sc_hd__xor2_1 _3232_ (.A(\g_timestamp.u_timestamp.prescalar[11] ),
    .B(_2046_),
    .X(_0047_));
 sky130_fd_sc_hd__nor2_1 _3233_ (.A(\g_timestamp.u_timestamp.prescalar[10] ),
    .B(_2045_),
    .Y(_2048_));
 sky130_fd_sc_hd__nor3_1 _3234_ (.A(_0725_),
    .B(_2046_),
    .C(_2048_),
    .Y(_0046_));
 sky130_fd_sc_hd__a31oi_1 _3235_ (.A1(_0829_),
    .A2(_0831_),
    .A3(_0837_),
    .B1(_0830_),
    .Y(_0637_));
 sky130_fd_sc_hd__nor2_1 _3236_ (.A(\g_timestamp.u_timestamp.prescalar[9] ),
    .B(_2044_),
    .Y(_2049_));
 sky130_fd_sc_hd__nor3_1 _3237_ (.A(_0725_),
    .B(_2045_),
    .C(_2049_),
    .Y(_0058_));
 sky130_fd_sc_hd__nor2_1 _3238_ (.A(\g_timestamp.u_timestamp.prescalar[8] ),
    .B(_2043_),
    .Y(_2050_));
 sky130_fd_sc_hd__nor3_1 _3239_ (.A(_0725_),
    .B(_2044_),
    .C(_2050_),
    .Y(_0057_));
 sky130_fd_sc_hd__a31oi_1 _3240_ (.A1(\g_timestamp.u_timestamp.prescalar[6] ),
    .A2(\g_timestamp.u_timestamp.prescalar[5] ),
    .A3(_2041_),
    .B1(\g_timestamp.u_timestamp.prescalar[7] ),
    .Y(_2051_));
 sky130_fd_sc_hd__nor2_1 _3241_ (.A(_2043_),
    .B(_2051_),
    .Y(_0056_));
 sky130_fd_sc_hd__xnor2_1 _3242_ (.A(\g_timestamp.u_timestamp.prescalar[6] ),
    .B(_2042_),
    .Y(_0055_));
 sky130_fd_sc_hd__xor2_1 _3243_ (.A(\g_timestamp.u_timestamp.prescalar[5] ),
    .B(_2041_),
    .X(_0054_));
 sky130_fd_sc_hd__nor2_1 _3244_ (.A(\g_timestamp.u_timestamp.prescalar[4] ),
    .B(_0718_),
    .Y(_2052_));
 sky130_fd_sc_hd__nor3_1 _3245_ (.A(_0725_),
    .B(_2041_),
    .C(_2052_),
    .Y(_0053_));
 sky130_fd_sc_hd__nand2_1 _3246_ (.A(\g_telemetry.u_reg_file.temp_dirty[8] ),
    .B(_0779_),
    .Y(_0838_));
 sky130_fd_sc_hd__a31oi_1 _3247_ (.A1(\g_timestamp.u_timestamp.prescalar[2] ),
    .A2(\g_timestamp.u_timestamp.prescalar[1] ),
    .A3(\g_timestamp.u_timestamp.prescalar[0] ),
    .B1(\g_timestamp.u_timestamp.prescalar[3] ),
    .Y(_2053_));
 sky130_fd_sc_hd__nor2_1 _3248_ (.A(_0718_),
    .B(_2053_),
    .Y(_0052_));
 sky130_fd_sc_hd__xnor2_1 _3249_ (.A(\g_timestamp.u_timestamp.prescalar[2] ),
    .B(_0717_),
    .Y(_0051_));
 sky130_fd_sc_hd__xor2_1 _3250_ (.A(\g_timestamp.u_timestamp.prescalar[1] ),
    .B(\g_timestamp.u_timestamp.prescalar[0] ),
    .X(_0050_));
 sky130_fd_sc_hd__and2_0 _3251_ (.A(\u_fault_arbiter.cp_delay[3] ),
    .B(_0704_),
    .X(_0086_));
 sky130_fd_sc_hd__nand2b_1 _3252_ (.A_N(\g_telemetry.u_spi_slave.rw ),
    .B(_1984_),
    .Y(_2054_));
 sky130_fd_sc_hd__nor4_1 _3253_ (.A(\g_telemetry.u_spi_slave.crc[1] ),
    .B(\g_telemetry.u_spi_slave.crc[4] ),
    .C(\g_telemetry.u_spi_slave.crc[6] ),
    .D(\g_telemetry.u_spi_slave.crc[3] ),
    .Y(_2055_));
 sky130_fd_sc_hd__nor4_1 _3254_ (.A(\g_telemetry.u_spi_slave.crc[5] ),
    .B(\g_telemetry.u_spi_slave.crc[0] ),
    .C(\g_telemetry.u_spi_slave.crc[2] ),
    .D(\g_telemetry.u_spi_slave.crc[7] ),
    .Y(_2056_));
 sky130_fd_sc_hd__nand2_1 _3255_ (.A(_2055_),
    .B(_2056_),
    .Y(_2057_));
 sky130_fd_sc_hd__a211oi_1 _3256_ (.A1(\g_telemetry.u_spi_slave.byte_count[1] ),
    .A2(\g_telemetry.u_spi_slave.byte_count[0] ),
    .B1(\g_telemetry.u_spi_slave.byte_count[2] ),
    .C1(\g_telemetry.u_spi_slave.byte_count[3] ),
    .Y(_2058_));
 sky130_fd_sc_hd__nand2_1 _3257_ (.A(_0785_),
    .B(_0838_),
    .Y(_0636_));
 sky130_fd_sc_hd__nand3b_1 _3258_ (.A_N(\g_telemetry.u_spi_slave.spi_state[1] ),
    .B(\g_telemetry.u_spi_slave.spi_state[2] ),
    .C(\g_telemetry.u_spi_slave.spi_state[0] ),
    .Y(_2059_));
 sky130_fd_sc_hd__nand2_1 _3259_ (.A(_1140_),
    .B(_2059_),
    .Y(_2060_));
 sky130_fd_sc_hd__nor3_1 _3260_ (.A(_2057_),
    .B(_2058_),
    .C(_2060_),
    .Y(_2061_));
 sky130_fd_sc_hd__nor2_1 _3261_ (.A(_2054_),
    .B(_2061_),
    .Y(_0034_));
 sky130_fd_sc_hd__nor4_1 _3262_ (.A(_2054_),
    .B(_2057_),
    .C(_2058_),
    .D(_2060_),
    .Y(_0042_));
 sky130_fd_sc_hd__nor2_1 _3263_ (.A(_0703_),
    .B(_0740_),
    .Y(_0059_));
 sky130_fd_sc_hd__and2_2 _3264_ (.A(\g_telemetry.u_spi_slave.sdio_out ),
    .B(\g_telemetry.u_spi_slave.sdio_oe ),
    .X(MISO));
 sky130_fd_sc_hd__a211oi_1 _3265_ (.A1(_0707_),
    .A2(_0992_),
    .B1(_1987_),
    .C1(\g_telemetry.u_spi_slave.spi_state[2] ),
    .Y(_2062_));
 sky130_fd_sc_hd__nor3_1 _3266_ (.A(_1111_),
    .B(_1984_),
    .C(_2062_),
    .Y(\g_telemetry.u_spi_slave.spi_state_next[2] ));
 sky130_fd_sc_hd__nor3_1 _3267_ (.A(_1111_),
    .B(_1984_),
    .C(_1987_),
    .Y(_2063_));
 sky130_fd_sc_hd__nor2_4 _3268_ (.A(_0832_),
    .B(_0836_),
    .Y(_0839_));
 sky130_fd_sc_hd__o21ai_0 _3269_ (.A1(\g_telemetry.u_spi_slave.spi_state[1] ),
    .A2(_0707_),
    .B1(_2063_),
    .Y(_2064_));
 sky130_fd_sc_hd__a31oi_1 _3270_ (.A1(_1110_),
    .A2(_1131_),
    .A3(_1986_),
    .B1(_2064_),
    .Y(\g_telemetry.u_spi_slave.spi_state_next[1] ));
 sky130_fd_sc_hd__and4_1 _3271_ (.A(_1985_),
    .B(_1986_),
    .C(_1989_),
    .D(\g_telemetry.u_spi_slave.spi_state_next[2] ),
    .X(_0043_));
 sky130_fd_sc_hd__xnor2_1 _3272_ (.A(\g_telemetry.u_reg_file.addr[6] ),
    .B(_1990_),
    .Y(_2065_));
 sky130_fd_sc_hd__nand3_1 _3273_ (.A(\g_telemetry.u_reg_file.addr[6] ),
    .B(_1117_),
    .C(_2007_),
    .Y(_2066_));
 sky130_fd_sc_hd__a22oi_1 _3274_ (.A1(\g_telemetry.u_spi_slave.rx_byte[6] ),
    .A2(_1116_),
    .B1(_2011_),
    .B2(_2065_),
    .Y(_2067_));
 sky130_fd_sc_hd__nand2_1 _3275_ (.A(_2066_),
    .B(_2067_),
    .Y(_0041_));
 sky130_fd_sc_hd__o21ai_4 _3276_ (.A1(\g_telemetry.u_reg_file.strike_level[0] ),
    .A2(\g_telemetry.u_reg_file.strike_level[1] ),
    .B1(\u_fault_LED.blink ),
    .Y(_2068_));
 sky130_fd_sc_hd__nand2_1 _3277_ (.A(_0738_),
    .B(_2068_),
    .Y(_0060_));
 sky130_fd_sc_hd__xor2_1 _3278_ (.A(\u_fault_LED.blink_counter[20] ),
    .B(_1974_),
    .X(_2069_));
 sky130_fd_sc_hd__or2_4 _3279_ (.A(_0832_),
    .B(_0836_),
    .X(_0840_));
 sky130_fd_sc_hd__nor2_1 _3280_ (.A(_1130_),
    .B(_2069_),
    .Y(_0073_));
 sky130_fd_sc_hd__nand2b_1 _3281_ (.A_N(SS_done),
    .B(_0755_),
    .Y(_2070_));
 sky130_fd_sc_hd__a221oi_1 _3282_ (.A1(_0660_),
    .A2(\g_telemetry.u_reg_file.sup_state[1] ),
    .B1(_0699_),
    .B2(_2070_),
    .C1(_0701_),
    .Y(_2071_));
 sky130_fd_sc_hd__nor2_1 _3283_ (.A(_1963_),
    .B(_2071_),
    .Y(\u_supervisor.next_state[1] ));
 sky130_fd_sc_hd__nand2_2 _3284_ (.A(\g_telemetry.u_reg_file.arm_timer[15] ),
    .B(_2025_),
    .Y(_2072_));
 sky130_fd_sc_hd__nand2_1 _3285_ (.A(\g_telemetry.u_reg_file.wr_en ),
    .B(_1167_),
    .Y(_2073_));
 sky130_fd_sc_hd__nand3_1 _3286_ (.A(\g_telemetry.u_reg_file.disable_armed ),
    .B(_2072_),
    .C(_2073_),
    .Y(_2074_));
 sky130_fd_sc_hd__nor2_1 _3287_ (.A(\g_telemetry.u_reg_file.wdata[1] ),
    .B(\g_telemetry.u_reg_file.wdata[2] ),
    .Y(_2075_));
 sky130_fd_sc_hd__nand4_1 _3288_ (.A(\g_telemetry.u_reg_file.wdata[6] ),
    .B(\g_telemetry.u_reg_file.wdata[7] ),
    .C(\g_telemetry.u_reg_file.wdata[0] ),
    .D(\g_telemetry.u_reg_file.wr_en ),
    .Y(_2076_));
 sky130_fd_sc_hd__nor4b_1 _3289_ (.A(\g_telemetry.u_reg_file.wdata[3] ),
    .B(\g_telemetry.u_reg_file.wdata[5] ),
    .C(_2076_),
    .D_N(\g_telemetry.u_reg_file.wdata[4] ),
    .Y(_2077_));
 sky130_fd_sc_hd__nor2_1 _3290_ (.A(\g_telemetry.u_reg_file.hiccup_base[17] ),
    .B(_0839_),
    .Y(_0841_));
 sky130_fd_sc_hd__nand3_1 _3291_ (.A(_1166_),
    .B(_2075_),
    .C(_2077_),
    .Y(_2078_));
 sky130_fd_sc_hd__a21boi_0 _3292_ (.A1(_2074_),
    .A2(_2078_),
    .B1_N(_0779_),
    .Y(_0032_));
 sky130_fd_sc_hd__nand2_1 _3293_ (.A(\g_telemetry.u_reg_file.wr_en ),
    .B(_1158_),
    .Y(_2079_));
 sky130_fd_sc_hd__nor2_1 _3294_ (.A(\g_telemetry.u_reg_file.wdata[3] ),
    .B(\g_telemetry.u_reg_file.wdata[4] ),
    .Y(_2080_));
 sky130_fd_sc_hd__nand3_1 _3295_ (.A(\g_telemetry.u_reg_file.wdata[2] ),
    .B(\g_telemetry.u_reg_file.wdata[5] ),
    .C(_2080_),
    .Y(_2081_));
 sky130_fd_sc_hd__nand4b_1 _3296_ (.A_N(\g_telemetry.u_reg_file.wdata[6] ),
    .B(\g_telemetry.u_reg_file.wdata[7] ),
    .C(\g_telemetry.u_reg_file.wdata[0] ),
    .D(\g_telemetry.u_reg_file.wdata[1] ),
    .Y(_2082_));
 sky130_fd_sc_hd__nor3_1 _3297_ (.A(_2079_),
    .B(_2081_),
    .C(_2082_),
    .Y(_2083_));
 sky130_fd_sc_hd__a31oi_1 _3298_ (.A1(\g_telemetry.u_reg_file.unlock_armed ),
    .A2(_2072_),
    .A3(_2079_),
    .B1(_2083_),
    .Y(_2084_));
 sky130_fd_sc_hd__nor3_1 _3299_ (.A(\g_telemetry.u_reg_file.integrity_OK ),
    .B(\g_telemetry.u_reg_file.abort ),
    .C(_2084_),
    .Y(_0033_));
 sky130_fd_sc_hd__o22ai_1 _3300_ (.A1(\g_telemetry.u_reg_file.unlock_armed ),
    .A2(\g_telemetry.u_reg_file.disable_armed ),
    .B1(\g_telemetry.u_reg_file.arm_timer[15] ),
    .B2(_2025_),
    .Y(_2085_));
 sky130_fd_sc_hd__nor3_1 _3301_ (.A(\g_telemetry.u_reg_file.temp_hiccup_2[7] ),
    .B(\g_telemetry.u_reg_file.temp_hiccup_2[4] ),
    .C(\g_telemetry.u_reg_file.temp_hiccup_2[5] ),
    .Y(_0842_));
 sky130_fd_sc_hd__a21oi_1 _3302_ (.A1(\g_telemetry.u_reg_file.arm_timer[15] ),
    .A2(_2025_),
    .B1(_2085_),
    .Y(_0022_));
 sky130_fd_sc_hd__and2_0 _3303_ (.A(CP_sync),
    .B(_0704_),
    .X(_0082_));
 sky130_fd_sc_hd__nand2_1 _3304_ (.A(Osc_sync),
    .B(_1217_),
    .Y(_0087_));
 sky130_fd_sc_hd__and2_0 _3305_ (.A(Osc_sync),
    .B(\u_pwm_mask.pulse_allowed ),
    .X(_0088_));
 sky130_fd_sc_hd__and4_1 _3306_ (.A(\g_timestamp.u_timestamp.prescalar[12] ),
    .B(\g_timestamp.u_timestamp.prescalar[11] ),
    .C(\g_timestamp.u_timestamp.prescalar[13] ),
    .D(_2046_),
    .X(_2086_));
 sky130_fd_sc_hd__a31oi_1 _3307_ (.A1(\g_timestamp.u_timestamp.prescalar[12] ),
    .A2(\g_timestamp.u_timestamp.prescalar[11] ),
    .A3(_2046_),
    .B1(\g_timestamp.u_timestamp.prescalar[13] ),
    .Y(_2087_));
 sky130_fd_sc_hd__nor3_1 _3308_ (.A(_0725_),
    .B(_2086_),
    .C(_2087_),
    .Y(_0049_));
 sky130_fd_sc_hd__inv_1 _3309_ (.A(\u_pwm_mask.run_counter[3] ),
    .Y(_0680_));
 sky130_fd_sc_hd__nor3_1 _3310_ (.A(\g_telemetry.u_reg_file.temp_hiccup_2[2] ),
    .B(\g_telemetry.u_reg_file.temp_hiccup_2[3] ),
    .C(\g_telemetry.u_reg_file.temp_hiccup_2[6] ),
    .Y(_0843_));
 sky130_fd_sc_hd__nand2_2 _3311_ (.A(_0842_),
    .B(_0843_),
    .Y(_0844_));
 sky130_fd_sc_hd__nor3_1 _3312_ (.A(\g_telemetry.u_reg_file.temp_hiccup_2[1] ),
    .B(_0840_),
    .C(_0844_),
    .Y(_0845_));
 sky130_fd_sc_hd__nor2_1 _3313_ (.A(_0841_),
    .B(_0845_),
    .Y(_0635_));
 sky130_fd_sc_hd__nor2_8 _3314_ (.A(_0783_),
    .B(_0795_),
    .Y(_0846_));
 sky130_fd_sc_hd__nand2_4 _3315_ (.A(_0780_),
    .B(_0846_),
    .Y(_0847_));
 sky130_fd_sc_hd__mux2_1 _3316_ (.A0(\g_telemetry.u_reg_file.wdata[7] ),
    .A1(\g_telemetry.u_reg_file.temp_hiccup_0[7] ),
    .S(_0847_),
    .X(_0634_));
 sky130_fd_sc_hd__nor2_8 _3317_ (.A(_0832_),
    .B(_0834_),
    .Y(_0848_));
 sky130_fd_sc_hd__nor2_1 _3318_ (.A(\g_telemetry.u_reg_file.temp_clean_2[7] ),
    .B(\g_telemetry.u_reg_file.temp_clean_2[3] ),
    .Y(_0849_));
 sky130_fd_sc_hd__nor3_1 _3319_ (.A(\g_telemetry.u_reg_file.temp_clean_2[4] ),
    .B(\g_telemetry.u_reg_file.temp_clean_2[5] ),
    .C(\g_telemetry.u_reg_file.temp_clean_2[6] ),
    .Y(_0850_));
 sky130_fd_sc_hd__inv_1 _3320_ (.A(\max_on_counts[1] ),
    .Y(_0681_));
 sky130_fd_sc_hd__nand2_4 _3321_ (.A(_0849_),
    .B(_0850_),
    .Y(_0851_));
 sky130_fd_sc_hd__inv_1 _3322_ (.A(_0851_),
    .Y(_0852_));
 sky130_fd_sc_hd__nand2_1 _3323_ (.A(_0848_),
    .B(_0852_),
    .Y(_0853_));
 sky130_fd_sc_hd__o22a_1 _3324_ (.A1(\clean_run_target[18] ),
    .A2(_0848_),
    .B1(_0853_),
    .B2(\g_telemetry.u_reg_file.temp_clean_2[2] ),
    .X(_0633_));
 sky130_fd_sc_hd__nor2_8 _3325_ (.A(\g_telemetry.u_reg_file.spi_enable ),
    .B(\g_telemetry.u_reg_file.integrity_OK ),
    .Y(_0854_));
 sky130_fd_sc_hd__mux2_1 _3326_ (.A0(\g_telemetry.u_fault_cause.timestamp_ms[23] ),
    .A1(\g_telemetry.u_reg_file.wd_mark[23] ),
    .S(_0854_),
    .X(_0632_));
 sky130_fd_sc_hd__nand2_1 _3327_ (.A(\g_telemetry.u_reg_file.temp_dirty[2] ),
    .B(_0831_),
    .Y(_0855_));
 sky130_fd_sc_hd__or4_1 _3328_ (.A(\g_telemetry.u_reg_file.temp_max_strk[7] ),
    .B(\g_telemetry.u_reg_file.temp_max_strk[4] ),
    .C(\g_telemetry.u_reg_file.temp_max_strk[5] ),
    .D(\g_telemetry.u_reg_file.temp_max_strk[3] ),
    .X(_0856_));
 sky130_fd_sc_hd__nor3_2 _3329_ (.A(\g_telemetry.u_reg_file.temp_max_strk[6] ),
    .B(\g_telemetry.u_reg_file.temp_max_strk[2] ),
    .C(_0856_),
    .Y(_0857_));
 sky130_fd_sc_hd__a21oi_1 _3330_ (.A1(\g_telemetry.u_reg_file.temp_dirty[2] ),
    .A2(_0831_),
    .B1(\g_telemetry.u_reg_file.max_strikes[1] ),
    .Y(_0858_));
 sky130_fd_sc_hd__inv_1 _3331_ (.A(\max_on_counts[4] ),
    .Y(_0682_));
 sky130_fd_sc_hd__nor2_1 _3332_ (.A(\g_telemetry.u_reg_file.temp_max_strk[1] ),
    .B(_0855_),
    .Y(_0859_));
 sky130_fd_sc_hd__a21oi_1 _3333_ (.A1(_0857_),
    .A2(_0859_),
    .B1(_0858_),
    .Y(_0631_));
 sky130_fd_sc_hd__nand2_2 _3334_ (.A(\g_telemetry.u_reg_file.temp_dirty[1] ),
    .B(_0831_),
    .Y(_0860_));
 sky130_fd_sc_hd__nor3_1 _3335_ (.A(\g_telemetry.u_reg_file.temp_trip_ss[7] ),
    .B(\g_telemetry.u_reg_file.temp_trip_ss[6] ),
    .C(\g_telemetry.u_reg_file.temp_trip_ss[5] ),
    .Y(_0861_));
 sky130_fd_sc_hd__and3_1 _3336_ (.A(\g_telemetry.u_reg_file.temp_dirty[1] ),
    .B(_0831_),
    .C(_0861_),
    .X(_0862_));
 sky130_fd_sc_hd__a21oi_1 _3337_ (.A1(_0662_),
    .A2(_0860_),
    .B1(_0862_),
    .Y(_0630_));
 sky130_fd_sc_hd__nor3_4 _3338_ (.A(_0712_),
    .B(_0775_),
    .C(_0794_),
    .Y(_0863_));
 sky130_fd_sc_hd__nand2_4 _3339_ (.A(_0780_),
    .B(_0863_),
    .Y(_0864_));
 sky130_fd_sc_hd__mux2_1 _3340_ (.A0(\g_telemetry.u_reg_file.wdata[7] ),
    .A1(\g_telemetry.u_reg_file.temp_max_on[7] ),
    .S(_0864_),
    .X(_0629_));
 sky130_fd_sc_hd__nand2_2 _3341_ (.A(\g_telemetry.u_reg_file.temp_dirty[0] ),
    .B(_0831_),
    .Y(_0865_));
 sky130_fd_sc_hd__inv_1 _3342_ (.A(\fault_count_run[3] ),
    .Y(_0683_));
 sky130_fd_sc_hd__and2_0 _3343_ (.A(\g_telemetry.u_reg_file.trip_run[5] ),
    .B(_0865_),
    .X(_0628_));
 sky130_fd_sc_hd__nand2_2 _3344_ (.A(\g_telemetry.u_reg_file.temp_dirty[3] ),
    .B(_0831_),
    .Y(_0866_));
 sky130_fd_sc_hd__or4_1 _3345_ (.A(\g_telemetry.u_reg_file.temp_max_on[7] ),
    .B(\g_telemetry.u_reg_file.temp_max_on[5] ),
    .C(\g_telemetry.u_reg_file.temp_max_on[6] ),
    .D(_0866_),
    .X(_0867_));
 sky130_fd_sc_hd__nor4_2 _3346_ (.A(\g_telemetry.u_reg_file.temp_max_on[7] ),
    .B(\g_telemetry.u_reg_file.temp_max_on[4] ),
    .C(\g_telemetry.u_reg_file.temp_max_on[5] ),
    .D(\g_telemetry.u_reg_file.temp_max_on[6] ),
    .Y(_0868_));
 sky130_fd_sc_hd__a21oi_1 _3347_ (.A1(\g_telemetry.u_reg_file.temp_dirty[3] ),
    .A2(_0831_),
    .B1(\g_telemetry.u_reg_file.max_on_limit[4] ),
    .Y(_0869_));
 sky130_fd_sc_hd__a31oi_1 _3348_ (.A1(\g_telemetry.u_reg_file.temp_dirty[3] ),
    .A2(_0831_),
    .A3(_0868_),
    .B1(_0869_),
    .Y(_0627_));
 sky130_fd_sc_hd__nand3_4 _3349_ (.A(\g_telemetry.u_reg_file.temp_dirty[7] ),
    .B(_0831_),
    .C(_0833_),
    .Y(_0870_));
 sky130_fd_sc_hd__nor3_1 _3350_ (.A(\g_telemetry.u_reg_file.temp_cyc_step[7] ),
    .B(\g_telemetry.u_reg_file.temp_cyc_step[6] ),
    .C(_0870_),
    .Y(_0871_));
 sky130_fd_sc_hd__a21oi_1 _3351_ (.A1(_0659_),
    .A2(_0870_),
    .B1(_0871_),
    .Y(_0626_));
 sky130_fd_sc_hd__nor2_4 _3352_ (.A(_0712_),
    .B(_0800_),
    .Y(_0872_));
 sky130_fd_sc_hd__inv_1 _3353_ (.A(\fault_count_run[2] ),
    .Y(_0684_));
 sky130_fd_sc_hd__nand2_4 _3354_ (.A(_0780_),
    .B(_0872_),
    .Y(_0873_));
 sky130_fd_sc_hd__nor3_1 _3355_ (.A(_0712_),
    .B(_0775_),
    .C(_0799_),
    .Y(_0874_));
 sky130_fd_sc_hd__mux2_1 _3356_ (.A0(\g_telemetry.u_reg_file.wdata[7] ),
    .A1(\g_telemetry.u_reg_file.temp_max_strk[7] ),
    .S(_0873_),
    .X(_0625_));
 sky130_fd_sc_hd__and3_1 _3357_ (.A(\g_telemetry.u_reg_file.en_pending ),
    .B(\g_telemetry.u_reg_file.integrity_OK ),
    .C(_0668_),
    .X(_0875_));
 sky130_fd_sc_hd__nor2b_1 _3358_ (.A(\g_telemetry.u_reg_file.wd_mark[22] ),
    .B_N(\g_telemetry.u_fault_cause.timestamp_ms[22] ),
    .Y(_0876_));
 sky130_fd_sc_hd__nor2b_1 _3359_ (.A(\g_telemetry.u_reg_file.wd_mark[21] ),
    .B_N(\g_telemetry.u_fault_cause.timestamp_ms[21] ),
    .Y(_0877_));
 sky130_fd_sc_hd__nand2b_1 _3360_ (.A_N(\g_telemetry.u_reg_file.wd_mark[20] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[20] ),
    .Y(_0878_));
 sky130_fd_sc_hd__nor2b_1 _3361_ (.A(\g_telemetry.u_reg_file.wd_mark[19] ),
    .B_N(\g_telemetry.u_fault_cause.timestamp_ms[19] ),
    .Y(_0879_));
 sky130_fd_sc_hd__nor2b_1 _3362_ (.A(\g_telemetry.u_reg_file.wd_mark[18] ),
    .B_N(\g_telemetry.u_fault_cause.timestamp_ms[18] ),
    .Y(_0880_));
 sky130_fd_sc_hd__nand2b_1 _3363_ (.A_N(\g_telemetry.u_reg_file.wd_mark[17] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[17] ),
    .Y(_0881_));
 sky130_fd_sc_hd__clkinv_1 _3364_ (.A(\u_soft_start.cycle_counter[5] ),
    .Y(_0685_));
 sky130_fd_sc_hd__nand2b_1 _3365_ (.A_N(\g_telemetry.u_reg_file.wd_mark[16] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[16] ),
    .Y(_0882_));
 sky130_fd_sc_hd__nor2b_1 _3366_ (.A(\g_telemetry.u_reg_file.wd_mark[15] ),
    .B_N(\g_telemetry.u_fault_cause.timestamp_ms[15] ),
    .Y(_0883_));
 sky130_fd_sc_hd__nor2b_1 _3367_ (.A(\g_telemetry.u_reg_file.wd_mark[14] ),
    .B_N(\g_telemetry.u_fault_cause.timestamp_ms[14] ),
    .Y(_0884_));
 sky130_fd_sc_hd__nand2b_1 _3368_ (.A_N(\g_telemetry.u_reg_file.wd_mark[13] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[13] ),
    .Y(_0885_));
 sky130_fd_sc_hd__nor2b_1 _3369_ (.A(\g_telemetry.u_reg_file.wd_mark[12] ),
    .B_N(\g_telemetry.u_fault_cause.timestamp_ms[12] ),
    .Y(_0886_));
 sky130_fd_sc_hd__nor2b_1 _3370_ (.A(\g_telemetry.u_reg_file.wd_mark[11] ),
    .B_N(\g_telemetry.u_fault_cause.timestamp_ms[11] ),
    .Y(_0887_));
 sky130_fd_sc_hd__nand2b_1 _3371_ (.A_N(\g_telemetry.u_reg_file.wd_mark[10] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[10] ),
    .Y(_0888_));
 sky130_fd_sc_hd__nor2b_1 _3372_ (.A(\g_telemetry.u_reg_file.wd_mark[9] ),
    .B_N(\g_telemetry.u_fault_cause.timestamp_ms[9] ),
    .Y(_0889_));
 sky130_fd_sc_hd__nand2b_1 _3373_ (.A_N(\g_telemetry.u_reg_file.wd_mark[8] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[8] ),
    .Y(_0890_));
 sky130_fd_sc_hd__nor2b_1 _3374_ (.A(\g_telemetry.u_reg_file.wd_mark[7] ),
    .B_N(\g_telemetry.u_fault_cause.timestamp_ms[7] ),
    .Y(_0891_));
 sky130_fd_sc_hd__inv_1 _3375_ (.A(\g_telemetry.u_spi_slave.rx_byte[2] ),
    .Y(_0686_));
 sky130_fd_sc_hd__nand2b_1 _3376_ (.A_N(\g_telemetry.u_reg_file.wd_mark[7] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[7] ),
    .Y(_0892_));
 sky130_fd_sc_hd__nand2b_1 _3377_ (.A_N(\g_telemetry.u_reg_file.wd_mark[6] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[6] ),
    .Y(_0893_));
 sky130_fd_sc_hd__nand2b_1 _3378_ (.A_N(\g_telemetry.u_reg_file.wd_mark[5] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[5] ),
    .Y(_0894_));
 sky130_fd_sc_hd__nor2b_1 _3379_ (.A(\g_telemetry.u_reg_file.wd_mark[4] ),
    .B_N(\g_telemetry.u_fault_cause.timestamp_ms[4] ),
    .Y(_0895_));
 sky130_fd_sc_hd__nand2b_1 _3380_ (.A_N(\g_telemetry.u_reg_file.wd_mark[3] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[3] ),
    .Y(_0896_));
 sky130_fd_sc_hd__xnor2_1 _3381_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[3] ),
    .B(\g_telemetry.u_reg_file.wd_mark[3] ),
    .Y(_0897_));
 sky130_fd_sc_hd__nor2b_1 _3382_ (.A(\g_telemetry.u_reg_file.wd_mark[2] ),
    .B_N(\g_telemetry.u_fault_cause.timestamp_ms[2] ),
    .Y(_0898_));
 sky130_fd_sc_hd__nand2b_1 _3383_ (.A_N(\g_telemetry.u_fault_cause.timestamp_ms[2] ),
    .B(\g_telemetry.u_reg_file.wd_mark[2] ),
    .Y(_0899_));
 sky130_fd_sc_hd__nand2b_1 _3384_ (.A_N(\g_telemetry.u_fault_cause.timestamp_ms[0] ),
    .B(\g_telemetry.u_reg_file.wd_mark[0] ),
    .Y(_0900_));
 sky130_fd_sc_hd__maj3_1 _3385_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[1] ),
    .B(_0689_),
    .C(_0900_),
    .X(_0901_));
 sky130_fd_sc_hd__inv_1 _3386_ (.A(\g_telemetry.u_reg_file.trip_run[4] ),
    .Y(_0687_));
 sky130_fd_sc_hd__o21ai_0 _3387_ (.A1(_0898_),
    .A2(_0901_),
    .B1(_0899_),
    .Y(_0902_));
 sky130_fd_sc_hd__o211ai_1 _3388_ (.A1(_0898_),
    .A2(_0901_),
    .B1(_0899_),
    .C1(_0897_),
    .Y(_0903_));
 sky130_fd_sc_hd__xor2_1 _3389_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[4] ),
    .B(\g_telemetry.u_reg_file.wd_mark[4] ),
    .X(_0904_));
 sky130_fd_sc_hd__a21oi_1 _3390_ (.A1(_0896_),
    .A2(_0903_),
    .B1(_0904_),
    .Y(_0905_));
 sky130_fd_sc_hd__nor2_1 _3391_ (.A(_0895_),
    .B(_0905_),
    .Y(_0906_));
 sky130_fd_sc_hd__xnor2_1 _3392_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[5] ),
    .B(\g_telemetry.u_reg_file.wd_mark[5] ),
    .Y(_0907_));
 sky130_fd_sc_hd__o21ai_0 _3393_ (.A1(_0895_),
    .A2(_0905_),
    .B1(_0907_),
    .Y(_0908_));
 sky130_fd_sc_hd__xor2_1 _3394_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[6] ),
    .B(\g_telemetry.u_reg_file.wd_mark[6] ),
    .X(_0909_));
 sky130_fd_sc_hd__a21o_1 _3395_ (.A1(_0894_),
    .A2(_0908_),
    .B1(_0909_),
    .X(_0910_));
 sky130_fd_sc_hd__nand2_1 _3396_ (.A(_0893_),
    .B(_0910_),
    .Y(_0911_));
 sky130_fd_sc_hd__inv_1 _3397_ (.A(\g_telemetry.u_reg_file.trip_ss[4] ),
    .Y(_0688_));
 sky130_fd_sc_hd__xnor2_1 _3398_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[7] ),
    .B(\g_telemetry.u_reg_file.wd_mark[7] ),
    .Y(_0912_));
 sky130_fd_sc_hd__a21boi_0 _3399_ (.A1(_0893_),
    .A2(_0910_),
    .B1_N(_0912_),
    .Y(_0913_));
 sky130_fd_sc_hd__xor2_1 _3400_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[8] ),
    .B(\g_telemetry.u_reg_file.wd_mark[8] ),
    .X(_0914_));
 sky130_fd_sc_hd__o21bai_1 _3401_ (.A1(_0891_),
    .A2(_0913_),
    .B1_N(_0914_),
    .Y(_0915_));
 sky130_fd_sc_hd__nand2_1 _3402_ (.A(_0890_),
    .B(_0915_),
    .Y(_0916_));
 sky130_fd_sc_hd__xnor2_1 _3403_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[9] ),
    .B(\g_telemetry.u_reg_file.wd_mark[9] ),
    .Y(_0917_));
 sky130_fd_sc_hd__a21boi_1 _3404_ (.A1(_0890_),
    .A2(_0915_),
    .B1_N(_0917_),
    .Y(_0918_));
 sky130_fd_sc_hd__nor2_1 _3405_ (.A(_0889_),
    .B(_0918_),
    .Y(_0919_));
 sky130_fd_sc_hd__xor2_1 _3406_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[10] ),
    .B(\g_telemetry.u_reg_file.wd_mark[10] ),
    .X(_0920_));
 sky130_fd_sc_hd__o21bai_1 _3407_ (.A1(_0889_),
    .A2(_0918_),
    .B1_N(_0920_),
    .Y(_0921_));
 sky130_fd_sc_hd__inv_1 _3408_ (.A(\g_telemetry.u_reg_file.trip_ss[5] ),
    .Y(_0662_));
 sky130_fd_sc_hd__inv_1 _3409_ (.A(\g_telemetry.u_reg_file.wd_mark[1] ),
    .Y(_0689_));
 sky130_fd_sc_hd__xor2_1 _3410_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[11] ),
    .B(\g_telemetry.u_reg_file.wd_mark[11] ),
    .X(_0922_));
 sky130_fd_sc_hd__a21oi_1 _3411_ (.A1(_0888_),
    .A2(_0921_),
    .B1(_0922_),
    .Y(_0923_));
 sky130_fd_sc_hd__xnor2_1 _3412_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[12] ),
    .B(\g_telemetry.u_reg_file.wd_mark[12] ),
    .Y(_0924_));
 sky130_fd_sc_hd__o21a_1 _3413_ (.A1(_0887_),
    .A2(_0923_),
    .B1(_0924_),
    .X(_0925_));
 sky130_fd_sc_hd__xnor2_1 _3414_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[13] ),
    .B(\g_telemetry.u_reg_file.wd_mark[13] ),
    .Y(_0926_));
 sky130_fd_sc_hd__o21ai_1 _3415_ (.A1(_0886_),
    .A2(_0925_),
    .B1(_0926_),
    .Y(_0927_));
 sky130_fd_sc_hd__nand2_1 _3416_ (.A(_0885_),
    .B(_0927_),
    .Y(_0928_));
 sky130_fd_sc_hd__xnor2_1 _3417_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[14] ),
    .B(\g_telemetry.u_reg_file.wd_mark[14] ),
    .Y(_0929_));
 sky130_fd_sc_hd__a21boi_0 _3418_ (.A1(_0885_),
    .A2(_0927_),
    .B1_N(_0929_),
    .Y(_0930_));
 sky130_fd_sc_hd__xnor2_1 _3419_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[15] ),
    .B(\g_telemetry.u_reg_file.wd_mark[15] ),
    .Y(_0931_));
 sky130_fd_sc_hd__clkinv_1 _3420_ (.A(\clean_run_target[2] ),
    .Y(_0690_));
 sky130_fd_sc_hd__o21a_1 _3421_ (.A1(_0884_),
    .A2(_0930_),
    .B1(_0931_),
    .X(_0932_));
 sky130_fd_sc_hd__nor2_1 _3422_ (.A(_0883_),
    .B(_0932_),
    .Y(_0933_));
 sky130_fd_sc_hd__xnor2_1 _3423_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[16] ),
    .B(\g_telemetry.u_reg_file.wd_mark[16] ),
    .Y(_0934_));
 sky130_fd_sc_hd__o21ai_1 _3424_ (.A1(_0883_),
    .A2(_0932_),
    .B1(_0934_),
    .Y(_0935_));
 sky130_fd_sc_hd__xor2_1 _3425_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[17] ),
    .B(\g_telemetry.u_reg_file.wd_mark[17] ),
    .X(_0936_));
 sky130_fd_sc_hd__a21o_1 _3426_ (.A1(_0882_),
    .A2(_0935_),
    .B1(_0936_),
    .X(_0937_));
 sky130_fd_sc_hd__nand2_1 _3427_ (.A(_0881_),
    .B(_0937_),
    .Y(_0938_));
 sky130_fd_sc_hd__xnor2_1 _3428_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[18] ),
    .B(\g_telemetry.u_reg_file.wd_mark[18] ),
    .Y(_0939_));
 sky130_fd_sc_hd__a21boi_2 _3429_ (.A1(_0881_),
    .A2(_0937_),
    .B1_N(_0939_),
    .Y(_0940_));
 sky130_fd_sc_hd__xnor2_1 _3430_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[19] ),
    .B(\g_telemetry.u_reg_file.wd_mark[19] ),
    .Y(_0941_));
 sky130_fd_sc_hd__inv_1 _3431_ (.A(\u_fault_LED.blink_counter[4] ),
    .Y(_0691_));
 sky130_fd_sc_hd__o21a_1 _3432_ (.A1(_0880_),
    .A2(_0940_),
    .B1(_0941_),
    .X(_0942_));
 sky130_fd_sc_hd__xnor2_1 _3433_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[20] ),
    .B(\g_telemetry.u_reg_file.wd_mark[20] ),
    .Y(_0943_));
 sky130_fd_sc_hd__o21ai_1 _3434_ (.A1(_0879_),
    .A2(_0942_),
    .B1(_0943_),
    .Y(_0944_));
 sky130_fd_sc_hd__xor2_1 _3435_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[21] ),
    .B(\g_telemetry.u_reg_file.wd_mark[21] ),
    .X(_0945_));
 sky130_fd_sc_hd__a21oi_1 _3436_ (.A1(_0878_),
    .A2(_0944_),
    .B1(_0945_),
    .Y(_0946_));
 sky130_fd_sc_hd__xnor2_1 _3437_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[22] ),
    .B(\g_telemetry.u_reg_file.wd_mark[22] ),
    .Y(_0947_));
 sky130_fd_sc_hd__o21a_1 _3438_ (.A1(_0877_),
    .A2(_0946_),
    .B1(_0947_),
    .X(_0948_));
 sky130_fd_sc_hd__xor2_1 _3439_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[23] ),
    .B(\g_telemetry.u_reg_file.wd_mark[23] ),
    .X(_0949_));
 sky130_fd_sc_hd__or3_1 _3440_ (.A(_0876_),
    .B(_0948_),
    .C(_0949_),
    .X(_0950_));
 sky130_fd_sc_hd__nor3_1 _3441_ (.A(_0877_),
    .B(_0946_),
    .C(_0947_),
    .Y(_0951_));
 sky130_fd_sc_hd__inv_1 _3442_ (.A(\u_fault_LED.blink_counter[0] ),
    .Y(_0061_));
 sky130_fd_sc_hd__or2_0 _3443_ (.A(_0948_),
    .B(_0951_),
    .X(_0952_));
 sky130_fd_sc_hd__nand3_1 _3444_ (.A(_0878_),
    .B(_0944_),
    .C(_0945_),
    .Y(_0953_));
 sky130_fd_sc_hd__nand2b_1 _3445_ (.A_N(_0946_),
    .B(_0953_),
    .Y(_0954_));
 sky130_fd_sc_hd__or3_1 _3446_ (.A(_0879_),
    .B(_0942_),
    .C(_0943_),
    .X(_0955_));
 sky130_fd_sc_hd__nand2_1 _3447_ (.A(_0944_),
    .B(_0955_),
    .Y(_0956_));
 sky130_fd_sc_hd__nor3_1 _3448_ (.A(_0880_),
    .B(_0940_),
    .C(_0941_),
    .Y(_0957_));
 sky130_fd_sc_hd__nor2_1 _3449_ (.A(_0938_),
    .B(_0939_),
    .Y(_0958_));
 sky130_fd_sc_hd__nor2_1 _3450_ (.A(_0940_),
    .B(_0958_),
    .Y(_0959_));
 sky130_fd_sc_hd__nand3_1 _3451_ (.A(_0882_),
    .B(_0935_),
    .C(_0936_),
    .Y(_0960_));
 sky130_fd_sc_hd__xnor2_1 _3452_ (.A(_0933_),
    .B(_0934_),
    .Y(_0961_));
 sky130_fd_sc_hd__inv_1 _3453_ (.A(\g_timestamp.u_timestamp.prescalar[0] ),
    .Y(_0045_));
 sky130_fd_sc_hd__nor3_1 _3454_ (.A(_0884_),
    .B(_0930_),
    .C(_0931_),
    .Y(_0962_));
 sky130_fd_sc_hd__xnor2_1 _3455_ (.A(_0928_),
    .B(_0929_),
    .Y(_0963_));
 sky130_fd_sc_hd__or3_1 _3456_ (.A(_0886_),
    .B(_0925_),
    .C(_0926_),
    .X(_0964_));
 sky130_fd_sc_hd__nand2_1 _3457_ (.A(_0927_),
    .B(_0964_),
    .Y(_0965_));
 sky130_fd_sc_hd__nor3_1 _3458_ (.A(_0887_),
    .B(_0923_),
    .C(_0924_),
    .Y(_0966_));
 sky130_fd_sc_hd__and3_1 _3459_ (.A(_0888_),
    .B(_0921_),
    .C(_0922_),
    .X(_0967_));
 sky130_fd_sc_hd__xor2_1 _3460_ (.A(_0919_),
    .B(_0920_),
    .X(_0968_));
 sky130_fd_sc_hd__nand3_1 _3461_ (.A(_0894_),
    .B(_0908_),
    .C(_0909_),
    .Y(_0969_));
 sky130_fd_sc_hd__xnor2_1 _3462_ (.A(_0906_),
    .B(_0907_),
    .Y(_0970_));
 sky130_fd_sc_hd__and3_1 _3463_ (.A(_0896_),
    .B(_0903_),
    .C(_0904_),
    .X(_0971_));
 sky130_fd_sc_hd__nor2b_4 _3464_ (.A(\g_telemetry.u_spi_slave.sck_d ),
    .B_N(\g_spi_filt.u_sck_filt.flag_out ),
    .Y(_0692_));
 sky130_fd_sc_hd__xor2_1 _3465_ (.A(_0897_),
    .B(_0902_),
    .X(_0972_));
 sky130_fd_sc_hd__o21ai_0 _3466_ (.A1(_0905_),
    .A2(_0971_),
    .B1(_0972_),
    .Y(_0973_));
 sky130_fd_sc_hd__a211oi_1 _3467_ (.A1(_0910_),
    .A2(_0969_),
    .B1(_0970_),
    .C1(_0973_),
    .Y(_0974_));
 sky130_fd_sc_hd__nor2_1 _3468_ (.A(_0911_),
    .B(_0912_),
    .Y(_0975_));
 sky130_fd_sc_hd__a2111oi_1 _3469_ (.A1(_0892_),
    .A2(_0914_),
    .B1(_0974_),
    .C1(_0975_),
    .D1(_0913_),
    .Y(_0976_));
 sky130_fd_sc_hd__o211ai_1 _3470_ (.A1(_0916_),
    .A2(_0917_),
    .B1(_0976_),
    .C1(_0915_),
    .Y(_0977_));
 sky130_fd_sc_hd__o22ai_1 _3471_ (.A1(_0923_),
    .A2(_0967_),
    .B1(_0977_),
    .B2(_0918_),
    .Y(_0978_));
 sky130_fd_sc_hd__nor2_1 _3472_ (.A(_0925_),
    .B(_0966_),
    .Y(_0979_));
 sky130_fd_sc_hd__o21ai_1 _3473_ (.A1(_0968_),
    .A2(_0978_),
    .B1(_0979_),
    .Y(_0980_));
 sky130_fd_sc_hd__o2111ai_4 _3474_ (.A1(_0932_),
    .A2(_0962_),
    .B1(_0963_),
    .C1(_0965_),
    .D1(_0980_),
    .Y(_0981_));
 sky130_fd_sc_hd__nand2b_4 _3475_ (.A_N(\g_telemetry.u_spi_slave.sck_d ),
    .B(\g_spi_filt.u_sck_filt.flag_out ),
    .Y(_0693_));
 sky130_fd_sc_hd__a2111oi_2 _3476_ (.A1(_0937_),
    .A2(_0960_),
    .B1(_0961_),
    .C1(_0981_),
    .D1(_0959_),
    .Y(_0982_));
 sky130_fd_sc_hd__o2111a_1 _3477_ (.A1(_0942_),
    .A2(_0957_),
    .B1(_0982_),
    .C1(_0954_),
    .D1(_0956_),
    .X(_0983_));
 sky130_fd_sc_hd__o21ai_0 _3478_ (.A1(_0876_),
    .A2(_0948_),
    .B1(_0949_),
    .Y(_0984_));
 sky130_fd_sc_hd__a41o_1 _3479_ (.A1(_0950_),
    .A2(_0952_),
    .A3(_0983_),
    .A4(_0984_),
    .B1(\g_telemetry.u_reg_file.spi_enable ),
    .X(_0985_));
 sky130_fd_sc_hd__a21oi_1 _3480_ (.A1(_0667_),
    .A2(_0985_),
    .B1(_0875_),
    .Y(_0624_));
 sky130_fd_sc_hd__mux2_1 _3481_ (.A0(\g_telemetry.u_reg_file.wdata[7] ),
    .A1(\g_telemetry.u_reg_file.temp_clean_2[7] ),
    .S(_0823_),
    .X(_0623_));
 sky130_fd_sc_hd__or4b_2 _3482_ (.A(\g_telemetry.u_reg_file.addr[4] ),
    .B(\g_telemetry.u_reg_file.addr[5] ),
    .C(_0712_),
    .D_N(\g_telemetry.u_reg_file.addr[6] ),
    .X(_0986_));
 sky130_fd_sc_hd__nor2_2 _3483_ (.A(_0776_),
    .B(_0986_),
    .Y(_0987_));
 sky130_fd_sc_hd__o211ai_1 _3484_ (.A1(\g_telemetry.u_reg_file.wdata[0] ),
    .A2(\g_telemetry.u_reg_file.disable_armed ),
    .B1(_0987_),
    .C1(\g_telemetry.u_reg_file.wr_en ),
    .Y(_0988_));
 sky130_fd_sc_hd__o21ai_0 _3485_ (.A1(\g_telemetry.u_reg_file.wdata[0] ),
    .A2(_0988_),
    .B1(_0779_),
    .Y(_0989_));
 sky130_fd_sc_hd__nor2b_2 _3486_ (.A(\g_spi_filt.u_sck_filt.flag_out ),
    .B_N(\g_telemetry.u_spi_slave.sck_d ),
    .Y(_0694_));
 sky130_fd_sc_hd__a21oi_1 _3487_ (.A1(_0668_),
    .A2(_0988_),
    .B1(_0989_),
    .Y(_0622_));
 sky130_fd_sc_hd__a21boi_0 _3488_ (.A1(_0665_),
    .A2(_0988_),
    .B1_N(_0779_),
    .Y(_0621_));
 sky130_fd_sc_hd__nor2_8 _3489_ (.A(_0712_),
    .B(_0777_),
    .Y(_0990_));
 sky130_fd_sc_hd__nand2_4 _3490_ (.A(_0780_),
    .B(_0990_),
    .Y(_0991_));
 sky130_fd_sc_hd__mux2_1 _3491_ (.A0(\g_telemetry.u_reg_file.wdata[7] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_ss[7] ),
    .S(_0991_),
    .X(_0620_));
 sky130_fd_sc_hd__and3b_1 _3492_ (.A_N(\g_telemetry.u_spi_slave.spi_state[2] ),
    .B(\g_telemetry.u_spi_slave.spi_state[1] ),
    .C(\g_telemetry.u_spi_slave.spi_state[0] ),
    .X(_0992_));
 sky130_fd_sc_hd__nor2b_2 _3493_ (.A(_0706_),
    .B_N(_0992_),
    .Y(_0993_));
 sky130_fd_sc_hd__and2_4 _3494_ (.A(_0694_),
    .B(_0993_),
    .X(_0994_));
 sky130_fd_sc_hd__mux2_1 _3495_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[23] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[23] ),
    .S(_0994_),
    .X(_0619_));
 sky130_fd_sc_hd__nor2_8 _3496_ (.A(_0712_),
    .B(_0783_),
    .Y(_0995_));
 sky130_fd_sc_hd__nor3_2 _3497_ (.A(cs_n_filt),
    .B(_0692_),
    .C(_0694_),
    .Y(_0695_));
 sky130_fd_sc_hd__nand2_4 _3498_ (.A(_0780_),
    .B(_0995_),
    .Y(_0996_));
 sky130_fd_sc_hd__mux2_1 _3499_ (.A0(\g_telemetry.u_reg_file.wdata[7] ),
    .A1(\g_telemetry.u_reg_file.temp_trip_run[7] ),
    .S(_0996_),
    .X(_0618_));
 sky130_fd_sc_hd__nor4_1 _3500_ (.A(\g_telemetry.u_reg_file.addr[6] ),
    .B(\g_telemetry.u_reg_file.addr[4] ),
    .C(\g_telemetry.u_reg_file.addr[5] ),
    .D(_0712_),
    .Y(_0997_));
 sky130_fd_sc_hd__or4_4 _3501_ (.A(\g_telemetry.u_reg_file.addr[6] ),
    .B(\g_telemetry.u_reg_file.addr[4] ),
    .C(\g_telemetry.u_reg_file.addr[5] ),
    .D(_0712_),
    .X(_0998_));
 sky130_fd_sc_hd__nor2_4 _3502_ (.A(_0794_),
    .B(_0998_),
    .Y(_0999_));
 sky130_fd_sc_hd__nand2_4 _3503_ (.A(\g_telemetry.u_reg_file.wr_en ),
    .B(_0999_),
    .Y(_1000_));
 sky130_fd_sc_hd__mux2_1 _3504_ (.A0(\g_telemetry.u_reg_file.wdata[7] ),
    .A1(\g_telemetry.u_reg_file.scratch_r[7] ),
    .S(_1000_),
    .X(_0617_));
 sky130_fd_sc_hd__nor2b_1 _3505_ (.A(OTP_sync),
    .B_N(OTP_sync_db),
    .Y(_1001_));
 sky130_fd_sc_hd__xnor2_4 _3506_ (.A(OTP_sync),
    .B(OTP_sync_db),
    .Y(_1002_));
 sky130_fd_sc_hd__and4_1 _3507_ (.A(\u_OTP_sync_db.disagree_counter[3] ),
    .B(\u_OTP_sync_db.disagree_counter[0] ),
    .C(\u_OTP_sync_db.disagree_counter[1] ),
    .D(\u_OTP_sync_db.disagree_counter[2] ),
    .X(_1003_));
 sky130_fd_sc_hd__or3_4 _3508_ (.A(cs_n_filt),
    .B(_0692_),
    .C(_0694_),
    .X(_0696_));
 sky130_fd_sc_hd__o21ai_0 _3509_ (.A1(\u_OTP_sync_db.disagree_counter[7] ),
    .A2(\u_OTP_sync_db.disagree_counter[6] ),
    .B1(OTP_sync),
    .Y(_1004_));
 sky130_fd_sc_hd__nor3_1 _3510_ (.A(\u_OTP_sync_db.disagree_counter[4] ),
    .B(\u_OTP_sync_db.disagree_counter[5] ),
    .C(_1003_),
    .Y(_1005_));
 sky130_fd_sc_hd__a21oi_1 _3511_ (.A1(\u_OTP_sync_db.disagree_counter[7] ),
    .A2(\u_OTP_sync_db.disagree_counter[6] ),
    .B1(OTP_sync),
    .Y(_1006_));
 sky130_fd_sc_hd__o21ai_0 _3512_ (.A1(_1005_),
    .A2(_1006_),
    .B1(_1004_),
    .Y(_1007_));
 sky130_fd_sc_hd__nand4_1 _3513_ (.A(\u_OTP_sync_db.disagree_counter[8] ),
    .B(\u_OTP_sync_db.disagree_counter[9] ),
    .C(\u_OTP_sync_db.disagree_counter[10] ),
    .D(_1007_),
    .Y(_1008_));
 sky130_fd_sc_hd__a211oi_1 _3514_ (.A1(_0661_),
    .A2(\u_OTP_sync_db.disagree_counter[13] ),
    .B1(\u_OTP_sync_db.disagree_counter[11] ),
    .C1(\u_OTP_sync_db.disagree_counter[12] ),
    .Y(_1009_));
 sky130_fd_sc_hd__nand2_1 _3515_ (.A(_1008_),
    .B(_1009_),
    .Y(_1010_));
 sky130_fd_sc_hd__nor3b_1 _3516_ (.A(_0661_),
    .B(OTP_sync_db),
    .C_N(\u_OTP_sync_db.disagree_counter[13] ),
    .Y(_1011_));
 sky130_fd_sc_hd__o21ai_2 _3517_ (.A1(_1001_),
    .A2(_1011_),
    .B1(_1010_),
    .Y(_1012_));
 sky130_fd_sc_hd__and2_1 _3518_ (.A(\u_OTP_sync_db.disagree_counter[0] ),
    .B(_1012_),
    .X(_1013_));
 sky130_fd_sc_hd__inv_1 _3519_ (.A(\g_telemetry.u_pwm_stats.period_counter[5] ),
    .Y(_0663_));
 sky130_fd_sc_hd__and3_1 _3520_ (.A(\g_telemetry.u_spi_slave.idle_counter[2] ),
    .B(\g_telemetry.u_spi_slave.idle_counter[1] ),
    .C(\g_telemetry.u_spi_slave.idle_counter[0] ),
    .X(_0697_));
 sky130_fd_sc_hd__and3_1 _3521_ (.A(\u_OTP_sync_db.disagree_counter[1] ),
    .B(\u_OTP_sync_db.disagree_counter[2] ),
    .C(_1013_),
    .X(_1014_));
 sky130_fd_sc_hd__and2_0 _3522_ (.A(_1003_),
    .B(_1012_),
    .X(_1015_));
 sky130_fd_sc_hd__and3_1 _3523_ (.A(\u_OTP_sync_db.disagree_counter[4] ),
    .B(_1003_),
    .C(_1012_),
    .X(_1016_));
 sky130_fd_sc_hd__and2_1 _3524_ (.A(\u_OTP_sync_db.disagree_counter[5] ),
    .B(_1016_),
    .X(_1017_));
 sky130_fd_sc_hd__and3_1 _3525_ (.A(\u_OTP_sync_db.disagree_counter[7] ),
    .B(\u_OTP_sync_db.disagree_counter[6] ),
    .C(_1017_),
    .X(_1018_));
 sky130_fd_sc_hd__and4_1 _3526_ (.A(\u_OTP_sync_db.disagree_counter[8] ),
    .B(\u_OTP_sync_db.disagree_counter[9] ),
    .C(\u_OTP_sync_db.disagree_counter[10] ),
    .D(_1018_),
    .X(_1019_));
 sky130_fd_sc_hd__and2_0 _3527_ (.A(\u_OTP_sync_db.disagree_counter[11] ),
    .B(_1019_),
    .X(_1020_));
 sky130_fd_sc_hd__and2_0 _3528_ (.A(\u_OTP_sync_db.disagree_counter[8] ),
    .B(_1018_),
    .X(_1021_));
 sky130_fd_sc_hd__a21oi_1 _3529_ (.A1(\u_OTP_sync_db.disagree_counter[12] ),
    .A2(_1020_),
    .B1(\u_OTP_sync_db.disagree_counter[13] ),
    .Y(_1022_));
 sky130_fd_sc_hd__nor2_1 _3530_ (.A(_1002_),
    .B(_1022_),
    .Y(_0616_));
 sky130_fd_sc_hd__a21oi_1 _3531_ (.A1(\g_telemetry.u_spi_slave.idle_counter[1] ),
    .A2(\g_telemetry.u_spi_slave.idle_counter[0] ),
    .B1(\g_telemetry.u_spi_slave.idle_counter[2] ),
    .Y(_0698_));
 sky130_fd_sc_hd__a22o_1 _3532_ (.A1(_1010_),
    .A2(_1011_),
    .B1(_1012_),
    .B2(OTP_sync_db),
    .X(_0615_));
 sky130_fd_sc_hd__a21oi_1 _3533_ (.A1(\g_telemetry.u_reg_file.en_pending ),
    .A2(\g_telemetry.u_reg_file.integrity_OK ),
    .B1(\g_telemetry.u_reg_file.spi_enable ),
    .Y(_1023_));
 sky130_fd_sc_hd__o221ai_1 _3534_ (.A1(_0664_),
    .A2(en_from_switch_sync_db_d),
    .B1(_0875_),
    .B2(_1023_),
    .C1(_0985_),
    .Y(_0614_));
 sky130_fd_sc_hd__nand2_1 _3535_ (.A(\g_spi_filt.u_cs_filt.disagree_counter[0] ),
    .B(\g_spi_filt.u_cs_filt.disagree_counter[1] ),
    .Y(_1024_));
 sky130_fd_sc_hd__a31oi_2 _3536_ (.A1(\g_spi_filt.u_cs_filt.disagree_counter[0] ),
    .A2(\g_spi_filt.u_cs_filt.disagree_counter[1] ),
    .A3(\g_spi_filt.u_cs_filt.disagree_counter[2] ),
    .B1(\g_spi_filt.u_cs_filt.disagree_counter[3] ),
    .Y(_1025_));
 sky130_fd_sc_hd__mux2_1 _3537_ (.A0(cs_n_sync),
    .A1(cs_n_filt),
    .S(_1025_),
    .X(_0613_));
 sky130_fd_sc_hd__a21oi_1 _3538_ (.A1(_0704_),
    .A2(_0756_),
    .B1(\fault_reg[0] ),
    .Y(_1026_));
 sky130_fd_sc_hd__nor2_1 _3539_ (.A(_0716_),
    .B(_1026_),
    .Y(_0612_));
 sky130_fd_sc_hd__xnor2_4 _3540_ (.A(UVLO_sync_db),
    .B(UVLO_sync),
    .Y(_1027_));
 sky130_fd_sc_hd__nand2_1 _3541_ (.A(\u_UVLO_sync_db.disagree_counter[0] ),
    .B(\u_UVLO_sync_db.disagree_counter[1] ),
    .Y(_1028_));
 sky130_fd_sc_hd__nor3_1 _3542_ (.A(_0696_),
    .B(_0697_),
    .C(_0698_),
    .Y(_0007_));
 sky130_fd_sc_hd__and3_1 _3543_ (.A(\u_UVLO_sync_db.disagree_counter[0] ),
    .B(\u_UVLO_sync_db.disagree_counter[1] ),
    .C(\u_UVLO_sync_db.disagree_counter[2] ),
    .X(_1029_));
 sky130_fd_sc_hd__and2_0 _3544_ (.A(\u_UVLO_sync_db.disagree_counter[3] ),
    .B(_1029_),
    .X(_1030_));
 sky130_fd_sc_hd__nand2_1 _3545_ (.A(\u_UVLO_sync_db.disagree_counter[4] ),
    .B(_1030_),
    .Y(_1031_));
 sky130_fd_sc_hd__nand3_1 _3546_ (.A(\u_UVLO_sync_db.disagree_counter[9] ),
    .B(\u_UVLO_sync_db.disagree_counter[8] ),
    .C(\u_UVLO_sync_db.disagree_counter[10] ),
    .Y(_1032_));
 sky130_fd_sc_hd__o21ai_0 _3547_ (.A1(\u_UVLO_sync_db.disagree_counter[7] ),
    .A2(\u_UVLO_sync_db.disagree_counter[6] ),
    .B1(UVLO_sync),
    .Y(_1033_));
 sky130_fd_sc_hd__nor3_1 _3548_ (.A(\u_UVLO_sync_db.disagree_counter[5] ),
    .B(\u_UVLO_sync_db.disagree_counter[4] ),
    .C(_1030_),
    .Y(_1034_));
 sky130_fd_sc_hd__a21oi_1 _3549_ (.A1(\u_UVLO_sync_db.disagree_counter[7] ),
    .A2(\u_UVLO_sync_db.disagree_counter[6] ),
    .B1(UVLO_sync),
    .Y(_1035_));
 sky130_fd_sc_hd__a211oi_2 _3550_ (.A1(_1033_),
    .A2(_1034_),
    .B1(_1035_),
    .C1(_1032_),
    .Y(_1036_));
 sky130_fd_sc_hd__a2111oi_4 _3551_ (.A1(\u_UVLO_sync_db.disagree_counter[13] ),
    .A2(_0671_),
    .B1(\u_UVLO_sync_db.disagree_counter[11] ),
    .C1(\u_UVLO_sync_db.disagree_counter[12] ),
    .D1(_1036_),
    .Y(_1037_));
 sky130_fd_sc_hd__a21oi_4 _3552_ (.A1(_0669_),
    .A2(UVLO_sync),
    .B1(_1037_),
    .Y(_1038_));
 sky130_fd_sc_hd__nor2b_4 _3553_ (.A(\g_telemetry.u_reg_file.sup_state[1] ),
    .B_N(\g_telemetry.u_reg_file.sup_state[0] ),
    .Y(_0699_));
 sky130_fd_sc_hd__nor2_1 _3554_ (.A(_1031_),
    .B(_1038_),
    .Y(_1039_));
 sky130_fd_sc_hd__and3_1 _3555_ (.A(\u_UVLO_sync_db.disagree_counter[8] ),
    .B(\u_UVLO_sync_db.disagree_counter[7] ),
    .C(\u_UVLO_sync_db.disagree_counter[6] ),
    .X(_1040_));
 sky130_fd_sc_hd__nand3_1 _3556_ (.A(\u_UVLO_sync_db.disagree_counter[9] ),
    .B(\u_UVLO_sync_db.disagree_counter[11] ),
    .C(\u_UVLO_sync_db.disagree_counter[10] ),
    .Y(_1041_));
 sky130_fd_sc_hd__nand4_1 _3557_ (.A(\u_UVLO_sync_db.disagree_counter[5] ),
    .B(\u_UVLO_sync_db.disagree_counter[4] ),
    .C(_1030_),
    .D(_1040_),
    .Y(_1042_));
 sky130_fd_sc_hd__nor2_1 _3558_ (.A(_1041_),
    .B(_1042_),
    .Y(_1043_));
 sky130_fd_sc_hd__nand2b_2 _3559_ (.A_N(_1027_),
    .B(_1038_),
    .Y(_1044_));
 sky130_fd_sc_hd__nand3_1 _3560_ (.A(\u_UVLO_sync_db.disagree_counter[12] ),
    .B(_1043_),
    .C(_1044_),
    .Y(_1045_));
 sky130_fd_sc_hd__a21oi_1 _3561_ (.A1(_0669_),
    .A2(_1045_),
    .B1(_1027_),
    .Y(_0611_));
 sky130_fd_sc_hd__o22a_1 _3562_ (.A1(UVLO_sync),
    .A2(_1037_),
    .B1(_1038_),
    .B2(UVLO_sync_db),
    .X(_0610_));
 sky130_fd_sc_hd__nand2_8 _3563_ (.A(\g_telemetry.u_reg_file.sup_state[0] ),
    .B(\g_telemetry.u_reg_file.sup_state[1] ),
    .Y(_1046_));
 sky130_fd_sc_hd__nand2b_4 _3564_ (.A_N(\g_telemetry.u_reg_file.sup_state[1] ),
    .B(\g_telemetry.u_reg_file.sup_state[0] ),
    .Y(_0700_));
 sky130_fd_sc_hd__clkinv_4 _3565_ (.A(_1046_),
    .Y(hiccup_active));
 sky130_fd_sc_hd__xnor2_4 _3566_ (.A(\g_telemetry.u_fault_cause.latch_state ),
    .B(latch_stat_sync),
    .Y(_1047_));
 sky130_fd_sc_hd__inv_1 _3567_ (.A(_1047_),
    .Y(_1048_));
 sky130_fd_sc_hd__nand2_1 _3568_ (.A(\u_latch_stat_sync_db.disagree_counter[0] ),
    .B(\u_latch_stat_sync_db.disagree_counter[1] ),
    .Y(_1049_));
 sky130_fd_sc_hd__nand2_1 _3569_ (.A(\u_latch_stat_sync_db.disagree_counter[3] ),
    .B(\u_latch_stat_sync_db.disagree_counter[2] ),
    .Y(_1050_));
 sky130_fd_sc_hd__nor2_1 _3570_ (.A(_1049_),
    .B(_1050_),
    .Y(_1051_));
 sky130_fd_sc_hd__nand3_1 _3571_ (.A(\u_latch_stat_sync_db.disagree_counter[9] ),
    .B(\u_latch_stat_sync_db.disagree_counter[8] ),
    .C(\u_latch_stat_sync_db.disagree_counter[10] ),
    .Y(_1052_));
 sky130_fd_sc_hd__o21ai_0 _3572_ (.A1(\u_latch_stat_sync_db.disagree_counter[6] ),
    .A2(\u_latch_stat_sync_db.disagree_counter[7] ),
    .B1(latch_stat_sync),
    .Y(_1053_));
 sky130_fd_sc_hd__nor3_1 _3573_ (.A(\u_latch_stat_sync_db.disagree_counter[5] ),
    .B(\u_latch_stat_sync_db.disagree_counter[4] ),
    .C(_1051_),
    .Y(_1054_));
 sky130_fd_sc_hd__a21oi_1 _3574_ (.A1(\u_latch_stat_sync_db.disagree_counter[6] ),
    .A2(\u_latch_stat_sync_db.disagree_counter[7] ),
    .B1(latch_stat_sync),
    .Y(_1055_));
 sky130_fd_sc_hd__nor2b_4 _3575_ (.A(\g_telemetry.u_reg_file.sup_state[0] ),
    .B_N(\g_telemetry.u_reg_file.sup_state[1] ),
    .Y(_0701_));
 sky130_fd_sc_hd__a211oi_1 _3576_ (.A1(_1053_),
    .A2(_1054_),
    .B1(_1055_),
    .C1(_1052_),
    .Y(_1056_));
 sky130_fd_sc_hd__a2111oi_2 _3577_ (.A1(\u_latch_stat_sync_db.disagree_counter[13] ),
    .A2(_0673_),
    .B1(\u_latch_stat_sync_db.disagree_counter[11] ),
    .C1(\u_latch_stat_sync_db.disagree_counter[12] ),
    .D1(_1056_),
    .Y(_1057_));
 sky130_fd_sc_hd__a21oi_2 _3578_ (.A1(_0670_),
    .A2(latch_stat_sync),
    .B1(_1057_),
    .Y(_1058_));
 sky130_fd_sc_hd__nor2_1 _3579_ (.A(_1049_),
    .B(_1058_),
    .Y(_1059_));
 sky130_fd_sc_hd__nor3_1 _3580_ (.A(_1049_),
    .B(_1050_),
    .C(_1058_),
    .Y(_1060_));
 sky130_fd_sc_hd__and2_1 _3581_ (.A(\u_latch_stat_sync_db.disagree_counter[4] ),
    .B(_1060_),
    .X(_1061_));
 sky130_fd_sc_hd__and3_1 _3582_ (.A(\u_latch_stat_sync_db.disagree_counter[5] ),
    .B(\u_latch_stat_sync_db.disagree_counter[6] ),
    .C(_1061_),
    .X(_1062_));
 sky130_fd_sc_hd__and2_0 _3583_ (.A(\u_latch_stat_sync_db.disagree_counter[7] ),
    .B(_1062_),
    .X(_1063_));
 sky130_fd_sc_hd__and3_1 _3584_ (.A(\u_latch_stat_sync_db.disagree_counter[8] ),
    .B(\u_latch_stat_sync_db.disagree_counter[7] ),
    .C(_1062_),
    .X(_1064_));
 sky130_fd_sc_hd__nor2b_1 _3585_ (.A(_1052_),
    .B_N(_1063_),
    .Y(_1065_));
 sky130_fd_sc_hd__nand2b_4 _3586_ (.A_N(\g_telemetry.u_reg_file.sup_state[0] ),
    .B(\g_telemetry.u_reg_file.sup_state[1] ),
    .Y(_0702_));
 sky130_fd_sc_hd__and3_1 _3587_ (.A(\u_latch_stat_sync_db.disagree_counter[11] ),
    .B(\u_latch_stat_sync_db.disagree_counter[12] ),
    .C(_1065_),
    .X(_1066_));
 sky130_fd_sc_hd__nor2_1 _3588_ (.A(\u_latch_stat_sync_db.disagree_counter[13] ),
    .B(_1066_),
    .Y(_1067_));
 sky130_fd_sc_hd__nor2_1 _3589_ (.A(_1047_),
    .B(_1067_),
    .Y(_0609_));
 sky130_fd_sc_hd__o22a_1 _3590_ (.A1(latch_stat_sync),
    .A2(_1057_),
    .B1(_1058_),
    .B2(\g_telemetry.u_fault_cause.latch_state ),
    .X(_0608_));
 sky130_fd_sc_hd__xnor2_1 _3591_ (.A(\g_telemetry.u_spi_slave.idle_counter[1] ),
    .B(\g_telemetry.u_spi_slave.idle_counter[0] ),
    .Y(_1068_));
 sky130_fd_sc_hd__nor2_1 _3592_ (.A(_0696_),
    .B(_1068_),
    .Y(_0006_));
 sky130_fd_sc_hd__nand2_1 _3593_ (.A(\g_telemetry.u_reg_file.temp_dirty[6] ),
    .B(_0779_),
    .Y(_1069_));
 sky130_fd_sc_hd__nand2_1 _3594_ (.A(_0802_),
    .B(_1069_),
    .Y(_0607_));
 sky130_fd_sc_hd__nand2_1 _3595_ (.A(\g_telemetry.u_reg_file.temp_dirty[0] ),
    .B(_0779_),
    .Y(_1070_));
 sky130_fd_sc_hd__nand2_1 _3596_ (.A(_0996_),
    .B(_1070_),
    .Y(_0606_));
 sky130_fd_sc_hd__nor2_8 _3597_ (.A(_0699_),
    .B(_0701_),
    .Y(_0703_));
 sky130_fd_sc_hd__nand2_1 _3598_ (.A(\g_telemetry.u_reg_file.temp_dirty[1] ),
    .B(_0779_),
    .Y(_1071_));
 sky130_fd_sc_hd__nand2_1 _3599_ (.A(_0991_),
    .B(_1071_),
    .Y(_0605_));
 sky130_fd_sc_hd__nand2_1 _3600_ (.A(\g_telemetry.u_reg_file.temp_dirty[5] ),
    .B(_0779_),
    .Y(_1072_));
 sky130_fd_sc_hd__nand2_1 _3601_ (.A(_0815_),
    .B(_1072_),
    .Y(_0604_));
 sky130_fd_sc_hd__nand2_1 _3602_ (.A(\g_telemetry.u_reg_file.temp_dirty[2] ),
    .B(_0779_),
    .Y(_1073_));
 sky130_fd_sc_hd__nand2_1 _3603_ (.A(_0873_),
    .B(_1073_),
    .Y(_0603_));
 sky130_fd_sc_hd__nand2_1 _3604_ (.A(\g_telemetry.u_reg_file.temp_dirty[3] ),
    .B(_0779_),
    .Y(_1074_));
 sky130_fd_sc_hd__nand2_1 _3605_ (.A(_0864_),
    .B(_1074_),
    .Y(_0602_));
 sky130_fd_sc_hd__nor2_2 _3606_ (.A(\u_strike_counter.hiccup_active_d ),
    .B(_1046_),
    .Y(_1075_));
 sky130_fd_sc_hd__xnor2_1 _3607_ (.A(\u_strike_counter.clean_counter[7] ),
    .B(\clean_run_target[7] ),
    .Y(_1076_));
 sky130_fd_sc_hd__nand2_4 _3608_ (.A(_0700_),
    .B(_0702_),
    .Y(_0704_));
 sky130_fd_sc_hd__xor2_1 _3609_ (.A(\u_strike_counter.clean_counter[9] ),
    .B(\clean_run_target[9] ),
    .X(_1077_));
 sky130_fd_sc_hd__xnor2_1 _3610_ (.A(\u_strike_counter.clean_counter[11] ),
    .B(\clean_run_target[11] ),
    .Y(_1078_));
 sky130_fd_sc_hd__xor2_1 _3611_ (.A(\u_strike_counter.clean_counter[15] ),
    .B(\clean_run_target[15] ),
    .X(_1079_));
 sky130_fd_sc_hd__xnor2_1 _3612_ (.A(\u_strike_counter.clean_counter[0] ),
    .B(\clean_run_target[0] ),
    .Y(_1080_));
 sky130_fd_sc_hd__xor2_1 _3613_ (.A(\clean_run_target[17] ),
    .B(\u_strike_counter.clean_counter[17] ),
    .X(_1081_));
 sky130_fd_sc_hd__xor2_1 _3614_ (.A(\u_strike_counter.clean_counter[5] ),
    .B(\clean_run_target[5] ),
    .X(_1082_));
 sky130_fd_sc_hd__xor2_1 _3615_ (.A(\u_strike_counter.clean_counter[16] ),
    .B(\clean_run_target[16] ),
    .X(_1083_));
 sky130_fd_sc_hd__xnor2_1 _3616_ (.A(\u_strike_counter.clean_counter[1] ),
    .B(\clean_run_target[1] ),
    .Y(_1084_));
 sky130_fd_sc_hd__xor2_1 _3617_ (.A(\u_strike_counter.clean_counter[10] ),
    .B(\clean_run_target[10] ),
    .X(_1085_));
 sky130_fd_sc_hd__xor2_1 _3618_ (.A(\clean_run_target[14] ),
    .B(\u_strike_counter.clean_counter[14] ),
    .X(_1086_));
 sky130_fd_sc_hd__a21oi_1 _3619_ (.A1(latch_out),
    .A2(_0704_),
    .B1(\fault_reg[3] ),
    .Y(_0705_));
 sky130_fd_sc_hd__xor2_1 _3620_ (.A(\u_strike_counter.clean_counter[8] ),
    .B(\clean_run_target[8] ),
    .X(_1087_));
 sky130_fd_sc_hd__xnor2_1 _3621_ (.A(\clean_run_target[13] ),
    .B(\u_strike_counter.clean_counter[13] ),
    .Y(_1088_));
 sky130_fd_sc_hd__xor2_1 _3622_ (.A(\u_strike_counter.clean_counter[6] ),
    .B(\clean_run_target[6] ),
    .X(_1089_));
 sky130_fd_sc_hd__xor2_1 _3623_ (.A(\u_strike_counter.clean_counter[3] ),
    .B(\clean_run_target[3] ),
    .X(_1090_));
 sky130_fd_sc_hd__xnor2_1 _3624_ (.A(\clean_run_target[4] ),
    .B(\u_strike_counter.clean_counter[4] ),
    .Y(_1091_));
 sky130_fd_sc_hd__xor2_1 _3625_ (.A(\u_strike_counter.clean_counter[12] ),
    .B(\clean_run_target[12] ),
    .X(_1092_));
 sky130_fd_sc_hd__a21oi_1 _3626_ (.A1(\u_strike_counter.clean_counter[2] ),
    .A2(_0690_),
    .B1(_1092_),
    .Y(_1093_));
 sky130_fd_sc_hd__xor2_1 _3627_ (.A(\clean_run_target[18] ),
    .B(\u_strike_counter.clean_counter[18] ),
    .X(_1094_));
 sky130_fd_sc_hd__nor4_1 _3628_ (.A(_1079_),
    .B(_1086_),
    .C(_1089_),
    .D(_1094_),
    .Y(_1095_));
 sky130_fd_sc_hd__nand4_1 _3629_ (.A(_1078_),
    .B(_1084_),
    .C(_1093_),
    .D(_1095_),
    .Y(_1096_));
 sky130_fd_sc_hd__inv_1 _3630_ (.A(en_from_switch_sync_db),
    .Y(_0664_));
 sky130_fd_sc_hd__nand3_2 _3631_ (.A(\g_telemetry.u_spi_slave.bit_count[2] ),
    .B(\g_telemetry.u_spi_slave.bit_count[1] ),
    .C(\g_telemetry.u_spi_slave.bit_count[0] ),
    .Y(_0706_));
 sky130_fd_sc_hd__nor3_1 _3632_ (.A(_1077_),
    .B(_1087_),
    .C(_1090_),
    .Y(_1097_));
 sky130_fd_sc_hd__o211ai_2 _3633_ (.A1(\u_strike_counter.clean_counter[2] ),
    .A2(_0690_),
    .B1(_1076_),
    .C1(_1097_),
    .Y(_1098_));
 sky130_fd_sc_hd__nor4_1 _3634_ (.A(_1081_),
    .B(_1082_),
    .C(_1083_),
    .D(_1085_),
    .Y(_1099_));
 sky130_fd_sc_hd__nand4_1 _3635_ (.A(_1080_),
    .B(_1088_),
    .C(_1091_),
    .D(_1099_),
    .Y(_1100_));
 sky130_fd_sc_hd__nor3_4 _3636_ (.A(_1096_),
    .B(_1098_),
    .C(_1100_),
    .Y(_1101_));
 sky130_fd_sc_hd__nor2_1 _3637_ (.A(_1075_),
    .B(_1101_),
    .Y(_1102_));
 sky130_fd_sc_hd__xor2_1 _3638_ (.A(\g_telemetry.u_reg_file.strike_level[0] ),
    .B(\g_telemetry.u_reg_file.strike_level[1] ),
    .X(_1103_));
 sky130_fd_sc_hd__a22o_1 _3639_ (.A1(\g_telemetry.u_reg_file.strike_level[1] ),
    .A2(_1102_),
    .B1(_1103_),
    .B2(_1075_),
    .X(_0601_));
 sky130_fd_sc_hd__nand2_1 _3640_ (.A(\g_telemetry.u_spi_slave.rx_byte[6] ),
    .B(_0692_),
    .Y(_1104_));
 sky130_fd_sc_hd__nand2_1 _3641_ (.A(\g_telemetry.u_spi_slave.rx_byte[7] ),
    .B(_0693_),
    .Y(_1105_));
 sky130_fd_sc_hd__nor2_4 _3642_ (.A(_0693_),
    .B(_0706_),
    .Y(_0707_));
 sky130_fd_sc_hd__nand2_1 _3643_ (.A(_1104_),
    .B(_1105_),
    .Y(_0600_));
 sky130_fd_sc_hd__xnor2_2 _3644_ (.A(\g_spi_filt.u_sck_filt.flag_out ),
    .B(\g_spi_filt.u_sck_filt.flag_in ),
    .Y(_1106_));
 sky130_fd_sc_hd__nor2b_1 _3645_ (.A(_1106_),
    .B_N(\g_spi_filt.u_sck_filt.disagree_counter[3] ),
    .Y(_0599_));
 sky130_fd_sc_hd__nand2_1 _3646_ (.A(\g_spi_filt.u_sck_filt.disagree_counter[1] ),
    .B(\g_spi_filt.u_sck_filt.disagree_counter[0] ),
    .Y(_1107_));
 sky130_fd_sc_hd__a31oi_1 _3647_ (.A1(\g_spi_filt.u_sck_filt.disagree_counter[1] ),
    .A2(\g_spi_filt.u_sck_filt.disagree_counter[0] ),
    .A3(\g_spi_filt.u_sck_filt.disagree_counter[2] ),
    .B1(\g_spi_filt.u_sck_filt.disagree_counter[3] ),
    .Y(_1108_));
 sky130_fd_sc_hd__mux2_1 _3648_ (.A0(\g_spi_filt.u_sck_filt.flag_in ),
    .A1(\g_spi_filt.u_sck_filt.flag_out ),
    .S(_1108_),
    .X(_0598_));
 sky130_fd_sc_hd__nor3b_1 _3649_ (.A(\g_telemetry.u_spi_slave.spi_state[1] ),
    .B(\g_telemetry.u_spi_slave.spi_state[2] ),
    .C_N(\g_telemetry.u_spi_slave.spi_state[0] ),
    .Y(_1109_));
 sky130_fd_sc_hd__or3b_2 _3650_ (.A(\g_telemetry.u_spi_slave.spi_state[1] ),
    .B(\g_telemetry.u_spi_slave.spi_state[2] ),
    .C_N(\g_telemetry.u_spi_slave.spi_state[0] ),
    .X(_1110_));
 sky130_fd_sc_hd__nor2b_4 _3651_ (.A(cs_n_filt),
    .B_N(\g_telemetry.u_spi_slave.cs_n_d ),
    .Y(_1111_));
 sky130_fd_sc_hd__nand2b_2 _3652_ (.A_N(cs_n_filt),
    .B(\g_telemetry.u_spi_slave.cs_n_d ),
    .Y(_1112_));
 sky130_fd_sc_hd__or2_1 _3653_ (.A(_0693_),
    .B(_0706_),
    .X(_0708_));
 sky130_fd_sc_hd__nor2_4 _3654_ (.A(_0693_),
    .B(_1111_),
    .Y(_1113_));
 sky130_fd_sc_hd__nor2_1 _3655_ (.A(_0708_),
    .B(_1111_),
    .Y(_1114_));
 sky130_fd_sc_hd__nand2_4 _3656_ (.A(_0707_),
    .B(_1112_),
    .Y(_1115_));
 sky130_fd_sc_hd__nor2_4 _3657_ (.A(_1110_),
    .B(_1115_),
    .Y(_1116_));
 sky130_fd_sc_hd__nand2_1 _3658_ (.A(_1109_),
    .B(_1114_),
    .Y(_1117_));
 sky130_fd_sc_hd__nand2_1 _3659_ (.A(\g_telemetry.u_spi_slave.rx_byte[7] ),
    .B(_1116_),
    .Y(_1118_));
 sky130_fd_sc_hd__nand2_1 _3660_ (.A(\g_telemetry.u_spi_slave.rw ),
    .B(_1117_),
    .Y(_1119_));
 sky130_fd_sc_hd__nand2_1 _3661_ (.A(_1118_),
    .B(_1119_),
    .Y(_0597_));
 sky130_fd_sc_hd__nor2_1 _3662_ (.A(\u_fault_LED.blink_counter[5] ),
    .B(\u_fault_LED.blink_counter[4] ),
    .Y(_1120_));
 sky130_fd_sc_hd__and4b_1 _3663_ (.A_N(\u_fault_LED.blink_counter[8] ),
    .B(\u_fault_LED.blink_counter[7] ),
    .C(\u_fault_LED.blink_counter[6] ),
    .D(\u_fault_LED.blink_counter[9] ),
    .X(_1121_));
 sky130_fd_sc_hd__nor2_2 _3664_ (.A(\g_telemetry.u_reg_file.addr[1] ),
    .B(\g_telemetry.u_reg_file.addr[0] ),
    .Y(_0709_));
 sky130_fd_sc_hd__nor4b_1 _3665_ (.A(\u_fault_LED.blink_counter[13] ),
    .B(\u_fault_LED.blink_counter[11] ),
    .C(\u_fault_LED.blink_counter[10] ),
    .D_N(\u_fault_LED.blink_counter[12] ),
    .Y(_1122_));
 sky130_fd_sc_hd__nand4_1 _3666_ (.A(\u_fault_LED.blink_counter[20] ),
    .B(_1120_),
    .C(_1121_),
    .D(_1122_),
    .Y(_1123_));
 sky130_fd_sc_hd__nand2_1 _3667_ (.A(\u_fault_LED.blink_counter[1] ),
    .B(\u_fault_LED.blink_counter[0] ),
    .Y(_1124_));
 sky130_fd_sc_hd__nand3_1 _3668_ (.A(\u_fault_LED.blink_counter[2] ),
    .B(\u_fault_LED.blink_counter[1] ),
    .C(\u_fault_LED.blink_counter[0] ),
    .Y(_1125_));
 sky130_fd_sc_hd__nand4_2 _3669_ (.A(\u_fault_LED.blink_counter[3] ),
    .B(\u_fault_LED.blink_counter[2] ),
    .C(\u_fault_LED.blink_counter[1] ),
    .D(\u_fault_LED.blink_counter[0] ),
    .Y(_1126_));
 sky130_fd_sc_hd__nor2_1 _3670_ (.A(\u_fault_LED.blink_counter[19] ),
    .B(\u_fault_LED.blink_counter[18] ),
    .Y(_1127_));
 sky130_fd_sc_hd__nor2_1 _3671_ (.A(\u_fault_LED.blink_counter[15] ),
    .B(\u_fault_LED.blink_counter[14] ),
    .Y(_1128_));
 sky130_fd_sc_hd__nand4_1 _3672_ (.A(\u_fault_LED.blink_counter[17] ),
    .B(\u_fault_LED.blink_counter[16] ),
    .C(_1127_),
    .D(_1128_),
    .Y(_1129_));
 sky130_fd_sc_hd__nor3_4 _3673_ (.A(_1123_),
    .B(_1126_),
    .C(_1129_),
    .Y(_1130_));
 sky130_fd_sc_hd__xor2_1 _3674_ (.A(\u_fault_LED.blink ),
    .B(_1130_),
    .X(_0596_));
 sky130_fd_sc_hd__or2_4 _3675_ (.A(\g_telemetry.u_reg_file.addr[1] ),
    .B(\g_telemetry.u_reg_file.addr[0] ),
    .X(_0710_));
 sky130_fd_sc_hd__or3b_4 _3676_ (.A(\g_telemetry.u_spi_slave.spi_state[0] ),
    .B(\g_telemetry.u_spi_slave.spi_state[2] ),
    .C_N(\g_telemetry.u_spi_slave.spi_state[1] ),
    .X(_1131_));
 sky130_fd_sc_hd__nor2_8 _3677_ (.A(_1115_),
    .B(_1131_),
    .Y(_1132_));
 sky130_fd_sc_hd__and3_4 _3678_ (.A(\g_telemetry.u_spi_slave.held_valid ),
    .B(_1110_),
    .C(_1132_),
    .X(_0044_));
 sky130_fd_sc_hd__mux2_1 _3679_ (.A0(\g_telemetry.u_reg_file.wdata[7] ),
    .A1(\g_telemetry.u_spi_slave.held_data[7] ),
    .S(_0044_),
    .X(_0595_));
 sky130_fd_sc_hd__and3_1 _3680_ (.A(\g_telemetry.u_spi_slave.byte_count[1] ),
    .B(\g_telemetry.u_spi_slave.byte_count[0] ),
    .C(\g_telemetry.u_spi_slave.byte_count[2] ),
    .X(_1133_));
 sky130_fd_sc_hd__a21oi_1 _3681_ (.A1(_0707_),
    .A2(_1133_),
    .B1(\g_telemetry.u_spi_slave.byte_count[3] ),
    .Y(_1134_));
 sky130_fd_sc_hd__nor2_1 _3682_ (.A(_1111_),
    .B(_1134_),
    .Y(_0594_));
 sky130_fd_sc_hd__nand2_1 _3683_ (.A(\g_telemetry.u_reg_file.temp_dirty[9] ),
    .B(_0779_),
    .Y(_1135_));
 sky130_fd_sc_hd__nand2_1 _3684_ (.A(_0781_),
    .B(_1135_),
    .Y(_0593_));
 sky130_fd_sc_hd__nor2_4 _3685_ (.A(_0692_),
    .B(_1111_),
    .Y(_1136_));
 sky130_fd_sc_hd__nor2_1 _3686_ (.A(\g_telemetry.u_reg_file.addr[3] ),
    .B(\g_telemetry.u_reg_file.addr[2] ),
    .Y(_0711_));
 sky130_fd_sc_hd__a22o_1 _3687_ (.A1(\g_telemetry.u_spi_slave.crc[6] ),
    .A2(_1113_),
    .B1(_1136_),
    .B2(\g_telemetry.u_spi_slave.crc[7] ),
    .X(_0592_));
 sky130_fd_sc_hd__a31oi_1 _3688_ (.A1(\g_telemetry.u_spi_slave.bit_count[1] ),
    .A2(\g_telemetry.u_spi_slave.bit_count[0] ),
    .A3(_0692_),
    .B1(\g_telemetry.u_spi_slave.bit_count[2] ),
    .Y(_1137_));
 sky130_fd_sc_hd__nor3_1 _3689_ (.A(_0707_),
    .B(_1111_),
    .C(_1137_),
    .Y(_0591_));
 sky130_fd_sc_hd__o21a_2 _3690_ (.A1(_0715_),
    .A2(_0993_),
    .B1(_0694_),
    .X(_1138_));
 sky130_fd_sc_hd__o21ai_4 _3691_ (.A1(_0715_),
    .A2(_0993_),
    .B1(_0694_),
    .Y(_1139_));
 sky130_fd_sc_hd__nor3_2 _3692_ (.A(\g_telemetry.u_spi_slave.bit_count[2] ),
    .B(\g_telemetry.u_spi_slave.bit_count[1] ),
    .C(\g_telemetry.u_spi_slave.bit_count[0] ),
    .Y(_1140_));
 sky130_fd_sc_hd__nor2_4 _3693_ (.A(_0993_),
    .B(_1140_),
    .Y(_1141_));
 sky130_fd_sc_hd__or4_1 _3694_ (.A(_0714_),
    .B(_0784_),
    .C(_0797_),
    .D(_0846_),
    .X(_1142_));
 sky130_fd_sc_hd__nor3b_4 _3695_ (.A(\g_telemetry.u_reg_file.addr[6] ),
    .B(\g_telemetry.u_reg_file.addr[5] ),
    .C_N(\g_telemetry.u_reg_file.addr[4] ),
    .Y(_1143_));
 sky130_fd_sc_hd__or3b_4 _3696_ (.A(\g_telemetry.u_reg_file.addr[6] ),
    .B(\g_telemetry.u_reg_file.addr[5] ),
    .C_N(\g_telemetry.u_reg_file.addr[4] ),
    .X(_1144_));
 sky130_fd_sc_hd__or2_4 _3697_ (.A(\g_telemetry.u_reg_file.addr[3] ),
    .B(\g_telemetry.u_reg_file.addr[2] ),
    .X(_0712_));
 sky130_fd_sc_hd__nand3_4 _3698_ (.A(\g_telemetry.u_reg_file.addr[3] ),
    .B(\g_telemetry.u_reg_file.addr[2] ),
    .C(_1143_),
    .Y(_1145_));
 sky130_fd_sc_hd__nand4_1 _3699_ (.A(\g_telemetry.u_reg_file.addr[3] ),
    .B(\g_telemetry.u_reg_file.addr[2] ),
    .C(_0794_),
    .D(_1143_),
    .Y(_1146_));
 sky130_fd_sc_hd__nor2_1 _3700_ (.A(_0863_),
    .B(_0995_),
    .Y(_1147_));
 sky130_fd_sc_hd__nand2b_4 _3701_ (.A_N(_0773_),
    .B(_1143_),
    .Y(_1148_));
 sky130_fd_sc_hd__nor2_1 _3702_ (.A(_0712_),
    .B(_1144_),
    .Y(_1149_));
 sky130_fd_sc_hd__nand2_4 _3703_ (.A(_0711_),
    .B(_1143_),
    .Y(_1150_));
 sky130_fd_sc_hd__nor2_4 _3704_ (.A(_0710_),
    .B(_1150_),
    .Y(_1151_));
 sky130_fd_sc_hd__o2111ai_1 _3705_ (.A1(_0710_),
    .A2(_1150_),
    .B1(_1148_),
    .C1(_1147_),
    .D1(_1146_),
    .Y(_1152_));
 sky130_fd_sc_hd__nor4_1 _3706_ (.A(_0778_),
    .B(_0801_),
    .C(_1142_),
    .D(_1152_),
    .Y(_1153_));
 sky130_fd_sc_hd__nor3_1 _3707_ (.A(\g_telemetry.u_reg_file.addr[3] ),
    .B(_0776_),
    .C(_1144_),
    .Y(_1154_));
 sky130_fd_sc_hd__nand3_1 _3708_ (.A(\g_telemetry.u_reg_file.addr[5] ),
    .B(_0709_),
    .C(_0711_),
    .Y(_0713_));
 sky130_fd_sc_hd__a21oi_1 _3709_ (.A1(_0799_),
    .A2(_0997_),
    .B1(_1154_),
    .Y(_1155_));
 sky130_fd_sc_hd__and2_1 _3710_ (.A(\g_telemetry.u_reg_file.addr[3] ),
    .B(_0796_),
    .X(_1156_));
 sky130_fd_sc_hd__nand2_1 _3711_ (.A(\g_telemetry.u_reg_file.addr[3] ),
    .B(_0796_),
    .Y(_1157_));
 sky130_fd_sc_hd__nor4b_2 _3712_ (.A(\g_telemetry.u_reg_file.addr[4] ),
    .B(\g_telemetry.u_reg_file.addr[5] ),
    .C(_1157_),
    .D_N(\g_telemetry.u_reg_file.addr[6] ),
    .Y(_1158_));
 sky130_fd_sc_hd__nand2b_1 _3713_ (.A_N(_0795_),
    .B(_1143_),
    .Y(_1159_));
 sky130_fd_sc_hd__nor3_4 _3714_ (.A(_0795_),
    .B(_0799_),
    .C(_1144_),
    .Y(_1160_));
 sky130_fd_sc_hd__nor2_4 _3715_ (.A(_0710_),
    .B(_1159_),
    .Y(_1161_));
 sky130_fd_sc_hd__nor3_1 _3716_ (.A(_1158_),
    .B(_1160_),
    .C(_1161_),
    .Y(_1162_));
 sky130_fd_sc_hd__nor2_2 _3717_ (.A(\g_telemetry.u_reg_file.addr[0] ),
    .B(_0998_),
    .Y(_1163_));
 sky130_fd_sc_hd__nor2_1 _3718_ (.A(_0799_),
    .B(_0998_),
    .Y(_1164_));
 sky130_fd_sc_hd__nor3_4 _3719_ (.A(\g_telemetry.u_reg_file.addr[6] ),
    .B(\g_telemetry.u_reg_file.addr[4] ),
    .C(_0713_),
    .Y(_0714_));
 sky130_fd_sc_hd__nor2_4 _3720_ (.A(_1144_),
    .B(_1157_),
    .Y(_1165_));
 sky130_fd_sc_hd__nor2_1 _3721_ (.A(_0710_),
    .B(_0986_),
    .Y(_1166_));
 sky130_fd_sc_hd__nor2_1 _3722_ (.A(\g_telemetry.u_reg_file.addr[1] ),
    .B(_0986_),
    .Y(_1167_));
 sky130_fd_sc_hd__a2111oi_0 _3723_ (.A1(\g_telemetry.u_reg_file.addr[1] ),
    .A2(_1149_),
    .B1(_1164_),
    .C1(_1165_),
    .D1(_1167_),
    .Y(_1168_));
 sky130_fd_sc_hd__nor4_1 _3724_ (.A(_0814_),
    .B(_0822_),
    .C(_0872_),
    .D(_0990_),
    .Y(_1169_));
 sky130_fd_sc_hd__and4_1 _3725_ (.A(_1155_),
    .B(_1162_),
    .C(_1168_),
    .D(_1169_),
    .X(_1170_));
 sky130_fd_sc_hd__nor2_2 _3726_ (.A(_0794_),
    .B(_1150_),
    .Y(_1171_));
 sky130_fd_sc_hd__nor2_1 _3727_ (.A(_0799_),
    .B(_1150_),
    .Y(_1172_));
 sky130_fd_sc_hd__nor2_4 _3728_ (.A(_0710_),
    .B(_1148_),
    .Y(_1173_));
 sky130_fd_sc_hd__nor2_4 _3729_ (.A(_0776_),
    .B(_1150_),
    .Y(_1174_));
 sky130_fd_sc_hd__nor3b_4 _3730_ (.A(\g_telemetry.u_spi_slave.spi_state[0] ),
    .B(\g_telemetry.u_spi_slave.spi_state[1] ),
    .C_N(\g_telemetry.u_spi_slave.spi_state[2] ),
    .Y(_0715_));
 sky130_fd_sc_hd__nor2_2 _3731_ (.A(_0776_),
    .B(_1159_),
    .Y(_1175_));
 sky130_fd_sc_hd__nor2_4 _3732_ (.A(_0794_),
    .B(_1148_),
    .Y(_1176_));
 sky130_fd_sc_hd__a21oi_2 _3733_ (.A1(_1153_),
    .A2(_1170_),
    .B1(_1141_),
    .Y(_1177_));
 sky130_fd_sc_hd__and2_1 _3734_ (.A(_1138_),
    .B(_1177_),
    .X(_1178_));
 sky130_fd_sc_hd__nor2_4 _3735_ (.A(_0799_),
    .B(_1145_),
    .Y(_1179_));
 sky130_fd_sc_hd__nor2_4 _3736_ (.A(_0710_),
    .B(_1145_),
    .Y(_1180_));
 sky130_fd_sc_hd__a22oi_2 _3737_ (.A1(\fault_time[6] ),
    .A2(_1179_),
    .B1(_1180_),
    .B2(\g_telemetry.u_reg_file.bus_err_count[14] ),
    .Y(_1181_));
 sky130_fd_sc_hd__nor2_4 _3738_ (.A(_0776_),
    .B(_1148_),
    .Y(_1182_));
 sky130_fd_sc_hd__mux2_1 _3739_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[14] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[14] ),
    .S(_0994_),
    .X(_0345_));
 sky130_fd_sc_hd__nor2_4 _3740_ (.A(_0799_),
    .B(_1148_),
    .Y(_1183_));
 sky130_fd_sc_hd__inv_1 _3741_ (.A(\g_telemetry.u_reg_file.en_pending ),
    .Y(_0665_));
 sky130_fd_sc_hd__and3_4 _3742_ (.A(_0707_),
    .B(_0714_),
    .C(_0715_),
    .X(_0716_));
 sky130_fd_sc_hd__mux2_1 _3743_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[22] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[22] ),
    .S(_0994_),
    .X(_0337_));
 sky130_fd_sc_hd__nand2_1 _3744_ (.A(_1183_),
    .B(_0337_),
    .Y(_1184_));
 sky130_fd_sc_hd__mux2_1 _3745_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[6] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[6] ),
    .S(_0994_),
    .X(_0353_));
 sky130_fd_sc_hd__nand2_1 _3746_ (.A(_1173_),
    .B(_0353_),
    .Y(_1185_));
 sky130_fd_sc_hd__a22oi_1 _3747_ (.A1(\g_telemetry.u_reg_file.hiccup_base[6] ),
    .A2(_0846_),
    .B1(_1176_),
    .B2(\g_telemetry.u_reg_file.bus_err_count[6] ),
    .Y(_1186_));
 sky130_fd_sc_hd__a22oi_4 _3748_ (.A1(\clean_run_target[6] ),
    .A2(_0784_),
    .B1(_0814_),
    .B2(\g_telemetry.u_reg_file.hiccup_base[14] ),
    .Y(_1187_));
 sky130_fd_sc_hd__a222oi_1 _3749_ (.A1(\fault_time[22] ),
    .A2(_0714_),
    .B1(_1151_),
    .B2(\g_telemetry.u_reg_file.disable_armed ),
    .C1(_0778_),
    .C2(\clean_run_target[14] ),
    .Y(_1188_));
 sky130_fd_sc_hd__and4_1 _3750_ (.A(_1181_),
    .B(_1186_),
    .C(_1187_),
    .D(_1188_),
    .X(_1189_));
 sky130_fd_sc_hd__a222oi_1 _3751_ (.A1(\cycles_per_step[6] ),
    .A2(_0797_),
    .B1(_0999_),
    .B2(\g_telemetry.u_reg_file.scratch_r[6] ),
    .C1(_1165_),
    .C2(\fault_time[14] ),
    .Y(_1190_));
 sky130_fd_sc_hd__nand4_1 _3752_ (.A(_1184_),
    .B(_1185_),
    .C(_1189_),
    .D(_1190_),
    .Y(_1191_));
 sky130_fd_sc_hd__nor2_1 _3753_ (.A(_0705_),
    .B(_0716_),
    .Y(_0658_));
 sky130_fd_sc_hd__a21o_1 _3754_ (.A1(_1182_),
    .A2(_0345_),
    .B1(_1191_),
    .X(_1192_));
 sky130_fd_sc_hd__and3_1 _3755_ (.A(\g_telemetry.u_spi_slave.tx_shift[5] ),
    .B(_1138_),
    .C(_1141_),
    .X(_1193_));
 sky130_fd_sc_hd__a221o_1 _3756_ (.A1(\g_telemetry.u_spi_slave.tx_shift[6] ),
    .A2(_1139_),
    .B1(_1178_),
    .B2(_1192_),
    .C1(_1193_),
    .X(_0590_));
 sky130_fd_sc_hd__and2_0 _3757_ (.A(\g_telemetry.u_spi_slave.idle_counter[3] ),
    .B(_0697_),
    .X(_1194_));
 sky130_fd_sc_hd__and3_1 _3758_ (.A(\g_telemetry.u_spi_slave.idle_counter[4] ),
    .B(\g_telemetry.u_spi_slave.idle_counter[3] ),
    .C(_0697_),
    .X(_1195_));
 sky130_fd_sc_hd__and2_1 _3759_ (.A(\g_telemetry.u_spi_slave.idle_counter[5] ),
    .B(_1195_),
    .X(_1196_));
 sky130_fd_sc_hd__and3_1 _3760_ (.A(\g_telemetry.u_spi_slave.idle_counter[7] ),
    .B(\g_telemetry.u_spi_slave.idle_counter[6] ),
    .C(_1196_),
    .X(_1197_));
 sky130_fd_sc_hd__and3_1 _3761_ (.A(\g_telemetry.u_spi_slave.idle_counter[9] ),
    .B(\g_telemetry.u_spi_slave.idle_counter[8] ),
    .C(_1197_),
    .X(_1198_));
 sky130_fd_sc_hd__and2_0 _3762_ (.A(\g_telemetry.u_spi_slave.idle_counter[10] ),
    .B(_1198_),
    .X(_1199_));
 sky130_fd_sc_hd__and4_1 _3763_ (.A(\g_telemetry.u_spi_slave.idle_counter[13] ),
    .B(\g_telemetry.u_spi_slave.idle_counter[12] ),
    .C(\g_telemetry.u_spi_slave.idle_counter[11] ),
    .D(_1199_),
    .X(_1200_));
 sky130_fd_sc_hd__nand2_1 _3764_ (.A(\g_timestamp.u_timestamp.prescalar[1] ),
    .B(\g_timestamp.u_timestamp.prescalar[0] ),
    .Y(_0717_));
 sky130_fd_sc_hd__and3_1 _3765_ (.A(\g_telemetry.u_spi_slave.idle_counter[11] ),
    .B(\g_telemetry.u_spi_slave.idle_counter[10] ),
    .C(_1198_),
    .X(_1201_));
 sky130_fd_sc_hd__nor4b_1 _3766_ (.A(\g_telemetry.u_spi_slave.idle_counter[12] ),
    .B(\g_telemetry.u_spi_slave.idle_counter[8] ),
    .C(\g_telemetry.u_spi_slave.idle_counter[7] ),
    .D_N(\g_telemetry.u_spi_slave.idle_counter[9] ),
    .Y(_1202_));
 sky130_fd_sc_hd__nor4b_1 _3767_ (.A(\g_telemetry.u_spi_slave.idle_counter[13] ),
    .B(\g_telemetry.u_spi_slave.idle_counter[1] ),
    .C(\g_telemetry.u_spi_slave.idle_counter[0] ),
    .D_N(\g_telemetry.u_spi_slave.idle_counter[14] ),
    .Y(_1203_));
 sky130_fd_sc_hd__nor4b_1 _3768_ (.A(\g_telemetry.u_spi_slave.idle_counter[6] ),
    .B(\g_telemetry.u_spi_slave.idle_counter[4] ),
    .C(\g_telemetry.u_spi_slave.idle_counter[3] ),
    .D_N(\g_telemetry.u_spi_slave.idle_counter[5] ),
    .Y(_1204_));
 sky130_fd_sc_hd__and4b_1 _3769_ (.A_N(\g_telemetry.u_spi_slave.idle_counter[2] ),
    .B(\g_telemetry.u_spi_slave.idle_counter[11] ),
    .C(\g_telemetry.u_spi_slave.idle_counter[10] ),
    .D(_1204_),
    .X(_1205_));
 sky130_fd_sc_hd__nand3_1 _3770_ (.A(_1202_),
    .B(_1203_),
    .C(_1205_),
    .Y(_1206_));
 sky130_fd_sc_hd__nand2_2 _3771_ (.A(_0695_),
    .B(_1206_),
    .Y(_1207_));
 sky130_fd_sc_hd__o21bai_1 _3772_ (.A1(\g_telemetry.u_spi_slave.idle_counter[14] ),
    .A2(_1200_),
    .B1_N(_1207_),
    .Y(_1208_));
 sky130_fd_sc_hd__a21oi_1 _3773_ (.A1(\g_telemetry.u_spi_slave.idle_counter[14] ),
    .A2(_1200_),
    .B1(_1208_),
    .Y(_0005_));
 sky130_fd_sc_hd__nand2b_1 _3774_ (.A_N(\max_on_counts[3] ),
    .B(\u_pwm_mask.run_counter[3] ),
    .Y(_1209_));
 sky130_fd_sc_hd__and4_1 _3775_ (.A(\g_timestamp.u_timestamp.prescalar[3] ),
    .B(\g_timestamp.u_timestamp.prescalar[2] ),
    .C(\g_timestamp.u_timestamp.prescalar[1] ),
    .D(\g_timestamp.u_timestamp.prescalar[0] ),
    .X(_0718_));
 sky130_fd_sc_hd__nand2b_1 _3776_ (.A_N(\u_pwm_mask.run_counter[0] ),
    .B(\max_on_counts[0] ),
    .Y(_1210_));
 sky130_fd_sc_hd__maj3_1 _3777_ (.A(\u_pwm_mask.run_counter[1] ),
    .B(_0681_),
    .C(_1210_),
    .X(_1211_));
 sky130_fd_sc_hd__nand2_1 _3778_ (.A(_1209_),
    .B(_1211_),
    .Y(_1212_));
 sky130_fd_sc_hd__maj3_1 _3779_ (.A(_0674_),
    .B(\max_on_counts[2] ),
    .C(_1212_),
    .X(_1213_));
 sky130_fd_sc_hd__a21oi_1 _3780_ (.A1(\max_on_counts[3] ),
    .A2(_0680_),
    .B1(_1213_),
    .Y(_1214_));
 sky130_fd_sc_hd__o21ai_1 _3781_ (.A1(_0675_),
    .A2(\max_on_counts[4] ),
    .B1(_1209_),
    .Y(_1215_));
 sky130_fd_sc_hd__o22ai_4 _3782_ (.A1(\u_pwm_mask.run_counter[4] ),
    .A2(_0682_),
    .B1(_1214_),
    .B2(_1215_),
    .Y(_1216_));
 sky130_fd_sc_hd__inv_1 _3783_ (.A(_1216_),
    .Y(_1217_));
 sky130_fd_sc_hd__and2_0 _3784_ (.A(\u_pwm_mask.run_counter[0] ),
    .B(_1216_),
    .X(_1218_));
 sky130_fd_sc_hd__and3_1 _3785_ (.A(\u_pwm_mask.run_counter[1] ),
    .B(\u_pwm_mask.run_counter[0] ),
    .C(_1216_),
    .X(_1219_));
 sky130_fd_sc_hd__nor4b_1 _3786_ (.A(\g_timestamp.u_timestamp.prescalar[6] ),
    .B(\g_timestamp.u_timestamp.prescalar[5] ),
    .C(\g_timestamp.u_timestamp.prescalar[4] ),
    .D_N(\g_timestamp.u_timestamp.prescalar[13] ),
    .Y(_0719_));
 sky130_fd_sc_hd__nand3_1 _3787_ (.A(\u_pwm_mask.run_counter[2] ),
    .B(\u_pwm_mask.run_counter[3] ),
    .C(_1219_),
    .Y(_1220_));
 sky130_fd_sc_hd__a21boi_0 _3788_ (.A1(_0675_),
    .A2(_1220_),
    .B1_N(Osc_sync),
    .Y(_0589_));
 sky130_fd_sc_hd__nor3_1 _3789_ (.A(\cycles_per_step[2] ),
    .B(\cycles_per_step[0] ),
    .C(\cycles_per_step[1] ),
    .Y(_1221_));
 sky130_fd_sc_hd__nand2b_1 _3790_ (.A_N(\cycles_per_step[3] ),
    .B(_1221_),
    .Y(_1222_));
 sky130_fd_sc_hd__xnor2_1 _3791_ (.A(\cycles_per_step[4] ),
    .B(_1222_),
    .Y(_1223_));
 sky130_fd_sc_hd__xnor2_1 _3792_ (.A(\u_soft_start.cycle_counter[4] ),
    .B(_1223_),
    .Y(_1224_));
 sky130_fd_sc_hd__nor3_1 _3793_ (.A(\cycles_per_step[4] ),
    .B(\cycles_per_step[5] ),
    .C(_1222_),
    .Y(_1225_));
 sky130_fd_sc_hd__xnor2_1 _3794_ (.A(\cycles_per_step[6] ),
    .B(\u_soft_start.cycle_counter[6] ),
    .Y(_1226_));
 sky130_fd_sc_hd__xnor2_1 _3795_ (.A(_1225_),
    .B(_1226_),
    .Y(_1227_));
 sky130_fd_sc_hd__o21a_1 _3796_ (.A1(\cycles_per_step[4] ),
    .A2(_1222_),
    .B1(\cycles_per_step[5] ),
    .X(_1228_));
 sky130_fd_sc_hd__nand2_1 _3797_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[14] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[13] ),
    .Y(_0720_));
 sky130_fd_sc_hd__nor2_1 _3798_ (.A(_1225_),
    .B(_1228_),
    .Y(_1229_));
 sky130_fd_sc_hd__o21a_1 _3799_ (.A1(\cycles_per_step[0] ),
    .A2(\cycles_per_step[1] ),
    .B1(\cycles_per_step[2] ),
    .X(_1230_));
 sky130_fd_sc_hd__nor2_1 _3800_ (.A(_1221_),
    .B(_1230_),
    .Y(_1231_));
 sky130_fd_sc_hd__xnor2_1 _3801_ (.A(\u_soft_start.cycle_counter[2] ),
    .B(_1231_),
    .Y(_1232_));
 sky130_fd_sc_hd__xnor2_1 _3802_ (.A(\u_soft_start.cycle_counter[1] ),
    .B(\cycles_per_step[1] ),
    .Y(_1233_));
 sky130_fd_sc_hd__nor3b_1 _3803_ (.A(_1233_),
    .B(\cycles_per_step[0] ),
    .C_N(\u_soft_start.cycle_counter[0] ),
    .Y(_1234_));
 sky130_fd_sc_hd__nor2b_1 _3804_ (.A(\u_soft_start.cycle_counter[0] ),
    .B_N(\cycles_per_step[0] ),
    .Y(_1235_));
 sky130_fd_sc_hd__a21oi_1 _3805_ (.A1(_1233_),
    .A2(_1235_),
    .B1(_1234_),
    .Y(_1236_));
 sky130_fd_sc_hd__xnor2_1 _3806_ (.A(\cycles_per_step[3] ),
    .B(_1221_),
    .Y(_1237_));
 sky130_fd_sc_hd__xnor2_1 _3807_ (.A(\u_soft_start.cycle_counter[3] ),
    .B(_1237_),
    .Y(_1238_));
 sky130_fd_sc_hd__nand4_1 _3808_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[0] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[2] ),
    .C(\g_telemetry.u_fault_cause.timestamp_ms[3] ),
    .D(\g_telemetry.u_fault_cause.timestamp_ms[1] ),
    .Y(_0721_));
 sky130_fd_sc_hd__nor4_2 _3809_ (.A(_1227_),
    .B(_1232_),
    .C(_1236_),
    .D(_1238_),
    .Y(_1239_));
 sky130_fd_sc_hd__xnor2_1 _3810_ (.A(_0685_),
    .B(_1229_),
    .Y(_1240_));
 sky130_fd_sc_hd__a31oi_4 _3811_ (.A1(_1224_),
    .A2(_1239_),
    .A3(_1240_),
    .B1(_0700_),
    .Y(_1241_));
 sky130_fd_sc_hd__a21oi_2 _3812_ (.A1(_0699_),
    .A2(_0767_),
    .B1(_0701_),
    .Y(_1242_));
 sky130_fd_sc_hd__o21ai_4 _3813_ (.A1(_0700_),
    .A2(_0766_),
    .B1(_0702_),
    .Y(_1243_));
 sky130_fd_sc_hd__nor2_2 _3814_ (.A(_1241_),
    .B(_1243_),
    .Y(_1244_));
 sky130_fd_sc_hd__and3_1 _3815_ (.A(\u_soft_start.cycle_counter[1] ),
    .B(\u_soft_start.cycle_counter[0] ),
    .C(\u_soft_start.cycle_counter[2] ),
    .X(_1245_));
 sky130_fd_sc_hd__nand3_1 _3816_ (.A(\u_soft_start.cycle_counter[4] ),
    .B(\u_soft_start.cycle_counter[3] ),
    .C(_1245_),
    .Y(_1246_));
 sky130_fd_sc_hd__nor3_1 _3817_ (.A(_0685_),
    .B(_1243_),
    .C(_1246_),
    .Y(_1247_));
 sky130_fd_sc_hd__xnor2_1 _3818_ (.A(\u_soft_start.cycle_counter[6] ),
    .B(_1247_),
    .Y(_1248_));
 sky130_fd_sc_hd__nand2_2 _3819_ (.A(\g_timestamp.u_timestamp.prescalar[9] ),
    .B(\g_timestamp.u_timestamp.prescalar[8] ),
    .Y(_0722_));
 sky130_fd_sc_hd__nor2_1 _3820_ (.A(_1244_),
    .B(_1248_),
    .Y(_0588_));
 sky130_fd_sc_hd__xnor2_1 _3821_ (.A(\g_telemetry.u_reg_file.max_on_limit[2] ),
    .B(\max_on_counts[2] ),
    .Y(_1249_));
 sky130_fd_sc_hd__nand2_1 _3822_ (.A(\g_telemetry.u_reg_file.max_on_limit[4] ),
    .B(_0682_),
    .Y(_1250_));
 sky130_fd_sc_hd__xnor2_1 _3823_ (.A(\g_telemetry.u_reg_file.max_on_limit[4] ),
    .B(\max_on_counts[4] ),
    .Y(_1251_));
 sky130_fd_sc_hd__nand2_1 _3824_ (.A(_1249_),
    .B(_1251_),
    .Y(_1252_));
 sky130_fd_sc_hd__xor2_1 _3825_ (.A(\max_on_counts[0] ),
    .B(\g_telemetry.u_reg_file.max_on_limit[0] ),
    .X(_1253_));
 sky130_fd_sc_hd__xor2_1 _3826_ (.A(\max_on_counts[1] ),
    .B(\g_telemetry.u_reg_file.max_on_limit[1] ),
    .X(_1254_));
 sky130_fd_sc_hd__xor2_1 _3827_ (.A(\max_on_counts[3] ),
    .B(\g_telemetry.u_reg_file.max_on_limit[3] ),
    .X(_1255_));
 sky130_fd_sc_hd__nor4_2 _3828_ (.A(_1252_),
    .B(_1253_),
    .C(_1254_),
    .D(_1255_),
    .Y(_1256_));
 sky130_fd_sc_hd__a211oi_4 _3829_ (.A1(_0699_),
    .A2(_1256_),
    .B1(_1243_),
    .C1(_1241_),
    .Y(_1257_));
 sky130_fd_sc_hd__nor4b_1 _3830_ (.A(\g_timestamp.u_timestamp.prescalar[12] ),
    .B(\g_timestamp.u_timestamp.prescalar[11] ),
    .C(\g_timestamp.u_timestamp.prescalar[7] ),
    .D_N(\g_timestamp.u_timestamp.prescalar[10] ),
    .Y(_0723_));
 sky130_fd_sc_hd__and2_1 _3831_ (.A(\max_on_counts[1] ),
    .B(\max_on_counts[0] ),
    .X(_1258_));
 sky130_fd_sc_hd__and3_1 _3832_ (.A(\max_on_counts[1] ),
    .B(\max_on_counts[0] ),
    .C(\max_on_counts[2] ),
    .X(_1259_));
 sky130_fd_sc_hd__and2_1 _3833_ (.A(\max_on_counts[3] ),
    .B(_1259_),
    .X(_1260_));
 sky130_fd_sc_hd__a21oi_1 _3834_ (.A1(_1257_),
    .A2(_1260_),
    .B1(\max_on_counts[4] ),
    .Y(_1261_));
 sky130_fd_sc_hd__and3_1 _3835_ (.A(\max_on_counts[4] ),
    .B(_1257_),
    .C(_1260_),
    .X(_1262_));
 sky130_fd_sc_hd__nor3_1 _3836_ (.A(_0703_),
    .B(_1261_),
    .C(_1262_),
    .Y(_0587_));
 sky130_fd_sc_hd__nor2_8 _3837_ (.A(_0700_),
    .B(_0764_),
    .Y(_1263_));
 sky130_fd_sc_hd__nor2_8 _3838_ (.A(_0703_),
    .B(_1263_),
    .Y(_1264_));
 sky130_fd_sc_hd__a22o_1 _3839_ (.A1(\u_fault_arbiter.fault_shifter_SS[30] ),
    .A2(_1263_),
    .B1(_1264_),
    .B2(\u_fault_arbiter.fault_shifter_SS[31] ),
    .X(_0586_));
 sky130_fd_sc_hd__nor2_8 _3840_ (.A(_0702_),
    .B(_0764_),
    .Y(_1265_));
 sky130_fd_sc_hd__nand3_2 _3841_ (.A(_0718_),
    .B(_0719_),
    .C(_0723_),
    .Y(_0724_));
 sky130_fd_sc_hd__nor2_8 _3842_ (.A(_0703_),
    .B(_1265_),
    .Y(_1266_));
 sky130_fd_sc_hd__a22o_1 _3843_ (.A1(\u_fault_arbiter.fault_shifter_RUN[14] ),
    .A2(_1265_),
    .B1(_1266_),
    .B2(\u_fault_arbiter.fault_shifter_RUN[15] ),
    .X(_0585_));
 sky130_fd_sc_hd__nor2_1 _3844_ (.A(\fault_count_run[1] ),
    .B(\fault_count_run[2] ),
    .Y(_1267_));
 sky130_fd_sc_hd__xor2_1 _3845_ (.A(\fault_count_run[1] ),
    .B(\fault_count_run[2] ),
    .X(_1268_));
 sky130_fd_sc_hd__nor2b_1 _3846_ (.A(\fault_count_run[0] ),
    .B_N(\u_fault_arbiter.fault_shifter_RUN[15] ),
    .Y(_1269_));
 sky130_fd_sc_hd__xor2_1 _3847_ (.A(\u_fault_arbiter.fault_shifter_RUN[15] ),
    .B(\fault_count_run[0] ),
    .X(_1270_));
 sky130_fd_sc_hd__nand2_1 _3848_ (.A(\u_fault_arbiter.cp_delay[4] ),
    .B(_1270_),
    .Y(_1271_));
 sky130_fd_sc_hd__xnor2_1 _3849_ (.A(\fault_count_run[1] ),
    .B(_1269_),
    .Y(_1272_));
 sky130_fd_sc_hd__maj3_1 _3850_ (.A(\fault_count_run[1] ),
    .B(_1269_),
    .C(_1271_),
    .X(_1273_));
 sky130_fd_sc_hd__or2_0 _3851_ (.A(_1268_),
    .B(_1273_),
    .X(_1274_));
 sky130_fd_sc_hd__inv_1 _3852_ (.A(\fault_count_ss[3] ),
    .Y(_0666_));
 sky130_fd_sc_hd__nor2_2 _3853_ (.A(_0722_),
    .B(_0724_),
    .Y(_0725_));
 sky130_fd_sc_hd__o21ai_0 _3854_ (.A1(\fault_count_run[3] ),
    .A2(_1267_),
    .B1(_1274_),
    .Y(_1275_));
 sky130_fd_sc_hd__o21ai_0 _3855_ (.A1(_0683_),
    .A2(\fault_count_run[2] ),
    .B1(_1275_),
    .Y(_1276_));
 sky130_fd_sc_hd__xnor2_1 _3856_ (.A(\fault_count_run[4] ),
    .B(\fault_count_run[3] ),
    .Y(_1277_));
 sky130_fd_sc_hd__xnor2_1 _3857_ (.A(_1276_),
    .B(_1277_),
    .Y(_1278_));
 sky130_fd_sc_hd__a22o_1 _3858_ (.A1(\fault_count_run[4] ),
    .A2(_1266_),
    .B1(_1278_),
    .B2(_1265_),
    .X(_0584_));
 sky130_fd_sc_hd__nand2_1 _3859_ (.A(\fault_count_ss[5] ),
    .B(_0704_),
    .Y(_1279_));
 sky130_fd_sc_hd__o21ai_0 _3860_ (.A1(\fault_count_ss[2] ),
    .A2(\fault_count_ss[1] ),
    .B1(_0666_),
    .Y(_1280_));
 sky130_fd_sc_hd__xor2_1 _3861_ (.A(\fault_count_ss[2] ),
    .B(\fault_count_ss[1] ),
    .X(_1281_));
 sky130_fd_sc_hd__nor2b_1 _3862_ (.A(\fault_count_ss[0] ),
    .B_N(\u_fault_arbiter.fault_shifter_SS[31] ),
    .Y(_1282_));
 sky130_fd_sc_hd__xor2_1 _3863_ (.A(\fault_count_ss[0] ),
    .B(\u_fault_arbiter.fault_shifter_SS[31] ),
    .X(_1283_));
 sky130_fd_sc_hd__nor3_4 _3864_ (.A(_0721_),
    .B(_0722_),
    .C(_0724_),
    .Y(_0726_));
 sky130_fd_sc_hd__nand2_1 _3865_ (.A(\u_fault_arbiter.cp_delay[4] ),
    .B(_1283_),
    .Y(_1284_));
 sky130_fd_sc_hd__xnor2_1 _3866_ (.A(\fault_count_ss[1] ),
    .B(_1282_),
    .Y(_1285_));
 sky130_fd_sc_hd__maj3_1 _3867_ (.A(\fault_count_ss[1] ),
    .B(_1282_),
    .C(_1284_),
    .X(_1286_));
 sky130_fd_sc_hd__or2_1 _3868_ (.A(_1281_),
    .B(_1286_),
    .X(_1287_));
 sky130_fd_sc_hd__a22oi_2 _3869_ (.A1(\fault_count_ss[3] ),
    .A2(_0672_),
    .B1(_1280_),
    .B2(_1287_),
    .Y(_1288_));
 sky130_fd_sc_hd__and2_0 _3870_ (.A(\fault_count_ss[3] ),
    .B(\fault_count_ss[4] ),
    .X(_1289_));
 sky130_fd_sc_hd__nand2_1 _3871_ (.A(\fault_count_ss[3] ),
    .B(\fault_count_ss[4] ),
    .Y(_1290_));
 sky130_fd_sc_hd__nor2_1 _3872_ (.A(\fault_count_ss[3] ),
    .B(\fault_count_ss[4] ),
    .Y(_1291_));
 sky130_fd_sc_hd__nor2_1 _3873_ (.A(_1288_),
    .B(_1291_),
    .Y(_1292_));
 sky130_fd_sc_hd__a2111oi_1 _3874_ (.A1(_1288_),
    .A2(_1290_),
    .B1(_1292_),
    .C1(_0764_),
    .D1(_0700_),
    .Y(_1293_));
 sky130_fd_sc_hd__and4_1 _3875_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[5] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[4] ),
    .C(\g_telemetry.u_fault_cause.timestamp_ms[6] ),
    .D(_0726_),
    .X(_0727_));
 sky130_fd_sc_hd__mux2i_1 _3876_ (.A0(_1279_),
    .A1(\fault_count_ss[5] ),
    .S(_1293_),
    .Y(_0583_));
 sky130_fd_sc_hd__mux2_1 _3877_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[7] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[7] ),
    .S(_0994_),
    .X(_0352_));
 sky130_fd_sc_hd__nand2_1 _3878_ (.A(\g_telemetry.u_reg_file.write_rejected ),
    .B(_1149_),
    .Y(_1294_));
 sky130_fd_sc_hd__mux2_1 _3879_ (.A0(\g_telemetry.u_reg_file.timestamp_snap[15] ),
    .A1(\g_telemetry.u_fault_cause.timestamp_ms[15] ),
    .S(_0994_),
    .X(_0344_));
 sky130_fd_sc_hd__and2_0 _3880_ (.A(\g_telemetry.u_reg_file.bus_err_count[7] ),
    .B(_1176_),
    .X(_1295_));
 sky130_fd_sc_hd__a221oi_1 _3881_ (.A1(_1173_),
    .A2(_0352_),
    .B1(_0344_),
    .B2(_1182_),
    .C1(_1295_),
    .Y(_1296_));
 sky130_fd_sc_hd__a21oi_1 _3882_ (.A1(_0998_),
    .A2(_1294_),
    .B1(_0710_),
    .Y(_1297_));
 sky130_fd_sc_hd__a21oi_1 _3883_ (.A1(\g_telemetry.u_reg_file.hiccup_base[7] ),
    .A2(_0846_),
    .B1(_1297_),
    .Y(_1298_));
 sky130_fd_sc_hd__a22oi_4 _3884_ (.A1(\fault_time[7] ),
    .A2(_1179_),
    .B1(_1180_),
    .B2(\g_telemetry.u_reg_file.bus_err_count[15] ),
    .Y(_1299_));
 sky130_fd_sc_hd__a22oi_4 _3885_ (.A1(\clean_run_target[7] ),
    .A2(_0784_),
    .B1(_0814_),
    .B2(\g_telemetry.u_reg_file.hiccup_base[15] ),
    .Y(_1300_));
 sky130_fd_sc_hd__inv_1 _3886_ (.A(_0727_),
    .Y(_0728_));
 sky130_fd_sc_hd__a22oi_1 _3887_ (.A1(\fault_time[23] ),
    .A2(_0714_),
    .B1(_0778_),
    .B2(\clean_run_target[15] ),
    .Y(_1301_));
 sky130_fd_sc_hd__nand4_2 _3888_ (.A(_1298_),
    .B(_1299_),
    .C(_1300_),
    .D(_1301_),
    .Y(_1302_));
 sky130_fd_sc_hd__a22o_1 _3889_ (.A1(\g_telemetry.u_reg_file.scratch_r[7] ),
    .A2(_0999_),
    .B1(_1165_),
    .B2(\fault_time[15] ),
    .X(_1303_));
 sky130_fd_sc_hd__a211oi_1 _3890_ (.A1(_0619_),
    .A2(_1183_),
    .B1(_1302_),
    .C1(_1303_),
    .Y(_1304_));
 sky130_fd_sc_hd__a21boi_0 _3891_ (.A1(_1296_),
    .A2(_1304_),
    .B1_N(_1178_),
    .Y(_1305_));
 sky130_fd_sc_hd__and3_1 _3892_ (.A(\g_telemetry.u_spi_slave.tx_shift[6] ),
    .B(_1138_),
    .C(_1141_),
    .X(_1306_));
 sky130_fd_sc_hd__a211o_1 _3893_ (.A1(\g_telemetry.u_spi_slave.sdio_out ),
    .A2(_1139_),
    .B1(_1305_),
    .C1(_1306_),
    .X(_0582_));
 sky130_fd_sc_hd__a21o_1 _3894_ (.A1(\g_telemetry.u_spi_slave.held_valid ),
    .A2(_1112_),
    .B1(_1132_),
    .X(_0581_));
 sky130_fd_sc_hd__a21o_1 _3895_ (.A1(\g_telemetry.u_reg_file.temp_dirty[7] ),
    .A2(_0779_),
    .B1(_0798_),
    .X(_0580_));
 sky130_fd_sc_hd__mux2_1 _3896_ (.A0(\g_telemetry.u_spi_slave.held_data[7] ),
    .A1(\g_telemetry.u_spi_slave.rx_byte[7] ),
    .S(_1132_),
    .X(_0579_));
 sky130_fd_sc_hd__nand4_1 _3897_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[9] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[7] ),
    .C(\g_telemetry.u_fault_cause.timestamp_ms[8] ),
    .D(\g_telemetry.u_fault_cause.timestamp_ms[15] ),
    .Y(_0729_));
 sky130_fd_sc_hd__xnor2_1 _3898_ (.A(\max_on_counts[3] ),
    .B(_1259_),
    .Y(_1307_));
 sky130_fd_sc_hd__nand2_1 _3899_ (.A(\g_telemetry.u_reg_file.max_on_limit[3] ),
    .B(_1307_),
    .Y(_1308_));
 sky130_fd_sc_hd__nand2_1 _3900_ (.A(_1249_),
    .B(_1258_),
    .Y(_1309_));
 sky130_fd_sc_hd__nor2_1 _3901_ (.A(\max_on_counts[1] ),
    .B(\max_on_counts[0] ),
    .Y(_1310_));
 sky130_fd_sc_hd__o21ai_0 _3902_ (.A1(_1258_),
    .A2(_1310_),
    .B1(\g_telemetry.u_reg_file.max_on_limit[1] ),
    .Y(_1311_));
 sky130_fd_sc_hd__nor3_1 _3903_ (.A(\g_telemetry.u_reg_file.max_on_limit[1] ),
    .B(_1258_),
    .C(_1310_),
    .Y(_1312_));
 sky130_fd_sc_hd__o22ai_1 _3904_ (.A1(_1249_),
    .A2(_1258_),
    .B1(_1260_),
    .B2(_1251_),
    .Y(_1313_));
 sky130_fd_sc_hd__o211ai_1 _3905_ (.A1(\g_telemetry.u_reg_file.max_on_limit[3] ),
    .A2(_1307_),
    .B1(_1309_),
    .C1(_1311_),
    .Y(_1314_));
 sky130_fd_sc_hd__a2111oi_0 _3906_ (.A1(_1250_),
    .A2(_1260_),
    .B1(_1312_),
    .C1(_1313_),
    .D1(_1314_),
    .Y(_1315_));
 sky130_fd_sc_hd__a31o_1 _3907_ (.A1(_1253_),
    .A2(_1308_),
    .A3(_1315_),
    .B1(_1256_),
    .X(_1316_));
 sky130_fd_sc_hd__nand3_1 _3908_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[10] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[12] ),
    .C(\g_telemetry.u_fault_cause.timestamp_ms[11] ),
    .Y(_0730_));
 sky130_fd_sc_hd__a21oi_1 _3909_ (.A1(_1244_),
    .A2(_1316_),
    .B1(SS_done),
    .Y(_1317_));
 sky130_fd_sc_hd__nor2_1 _3910_ (.A(_0703_),
    .B(_1317_),
    .Y(_0578_));
 sky130_fd_sc_hd__and2_4 _3911_ (.A(_0701_),
    .B(_0747_),
    .X(_1318_));
 sky130_fd_sc_hd__nand2_4 _3912_ (.A(_0701_),
    .B(_0747_),
    .Y(_1319_));
 sky130_fd_sc_hd__nor2_1 _3913_ (.A(_0767_),
    .B(_1101_),
    .Y(_1320_));
 sky130_fd_sc_hd__nor2_2 _3914_ (.A(_1319_),
    .B(_1320_),
    .Y(_1321_));
 sky130_fd_sc_hd__inv_1 _3915_ (.A(_1321_),
    .Y(_1322_));
 sky130_fd_sc_hd__nand3_1 _3916_ (.A(\u_strike_counter.clean_counter[1] ),
    .B(\u_strike_counter.clean_counter[0] ),
    .C(\u_strike_counter.clean_counter[2] ),
    .Y(_1323_));
 sky130_fd_sc_hd__nand3_1 _3917_ (.A(\u_strike_counter.clean_counter[3] ),
    .B(\u_strike_counter.clean_counter[5] ),
    .C(\u_strike_counter.clean_counter[4] ),
    .Y(_1324_));
 sky130_fd_sc_hd__nor3_1 _3918_ (.A(_0676_),
    .B(_1323_),
    .C(_1324_),
    .Y(_1325_));
 sky130_fd_sc_hd__nor4_2 _3919_ (.A(_0720_),
    .B(_0728_),
    .C(_0729_),
    .D(_0730_),
    .Y(_0731_));
 sky130_fd_sc_hd__and2_0 _3920_ (.A(\u_strike_counter.clean_counter[7] ),
    .B(\u_strike_counter.clean_counter[8] ),
    .X(_1326_));
 sky130_fd_sc_hd__and4_1 _3921_ (.A(\u_strike_counter.clean_counter[10] ),
    .B(\u_strike_counter.clean_counter[9] ),
    .C(_1325_),
    .D(_1326_),
    .X(_1327_));
 sky130_fd_sc_hd__and3_1 _3922_ (.A(\u_strike_counter.clean_counter[11] ),
    .B(\u_strike_counter.clean_counter[12] ),
    .C(_1327_),
    .X(_1328_));
 sky130_fd_sc_hd__nand3_1 _3923_ (.A(\u_strike_counter.clean_counter[14] ),
    .B(\u_strike_counter.clean_counter[13] ),
    .C(_1328_),
    .Y(_1329_));
 sky130_fd_sc_hd__nor3b_1 _3924_ (.A(_1321_),
    .B(_1329_),
    .C_N(\u_strike_counter.clean_counter[15] ),
    .Y(_1330_));
 sky130_fd_sc_hd__and2_0 _3925_ (.A(\u_strike_counter.clean_counter[16] ),
    .B(_1330_),
    .X(_1331_));
 sky130_fd_sc_hd__a21oi_1 _3926_ (.A1(\u_strike_counter.clean_counter[17] ),
    .A2(_1331_),
    .B1(\u_strike_counter.clean_counter[18] ),
    .Y(_1332_));
 sky130_fd_sc_hd__and3_1 _3927_ (.A(\u_strike_counter.clean_counter[18] ),
    .B(\u_strike_counter.clean_counter[17] ),
    .C(_1331_),
    .X(_1333_));
 sky130_fd_sc_hd__nor3_1 _3928_ (.A(_1319_),
    .B(_1332_),
    .C(_1333_),
    .Y(_0577_));
 sky130_fd_sc_hd__and2_2 _3929_ (.A(PGOOD_comp_sync),
    .B(_0701_),
    .X(_1334_));
 sky130_fd_sc_hd__and3_1 _3930_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[17] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[16] ),
    .C(_0731_),
    .X(_0732_));
 sky130_fd_sc_hd__nand2_2 _3931_ (.A(PGOOD_comp_sync),
    .B(_0701_),
    .Y(_1335_));
 sky130_fd_sc_hd__nand2_1 _3932_ (.A(\u_pgood_gen.qualify_counter[0] ),
    .B(\u_pgood_gen.qualify_counter[1] ),
    .Y(_1336_));
 sky130_fd_sc_hd__nand4_1 _3933_ (.A(\u_pgood_gen.qualify_counter[0] ),
    .B(\u_pgood_gen.qualify_counter[1] ),
    .C(\u_pgood_gen.qualify_counter[2] ),
    .D(\u_pgood_gen.qualify_counter[3] ),
    .Y(_1337_));
 sky130_fd_sc_hd__nor2_1 _3934_ (.A(_0767_),
    .B(_1337_),
    .Y(_1338_));
 sky130_fd_sc_hd__and2_0 _3935_ (.A(\u_pgood_gen.qualify_counter[4] ),
    .B(_1338_),
    .X(_1339_));
 sky130_fd_sc_hd__and3_1 _3936_ (.A(\u_pgood_gen.qualify_counter[6] ),
    .B(\u_pgood_gen.qualify_counter[5] ),
    .C(_1339_),
    .X(_1340_));
 sky130_fd_sc_hd__and2_0 _3937_ (.A(\u_pgood_gen.qualify_counter[7] ),
    .B(_1340_),
    .X(_1341_));
 sky130_fd_sc_hd__and3_1 _3938_ (.A(\u_pgood_gen.qualify_counter[7] ),
    .B(\u_pgood_gen.qualify_counter[8] ),
    .C(_1340_),
    .X(_1342_));
 sky130_fd_sc_hd__and2_0 _3939_ (.A(\u_pgood_gen.qualify_counter[9] ),
    .B(_1342_),
    .X(_1343_));
 sky130_fd_sc_hd__a21oi_1 _3940_ (.A1(\u_pgood_gen.qualify_counter[10] ),
    .A2(_1343_),
    .B1(\u_pgood_gen.qualify_counter[11] ),
    .Y(_1344_));
 sky130_fd_sc_hd__and3_1 _3941_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[18] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[19] ),
    .C(_0732_),
    .X(_0733_));
 sky130_fd_sc_hd__and3_1 _3942_ (.A(\u_pgood_gen.qualify_counter[11] ),
    .B(\u_pgood_gen.qualify_counter[10] ),
    .C(_1343_),
    .X(_1345_));
 sky130_fd_sc_hd__nor3_1 _3943_ (.A(_1335_),
    .B(_1344_),
    .C(_1345_),
    .Y(_0576_));
 sky130_fd_sc_hd__nor2_1 _3944_ (.A(_0696_),
    .B(_1206_),
    .Y(_0015_));
 sky130_fd_sc_hd__and3_1 _3945_ (.A(\u_hiccup_timer.cool_counter[15] ),
    .B(\u_hiccup_timer.cool_counter[16] ),
    .C(\u_hiccup_timer.cool_counter[14] ),
    .X(_1346_));
 sky130_fd_sc_hd__nand2_1 _3946_ (.A(\u_hiccup_timer.cool_counter[10] ),
    .B(\u_hiccup_timer.cool_counter[3] ),
    .Y(_1347_));
 sky130_fd_sc_hd__nand4_1 _3947_ (.A(\u_hiccup_timer.cool_counter[8] ),
    .B(\u_hiccup_timer.cool_counter[6] ),
    .C(\u_hiccup_timer.cool_counter[12] ),
    .D(\u_hiccup_timer.cool_counter[5] ),
    .Y(_1348_));
 sky130_fd_sc_hd__nand4_1 _3948_ (.A(\u_hiccup_timer.cool_counter[11] ),
    .B(\u_hiccup_timer.cool_counter[0] ),
    .C(\u_hiccup_timer.cool_counter[1] ),
    .D(\u_hiccup_timer.cool_counter[4] ),
    .Y(_1349_));
 sky130_fd_sc_hd__nand4_1 _3949_ (.A(\u_hiccup_timer.cool_counter[9] ),
    .B(\u_hiccup_timer.cool_counter[7] ),
    .C(\u_hiccup_timer.cool_counter[2] ),
    .D(\u_hiccup_timer.cool_counter[13] ),
    .Y(_1350_));
 sky130_fd_sc_hd__nor4_1 _3950_ (.A(_1347_),
    .B(_1348_),
    .C(_1349_),
    .D(_1350_),
    .Y(_1351_));
 sky130_fd_sc_hd__nand4_1 _3951_ (.A(\u_hiccup_timer.cool_counter[18] ),
    .B(\u_hiccup_timer.cool_counter[17] ),
    .C(_1346_),
    .D(_1351_),
    .Y(_1352_));
 sky130_fd_sc_hd__nand2_1 _3952_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[20] ),
    .B(_0733_),
    .Y(_0734_));
 sky130_fd_sc_hd__xor2_1 _3953_ (.A(\u_hiccup_timer.cool_counter[19] ),
    .B(_1352_),
    .X(_1353_));
 sky130_fd_sc_hd__nand3_1 _3954_ (.A(\u_hiccup_timer.cool_counter[6] ),
    .B(\u_hiccup_timer.cool_counter[5] ),
    .C(\u_hiccup_timer.cool_counter[7] ),
    .Y(_1354_));
 sky130_fd_sc_hd__nand2_1 _3955_ (.A(\u_hiccup_timer.cool_counter[0] ),
    .B(\u_hiccup_timer.cool_counter[4] ),
    .Y(_1355_));
 sky130_fd_sc_hd__nand3_1 _3956_ (.A(\u_hiccup_timer.cool_counter[3] ),
    .B(\u_hiccup_timer.cool_counter[2] ),
    .C(\u_hiccup_timer.cool_counter[1] ),
    .Y(_1356_));
 sky130_fd_sc_hd__nor3_1 _3957_ (.A(_1354_),
    .B(_1355_),
    .C(_1356_),
    .Y(_1357_));
 sky130_fd_sc_hd__nand4_1 _3958_ (.A(\u_hiccup_timer.cool_counter[10] ),
    .B(\u_hiccup_timer.cool_counter[8] ),
    .C(\u_hiccup_timer.cool_counter[9] ),
    .D(_1357_),
    .Y(_1358_));
 sky130_fd_sc_hd__nand3_1 _3959_ (.A(\u_hiccup_timer.cool_counter[12] ),
    .B(\u_hiccup_timer.cool_counter[13] ),
    .C(\u_hiccup_timer.cool_counter[11] ),
    .Y(_1359_));
 sky130_fd_sc_hd__nor2_1 _3960_ (.A(_1046_),
    .B(_1353_),
    .Y(_0575_));
 sky130_fd_sc_hd__nor2b_1 _3961_ (.A(\g_telemetry.u_reg_file.strike_level[0] ),
    .B_N(\g_telemetry.u_reg_file.hiccup_base[9] ),
    .Y(_1360_));
 sky130_fd_sc_hd__mux4_1 _3962_ (.A0(\g_telemetry.u_reg_file.hiccup_base[11] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[10] ),
    .A2(\g_telemetry.u_reg_file.hiccup_base[9] ),
    .A3(\g_telemetry.u_reg_file.hiccup_base[8] ),
    .S0(\g_telemetry.u_reg_file.strike_level[0] ),
    .S1(\g_telemetry.u_reg_file.strike_level[1] ),
    .X(_1361_));
 sky130_fd_sc_hd__inv_1 _3963_ (.A(\g_telemetry.u_reg_file.wd_restored ),
    .Y(_0667_));
 sky130_fd_sc_hd__nand3_1 _3964_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[21] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[20] ),
    .C(_0733_),
    .Y(_0735_));
 sky130_fd_sc_hd__xor2_1 _3965_ (.A(\u_hiccup_timer.cool_counter[11] ),
    .B(_1361_),
    .X(_1362_));
 sky130_fd_sc_hd__mux2i_1 _3966_ (.A0(\g_telemetry.u_reg_file.hiccup_base[16] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[15] ),
    .S(\g_telemetry.u_reg_file.strike_level[0] ),
    .Y(_1363_));
 sky130_fd_sc_hd__a21oi_1 _3967_ (.A1(\g_telemetry.u_reg_file.strike_level[0] ),
    .A2(\g_telemetry.u_reg_file.hiccup_base[17] ),
    .B1(\g_telemetry.u_reg_file.strike_level[1] ),
    .Y(_1364_));
 sky130_fd_sc_hd__a21oi_1 _3968_ (.A1(\g_telemetry.u_reg_file.strike_level[1] ),
    .A2(_1363_),
    .B1(_1364_),
    .Y(_1365_));
 sky130_fd_sc_hd__mux2i_1 _3969_ (.A0(\g_telemetry.u_reg_file.hiccup_base[7] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[6] ),
    .S(\g_telemetry.u_reg_file.strike_level[0] ),
    .Y(_1366_));
 sky130_fd_sc_hd__nor2_1 _3970_ (.A(\g_telemetry.u_reg_file.strike_level[1] ),
    .B(_1366_),
    .Y(_1367_));
 sky130_fd_sc_hd__mux2_1 _3971_ (.A0(\g_telemetry.u_reg_file.hiccup_base[5] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[4] ),
    .S(\g_telemetry.u_reg_file.strike_level[0] ),
    .X(_1368_));
 sky130_fd_sc_hd__a21oi_1 _3972_ (.A1(\g_telemetry.u_reg_file.strike_level[1] ),
    .A2(_1368_),
    .B1(_1367_),
    .Y(_1369_));
 sky130_fd_sc_hd__mux2i_1 _3973_ (.A0(\g_telemetry.u_reg_file.hiccup_base[8] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[7] ),
    .S(\g_telemetry.u_reg_file.strike_level[0] ),
    .Y(_1370_));
 sky130_fd_sc_hd__nor2_1 _3974_ (.A(\g_telemetry.u_reg_file.strike_level[1] ),
    .B(_1370_),
    .Y(_1371_));
 sky130_fd_sc_hd__nand4_1 _3975_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[21] ),
    .B(\g_telemetry.u_fault_cause.timestamp_ms[20] ),
    .C(\g_telemetry.u_fault_cause.timestamp_ms[22] ),
    .D(_0733_),
    .Y(_0736_));
 sky130_fd_sc_hd__mux2_1 _3976_ (.A0(\g_telemetry.u_reg_file.hiccup_base[6] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[5] ),
    .S(\g_telemetry.u_reg_file.strike_level[0] ),
    .X(_1372_));
 sky130_fd_sc_hd__a21oi_1 _3977_ (.A1(\g_telemetry.u_reg_file.strike_level[1] ),
    .A2(_1372_),
    .B1(_1371_),
    .Y(_1373_));
 sky130_fd_sc_hd__mux2i_1 _3978_ (.A0(\g_telemetry.u_reg_file.hiccup_base[12] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[11] ),
    .S(\g_telemetry.u_reg_file.strike_level[0] ),
    .Y(_1374_));
 sky130_fd_sc_hd__nor2_1 _3979_ (.A(\g_telemetry.u_reg_file.strike_level[1] ),
    .B(_1374_),
    .Y(_1375_));
 sky130_fd_sc_hd__mux2_1 _3980_ (.A0(\g_telemetry.u_reg_file.hiccup_base[10] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[9] ),
    .S(\g_telemetry.u_reg_file.strike_level[0] ),
    .X(_1376_));
 sky130_fd_sc_hd__a21oi_1 _3981_ (.A1(\g_telemetry.u_reg_file.strike_level[1] ),
    .A2(_1376_),
    .B1(_1375_),
    .Y(_1377_));
 sky130_fd_sc_hd__nor2_1 _3982_ (.A(\g_telemetry.u_reg_file.strike_level[1] ),
    .B(_1376_),
    .Y(_1378_));
 sky130_fd_sc_hd__a21oi_1 _3983_ (.A1(\g_telemetry.u_reg_file.strike_level[1] ),
    .A2(_1370_),
    .B1(_1378_),
    .Y(_1379_));
 sky130_fd_sc_hd__mux2_1 _3984_ (.A0(\g_telemetry.u_reg_file.hiccup_base[3] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[2] ),
    .S(\g_telemetry.u_reg_file.strike_level[0] ),
    .X(_1380_));
 sky130_fd_sc_hd__mux2i_1 _3985_ (.A0(\g_telemetry.u_reg_file.hiccup_base[1] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[0] ),
    .S(\g_telemetry.u_reg_file.strike_level[0] ),
    .Y(_1381_));
 sky130_fd_sc_hd__xnor2_1 _3986_ (.A(\g_telemetry.u_fault_cause.timestamp_ms[23] ),
    .B(_0736_),
    .Y(_0657_));
 sky130_fd_sc_hd__nand2_1 _3987_ (.A(\g_telemetry.u_reg_file.strike_level[1] ),
    .B(_1381_),
    .Y(_1382_));
 sky130_fd_sc_hd__o21ai_0 _3988_ (.A1(\g_telemetry.u_reg_file.strike_level[1] ),
    .A2(_1380_),
    .B1(_1382_),
    .Y(_1383_));
 sky130_fd_sc_hd__nor2_1 _3989_ (.A(\u_hiccup_timer.cool_counter[8] ),
    .B(_1373_),
    .Y(_1384_));
 sky130_fd_sc_hd__mux4_1 _3990_ (.A0(\g_telemetry.u_reg_file.hiccup_base[15] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[13] ),
    .A2(\g_telemetry.u_reg_file.hiccup_base[14] ),
    .A3(\g_telemetry.u_reg_file.hiccup_base[12] ),
    .S0(\g_telemetry.u_reg_file.strike_level[1] ),
    .S1(\g_telemetry.u_reg_file.strike_level[0] ),
    .X(_1385_));
 sky130_fd_sc_hd__xnor2_1 _3991_ (.A(\u_hiccup_timer.cool_counter[15] ),
    .B(_1385_),
    .Y(_1386_));
 sky130_fd_sc_hd__mux2i_1 _3992_ (.A0(\g_telemetry.u_reg_file.hiccup_base[4] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[3] ),
    .S(\g_telemetry.u_reg_file.strike_level[0] ),
    .Y(_1387_));
 sky130_fd_sc_hd__nor2_1 _3993_ (.A(\g_telemetry.u_reg_file.strike_level[1] ),
    .B(_1387_),
    .Y(_1388_));
 sky130_fd_sc_hd__mux2_1 _3994_ (.A0(\g_telemetry.u_reg_file.hiccup_base[2] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[1] ),
    .S(\g_telemetry.u_reg_file.strike_level[0] ),
    .X(_1389_));
 sky130_fd_sc_hd__a21oi_1 _3995_ (.A1(\g_telemetry.u_reg_file.strike_level[1] ),
    .A2(_1389_),
    .B1(_1388_),
    .Y(_1390_));
 sky130_fd_sc_hd__xnor2_1 _3996_ (.A(\u_hiccup_timer.cool_counter[4] ),
    .B(_1390_),
    .Y(_1391_));
 sky130_fd_sc_hd__a21oi_1 _3997_ (.A1(OTP_sync_db),
    .A2(_0704_),
    .B1(\fault_reg[2] ),
    .Y(_0737_));
 sky130_fd_sc_hd__mux2i_1 _3998_ (.A0(_1368_),
    .A1(_1380_),
    .S(\g_telemetry.u_reg_file.strike_level[1] ),
    .Y(_1392_));
 sky130_fd_sc_hd__xnor2_1 _3999_ (.A(\u_hiccup_timer.cool_counter[5] ),
    .B(_1392_),
    .Y(_1393_));
 sky130_fd_sc_hd__mux2i_1 _4000_ (.A0(\g_telemetry.u_reg_file.hiccup_base[14] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[13] ),
    .S(\g_telemetry.u_reg_file.strike_level[0] ),
    .Y(_1394_));
 sky130_fd_sc_hd__mux2_1 _4001_ (.A0(_1394_),
    .A1(_1374_),
    .S(\g_telemetry.u_reg_file.strike_level[1] ),
    .X(_1395_));
 sky130_fd_sc_hd__xor2_1 _4002_ (.A(\u_hiccup_timer.cool_counter[14] ),
    .B(_1395_),
    .X(_1396_));
 sky130_fd_sc_hd__nand2b_1 _4003_ (.A_N(\g_telemetry.u_reg_file.strike_level[0] ),
    .B(\g_telemetry.u_reg_file.hiccup_base[0] ),
    .Y(_1397_));
 sky130_fd_sc_hd__nor2_1 _4004_ (.A(\g_telemetry.u_reg_file.strike_level[1] ),
    .B(_1389_),
    .Y(_1398_));
 sky130_fd_sc_hd__a21oi_1 _4005_ (.A1(\g_telemetry.u_reg_file.strike_level[1] ),
    .A2(_1397_),
    .B1(_1398_),
    .Y(_1399_));
 sky130_fd_sc_hd__xnor2_1 _4006_ (.A(\u_hiccup_timer.cool_counter[2] ),
    .B(_1399_),
    .Y(_1400_));
 sky130_fd_sc_hd__nand2_1 _4007_ (.A(\g_telemetry.u_reg_file.strike_level[1] ),
    .B(_1387_),
    .Y(_1401_));
 sky130_fd_sc_hd__nor2_1 _4008_ (.A(_0716_),
    .B(_0737_),
    .Y(_0656_));
 sky130_fd_sc_hd__o21ai_0 _4009_ (.A1(\g_telemetry.u_reg_file.strike_level[1] ),
    .A2(_1372_),
    .B1(_1401_),
    .Y(_1402_));
 sky130_fd_sc_hd__xnor2_1 _4010_ (.A(\u_hiccup_timer.cool_counter[6] ),
    .B(_1402_),
    .Y(_1403_));
 sky130_fd_sc_hd__nand2b_1 _4011_ (.A_N(\g_telemetry.u_reg_file.hiccup_base[16] ),
    .B(\g_telemetry.u_reg_file.strike_level[0] ),
    .Y(_1404_));
 sky130_fd_sc_hd__mux4_1 _4012_ (.A0(\g_telemetry.u_reg_file.hiccup_base[17] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[15] ),
    .A2(\g_telemetry.u_reg_file.hiccup_base[16] ),
    .A3(\g_telemetry.u_reg_file.hiccup_base[14] ),
    .S0(\g_telemetry.u_reg_file.strike_level[1] ),
    .S1(\g_telemetry.u_reg_file.strike_level[0] ),
    .X(_1405_));
 sky130_fd_sc_hd__xnor2_1 _4013_ (.A(\u_hiccup_timer.cool_counter[17] ),
    .B(_1405_),
    .Y(_1406_));
 sky130_fd_sc_hd__a211oi_1 _4014_ (.A1(\g_telemetry.u_reg_file.strike_level[0] ),
    .A2(\g_telemetry.u_reg_file.hiccup_base[8] ),
    .B1(_1360_),
    .C1(\g_telemetry.u_reg_file.strike_level[1] ),
    .Y(_1407_));
 sky130_fd_sc_hd__a21oi_1 _4015_ (.A1(\g_telemetry.u_reg_file.strike_level[1] ),
    .A2(_1366_),
    .B1(_1407_),
    .Y(_1408_));
 sky130_fd_sc_hd__xor2_1 _4016_ (.A(\u_hiccup_timer.cool_counter[9] ),
    .B(_1408_),
    .X(_1409_));
 sky130_fd_sc_hd__mux2i_1 _4017_ (.A0(_1363_),
    .A1(_1394_),
    .S(\g_telemetry.u_reg_file.strike_level[1] ),
    .Y(_1410_));
 sky130_fd_sc_hd__mux4_1 _4018_ (.A0(\g_telemetry.u_reg_file.hiccup_base[13] ),
    .A1(\g_telemetry.u_reg_file.hiccup_base[11] ),
    .A2(\g_telemetry.u_reg_file.hiccup_base[12] ),
    .A3(\g_telemetry.u_reg_file.hiccup_base[10] ),
    .S0(\g_telemetry.u_reg_file.strike_level[1] ),
    .S1(\g_telemetry.u_reg_file.strike_level[0] ),
    .X(_1411_));
 sky130_fd_sc_hd__nor2_1 _4019_ (.A(\g_telemetry.u_fault_cause.latch_state ),
    .B(latch_out),
    .Y(_0738_));
 sky130_fd_sc_hd__nor2_1 _4020_ (.A(\g_telemetry.u_reg_file.strike_level[1] ),
    .B(_1381_),
    .Y(_1412_));
 sky130_fd_sc_hd__nor2_1 _4021_ (.A(\g_telemetry.u_reg_file.strike_level[1] ),
    .B(_1397_),
    .Y(_1413_));
 sky130_fd_sc_hd__xnor2_1 _4022_ (.A(\u_hiccup_timer.cool_counter[0] ),
    .B(_1413_),
    .Y(_1414_));
 sky130_fd_sc_hd__xnor2_1 _4023_ (.A(\u_hiccup_timer.cool_counter[1] ),
    .B(_1412_),
    .Y(_1415_));
 sky130_fd_sc_hd__o211ai_1 _4024_ (.A1(\g_telemetry.u_reg_file.strike_level[0] ),
    .A2(\g_telemetry.u_reg_file.hiccup_base[17] ),
    .B1(\g_telemetry.u_reg_file.strike_level[1] ),
    .C1(_1404_),
    .Y(_1416_));
 sky130_fd_sc_hd__xor2_1 _4025_ (.A(\u_hiccup_timer.cool_counter[19] ),
    .B(_1416_),
    .X(_1417_));
 sky130_fd_sc_hd__xnor2_1 _4026_ (.A(\u_hiccup_timer.cool_counter[3] ),
    .B(_1383_),
    .Y(_1418_));
 sky130_fd_sc_hd__xor2_1 _4027_ (.A(\u_hiccup_timer.cool_counter[13] ),
    .B(_1411_),
    .X(_1419_));
 sky130_fd_sc_hd__xnor2_1 _4028_ (.A(\u_hiccup_timer.cool_counter[10] ),
    .B(_1379_),
    .Y(_1420_));
 sky130_fd_sc_hd__xnor2_1 _4029_ (.A(\u_hiccup_timer.cool_counter[18] ),
    .B(_1365_),
    .Y(_1421_));
 sky130_fd_sc_hd__nor2_1 _4030_ (.A(OTP_sync_db),
    .B(UVLO_sync_db),
    .Y(_0739_));
 sky130_fd_sc_hd__o21ai_0 _4031_ (.A1(\u_hiccup_timer.cool_counter[7] ),
    .A2(_1369_),
    .B1(_1417_),
    .Y(_1422_));
 sky130_fd_sc_hd__nor4_1 _4032_ (.A(_1391_),
    .B(_1393_),
    .C(_1418_),
    .D(_1422_),
    .Y(_1423_));
 sky130_fd_sc_hd__o2111ai_1 _4033_ (.A1(\u_hiccup_timer.cool_counter[12] ),
    .A2(_1377_),
    .B1(_1406_),
    .C1(_1421_),
    .D1(_1423_),
    .Y(_1424_));
 sky130_fd_sc_hd__a21oi_1 _4034_ (.A1(\u_hiccup_timer.cool_counter[7] ),
    .A2(_1369_),
    .B1(_1384_),
    .Y(_1425_));
 sky130_fd_sc_hd__nand4_1 _4035_ (.A(_1396_),
    .B(_1400_),
    .C(_1420_),
    .D(_1425_),
    .Y(_1426_));
 sky130_fd_sc_hd__xor2_1 _4036_ (.A(\u_hiccup_timer.cool_counter[16] ),
    .B(_1410_),
    .X(_1427_));
 sky130_fd_sc_hd__nor3_1 _4037_ (.A(_1424_),
    .B(_1426_),
    .C(_1427_),
    .Y(_1428_));
 sky130_fd_sc_hd__a211oi_2 _4038_ (.A1(\u_hiccup_timer.cool_counter[8] ),
    .A2(_1373_),
    .B1(_1403_),
    .C1(_1362_),
    .Y(_1429_));
 sky130_fd_sc_hd__nand3_1 _4039_ (.A(_1386_),
    .B(_1414_),
    .C(_1415_),
    .Y(_1430_));
 sky130_fd_sc_hd__a2111oi_2 _4040_ (.A1(\u_hiccup_timer.cool_counter[12] ),
    .A2(_1377_),
    .B1(_1409_),
    .C1(_1419_),
    .D1(_1430_),
    .Y(_1431_));
 sky130_fd_sc_hd__nand2_1 _4041_ (.A(_0738_),
    .B(_0739_),
    .Y(_0740_));
 sky130_fd_sc_hd__nand3_4 _4042_ (.A(_1428_),
    .B(_1429_),
    .C(_1431_),
    .Y(_1432_));
 sky130_fd_sc_hd__a21oi_1 _4043_ (.A1(_0660_),
    .A2(_1432_),
    .B1(_1046_),
    .Y(_0574_));
 sky130_fd_sc_hd__xor2_2 _4044_ (.A(\g_telemetry.u_reg_file.max_strikes[0] ),
    .B(\g_telemetry.u_reg_file.strike_level[1] ),
    .X(_1433_));
 sky130_fd_sc_hd__nand2_1 _4045_ (.A(\g_telemetry.u_reg_file.max_strikes[1] ),
    .B(_1433_),
    .Y(_1434_));
 sky130_fd_sc_hd__xor2_1 _4046_ (.A(\g_telemetry.u_reg_file.strike_level[0] ),
    .B(\g_telemetry.u_reg_file.max_strikes[0] ),
    .X(_1435_));
 sky130_fd_sc_hd__o2111ai_4 _4047_ (.A1(\g_telemetry.u_reg_file.max_strikes[1] ),
    .A2(_1433_),
    .B1(_1434_),
    .C1(_1435_),
    .D1(_1075_),
    .Y(_1436_));
 sky130_fd_sc_hd__nand2_1 _4048_ (.A(_0677_),
    .B(_1436_),
    .Y(_0573_));
 sky130_fd_sc_hd__nand2_1 _4049_ (.A(\g_telemetry.u_reg_file.temp_dirty[4] ),
    .B(_0779_),
    .Y(_1437_));
 sky130_fd_sc_hd__nand2_1 _4050_ (.A(_0847_),
    .B(_1437_),
    .Y(_0572_));
 sky130_fd_sc_hd__o21ai_0 _4051_ (.A1(\g_telemetry.u_spi_slave.idle_counter[4] ),
    .A2(_1194_),
    .B1(_0695_),
    .Y(_1438_));
 sky130_fd_sc_hd__nor2b_1 _4052_ (.A(\fault_count_run[0] ),
    .B_N(\g_telemetry.u_reg_file.trip_run[0] ),
    .Y(_0741_));
 sky130_fd_sc_hd__nor2_1 _4053_ (.A(_1195_),
    .B(_1438_),
    .Y(_0009_));
 sky130_fd_sc_hd__a21oi_1 _4054_ (.A1(\g_telemetry.u_spi_slave.idle_counter[6] ),
    .A2(_1196_),
    .B1(\g_telemetry.u_spi_slave.idle_counter[7] ),
    .Y(_1439_));
 sky130_fd_sc_hd__nor3_1 _4055_ (.A(_0696_),
    .B(_1197_),
    .C(_1439_),
    .Y(_0012_));
 sky130_fd_sc_hd__nor2_1 _4056_ (.A(\g_telemetry.u_spi_slave.idle_counter[0] ),
    .B(_1207_),
    .Y(_0000_));
 sky130_fd_sc_hd__nor2_1 _4057_ (.A(\g_telemetry.u_spi_slave.idle_counter[3] ),
    .B(_0697_),
    .Y(_1440_));
 sky130_fd_sc_hd__nor3_1 _4058_ (.A(_0696_),
    .B(_1194_),
    .C(_1440_),
    .Y(_0008_));
 sky130_fd_sc_hd__and2_0 _4059_ (.A(\u_hiccup_timer.cool_counter[0] ),
    .B(_1432_),
    .X(_1441_));
 sky130_fd_sc_hd__o21ai_0 _4060_ (.A1(\u_hiccup_timer.cool_counter[0] ),
    .A2(_1432_),
    .B1(hiccup_active),
    .Y(_1442_));
 sky130_fd_sc_hd__nor2_1 _4061_ (.A(_1441_),
    .B(_1442_),
    .Y(_0571_));
 sky130_fd_sc_hd__and3_1 _4062_ (.A(\u_hiccup_timer.cool_counter[0] ),
    .B(\u_hiccup_timer.cool_counter[1] ),
    .C(_1432_),
    .X(_1443_));
 sky130_fd_sc_hd__maj3_1 _4063_ (.A(_0678_),
    .B(\g_telemetry.u_reg_file.trip_run[1] ),
    .C(_0741_),
    .X(_0742_));
 sky130_fd_sc_hd__o21ai_0 _4064_ (.A1(\u_hiccup_timer.cool_counter[1] ),
    .A2(_1441_),
    .B1(hiccup_active),
    .Y(_1444_));
 sky130_fd_sc_hd__nor2_1 _4065_ (.A(_1443_),
    .B(_1444_),
    .Y(_0570_));
 sky130_fd_sc_hd__and2_0 _4066_ (.A(\u_hiccup_timer.cool_counter[2] ),
    .B(_1443_),
    .X(_1445_));
 sky130_fd_sc_hd__o21ai_0 _4067_ (.A1(\u_hiccup_timer.cool_counter[2] ),
    .A2(_1443_),
    .B1(hiccup_active),
    .Y(_1446_));
 sky130_fd_sc_hd__nor2_1 _4068_ (.A(_1445_),
    .B(_1446_),
    .Y(_0569_));
 sky130_fd_sc_hd__nor2b_1 _4069_ (.A(_1356_),
    .B_N(_1441_),
    .Y(_1447_));
 sky130_fd_sc_hd__o21ai_0 _4070_ (.A1(\u_hiccup_timer.cool_counter[3] ),
    .A2(_1445_),
    .B1(hiccup_active),
    .Y(_1448_));
 sky130_fd_sc_hd__nor2_1 _4071_ (.A(_1447_),
    .B(_1448_),
    .Y(_0568_));
 sky130_fd_sc_hd__and2_1 _4072_ (.A(\u_hiccup_timer.cool_counter[4] ),
    .B(_1447_),
    .X(_1449_));
 sky130_fd_sc_hd__o21ai_0 _4073_ (.A1(\u_hiccup_timer.cool_counter[4] ),
    .A2(_1447_),
    .B1(hiccup_active),
    .Y(_1450_));
 sky130_fd_sc_hd__inv_1 _4074_ (.A(\g_telemetry.u_reg_file.en_pending_val ),
    .Y(_0668_));
 sky130_fd_sc_hd__maj3_1 _4075_ (.A(\g_telemetry.u_reg_file.trip_run[2] ),
    .B(_0684_),
    .C(_0742_),
    .X(_0743_));
 sky130_fd_sc_hd__nor2_1 _4076_ (.A(_1449_),
    .B(_1450_),
    .Y(_0567_));
 sky130_fd_sc_hd__o21ai_0 _4077_ (.A1(\u_hiccup_timer.cool_counter[5] ),
    .A2(_1449_),
    .B1(hiccup_active),
    .Y(_1451_));
 sky130_fd_sc_hd__a21oi_1 _4078_ (.A1(\u_hiccup_timer.cool_counter[5] ),
    .A2(_1449_),
    .B1(_1451_),
    .Y(_0566_));
 sky130_fd_sc_hd__and3_1 _4079_ (.A(\u_hiccup_timer.cool_counter[6] ),
    .B(\u_hiccup_timer.cool_counter[5] ),
    .C(_1449_),
    .X(_1452_));
 sky130_fd_sc_hd__a21oi_1 _4080_ (.A1(\u_hiccup_timer.cool_counter[5] ),
    .A2(_1449_),
    .B1(\u_hiccup_timer.cool_counter[6] ),
    .Y(_1453_));
 sky130_fd_sc_hd__nor3_1 _4081_ (.A(_1046_),
    .B(_1452_),
    .C(_1453_),
    .Y(_0565_));
 sky130_fd_sc_hd__nor2b_2 _4082_ (.A(_1354_),
    .B_N(_1449_),
    .Y(_1454_));
 sky130_fd_sc_hd__o21ai_0 _4083_ (.A1(\u_hiccup_timer.cool_counter[7] ),
    .A2(_1452_),
    .B1(hiccup_active),
    .Y(_1455_));
 sky130_fd_sc_hd__nor2_1 _4084_ (.A(_1454_),
    .B(_1455_),
    .Y(_0564_));
 sky130_fd_sc_hd__o21ai_0 _4085_ (.A1(\u_hiccup_timer.cool_counter[8] ),
    .A2(_1454_),
    .B1(hiccup_active),
    .Y(_1456_));
 sky130_fd_sc_hd__nand2_1 _4086_ (.A(\fault_count_run[4] ),
    .B(_0687_),
    .Y(_0744_));
 sky130_fd_sc_hd__a21oi_1 _4087_ (.A1(\u_hiccup_timer.cool_counter[8] ),
    .A2(_1454_),
    .B1(_1456_),
    .Y(_0563_));
 sky130_fd_sc_hd__and3_1 _4088_ (.A(\u_hiccup_timer.cool_counter[8] ),
    .B(\u_hiccup_timer.cool_counter[9] ),
    .C(_1454_),
    .X(_1457_));
 sky130_fd_sc_hd__a21oi_1 _4089_ (.A1(\u_hiccup_timer.cool_counter[8] ),
    .A2(_1454_),
    .B1(\u_hiccup_timer.cool_counter[9] ),
    .Y(_1458_));
 sky130_fd_sc_hd__nor3_1 _4090_ (.A(_1046_),
    .B(_1457_),
    .C(_1458_),
    .Y(_0562_));
 sky130_fd_sc_hd__o21ai_0 _4091_ (.A1(\u_hiccup_timer.cool_counter[10] ),
    .A2(_1457_),
    .B1(hiccup_active),
    .Y(_1459_));
 sky130_fd_sc_hd__a21oi_1 _4092_ (.A1(\u_hiccup_timer.cool_counter[10] ),
    .A2(_1457_),
    .B1(_1459_),
    .Y(_0561_));
 sky130_fd_sc_hd__and3_1 _4093_ (.A(\u_hiccup_timer.cool_counter[10] ),
    .B(\u_hiccup_timer.cool_counter[11] ),
    .C(_1457_),
    .X(_1460_));
 sky130_fd_sc_hd__a21oi_1 _4094_ (.A1(\u_hiccup_timer.cool_counter[10] ),
    .A2(_1457_),
    .B1(\u_hiccup_timer.cool_counter[11] ),
    .Y(_1461_));
 sky130_fd_sc_hd__nor3_1 _4095_ (.A(_1046_),
    .B(_1460_),
    .C(_1461_),
    .Y(_0560_));
 sky130_fd_sc_hd__o21ai_0 _4096_ (.A1(\u_hiccup_timer.cool_counter[12] ),
    .A2(_1460_),
    .B1(hiccup_active),
    .Y(_1462_));
 sky130_fd_sc_hd__maj3_1 _4097_ (.A(_0683_),
    .B(\g_telemetry.u_reg_file.trip_run[3] ),
    .C(_0743_),
    .X(_0745_));
 sky130_fd_sc_hd__a21oi_1 _4098_ (.A1(\u_hiccup_timer.cool_counter[12] ),
    .A2(_1460_),
    .B1(_1462_),
    .Y(_0559_));
 sky130_fd_sc_hd__a21oi_1 _4099_ (.A1(\u_hiccup_timer.cool_counter[12] ),
    .A2(_1460_),
    .B1(\u_hiccup_timer.cool_counter[13] ),
    .Y(_1463_));
 sky130_fd_sc_hd__nor3b_1 _4100_ (.A(_1358_),
    .B(_1359_),
    .C_N(_1432_),
    .Y(_1464_));
 sky130_fd_sc_hd__nor3_1 _4101_ (.A(_1046_),
    .B(_1463_),
    .C(_1464_),
    .Y(_0558_));
 sky130_fd_sc_hd__and3_1 _4102_ (.A(\u_hiccup_timer.cool_counter[14] ),
    .B(_1351_),
    .C(_1432_),
    .X(_1465_));
 sky130_fd_sc_hd__o21ai_0 _4103_ (.A1(\u_hiccup_timer.cool_counter[14] ),
    .A2(_1464_),
    .B1(hiccup_active),
    .Y(_1466_));
 sky130_fd_sc_hd__nor2_1 _4104_ (.A(_1465_),
    .B(_1466_),
    .Y(_0557_));
 sky130_fd_sc_hd__and2_0 _4105_ (.A(\u_hiccup_timer.cool_counter[15] ),
    .B(_1465_),
    .X(_1467_));
 sky130_fd_sc_hd__o21ai_0 _4106_ (.A1(\u_hiccup_timer.cool_counter[15] ),
    .A2(_1465_),
    .B1(hiccup_active),
    .Y(_1468_));
 sky130_fd_sc_hd__nor2_1 _4107_ (.A(_1467_),
    .B(_1468_),
    .Y(_0556_));
 sky130_fd_sc_hd__a21oi_1 _4108_ (.A1(_0744_),
    .A2(_0745_),
    .B1(\g_telemetry.u_reg_file.trip_run[5] ),
    .Y(_0746_));
 sky130_fd_sc_hd__and2_0 _4109_ (.A(_1346_),
    .B(_1464_),
    .X(_1469_));
 sky130_fd_sc_hd__o21ai_0 _4110_ (.A1(\u_hiccup_timer.cool_counter[16] ),
    .A2(_1467_),
    .B1(hiccup_active),
    .Y(_1470_));
 sky130_fd_sc_hd__nor2_1 _4111_ (.A(_1469_),
    .B(_1470_),
    .Y(_0555_));
 sky130_fd_sc_hd__o21ai_0 _4112_ (.A1(\u_hiccup_timer.cool_counter[17] ),
    .A2(_1469_),
    .B1(hiccup_active),
    .Y(_1471_));
 sky130_fd_sc_hd__a21oi_1 _4113_ (.A1(\u_hiccup_timer.cool_counter[17] ),
    .A2(_1469_),
    .B1(_1471_),
    .Y(_0554_));
 sky130_fd_sc_hd__a21oi_1 _4114_ (.A1(\u_hiccup_timer.cool_counter[17] ),
    .A2(_1469_),
    .B1(\u_hiccup_timer.cool_counter[18] ),
    .Y(_1472_));
 sky130_fd_sc_hd__nand2_1 _4115_ (.A(hiccup_active),
    .B(_1352_),
    .Y(_1473_));
 sky130_fd_sc_hd__nor2_1 _4116_ (.A(_1472_),
    .B(_1473_),
    .Y(_0553_));
 sky130_fd_sc_hd__nand2_1 _4117_ (.A(\u_pgood_gen.qualify_counter[1] ),
    .B(\u_pgood_gen.qualify_counter[7] ),
    .Y(_1474_));
 sky130_fd_sc_hd__nor3_1 _4118_ (.A(\u_pgood_gen.qualify_counter[0] ),
    .B(\u_pgood_gen.qualify_counter[2] ),
    .C(_1474_),
    .Y(_1475_));
 sky130_fd_sc_hd__o21ai_4 _4119_ (.A1(\fault_count_run[4] ),
    .A2(_0687_),
    .B1(_0746_),
    .Y(_0747_));
 sky130_fd_sc_hd__nand3_1 _4120_ (.A(\u_pgood_gen.qualify_counter[11] ),
    .B(\u_pgood_gen.qualify_counter[6] ),
    .C(\u_pgood_gen.qualify_counter[8] ),
    .Y(_1476_));
 sky130_fd_sc_hd__nor4b_1 _4121_ (.A(\u_pgood_gen.qualify_counter[5] ),
    .B(_1476_),
    .C(\u_pgood_gen.qualify_counter[3] ),
    .D_N(\u_pgood_gen.qualify_counter[10] ),
    .Y(_1477_));
 sky130_fd_sc_hd__nand4_2 _4122_ (.A(\u_pgood_gen.qualify_counter[9] ),
    .B(\u_pgood_gen.qualify_counter[4] ),
    .C(_1475_),
    .D(_1477_),
    .Y(_1478_));
 sky130_fd_sc_hd__nor2_1 _4123_ (.A(_0766_),
    .B(_1335_),
    .Y(_1479_));
 sky130_fd_sc_hd__nor2_1 _4124_ (.A(\u_pgood_gen.qualify_counter[0] ),
    .B(_0767_),
    .Y(_1480_));
 sky130_fd_sc_hd__a32o_1 _4125_ (.A1(_1334_),
    .A2(_1478_),
    .A3(_1480_),
    .B1(_1479_),
    .B2(\u_pgood_gen.qualify_counter[0] ),
    .X(_0552_));
 sky130_fd_sc_hd__a21oi_1 _4126_ (.A1(\u_pgood_gen.qualify_counter[0] ),
    .A2(_0766_),
    .B1(\u_pgood_gen.qualify_counter[1] ),
    .Y(_1481_));
 sky130_fd_sc_hd__o21ai_0 _4127_ (.A1(_0767_),
    .A2(_1336_),
    .B1(_1334_),
    .Y(_1482_));
 sky130_fd_sc_hd__nor2_1 _4128_ (.A(_1481_),
    .B(_1482_),
    .Y(_0551_));
 sky130_fd_sc_hd__o21ai_1 _4129_ (.A1(_0767_),
    .A2(_1478_),
    .B1(_1334_),
    .Y(_1483_));
 sky130_fd_sc_hd__nor2b_1 _4130_ (.A(\fault_count_ss[0] ),
    .B_N(\g_telemetry.u_reg_file.trip_ss[0] ),
    .Y(_0748_));
 sky130_fd_sc_hd__nor2_1 _4131_ (.A(_1336_),
    .B(_1479_),
    .Y(_1484_));
 sky130_fd_sc_hd__xnor2_1 _4132_ (.A(\u_pgood_gen.qualify_counter[2] ),
    .B(_1484_),
    .Y(_1485_));
 sky130_fd_sc_hd__nor2_1 _4133_ (.A(_1483_),
    .B(_1485_),
    .Y(_0550_));
 sky130_fd_sc_hd__nor2_1 _4134_ (.A(_1337_),
    .B(_1479_),
    .Y(_1486_));
 sky130_fd_sc_hd__a21oi_1 _4135_ (.A1(\u_pgood_gen.qualify_counter[2] ),
    .A2(_1484_),
    .B1(\u_pgood_gen.qualify_counter[3] ),
    .Y(_1487_));
 sky130_fd_sc_hd__nor3_1 _4136_ (.A(_1483_),
    .B(_1486_),
    .C(_1487_),
    .Y(_0549_));
 sky130_fd_sc_hd__o21ai_0 _4137_ (.A1(\u_pgood_gen.qualify_counter[4] ),
    .A2(_1338_),
    .B1(_1334_),
    .Y(_1488_));
 sky130_fd_sc_hd__nor2_1 _4138_ (.A(_1339_),
    .B(_1488_),
    .Y(_0548_));
 sky130_fd_sc_hd__a21oi_1 _4139_ (.A1(\u_pgood_gen.qualify_counter[4] ),
    .A2(_1486_),
    .B1(\u_pgood_gen.qualify_counter[5] ),
    .Y(_1489_));
 sky130_fd_sc_hd__a311oi_1 _4140_ (.A1(\u_pgood_gen.qualify_counter[4] ),
    .A2(\u_pgood_gen.qualify_counter[5] ),
    .A3(_1486_),
    .B1(_1489_),
    .C1(_1483_),
    .Y(_0547_));
 sky130_fd_sc_hd__maj3_1 _4141_ (.A(_0679_),
    .B(\g_telemetry.u_reg_file.trip_ss[1] ),
    .C(_0748_),
    .X(_0749_));
 sky130_fd_sc_hd__a21oi_1 _4142_ (.A1(\u_pgood_gen.qualify_counter[5] ),
    .A2(_1339_),
    .B1(\u_pgood_gen.qualify_counter[6] ),
    .Y(_1490_));
 sky130_fd_sc_hd__nor3_1 _4143_ (.A(_1335_),
    .B(_1340_),
    .C(_1490_),
    .Y(_0546_));
 sky130_fd_sc_hd__o21ai_0 _4144_ (.A1(\u_pgood_gen.qualify_counter[7] ),
    .A2(_1340_),
    .B1(_1334_),
    .Y(_1491_));
 sky130_fd_sc_hd__nor2_1 _4145_ (.A(_1341_),
    .B(_1491_),
    .Y(_0545_));
 sky130_fd_sc_hd__o21ai_0 _4146_ (.A1(\u_pgood_gen.qualify_counter[8] ),
    .A2(_1341_),
    .B1(_1334_),
    .Y(_1492_));
 sky130_fd_sc_hd__nor2_1 _4147_ (.A(_1342_),
    .B(_1492_),
    .Y(_0544_));
 sky130_fd_sc_hd__o21ai_0 _4148_ (.A1(\u_pgood_gen.qualify_counter[9] ),
    .A2(_1342_),
    .B1(_1334_),
    .Y(_1493_));
 sky130_fd_sc_hd__nor2_1 _4149_ (.A(_1343_),
    .B(_1493_),
    .Y(_0543_));
 sky130_fd_sc_hd__o21ai_0 _4150_ (.A1(\u_pgood_gen.qualify_counter[10] ),
    .A2(_1343_),
    .B1(_1334_),
    .Y(_1494_));
 sky130_fd_sc_hd__a21oi_1 _4151_ (.A1(\u_pgood_gen.qualify_counter[10] ),
    .A2(_1343_),
    .B1(_1494_),
    .Y(_0542_));
 sky130_fd_sc_hd__maj3_1 _4152_ (.A(_0672_),
    .B(\g_telemetry.u_reg_file.trip_ss[2] ),
    .C(_0749_),
    .X(_0750_));
 sky130_fd_sc_hd__a21oi_1 _4153_ (.A1(_1318_),
    .A2(_1320_),
    .B1(\u_strike_counter.clean_counter[0] ),
    .Y(_1495_));
 sky130_fd_sc_hd__a21oi_1 _4154_ (.A1(\u_strike_counter.clean_counter[0] ),
    .A2(_1322_),
    .B1(_1495_),
    .Y(_0541_));
 sky130_fd_sc_hd__a21oi_1 _4155_ (.A1(\u_strike_counter.clean_counter[0] ),
    .A2(_1322_),
    .B1(\u_strike_counter.clean_counter[1] ),
    .Y(_1496_));
 sky130_fd_sc_hd__and3_1 _4156_ (.A(\u_strike_counter.clean_counter[1] ),
    .B(\u_strike_counter.clean_counter[0] ),
    .C(_1320_),
    .X(_1497_));
 sky130_fd_sc_hd__nor3_1 _4157_ (.A(_1319_),
    .B(_1496_),
    .C(_1497_),
    .Y(_0540_));
 sky130_fd_sc_hd__nor2_1 _4158_ (.A(_1321_),
    .B(_1323_),
    .Y(_1498_));
 sky130_fd_sc_hd__o21ai_0 _4159_ (.A1(\u_strike_counter.clean_counter[2] ),
    .A2(_1497_),
    .B1(_1318_),
    .Y(_1499_));
 sky130_fd_sc_hd__nor2_1 _4160_ (.A(_1498_),
    .B(_1499_),
    .Y(_0539_));
 sky130_fd_sc_hd__o21ai_0 _4161_ (.A1(\u_strike_counter.clean_counter[3] ),
    .A2(_1498_),
    .B1(_1318_),
    .Y(_1500_));
 sky130_fd_sc_hd__a21oi_1 _4162_ (.A1(\u_strike_counter.clean_counter[3] ),
    .A2(_1498_),
    .B1(_1500_),
    .Y(_0538_));
 sky130_fd_sc_hd__nand2_1 _4163_ (.A(\fault_count_ss[4] ),
    .B(_0688_),
    .Y(_0751_));
 sky130_fd_sc_hd__and3_1 _4164_ (.A(\u_strike_counter.clean_counter[3] ),
    .B(\u_strike_counter.clean_counter[4] ),
    .C(_1498_),
    .X(_1501_));
 sky130_fd_sc_hd__a21oi_1 _4165_ (.A1(\u_strike_counter.clean_counter[3] ),
    .A2(_1498_),
    .B1(\u_strike_counter.clean_counter[4] ),
    .Y(_1502_));
 sky130_fd_sc_hd__nor3_1 _4166_ (.A(_1319_),
    .B(_1501_),
    .C(_1502_),
    .Y(_0537_));
 sky130_fd_sc_hd__nor4_1 _4167_ (.A(_0767_),
    .B(_1101_),
    .C(_1323_),
    .D(_1324_),
    .Y(_1503_));
 sky130_fd_sc_hd__o21ai_0 _4168_ (.A1(\u_strike_counter.clean_counter[5] ),
    .A2(_1501_),
    .B1(_1318_),
    .Y(_1504_));
 sky130_fd_sc_hd__nor2_1 _4169_ (.A(_1503_),
    .B(_1504_),
    .Y(_0536_));
 sky130_fd_sc_hd__nor2b_2 _4170_ (.A(_1321_),
    .B_N(_1325_),
    .Y(_1505_));
 sky130_fd_sc_hd__o21ai_0 _4171_ (.A1(\u_strike_counter.clean_counter[6] ),
    .A2(_1503_),
    .B1(_1318_),
    .Y(_1506_));
 sky130_fd_sc_hd__nor2_1 _4172_ (.A(_1505_),
    .B(_1506_),
    .Y(_0535_));
 sky130_fd_sc_hd__o21ai_0 _4173_ (.A1(\u_strike_counter.clean_counter[7] ),
    .A2(_1505_),
    .B1(_1318_),
    .Y(_1507_));
 sky130_fd_sc_hd__maj3_1 _4174_ (.A(_0666_),
    .B(\g_telemetry.u_reg_file.trip_ss[3] ),
    .C(_0750_),
    .X(_0752_));
 sky130_fd_sc_hd__a21oi_1 _4175_ (.A1(\u_strike_counter.clean_counter[7] ),
    .A2(_1505_),
    .B1(_1507_),
    .Y(_0534_));
 sky130_fd_sc_hd__a21oi_1 _4176_ (.A1(\u_strike_counter.clean_counter[7] ),
    .A2(_1505_),
    .B1(\u_strike_counter.clean_counter[8] ),
    .Y(_1508_));
 sky130_fd_sc_hd__a211oi_1 _4177_ (.A1(_1326_),
    .A2(_1505_),
    .B1(_1508_),
    .C1(_1319_),
    .Y(_0533_));
 sky130_fd_sc_hd__a21oi_1 _4178_ (.A1(_1326_),
    .A2(_1505_),
    .B1(\u_strike_counter.clean_counter[9] ),
    .Y(_1509_));
 sky130_fd_sc_hd__and4_1 _4179_ (.A(\u_strike_counter.clean_counter[9] ),
    .B(_1320_),
    .C(_1325_),
    .D(_1326_),
    .X(_1510_));
 sky130_fd_sc_hd__nor3_1 _4180_ (.A(_1319_),
    .B(_1509_),
    .C(_1510_),
    .Y(_0532_));
 sky130_fd_sc_hd__nor2b_1 _4181_ (.A(_1321_),
    .B_N(_1327_),
    .Y(_1511_));
 sky130_fd_sc_hd__o21ai_0 _4182_ (.A1(\u_strike_counter.clean_counter[10] ),
    .A2(_1510_),
    .B1(_1318_),
    .Y(_1512_));
 sky130_fd_sc_hd__nor2_1 _4183_ (.A(_1511_),
    .B(_1512_),
    .Y(_0531_));
 sky130_fd_sc_hd__and3_1 _4184_ (.A(\u_strike_counter.clean_counter[11] ),
    .B(_1320_),
    .C(_1327_),
    .X(_1513_));
 sky130_fd_sc_hd__dfrtp_2 _4185_ (.D(_0573_),
    .Q(latch_out),
    .RESET_B(net12),
    .CLK(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4186_ (.D(_0574_),
    .Q(hiccup_done),
    .RESET_B(net6),
    .CLK(clknet_6_25__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4187_ (.D(_0571_),
    .Q(\u_hiccup_timer.cool_counter[0] ),
    .RESET_B(net6),
    .CLK(clknet_6_22__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4188_ (.D(_0570_),
    .Q(\u_hiccup_timer.cool_counter[1] ),
    .RESET_B(net6),
    .CLK(clknet_6_22__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4189_ (.D(_0569_),
    .Q(\u_hiccup_timer.cool_counter[2] ),
    .RESET_B(net6),
    .CLK(clknet_6_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4190_ (.D(_0568_),
    .Q(\u_hiccup_timer.cool_counter[3] ),
    .RESET_B(net6),
    .CLK(clknet_6_22__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4191_ (.D(_0567_),
    .Q(\u_hiccup_timer.cool_counter[4] ),
    .RESET_B(net6),
    .CLK(clknet_6_22__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4192_ (.D(_0566_),
    .Q(\u_hiccup_timer.cool_counter[5] ),
    .RESET_B(net6),
    .CLK(clknet_6_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4193_ (.D(_0565_),
    .Q(\u_hiccup_timer.cool_counter[6] ),
    .RESET_B(net6),
    .CLK(clknet_6_22__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4194_ (.D(_0564_),
    .Q(\u_hiccup_timer.cool_counter[7] ),
    .RESET_B(net6),
    .CLK(clknet_6_22__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4195_ (.D(_0563_),
    .Q(\u_hiccup_timer.cool_counter[8] ),
    .RESET_B(net6),
    .CLK(clknet_6_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4196_ (.D(_0562_),
    .Q(\u_hiccup_timer.cool_counter[9] ),
    .RESET_B(net6),
    .CLK(clknet_6_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4197_ (.D(_0561_),
    .Q(\u_hiccup_timer.cool_counter[10] ),
    .RESET_B(net6),
    .CLK(clknet_6_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4198_ (.D(_0560_),
    .Q(\u_hiccup_timer.cool_counter[11] ),
    .RESET_B(net6),
    .CLK(clknet_6_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4199_ (.D(_0559_),
    .Q(\u_hiccup_timer.cool_counter[12] ),
    .RESET_B(net6),
    .CLK(clknet_6_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4200_ (.D(_0558_),
    .Q(\u_hiccup_timer.cool_counter[13] ),
    .RESET_B(net6),
    .CLK(clknet_6_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4201_ (.D(_0557_),
    .Q(\u_hiccup_timer.cool_counter[14] ),
    .RESET_B(net2),
    .CLK(clknet_6_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4202_ (.D(_0556_),
    .Q(\u_hiccup_timer.cool_counter[15] ),
    .RESET_B(net2),
    .CLK(clknet_6_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4203_ (.D(_0555_),
    .Q(\u_hiccup_timer.cool_counter[16] ),
    .RESET_B(net2),
    .CLK(clknet_6_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4204_ (.D(_0554_),
    .Q(\u_hiccup_timer.cool_counter[17] ),
    .RESET_B(net2),
    .CLK(clknet_6_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4205_ (.D(_0553_),
    .Q(\u_hiccup_timer.cool_counter[18] ),
    .RESET_B(net2),
    .CLK(clknet_6_20__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4206_ (.D(_0575_),
    .Q(\u_hiccup_timer.cool_counter[19] ),
    .RESET_B(net2),
    .CLK(clknet_6_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4207_ (.D(_0552_),
    .Q(\u_pgood_gen.qualify_counter[0] ),
    .RESET_B(net11),
    .CLK(clknet_6_33__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4208_ (.D(_0551_),
    .Q(\u_pgood_gen.qualify_counter[1] ),
    .RESET_B(net11),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4209_ (.D(_0550_),
    .Q(\u_pgood_gen.qualify_counter[2] ),
    .RESET_B(net11),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4210_ (.D(_0549_),
    .Q(\u_pgood_gen.qualify_counter[3] ),
    .RESET_B(net11),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4211_ (.D(_0548_),
    .Q(\u_pgood_gen.qualify_counter[4] ),
    .RESET_B(net11),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4212_ (.D(_0547_),
    .Q(\u_pgood_gen.qualify_counter[5] ),
    .RESET_B(net11),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4213_ (.D(_0546_),
    .Q(\u_pgood_gen.qualify_counter[6] ),
    .RESET_B(net11),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4214_ (.D(_0545_),
    .Q(\u_pgood_gen.qualify_counter[7] ),
    .RESET_B(net11),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4215_ (.D(_0544_),
    .Q(\u_pgood_gen.qualify_counter[8] ),
    .RESET_B(net11),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4216_ (.D(_0543_),
    .Q(\u_pgood_gen.qualify_counter[9] ),
    .RESET_B(net11),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4217_ (.D(_0542_),
    .Q(\u_pgood_gen.qualify_counter[10] ),
    .RESET_B(net11),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4218_ (.D(_0576_),
    .Q(\u_pgood_gen.qualify_counter[11] ),
    .RESET_B(net11),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4219_ (.D(_0541_),
    .Q(\u_strike_counter.clean_counter[0] ),
    .RESET_B(net12),
    .CLK(clknet_6_33__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4220_ (.D(_0540_),
    .Q(\u_strike_counter.clean_counter[1] ),
    .RESET_B(net12),
    .CLK(clknet_6_33__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4221_ (.D(_0539_),
    .Q(\u_strike_counter.clean_counter[2] ),
    .RESET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4222_ (.D(_0538_),
    .Q(\u_strike_counter.clean_counter[3] ),
    .RESET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4223_ (.D(_0537_),
    .Q(\u_strike_counter.clean_counter[4] ),
    .RESET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4224_ (.D(_0536_),
    .Q(\u_strike_counter.clean_counter[5] ),
    .RESET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4225_ (.D(_0535_),
    .Q(\u_strike_counter.clean_counter[6] ),
    .RESET_B(net12),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4226_ (.D(_0534_),
    .Q(\u_strike_counter.clean_counter[7] ),
    .RESET_B(net12),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4227_ (.D(_0533_),
    .Q(\u_strike_counter.clean_counter[8] ),
    .RESET_B(net12),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4228_ (.D(_0532_),
    .Q(\u_strike_counter.clean_counter[9] ),
    .RESET_B(net12),
    .CLK(clknet_6_33__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4229_ (.D(_0531_),
    .Q(\u_strike_counter.clean_counter[10] ),
    .RESET_B(net11),
    .CLK(clknet_6_33__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4230_ (.D(_0530_),
    .Q(\u_strike_counter.clean_counter[11] ),
    .RESET_B(net11),
    .CLK(clknet_6_33__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4231_ (.D(_0529_),
    .Q(\u_strike_counter.clean_counter[12] ),
    .RESET_B(net11),
    .CLK(clknet_6_33__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4232_ (.D(_0528_),
    .Q(\u_strike_counter.clean_counter[13] ),
    .RESET_B(net10),
    .CLK(clknet_6_33__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4233_ (.D(_0527_),
    .Q(\u_strike_counter.clean_counter[14] ),
    .RESET_B(net10),
    .CLK(clknet_6_33__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4234_ (.D(_0526_),
    .Q(\u_strike_counter.clean_counter[15] ),
    .RESET_B(net10),
    .CLK(clknet_6_36__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4235_ (.D(_0525_),
    .Q(\u_strike_counter.clean_counter[16] ),
    .RESET_B(net12),
    .CLK(clknet_6_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4236_ (.D(_0524_),
    .Q(\u_strike_counter.clean_counter[17] ),
    .RESET_B(net12),
    .CLK(clknet_6_36__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4237_ (.D(_0577_),
    .Q(\u_strike_counter.clean_counter[18] ),
    .RESET_B(net12),
    .CLK(clknet_6_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4238_ (.D(_0578_),
    .Q(SS_done),
    .RESET_B(net7),
    .CLK(clknet_6_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4239_ (.D(_0523_),
    .Q(\g_telemetry.u_spi_slave.held_data[0] ),
    .RESET_B(net11),
    .CLK(clknet_6_34__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4240_ (.D(_0522_),
    .Q(\g_telemetry.u_spi_slave.held_data[1] ),
    .RESET_B(net11),
    .CLK(clknet_6_38__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4241_ (.D(_0521_),
    .Q(\g_telemetry.u_spi_slave.held_data[2] ),
    .RESET_B(net11),
    .CLK(clknet_6_35__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4242_ (.D(_0520_),
    .Q(\g_telemetry.u_spi_slave.held_data[3] ),
    .RESET_B(net11),
    .CLK(clknet_6_35__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4243_ (.D(_0519_),
    .Q(\g_telemetry.u_spi_slave.held_data[4] ),
    .RESET_B(net9),
    .CLK(clknet_6_41__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4244_ (.D(_0518_),
    .Q(\g_telemetry.u_spi_slave.held_data[5] ),
    .RESET_B(net11),
    .CLK(clknet_6_35__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4245_ (.D(_0517_),
    .Q(\g_telemetry.u_spi_slave.held_data[6] ),
    .RESET_B(net11),
    .CLK(clknet_6_35__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4246_ (.D(_0579_),
    .Q(\g_telemetry.u_spi_slave.held_data[7] ),
    .RESET_B(net9),
    .CLK(clknet_6_41__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4247_ (.D(_0581_),
    .Q(\g_telemetry.u_spi_slave.held_valid ),
    .RESET_B(net9),
    .CLK(clknet_6_44__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4248_ (.D(_0582_),
    .Q(\g_telemetry.u_spi_slave.sdio_out ),
    .RESET_B(net9),
    .CLK(clknet_6_47__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4249_ (.D(_0516_),
    .Q(\fault_count_ss[0] ),
    .RESET_B(net12),
    .CLK(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4250_ (.D(_0515_),
    .Q(\fault_count_ss[1] ),
    .RESET_B(net12),
    .CLK(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4251_ (.D(_0514_),
    .Q(\fault_count_ss[2] ),
    .RESET_B(net12),
    .CLK(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4252_ (.D(_0513_),
    .Q(\fault_count_ss[3] ),
    .RESET_B(net12),
    .CLK(clknet_6_27__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4253_ (.D(_0512_),
    .Q(\fault_count_ss[4] ),
    .RESET_B(net12),
    .CLK(clknet_6_27__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4254_ (.D(_0583_),
    .Q(\fault_count_ss[5] ),
    .RESET_B(net12),
    .CLK(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4255_ (.D(_0511_),
    .Q(\fault_count_run[0] ),
    .RESET_B(net7),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4256_ (.D(_0510_),
    .Q(\fault_count_run[1] ),
    .RESET_B(net7),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4257_ (.D(_0509_),
    .Q(\fault_count_run[2] ),
    .RESET_B(net7),
    .CLK(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4258_ (.D(_0508_),
    .Q(\fault_count_run[3] ),
    .RESET_B(net7),
    .CLK(clknet_6_27__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4259_ (.D(_0584_),
    .Q(\fault_count_run[4] ),
    .RESET_B(net7),
    .CLK(clknet_6_27__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4260_ (.D(_0507_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[0] ),
    .RESET_B(net7),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4261_ (.D(_0506_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[1] ),
    .RESET_B(net7),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4262_ (.D(_0505_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[2] ),
    .RESET_B(net7),
    .CLK(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4263_ (.D(_0504_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[3] ),
    .RESET_B(net7),
    .CLK(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4264_ (.D(_0503_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[4] ),
    .RESET_B(net7),
    .CLK(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4265_ (.D(_0502_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[5] ),
    .RESET_B(net7),
    .CLK(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4266_ (.D(_0501_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[6] ),
    .RESET_B(net7),
    .CLK(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4267_ (.D(_0500_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[7] ),
    .RESET_B(net7),
    .CLK(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4268_ (.D(_0499_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[8] ),
    .RESET_B(net7),
    .CLK(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4269_ (.D(_0498_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[9] ),
    .RESET_B(net7),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4270_ (.D(_0497_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[10] ),
    .RESET_B(net7),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4271_ (.D(_0496_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[11] ),
    .RESET_B(net7),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4272_ (.D(_0495_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[12] ),
    .RESET_B(net7),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4273_ (.D(_0494_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[13] ),
    .RESET_B(net7),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4274_ (.D(_0493_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[14] ),
    .RESET_B(net7),
    .CLK(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4275_ (.D(_0585_),
    .Q(\u_fault_arbiter.fault_shifter_RUN[15] ),
    .RESET_B(net7),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4276_ (.D(_0492_),
    .Q(\u_fault_arbiter.fault_shifter_SS[0] ),
    .RESET_B(net12),
    .CLK(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4277_ (.D(_0491_),
    .Q(\u_fault_arbiter.fault_shifter_SS[1] ),
    .RESET_B(net12),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4278_ (.D(_0490_),
    .Q(\u_fault_arbiter.fault_shifter_SS[2] ),
    .RESET_B(net12),
    .CLK(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4279_ (.D(_0489_),
    .Q(\u_fault_arbiter.fault_shifter_SS[3] ),
    .RESET_B(net12),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4280_ (.D(_0488_),
    .Q(\u_fault_arbiter.fault_shifter_SS[4] ),
    .RESET_B(net12),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4281_ (.D(_0487_),
    .Q(\u_fault_arbiter.fault_shifter_SS[5] ),
    .RESET_B(net12),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4282_ (.D(_0486_),
    .Q(\u_fault_arbiter.fault_shifter_SS[6] ),
    .RESET_B(net12),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4283_ (.D(_0485_),
    .Q(\u_fault_arbiter.fault_shifter_SS[7] ),
    .RESET_B(net12),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4284_ (.D(_0484_),
    .Q(\u_fault_arbiter.fault_shifter_SS[8] ),
    .RESET_B(net12),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4285_ (.D(_0483_),
    .Q(\u_fault_arbiter.fault_shifter_SS[9] ),
    .RESET_B(net5),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4286_ (.D(_0482_),
    .Q(\u_fault_arbiter.fault_shifter_SS[10] ),
    .RESET_B(net5),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4287_ (.D(_0481_),
    .Q(\u_fault_arbiter.fault_shifter_SS[11] ),
    .RESET_B(net5),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4288_ (.D(_0480_),
    .Q(\u_fault_arbiter.fault_shifter_SS[12] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4289_ (.D(_0479_),
    .Q(\u_fault_arbiter.fault_shifter_SS[13] ),
    .RESET_B(net5),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4290_ (.D(_0478_),
    .Q(\u_fault_arbiter.fault_shifter_SS[14] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4291_ (.D(_0477_),
    .Q(\u_fault_arbiter.fault_shifter_SS[15] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4292_ (.D(_0476_),
    .Q(\u_fault_arbiter.fault_shifter_SS[16] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4293_ (.D(_0475_),
    .Q(\u_fault_arbiter.fault_shifter_SS[17] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4294_ (.D(_0474_),
    .Q(\u_fault_arbiter.fault_shifter_SS[18] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4295_ (.D(_0473_),
    .Q(\u_fault_arbiter.fault_shifter_SS[19] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4296_ (.D(_0472_),
    .Q(\u_fault_arbiter.fault_shifter_SS[20] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4297_ (.D(_0471_),
    .Q(\u_fault_arbiter.fault_shifter_SS[21] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4298_ (.D(_0470_),
    .Q(\u_fault_arbiter.fault_shifter_SS[22] ),
    .RESET_B(net5),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4299_ (.D(_0469_),
    .Q(\u_fault_arbiter.fault_shifter_SS[23] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4300_ (.D(_0468_),
    .Q(\u_fault_arbiter.fault_shifter_SS[24] ),
    .RESET_B(net5),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4301_ (.D(_0467_),
    .Q(\u_fault_arbiter.fault_shifter_SS[25] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4302_ (.D(_0466_),
    .Q(\u_fault_arbiter.fault_shifter_SS[26] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4303_ (.D(_0465_),
    .Q(\u_fault_arbiter.fault_shifter_SS[27] ),
    .RESET_B(net5),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4304_ (.D(_0464_),
    .Q(\u_fault_arbiter.fault_shifter_SS[28] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4305_ (.D(_0463_),
    .Q(\u_fault_arbiter.fault_shifter_SS[29] ),
    .RESET_B(net12),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4306_ (.D(_0462_),
    .Q(\u_fault_arbiter.fault_shifter_SS[30] ),
    .RESET_B(net12),
    .CLK(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4307_ (.D(_0586_),
    .Q(\u_fault_arbiter.fault_shifter_SS[31] ),
    .RESET_B(net12),
    .CLK(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4308_ (.D(_0461_),
    .Q(\max_on_counts[0] ),
    .SET_B(net3),
    .CLK(clknet_6_13__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4309_ (.D(_0460_),
    .Q(\max_on_counts[1] ),
    .SET_B(net3),
    .CLK(clknet_6_12__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4310_ (.D(_0459_),
    .Q(\max_on_counts[2] ),
    .RESET_B(net3),
    .CLK(clknet_6_6__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4311_ (.D(_0458_),
    .Q(\max_on_counts[3] ),
    .RESET_B(net3),
    .CLK(clknet_6_6__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4312_ (.D(_0587_),
    .Q(\max_on_counts[4] ),
    .RESET_B(net3),
    .CLK(clknet_6_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4313_ (.D(_0457_),
    .Q(\u_soft_start.cycle_counter[0] ),
    .RESET_B(net12),
    .CLK(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4314_ (.D(_0456_),
    .Q(\u_soft_start.cycle_counter[1] ),
    .RESET_B(net12),
    .CLK(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4315_ (.D(_0455_),
    .Q(\u_soft_start.cycle_counter[2] ),
    .RESET_B(net5),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4316_ (.D(_0454_),
    .Q(\u_soft_start.cycle_counter[3] ),
    .RESET_B(net5),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4317_ (.D(_0453_),
    .Q(\u_soft_start.cycle_counter[4] ),
    .RESET_B(net12),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4318_ (.D(_0452_),
    .Q(\u_soft_start.cycle_counter[5] ),
    .RESET_B(net12),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4319_ (.D(_0588_),
    .Q(\u_soft_start.cycle_counter[6] ),
    .RESET_B(net12),
    .CLK(clknet_6_49__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4320_ (.D(_0451_),
    .Q(\u_pwm_mask.run_counter[0] ),
    .RESET_B(net3),
    .CLK(clknet_6_3__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4321_ (.D(_0450_),
    .Q(\u_pwm_mask.run_counter[1] ),
    .RESET_B(net3),
    .CLK(clknet_6_3__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4322_ (.D(_0449_),
    .Q(\u_pwm_mask.run_counter[2] ),
    .RESET_B(net3),
    .CLK(clknet_6_3__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4323_ (.D(_0448_),
    .Q(\u_pwm_mask.run_counter[3] ),
    .RESET_B(net3),
    .CLK(clknet_6_6__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4324_ (.D(_0589_),
    .Q(\u_pwm_mask.run_counter[4] ),
    .RESET_B(net3),
    .CLK(clknet_6_6__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4325_ (.D(_0447_),
    .Q(\g_telemetry.u_spi_slave.tx_shift[0] ),
    .RESET_B(net9),
    .CLK(clknet_6_47__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4326_ (.D(_0446_),
    .Q(\g_telemetry.u_spi_slave.tx_shift[1] ),
    .RESET_B(net9),
    .CLK(clknet_6_47__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4327_ (.D(_0445_),
    .Q(\g_telemetry.u_spi_slave.tx_shift[2] ),
    .RESET_B(net9),
    .CLK(clknet_6_47__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4328_ (.D(_0444_),
    .Q(\g_telemetry.u_spi_slave.tx_shift[3] ),
    .RESET_B(net9),
    .CLK(clknet_6_47__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4329_ (.D(_0443_),
    .Q(\g_telemetry.u_spi_slave.tx_shift[4] ),
    .RESET_B(net9),
    .CLK(clknet_6_58__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4330_ (.D(_0442_),
    .Q(\g_telemetry.u_spi_slave.tx_shift[5] ),
    .RESET_B(net8),
    .CLK(clknet_6_58__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4331_ (.D(_0590_),
    .Q(\g_telemetry.u_spi_slave.tx_shift[6] ),
    .RESET_B(net8),
    .CLK(clknet_6_58__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4332_ (.D(_0441_),
    .Q(\g_telemetry.u_spi_slave.bit_count[0] ),
    .RESET_B(net9),
    .CLK(clknet_6_46__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4333_ (.D(_0440_),
    .Q(\g_telemetry.u_spi_slave.bit_count[1] ),
    .RESET_B(net9),
    .CLK(clknet_6_46__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4334_ (.D(_0591_),
    .Q(\g_telemetry.u_spi_slave.bit_count[2] ),
    .RESET_B(net9),
    .CLK(clknet_6_46__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4335_ (.D(_0439_),
    .Q(\g_telemetry.u_spi_slave.crc[0] ),
    .RESET_B(net9),
    .CLK(clknet_6_43__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4336_ (.D(_0438_),
    .Q(\g_telemetry.u_spi_slave.crc[1] ),
    .RESET_B(net9),
    .CLK(clknet_6_43__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4337_ (.D(_0437_),
    .Q(\g_telemetry.u_spi_slave.crc[2] ),
    .RESET_B(net9),
    .CLK(clknet_6_43__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4338_ (.D(_0436_),
    .Q(\g_telemetry.u_spi_slave.crc[3] ),
    .RESET_B(net9),
    .CLK(clknet_6_43__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4339_ (.D(_0435_),
    .Q(\g_telemetry.u_spi_slave.crc[4] ),
    .RESET_B(net9),
    .CLK(clknet_6_46__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4340_ (.D(_0434_),
    .Q(\g_telemetry.u_spi_slave.crc[5] ),
    .RESET_B(net9),
    .CLK(clknet_6_46__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4341_ (.D(_0433_),
    .Q(\g_telemetry.u_spi_slave.crc[6] ),
    .RESET_B(net9),
    .CLK(clknet_6_46__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4342_ (.D(_0592_),
    .Q(\g_telemetry.u_spi_slave.crc[7] ),
    .RESET_B(net9),
    .CLK(clknet_6_43__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4343_ (.D(_0432_),
    .Q(\g_telemetry.u_spi_slave.byte_count[0] ),
    .RESET_B(net9),
    .CLK(clknet_6_47__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4344_ (.D(_0431_),
    .Q(\g_telemetry.u_spi_slave.byte_count[1] ),
    .RESET_B(net9),
    .CLK(clknet_6_46__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4345_ (.D(_0430_),
    .Q(\g_telemetry.u_spi_slave.byte_count[2] ),
    .RESET_B(net9),
    .CLK(clknet_6_46__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4346_ (.D(_0594_),
    .Q(\g_telemetry.u_spi_slave.byte_count[3] ),
    .RESET_B(net9),
    .CLK(clknet_6_46__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4347_ (.D(_0429_),
    .Q(\g_telemetry.u_reg_file.wdata[0] ),
    .RESET_B(net11),
    .CLK(clknet_6_33__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4348_ (.D(_0428_),
    .Q(\g_telemetry.u_reg_file.wdata[1] ),
    .RESET_B(net11),
    .CLK(clknet_6_36__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4349_ (.D(_0427_),
    .Q(\g_telemetry.u_reg_file.wdata[2] ),
    .RESET_B(net11),
    .CLK(clknet_6_38__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4350_ (.D(_0426_),
    .Q(\g_telemetry.u_reg_file.wdata[3] ),
    .RESET_B(net11),
    .CLK(clknet_6_36__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4351_ (.D(_0425_),
    .Q(\g_telemetry.u_reg_file.wdata[4] ),
    .RESET_B(net9),
    .CLK(clknet_6_41__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4352_ (.D(_0424_),
    .Q(\g_telemetry.u_reg_file.wdata[5] ),
    .RESET_B(net10),
    .CLK(clknet_6_33__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4353_ (.D(_0423_),
    .Q(\g_telemetry.u_reg_file.wdata[6] ),
    .RESET_B(net11),
    .CLK(clknet_6_35__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4354_ (.D(_0595_),
    .Q(\g_telemetry.u_reg_file.wdata[7] ),
    .RESET_B(net9),
    .CLK(clknet_6_41__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4355_ (.D(_0596_),
    .Q(\u_fault_LED.blink ),
    .RESET_B(net4),
    .CLK(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4356_ (.D(_0597_),
    .Q(\g_telemetry.u_spi_slave.rw ),
    .RESET_B(net9),
    .CLK(clknet_6_44__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4357_ (.D(_0598_),
    .Q(\g_spi_filt.u_sck_filt.flag_out ),
    .RESET_B(net9),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4358_ (.D(_0422_),
    .Q(\g_spi_filt.u_sck_filt.disagree_counter[0] ),
    .RESET_B(net11),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4359_ (.D(_0421_),
    .Q(\g_spi_filt.u_sck_filt.disagree_counter[1] ),
    .RESET_B(net11),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4360_ (.D(_0420_),
    .Q(\g_spi_filt.u_sck_filt.disagree_counter[2] ),
    .RESET_B(net11),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4361_ (.D(_0599_),
    .Q(\g_spi_filt.u_sck_filt.disagree_counter[3] ),
    .RESET_B(net9),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4362_ (.D(_0419_),
    .Q(\g_telemetry.u_spi_slave.rx_byte[1] ),
    .RESET_B(net11),
    .CLK(clknet_6_38__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4363_ (.D(_0418_),
    .Q(\g_telemetry.u_spi_slave.rx_byte[2] ),
    .RESET_B(net11),
    .CLK(clknet_6_38__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4364_ (.D(_0417_),
    .Q(\g_telemetry.u_spi_slave.rx_byte[3] ),
    .RESET_B(net11),
    .CLK(clknet_6_38__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4365_ (.D(_0416_),
    .Q(\g_telemetry.u_spi_slave.rx_byte[4] ),
    .RESET_B(net11),
    .CLK(clknet_6_44__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4366_ (.D(_0415_),
    .Q(\g_telemetry.u_spi_slave.rx_byte[5] ),
    .RESET_B(net11),
    .CLK(clknet_6_44__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4367_ (.D(_0414_),
    .Q(\g_telemetry.u_spi_slave.rx_byte[6] ),
    .RESET_B(net11),
    .CLK(clknet_6_44__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4368_ (.D(_0600_),
    .Q(\g_telemetry.u_spi_slave.rx_byte[7] ),
    .RESET_B(net9),
    .CLK(clknet_6_41__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4369_ (.D(_0413_),
    .Q(\g_telemetry.u_reg_file.strike_level[0] ),
    .RESET_B(net3),
    .CLK(clknet_6_24__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4370_ (.D(_0601_),
    .Q(\g_telemetry.u_reg_file.strike_level[1] ),
    .RESET_B(net3),
    .CLK(clknet_6_24__leaf_clk));
 sky130_fd_sc_hd__dfstp_4 _4371_ (.D(_0608_),
    .Q(\g_telemetry.u_fault_cause.latch_state ),
    .SET_B(net4),
    .CLK(clknet_6_3__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4372_ (.D(_0412_),
    .Q(\u_latch_stat_sync_db.disagree_counter[0] ),
    .RESET_B(net4),
    .CLK(clknet_6_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4373_ (.D(_0411_),
    .Q(\u_latch_stat_sync_db.disagree_counter[1] ),
    .RESET_B(net4),
    .CLK(clknet_6_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4374_ (.D(_0410_),
    .Q(\u_latch_stat_sync_db.disagree_counter[2] ),
    .RESET_B(net4),
    .CLK(clknet_6_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4375_ (.D(_0409_),
    .Q(\u_latch_stat_sync_db.disagree_counter[3] ),
    .RESET_B(net4),
    .CLK(clknet_6_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4376_ (.D(_0408_),
    .Q(\u_latch_stat_sync_db.disagree_counter[4] ),
    .RESET_B(net4),
    .CLK(clknet_6_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4377_ (.D(_0407_),
    .Q(\u_latch_stat_sync_db.disagree_counter[5] ),
    .RESET_B(net4),
    .CLK(clknet_6_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4378_ (.D(_0406_),
    .Q(\u_latch_stat_sync_db.disagree_counter[6] ),
    .RESET_B(net4),
    .CLK(clknet_6_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4379_ (.D(_0405_),
    .Q(\u_latch_stat_sync_db.disagree_counter[7] ),
    .RESET_B(net4),
    .CLK(clknet_6_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4380_ (.D(_0404_),
    .Q(\u_latch_stat_sync_db.disagree_counter[8] ),
    .RESET_B(net4),
    .CLK(clknet_6_3__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4381_ (.D(_0403_),
    .Q(\u_latch_stat_sync_db.disagree_counter[9] ),
    .RESET_B(net4),
    .CLK(clknet_6_3__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4382_ (.D(_0402_),
    .Q(\u_latch_stat_sync_db.disagree_counter[10] ),
    .RESET_B(net4),
    .CLK(clknet_6_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4383_ (.D(_0401_),
    .Q(\u_latch_stat_sync_db.disagree_counter[11] ),
    .RESET_B(net4),
    .CLK(clknet_6_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4384_ (.D(_0400_),
    .Q(\u_latch_stat_sync_db.disagree_counter[12] ),
    .RESET_B(net4),
    .CLK(clknet_6_2__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4385_ (.D(_0609_),
    .Q(\u_latch_stat_sync_db.disagree_counter[13] ),
    .RESET_B(net4),
    .CLK(clknet_6_2__leaf_clk));
 sky130_fd_sc_hd__dfstp_4 _4386_ (.D(_0610_),
    .Q(UVLO_sync_db),
    .SET_B(net11),
    .CLK(clknet_6_34__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4387_ (.D(_0399_),
    .Q(\u_UVLO_sync_db.disagree_counter[0] ),
    .RESET_B(net11),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4388_ (.D(_0398_),
    .Q(\u_UVLO_sync_db.disagree_counter[1] ),
    .RESET_B(net11),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4389_ (.D(_0397_),
    .Q(\u_UVLO_sync_db.disagree_counter[2] ),
    .RESET_B(net11),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4390_ (.D(_0396_),
    .Q(\u_UVLO_sync_db.disagree_counter[3] ),
    .RESET_B(net11),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4391_ (.D(_0395_),
    .Q(\u_UVLO_sync_db.disagree_counter[4] ),
    .RESET_B(net11),
    .CLK(clknet_6_40__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4392_ (.D(_0394_),
    .Q(\u_UVLO_sync_db.disagree_counter[5] ),
    .RESET_B(net11),
    .CLK(clknet_6_40__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4393_ (.D(_0393_),
    .Q(\u_UVLO_sync_db.disagree_counter[6] ),
    .RESET_B(net11),
    .CLK(clknet_6_40__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4394_ (.D(_0392_),
    .Q(\u_UVLO_sync_db.disagree_counter[7] ),
    .RESET_B(net11),
    .CLK(clknet_6_40__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4395_ (.D(_0391_),
    .Q(\u_UVLO_sync_db.disagree_counter[8] ),
    .RESET_B(net11),
    .CLK(clknet_6_40__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4396_ (.D(_0390_),
    .Q(\u_UVLO_sync_db.disagree_counter[9] ),
    .RESET_B(net9),
    .CLK(clknet_6_40__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4397_ (.D(_0389_),
    .Q(\u_UVLO_sync_db.disagree_counter[10] ),
    .RESET_B(net9),
    .CLK(clknet_6_40__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4398_ (.D(_0388_),
    .Q(\u_UVLO_sync_db.disagree_counter[11] ),
    .RESET_B(net9),
    .CLK(clknet_6_40__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4399_ (.D(_0387_),
    .Q(\u_UVLO_sync_db.disagree_counter[12] ),
    .RESET_B(net9),
    .CLK(clknet_6_40__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4400_ (.D(_0611_),
    .Q(\u_UVLO_sync_db.disagree_counter[13] ),
    .RESET_B(net9),
    .CLK(clknet_6_40__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4401_ (.D(_0613_),
    .Q(cs_n_filt),
    .SET_B(net9),
    .CLK(clknet_6_40__leaf_clk));
 sky130_fd_sc_hd__dfstp_4 _4402_ (.D(_0614_),
    .Q(\g_telemetry.u_reg_file.spi_enable ),
    .SET_B(net12),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfstp_4 _4403_ (.D(_0615_),
    .Q(OTP_sync_db),
    .SET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4404_ (.D(_0386_),
    .Q(\u_OTP_sync_db.disagree_counter[0] ),
    .RESET_B(net4),
    .CLK(clknet_6_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4405_ (.D(_0385_),
    .Q(\u_OTP_sync_db.disagree_counter[1] ),
    .RESET_B(net4),
    .CLK(clknet_6_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4406_ (.D(_0384_),
    .Q(\u_OTP_sync_db.disagree_counter[2] ),
    .RESET_B(net4),
    .CLK(clknet_6_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4407_ (.D(_0383_),
    .Q(\u_OTP_sync_db.disagree_counter[3] ),
    .RESET_B(net4),
    .CLK(clknet_6_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4408_ (.D(_0382_),
    .Q(\u_OTP_sync_db.disagree_counter[4] ),
    .RESET_B(net3),
    .CLK(clknet_6_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4409_ (.D(_0381_),
    .Q(\u_OTP_sync_db.disagree_counter[5] ),
    .RESET_B(net3),
    .CLK(clknet_6_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4410_ (.D(_0380_),
    .Q(\u_OTP_sync_db.disagree_counter[6] ),
    .RESET_B(net3),
    .CLK(clknet_6_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4411_ (.D(_0379_),
    .Q(\u_OTP_sync_db.disagree_counter[7] ),
    .RESET_B(net3),
    .CLK(clknet_6_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4412_ (.D(_0378_),
    .Q(\u_OTP_sync_db.disagree_counter[8] ),
    .RESET_B(net4),
    .CLK(clknet_6_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4413_ (.D(_0377_),
    .Q(\u_OTP_sync_db.disagree_counter[9] ),
    .RESET_B(net4),
    .CLK(clknet_6_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4414_ (.D(_0376_),
    .Q(\u_OTP_sync_db.disagree_counter[10] ),
    .RESET_B(net4),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4415_ (.D(_0375_),
    .Q(\u_OTP_sync_db.disagree_counter[11] ),
    .RESET_B(net4),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4416_ (.D(_0374_),
    .Q(\u_OTP_sync_db.disagree_counter[12] ),
    .RESET_B(net4),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4417_ (.D(_0616_),
    .Q(\u_OTP_sync_db.disagree_counter[13] ),
    .RESET_B(net4),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4418_ (.D(_0373_),
    .Q(\g_telemetry.u_reg_file.scratch_r[0] ),
    .RESET_B(net10),
    .CLK(clknet_6_48__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4419_ (.D(_0372_),
    .Q(\g_telemetry.u_reg_file.scratch_r[1] ),
    .RESET_B(net10),
    .CLK(clknet_6_50__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4420_ (.D(_0371_),
    .Q(\g_telemetry.u_reg_file.scratch_r[2] ),
    .RESET_B(net10),
    .CLK(clknet_6_50__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4421_ (.D(_0370_),
    .Q(\g_telemetry.u_reg_file.scratch_r[3] ),
    .RESET_B(net10),
    .CLK(clknet_6_50__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4422_ (.D(_0369_),
    .Q(\g_telemetry.u_reg_file.scratch_r[4] ),
    .RESET_B(net8),
    .CLK(clknet_6_57__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4423_ (.D(_0368_),
    .Q(\g_telemetry.u_reg_file.scratch_r[5] ),
    .RESET_B(net10),
    .CLK(clknet_6_50__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4424_ (.D(_0367_),
    .Q(\g_telemetry.u_reg_file.scratch_r[6] ),
    .RESET_B(net10),
    .CLK(clknet_6_50__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4425_ (.D(_0617_),
    .Q(\g_telemetry.u_reg_file.scratch_r[7] ),
    .RESET_B(net8),
    .CLK(clknet_6_57__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4426_ (.D(_0366_),
    .Q(\g_telemetry.u_reg_file.temp_trip_run[0] ),
    .RESET_B(net7),
    .CLK(clknet_6_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4427_ (.D(_0365_),
    .Q(\g_telemetry.u_reg_file.temp_trip_run[1] ),
    .RESET_B(net7),
    .CLK(clknet_6_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4428_ (.D(_0364_),
    .Q(\g_telemetry.u_reg_file.temp_trip_run[2] ),
    .RESET_B(net7),
    .CLK(clknet_6_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4429_ (.D(_0363_),
    .Q(\g_telemetry.u_reg_file.temp_trip_run[3] ),
    .RESET_B(net7),
    .CLK(clknet_6_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4430_ (.D(_0362_),
    .Q(\g_telemetry.u_reg_file.temp_trip_run[4] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4431_ (.D(_0361_),
    .Q(\g_telemetry.u_reg_file.temp_trip_run[5] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4432_ (.D(_0360_),
    .Q(\g_telemetry.u_reg_file.temp_trip_run[6] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4433_ (.D(_0618_),
    .Q(\g_telemetry.u_reg_file.temp_trip_run[7] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4434_ (.D(_0359_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[0] ),
    .RESET_B(net10),
    .CLK(clknet_6_51__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4435_ (.D(_0358_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[1] ),
    .RESET_B(net10),
    .CLK(clknet_6_50__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4436_ (.D(_0357_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[2] ),
    .RESET_B(net10),
    .CLK(clknet_6_51__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4437_ (.D(_0356_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[3] ),
    .RESET_B(net8),
    .CLK(clknet_6_57__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4438_ (.D(_0355_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[4] ),
    .RESET_B(net8),
    .CLK(clknet_6_60__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4439_ (.D(_0354_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[5] ),
    .RESET_B(net8),
    .CLK(clknet_6_62__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4440_ (.D(_0353_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[6] ),
    .RESET_B(net8),
    .CLK(clknet_6_57__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4441_ (.D(_0352_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[7] ),
    .RESET_B(net8),
    .CLK(clknet_6_58__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4442_ (.D(_0351_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[8] ),
    .RESET_B(net8),
    .CLK(clknet_6_63__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4443_ (.D(_0350_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[9] ),
    .RESET_B(net9),
    .CLK(clknet_6_58__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4444_ (.D(_0349_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[10] ),
    .RESET_B(net8),
    .CLK(clknet_6_59__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4445_ (.D(_0348_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[11] ),
    .RESET_B(net8),
    .CLK(clknet_6_62__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4446_ (.D(_0347_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[12] ),
    .RESET_B(net9),
    .CLK(clknet_6_58__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4447_ (.D(_0346_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[13] ),
    .RESET_B(net9),
    .CLK(clknet_6_58__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4448_ (.D(_0345_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[14] ),
    .RESET_B(net8),
    .CLK(clknet_6_59__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4449_ (.D(_0344_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[15] ),
    .RESET_B(net9),
    .CLK(clknet_6_58__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4450_ (.D(_0343_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[16] ),
    .RESET_B(net10),
    .CLK(clknet_6_51__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4451_ (.D(_0342_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[17] ),
    .RESET_B(net10),
    .CLK(clknet_6_50__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4452_ (.D(_0341_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[18] ),
    .RESET_B(net10),
    .CLK(clknet_6_51__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4453_ (.D(_0340_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[19] ),
    .RESET_B(net10),
    .CLK(clknet_6_60__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4454_ (.D(_0339_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[20] ),
    .RESET_B(net10),
    .CLK(clknet_6_54__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4455_ (.D(_0338_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[21] ),
    .RESET_B(net8),
    .CLK(clknet_6_62__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4456_ (.D(_0337_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[22] ),
    .RESET_B(net10),
    .CLK(clknet_6_54__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4457_ (.D(_0619_),
    .Q(\g_telemetry.u_reg_file.timestamp_snap[23] ),
    .RESET_B(net8),
    .CLK(clknet_6_60__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4458_ (.D(_0336_),
    .Q(\g_telemetry.u_reg_file.temp_trip_ss[0] ),
    .RESET_B(net6),
    .CLK(clknet_6_25__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4459_ (.D(_0335_),
    .Q(\g_telemetry.u_reg_file.temp_trip_ss[1] ),
    .RESET_B(net6),
    .CLK(clknet_6_24__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4460_ (.D(_0334_),
    .Q(\g_telemetry.u_reg_file.temp_trip_ss[2] ),
    .RESET_B(net3),
    .CLK(clknet_6_24__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4461_ (.D(_0333_),
    .Q(\g_telemetry.u_reg_file.temp_trip_ss[3] ),
    .RESET_B(net6),
    .CLK(clknet_6_25__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4462_ (.D(_0332_),
    .Q(\g_telemetry.u_reg_file.temp_trip_ss[4] ),
    .RESET_B(net3),
    .CLK(clknet_6_25__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4463_ (.D(_0331_),
    .Q(\g_telemetry.u_reg_file.temp_trip_ss[5] ),
    .RESET_B(net3),
    .CLK(clknet_6_19__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4464_ (.D(_0330_),
    .Q(\g_telemetry.u_reg_file.temp_trip_ss[6] ),
    .RESET_B(net3),
    .CLK(clknet_6_25__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4465_ (.D(_0620_),
    .Q(\g_telemetry.u_reg_file.temp_trip_ss[7] ),
    .RESET_B(net3),
    .CLK(clknet_6_25__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4466_ (.D(_0621_),
    .Q(\g_telemetry.u_reg_file.en_pending ),
    .RESET_B(net12),
    .CLK(clknet_6_48__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4467_ (.D(_0622_),
    .Q(\g_telemetry.u_reg_file.en_pending_val ),
    .RESET_B(net12),
    .CLK(clknet_6_48__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4468_ (.D(_0329_),
    .Q(\g_telemetry.u_reg_file.temp_clean_2[0] ),
    .RESET_B(net3),
    .CLK(clknet_6_12__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4469_ (.D(_0328_),
    .Q(\g_telemetry.u_reg_file.temp_clean_2[1] ),
    .RESET_B(net3),
    .CLK(clknet_6_12__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4470_ (.D(_0327_),
    .Q(\g_telemetry.u_reg_file.temp_clean_2[2] ),
    .RESET_B(net7),
    .CLK(clknet_6_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4471_ (.D(_0326_),
    .Q(\g_telemetry.u_reg_file.temp_clean_2[3] ),
    .RESET_B(net2),
    .CLK(clknet_6_3__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4472_ (.D(_0325_),
    .Q(\g_telemetry.u_reg_file.temp_clean_2[4] ),
    .RESET_B(net2),
    .CLK(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4473_ (.D(_0324_),
    .Q(\g_telemetry.u_reg_file.temp_clean_2[5] ),
    .RESET_B(net2),
    .CLK(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4474_ (.D(_0323_),
    .Q(\g_telemetry.u_reg_file.temp_clean_2[6] ),
    .RESET_B(net2),
    .CLK(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4475_ (.D(_0623_),
    .Q(\g_telemetry.u_reg_file.temp_clean_2[7] ),
    .RESET_B(net2),
    .CLK(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4476_ (.D(_0624_),
    .Q(\g_telemetry.u_reg_file.wd_restored ),
    .RESET_B(net12),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4477_ (.D(_0322_),
    .Q(\g_telemetry.u_reg_file.temp_max_strk[0] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4478_ (.D(_0321_),
    .Q(\g_telemetry.u_reg_file.temp_max_strk[1] ),
    .RESET_B(net3),
    .CLK(clknet_6_7__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4479_ (.D(_0320_),
    .Q(\g_telemetry.u_reg_file.temp_max_strk[2] ),
    .RESET_B(net2),
    .CLK(clknet_6_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4480_ (.D(_0319_),
    .Q(\g_telemetry.u_reg_file.temp_max_strk[3] ),
    .RESET_B(net4),
    .CLK(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4481_ (.D(_0318_),
    .Q(\g_telemetry.u_reg_file.temp_max_strk[4] ),
    .RESET_B(net4),
    .CLK(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4482_ (.D(_0317_),
    .Q(\g_telemetry.u_reg_file.temp_max_strk[5] ),
    .RESET_B(net4),
    .CLK(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4483_ (.D(_0316_),
    .Q(\g_telemetry.u_reg_file.temp_max_strk[6] ),
    .RESET_B(net2),
    .CLK(clknet_6_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4484_ (.D(_0625_),
    .Q(\g_telemetry.u_reg_file.temp_max_strk[7] ),
    .RESET_B(net4),
    .CLK(clknet_6_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4485_ (.D(_0315_),
    .Q(\cycles_per_step[0] ),
    .RESET_B(net5),
    .CLK(clknet_6_49__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4486_ (.D(_0314_),
    .Q(\cycles_per_step[1] ),
    .RESET_B(net5),
    .CLK(clknet_6_49__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4487_ (.D(_0313_),
    .Q(\cycles_per_step[2] ),
    .RESET_B(net5),
    .CLK(clknet_6_49__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4488_ (.D(_0312_),
    .Q(\cycles_per_step[3] ),
    .RESET_B(net5),
    .CLK(clknet_6_49__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4489_ (.D(_0311_),
    .Q(\cycles_per_step[4] ),
    .RESET_B(net5),
    .CLK(clknet_6_49__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4490_ (.D(_0310_),
    .Q(\cycles_per_step[5] ),
    .RESET_B(net5),
    .CLK(clknet_6_49__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4491_ (.D(_0626_),
    .Q(\cycles_per_step[6] ),
    .SET_B(net5),
    .CLK(clknet_6_49__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4492_ (.D(_0309_),
    .Q(\g_telemetry.u_reg_file.max_on_limit[0] ),
    .RESET_B(net2),
    .CLK(clknet_6_7__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4493_ (.D(_0308_),
    .Q(\g_telemetry.u_reg_file.max_on_limit[1] ),
    .RESET_B(net2),
    .CLK(clknet_6_6__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4494_ (.D(_0307_),
    .Q(\g_telemetry.u_reg_file.max_on_limit[2] ),
    .RESET_B(net2),
    .CLK(clknet_6_7__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4495_ (.D(_0306_),
    .Q(\g_telemetry.u_reg_file.max_on_limit[3] ),
    .RESET_B(net2),
    .CLK(clknet_6_7__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4496_ (.D(_0627_),
    .Q(\g_telemetry.u_reg_file.max_on_limit[4] ),
    .SET_B(net3),
    .CLK(clknet_6_7__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4497_ (.D(_0305_),
    .Q(\g_telemetry.u_reg_file.trip_run[0] ),
    .RESET_B(net7),
    .CLK(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4498_ (.D(_0304_),
    .Q(\g_telemetry.u_reg_file.trip_run[1] ),
    .RESET_B(net7),
    .CLK(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4499_ (.D(_0303_),
    .Q(\g_telemetry.u_reg_file.trip_run[2] ),
    .SET_B(net7),
    .CLK(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4500_ (.D(_0302_),
    .Q(\g_telemetry.u_reg_file.trip_run[3] ),
    .SET_B(net7),
    .CLK(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4501_ (.D(_0301_),
    .Q(\g_telemetry.u_reg_file.trip_run[4] ),
    .RESET_B(net7),
    .CLK(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4502_ (.D(_0628_),
    .Q(\g_telemetry.u_reg_file.trip_run[5] ),
    .RESET_B(net7),
    .CLK(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4503_ (.D(_0300_),
    .Q(\g_telemetry.u_reg_file.temp_max_on[0] ),
    .RESET_B(net2),
    .CLK(clknet_6_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4504_ (.D(_0299_),
    .Q(\g_telemetry.u_reg_file.temp_max_on[1] ),
    .RESET_B(net2),
    .CLK(clknet_6_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4505_ (.D(_0298_),
    .Q(\g_telemetry.u_reg_file.temp_max_on[2] ),
    .RESET_B(net2),
    .CLK(clknet_6_6__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4506_ (.D(_0297_),
    .Q(\g_telemetry.u_reg_file.temp_max_on[3] ),
    .RESET_B(net2),
    .CLK(clknet_6_6__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4507_ (.D(_0296_),
    .Q(\g_telemetry.u_reg_file.temp_max_on[4] ),
    .RESET_B(net2),
    .CLK(clknet_6_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4508_ (.D(_0295_),
    .Q(\g_telemetry.u_reg_file.temp_max_on[5] ),
    .RESET_B(net2),
    .CLK(clknet_6_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4509_ (.D(_0294_),
    .Q(\g_telemetry.u_reg_file.temp_max_on[6] ),
    .RESET_B(net2),
    .CLK(clknet_6_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4510_ (.D(_0629_),
    .Q(\g_telemetry.u_reg_file.temp_max_on[7] ),
    .RESET_B(net2),
    .CLK(clknet_6_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4511_ (.D(_0293_),
    .Q(\g_telemetry.u_reg_file.trip_ss[0] ),
    .RESET_B(net7),
    .CLK(clknet_6_27__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4512_ (.D(_0292_),
    .Q(\g_telemetry.u_reg_file.trip_ss[1] ),
    .RESET_B(net6),
    .CLK(clknet_6_27__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4513_ (.D(_0291_),
    .Q(\g_telemetry.u_reg_file.trip_ss[2] ),
    .SET_B(net7),
    .CLK(clknet_6_27__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4514_ (.D(_0290_),
    .Q(\g_telemetry.u_reg_file.trip_ss[3] ),
    .SET_B(net6),
    .CLK(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4515_ (.D(_0289_),
    .Q(\g_telemetry.u_reg_file.trip_ss[4] ),
    .SET_B(net6),
    .CLK(clknet_6_27__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4516_ (.D(_0630_),
    .Q(\g_telemetry.u_reg_file.trip_ss[5] ),
    .RESET_B(net7),
    .CLK(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4517_ (.D(_0288_),
    .Q(\g_telemetry.u_reg_file.max_strikes[0] ),
    .SET_B(net3),
    .CLK(clknet_6_7__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4518_ (.D(_0631_),
    .Q(\g_telemetry.u_reg_file.max_strikes[1] ),
    .SET_B(net3),
    .CLK(clknet_6_7__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4519_ (.D(_0287_),
    .Q(\g_telemetry.u_reg_file.wd_mark[0] ),
    .RESET_B(net10),
    .CLK(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4520_ (.D(_0286_),
    .Q(\g_telemetry.u_reg_file.wd_mark[1] ),
    .RESET_B(net10),
    .CLK(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4521_ (.D(_0285_),
    .Q(\g_telemetry.u_reg_file.wd_mark[2] ),
    .RESET_B(net10),
    .CLK(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4522_ (.D(_0284_),
    .Q(\g_telemetry.u_reg_file.wd_mark[3] ),
    .RESET_B(net10),
    .CLK(clknet_6_61__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4523_ (.D(_0283_),
    .Q(\g_telemetry.u_reg_file.wd_mark[4] ),
    .RESET_B(net10),
    .CLK(clknet_6_61__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4524_ (.D(_0282_),
    .Q(\g_telemetry.u_reg_file.wd_mark[5] ),
    .RESET_B(net10),
    .CLK(clknet_6_61__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4525_ (.D(_0281_),
    .Q(\g_telemetry.u_reg_file.wd_mark[6] ),
    .RESET_B(net8),
    .CLK(clknet_6_63__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4526_ (.D(_0280_),
    .Q(\g_telemetry.u_reg_file.wd_mark[7] ),
    .RESET_B(net8),
    .CLK(clknet_6_63__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4527_ (.D(_0279_),
    .Q(\g_telemetry.u_reg_file.wd_mark[8] ),
    .RESET_B(net8),
    .CLK(clknet_6_63__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4528_ (.D(_0278_),
    .Q(\g_telemetry.u_reg_file.wd_mark[9] ),
    .RESET_B(net8),
    .CLK(clknet_6_63__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4529_ (.D(_0277_),
    .Q(\g_telemetry.u_reg_file.wd_mark[10] ),
    .RESET_B(net8),
    .CLK(clknet_6_63__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4530_ (.D(_0276_),
    .Q(\g_telemetry.u_reg_file.wd_mark[11] ),
    .RESET_B(net8),
    .CLK(clknet_6_63__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4531_ (.D(_0275_),
    .Q(\g_telemetry.u_reg_file.wd_mark[12] ),
    .RESET_B(net8),
    .CLK(clknet_6_62__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4532_ (.D(_0274_),
    .Q(\g_telemetry.u_reg_file.wd_mark[13] ),
    .RESET_B(net8),
    .CLK(clknet_6_62__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4533_ (.D(_0273_),
    .Q(\g_telemetry.u_reg_file.wd_mark[14] ),
    .RESET_B(net8),
    .CLK(clknet_6_62__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4534_ (.D(_0272_),
    .Q(\g_telemetry.u_reg_file.wd_mark[15] ),
    .RESET_B(net8),
    .CLK(clknet_6_63__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4535_ (.D(_0271_),
    .Q(\g_telemetry.u_reg_file.wd_mark[16] ),
    .RESET_B(net8),
    .CLK(clknet_6_60__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4536_ (.D(_0270_),
    .Q(\g_telemetry.u_reg_file.wd_mark[17] ),
    .RESET_B(net10),
    .CLK(clknet_6_61__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4537_ (.D(_0269_),
    .Q(\g_telemetry.u_reg_file.wd_mark[18] ),
    .RESET_B(net10),
    .CLK(clknet_6_54__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4538_ (.D(_0268_),
    .Q(\g_telemetry.u_reg_file.wd_mark[19] ),
    .RESET_B(net10),
    .CLK(clknet_6_54__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4539_ (.D(_0267_),
    .Q(\g_telemetry.u_reg_file.wd_mark[20] ),
    .RESET_B(net10),
    .CLK(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4540_ (.D(_0266_),
    .Q(\g_telemetry.u_reg_file.wd_mark[21] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4541_ (.D(_0265_),
    .Q(\g_telemetry.u_reg_file.wd_mark[22] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4542_ (.D(_0632_),
    .Q(\g_telemetry.u_reg_file.wd_mark[23] ),
    .RESET_B(net5),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4543_ (.D(_0264_),
    .Q(\clean_run_target[0] ),
    .RESET_B(net3),
    .CLK(clknet_6_12__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4544_ (.D(_0263_),
    .Q(\clean_run_target[1] ),
    .RESET_B(net3),
    .CLK(clknet_6_9__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4545_ (.D(_0262_),
    .Q(\clean_run_target[2] ),
    .RESET_B(net7),
    .CLK(clknet_6_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4546_ (.D(_0261_),
    .Q(\clean_run_target[3] ),
    .RESET_B(net3),
    .CLK(clknet_6_9__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4547_ (.D(_0260_),
    .Q(\clean_run_target[4] ),
    .SET_B(net3),
    .CLK(clknet_6_9__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4548_ (.D(_0259_),
    .Q(\clean_run_target[5] ),
    .RESET_B(net3),
    .CLK(clknet_6_12__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4549_ (.D(_0258_),
    .Q(\clean_run_target[6] ),
    .SET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_11__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4550_ (.D(_0257_),
    .Q(\clean_run_target[7] ),
    .SET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_11__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4551_ (.D(_0256_),
    .Q(\clean_run_target[8] ),
    .SET_B(net3),
    .CLK(clknet_6_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4552_ (.D(_0255_),
    .Q(\clean_run_target[9] ),
    .RESET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_11__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4553_ (.D(_0254_),
    .Q(\clean_run_target[10] ),
    .SET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_11__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4554_ (.D(_0253_),
    .Q(\clean_run_target[11] ),
    .SET_B(net3),
    .CLK(clknet_6_11__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4555_ (.D(_0252_),
    .Q(\clean_run_target[12] ),
    .SET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4556_ (.D(_0251_),
    .Q(\clean_run_target[13] ),
    .RESET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_14__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4557_ (.D(_0250_),
    .Q(\clean_run_target[14] ),
    .SET_B(net7),
    .CLK(clknet_6_14__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4558_ (.D(_0249_),
    .Q(\clean_run_target[15] ),
    .SET_B(net7),
    .CLK(clknet_6_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4559_ (.D(_0248_),
    .Q(\clean_run_target[16] ),
    .RESET_B(net7),
    .CLK(clknet_6_15__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4560_ (.D(_0247_),
    .Q(\clean_run_target[17] ),
    .SET_B(net7),
    .CLK(clknet_6_14__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4561_ (.D(_0633_),
    .Q(\clean_run_target[18] ),
    .SET_B(net7),
    .CLK(clknet_6_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4562_ (.D(_0246_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_0[0] ),
    .RESET_B(net3),
    .CLK(clknet_6_18__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4563_ (.D(_0245_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_0[1] ),
    .RESET_B(net3),
    .CLK(clknet_6_18__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4564_ (.D(_0244_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_0[2] ),
    .RESET_B(net3),
    .CLK(clknet_6_18__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4565_ (.D(_0243_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_0[3] ),
    .RESET_B(net3),
    .CLK(clknet_6_18__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4566_ (.D(_0242_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_0[4] ),
    .RESET_B(net2),
    .CLK(clknet_6_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4567_ (.D(_0241_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_0[5] ),
    .RESET_B(net2),
    .CLK(clknet_6_18__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4568_ (.D(_0240_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_0[6] ),
    .RESET_B(net2),
    .CLK(clknet_6_7__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4569_ (.D(_0634_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_0[7] ),
    .RESET_B(net2),
    .CLK(clknet_6_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4570_ (.D(_0239_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[0] ),
    .RESET_B(net3),
    .CLK(clknet_6_19__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4571_ (.D(_0238_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[1] ),
    .RESET_B(net3),
    .CLK(clknet_6_19__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4572_ (.D(_0237_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[2] ),
    .RESET_B(net3),
    .CLK(clknet_6_19__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4573_ (.D(_0236_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[3] ),
    .RESET_B(net3),
    .CLK(clknet_6_19__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4574_ (.D(_0235_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[4] ),
    .SET_B(net3),
    .CLK(clknet_6_18__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4575_ (.D(_0234_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[5] ),
    .RESET_B(net3),
    .CLK(clknet_6_19__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4576_ (.D(_0233_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[6] ),
    .SET_B(net3),
    .CLK(clknet_6_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4577_ (.D(_0232_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[7] ),
    .RESET_B(net3),
    .CLK(clknet_6_19__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4578_ (.D(_0231_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[8] ),
    .SET_B(net2),
    .CLK(clknet_6_16__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4579_ (.D(_0230_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[9] ),
    .SET_B(net2),
    .CLK(clknet_6_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4580_ (.D(_0229_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[10] ),
    .RESET_B(net2),
    .CLK(clknet_6_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4581_ (.D(_0228_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[11] ),
    .RESET_B(net2),
    .CLK(clknet_6_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4582_ (.D(_0227_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[12] ),
    .RESET_B(net2),
    .CLK(clknet_6_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4583_ (.D(_0226_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[13] ),
    .RESET_B(net2),
    .CLK(clknet_6_17__leaf_clk));
 sky130_fd_sc_hd__dfstp_4 _4584_ (.D(_0225_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[14] ),
    .SET_B(net2),
    .CLK(clknet_6_17__leaf_clk));
 sky130_fd_sc_hd__dfstp_4 _4585_ (.D(_0224_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[15] ),
    .SET_B(net2),
    .CLK(clknet_6_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4586_ (.D(_0223_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[16] ),
    .RESET_B(net2),
    .CLK(clknet_6_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4587_ (.D(_0635_),
    .Q(\g_telemetry.u_reg_file.hiccup_base[17] ),
    .RESET_B(net2),
    .CLK(clknet_6_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4588_ (.D(_0637_),
    .Q(\g_telemetry.u_reg_file.write_rejected ),
    .RESET_B(net3),
    .CLK(clknet_6_24__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4589_ (.D(_0638_),
    .Q(\g_telemetry.u_reg_file.temp_dirty[10] ),
    .RESET_B(net3),
    .CLK(clknet_6_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4590_ (.D(_0593_),
    .Q(\g_telemetry.u_reg_file.temp_dirty[9] ),
    .RESET_B(net3),
    .CLK(clknet_6_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4591_ (.D(_0636_),
    .Q(\g_telemetry.u_reg_file.temp_dirty[8] ),
    .RESET_B(net3),
    .CLK(clknet_6_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4592_ (.D(_0580_),
    .Q(\g_telemetry.u_reg_file.temp_dirty[7] ),
    .RESET_B(net6),
    .CLK(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4593_ (.D(_0607_),
    .Q(\g_telemetry.u_reg_file.temp_dirty[6] ),
    .RESET_B(net3),
    .CLK(clknet_6_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4594_ (.D(_0604_),
    .Q(\g_telemetry.u_reg_file.temp_dirty[5] ),
    .RESET_B(net3),
    .CLK(clknet_6_24__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4595_ (.D(_0572_),
    .Q(\g_telemetry.u_reg_file.temp_dirty[4] ),
    .RESET_B(net3),
    .CLK(clknet_6_24__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4596_ (.D(_0602_),
    .Q(\g_telemetry.u_reg_file.temp_dirty[3] ),
    .RESET_B(net3),
    .CLK(clknet_6_13__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4597_ (.D(_0603_),
    .Q(\g_telemetry.u_reg_file.temp_dirty[2] ),
    .RESET_B(net3),
    .CLK(clknet_6_7__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4598_ (.D(_0605_),
    .Q(\g_telemetry.u_reg_file.temp_dirty[1] ),
    .RESET_B(net6),
    .CLK(clknet_6_24__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4599_ (.D(_0606_),
    .Q(\g_telemetry.u_reg_file.temp_dirty[0] ),
    .RESET_B(net3),
    .CLK(clknet_6_24__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4600_ (.D(_0222_),
    .Q(\u_en_from_switch_db.disagree_counter[0] ),
    .RESET_B(net6),
    .CLK(clknet_6_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4601_ (.D(_0221_),
    .Q(\u_en_from_switch_db.disagree_counter[1] ),
    .RESET_B(net6),
    .CLK(clknet_6_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4602_ (.D(_0220_),
    .Q(\u_en_from_switch_db.disagree_counter[2] ),
    .RESET_B(net6),
    .CLK(clknet_6_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4603_ (.D(_0219_),
    .Q(\u_en_from_switch_db.disagree_counter[3] ),
    .RESET_B(net6),
    .CLK(clknet_6_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4604_ (.D(_0218_),
    .Q(\u_en_from_switch_db.disagree_counter[4] ),
    .RESET_B(net6),
    .CLK(clknet_6_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4605_ (.D(_0217_),
    .Q(\u_en_from_switch_db.disagree_counter[5] ),
    .RESET_B(net6),
    .CLK(clknet_6_22__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4606_ (.D(_0216_),
    .Q(\u_en_from_switch_db.disagree_counter[6] ),
    .RESET_B(net7),
    .CLK(clknet_6_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4607_ (.D(_0215_),
    .Q(\u_en_from_switch_db.disagree_counter[7] ),
    .RESET_B(net7),
    .CLK(clknet_6_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4608_ (.D(_0214_),
    .Q(\u_en_from_switch_db.disagree_counter[8] ),
    .RESET_B(net7),
    .CLK(clknet_6_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4609_ (.D(_0213_),
    .Q(\u_en_from_switch_db.disagree_counter[9] ),
    .RESET_B(net6),
    .CLK(clknet_6_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4610_ (.D(_0212_),
    .Q(\u_en_from_switch_db.disagree_counter[10] ),
    .RESET_B(net6),
    .CLK(clknet_6_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4611_ (.D(_0211_),
    .Q(\u_en_from_switch_db.disagree_counter[11] ),
    .RESET_B(net6),
    .CLK(clknet_6_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4612_ (.D(_0210_),
    .Q(\u_en_from_switch_db.disagree_counter[12] ),
    .RESET_B(net6),
    .CLK(clknet_6_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4613_ (.D(_0209_),
    .Q(\u_en_from_switch_db.disagree_counter[13] ),
    .RESET_B(net6),
    .CLK(clknet_6_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4614_ (.D(_0208_),
    .Q(\u_en_from_switch_db.disagree_counter[14] ),
    .RESET_B(net6),
    .CLK(clknet_6_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4615_ (.D(_0207_),
    .Q(\u_en_from_switch_db.disagree_counter[15] ),
    .RESET_B(net6),
    .CLK(clknet_6_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4616_ (.D(_0206_),
    .Q(\u_en_from_switch_db.disagree_counter[16] ),
    .RESET_B(net6),
    .CLK(clknet_6_23__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4617_ (.D(_0639_),
    .Q(\u_en_from_switch_db.disagree_counter[17] ),
    .RESET_B(net6),
    .CLK(clknet_6_21__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4618_ (.D(_0205_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_1[0] ),
    .RESET_B(net2),
    .CLK(clknet_6_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4619_ (.D(_0204_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_1[1] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4620_ (.D(_0203_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_1[2] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4621_ (.D(_0202_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_1[3] ),
    .RESET_B(net2),
    .CLK(clknet_6_16__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4622_ (.D(_0201_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_1[4] ),
    .RESET_B(net2),
    .CLK(clknet_6_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4623_ (.D(_0200_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_1[5] ),
    .RESET_B(net2),
    .CLK(clknet_6_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4624_ (.D(_0199_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_1[6] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4625_ (.D(_0640_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_1[7] ),
    .RESET_B(net2),
    .CLK(clknet_6_17__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4626_ (.D(_0198_),
    .Q(\g_spi_filt.u_cs_filt.disagree_counter[0] ),
    .RESET_B(net9),
    .CLK(clknet_6_41__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4627_ (.D(_0197_),
    .Q(\g_spi_filt.u_cs_filt.disagree_counter[1] ),
    .RESET_B(net9),
    .CLK(clknet_6_41__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4628_ (.D(_0196_),
    .Q(\g_spi_filt.u_cs_filt.disagree_counter[2] ),
    .RESET_B(net9),
    .CLK(clknet_6_41__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4629_ (.D(_0641_),
    .Q(\g_spi_filt.u_cs_filt.disagree_counter[3] ),
    .RESET_B(net9),
    .CLK(clknet_6_41__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4630_ (.D(_0642_),
    .Q(en_from_switch_sync_db),
    .RESET_B(net12),
    .CLK(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4631_ (.D(_0195_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_2[0] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4632_ (.D(_0194_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_2[1] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4633_ (.D(_0193_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_2[2] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4634_ (.D(_0192_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_2[3] ),
    .RESET_B(net2),
    .CLK(clknet_6_4__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4635_ (.D(_0191_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_2[4] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4636_ (.D(_0190_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_2[5] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4637_ (.D(_0189_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_2[6] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4638_ (.D(_0643_),
    .Q(\g_telemetry.u_reg_file.temp_hiccup_2[7] ),
    .RESET_B(net2),
    .CLK(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4639_ (.D(_0188_),
    .Q(\g_telemetry.u_reg_file.temp_cyc_step[0] ),
    .RESET_B(net5),
    .CLK(clknet_6_48__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4640_ (.D(_0187_),
    .Q(\g_telemetry.u_reg_file.temp_cyc_step[1] ),
    .RESET_B(net5),
    .CLK(clknet_6_48__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4641_ (.D(_0186_),
    .Q(\g_telemetry.u_reg_file.temp_cyc_step[2] ),
    .RESET_B(net5),
    .CLK(clknet_6_48__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4642_ (.D(_0185_),
    .Q(\g_telemetry.u_reg_file.temp_cyc_step[3] ),
    .RESET_B(net5),
    .CLK(clknet_6_48__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4643_ (.D(_0184_),
    .Q(\g_telemetry.u_reg_file.temp_cyc_step[4] ),
    .RESET_B(net5),
    .CLK(clknet_6_48__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4644_ (.D(_0183_),
    .Q(\g_telemetry.u_reg_file.temp_cyc_step[5] ),
    .RESET_B(net5),
    .CLK(clknet_6_48__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4645_ (.D(_0182_),
    .Q(\g_telemetry.u_reg_file.temp_cyc_step[6] ),
    .RESET_B(net5),
    .CLK(clknet_6_50__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4646_ (.D(_0644_),
    .Q(\g_telemetry.u_reg_file.temp_cyc_step[7] ),
    .RESET_B(net5),
    .CLK(clknet_6_48__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4647_ (.D(_0645_),
    .Q(\g_spi_filt.u_mosi_filt.flag_out ),
    .RESET_B(net11),
    .CLK(clknet_6_34__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4648_ (.D(_0181_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[0] ),
    .RESET_B(net8),
    .CLK(clknet_6_45__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4649_ (.D(_0180_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[1] ),
    .RESET_B(net8),
    .CLK(clknet_6_45__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4650_ (.D(_0179_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[2] ),
    .RESET_B(net8),
    .CLK(clknet_6_56__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4651_ (.D(_0178_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[3] ),
    .RESET_B(net8),
    .CLK(clknet_6_45__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4652_ (.D(_0177_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[4] ),
    .RESET_B(net8),
    .CLK(clknet_6_57__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4653_ (.D(_0176_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[5] ),
    .RESET_B(net8),
    .CLK(clknet_6_56__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4654_ (.D(_0175_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[6] ),
    .RESET_B(net8),
    .CLK(clknet_6_56__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4655_ (.D(_0174_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[7] ),
    .RESET_B(net8),
    .CLK(clknet_6_56__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4656_ (.D(_0173_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[8] ),
    .RESET_B(net8),
    .CLK(clknet_6_39__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4657_ (.D(_0172_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[9] ),
    .RESET_B(net8),
    .CLK(clknet_6_39__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4658_ (.D(_0171_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[10] ),
    .RESET_B(net8),
    .CLK(clknet_6_39__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4659_ (.D(_0170_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[11] ),
    .RESET_B(net8),
    .CLK(clknet_6_45__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4660_ (.D(_0169_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[12] ),
    .RESET_B(net8),
    .CLK(clknet_6_45__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4661_ (.D(_0168_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[13] ),
    .RESET_B(net8),
    .CLK(clknet_6_56__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4662_ (.D(_0167_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[14] ),
    .RESET_B(net8),
    .CLK(clknet_6_56__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4663_ (.D(_0646_),
    .Q(\g_telemetry.u_reg_file.bus_err_count[15] ),
    .RESET_B(net8),
    .CLK(clknet_6_56__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4664_ (.D(_0166_),
    .Q(\g_telemetry.u_reg_file.temp_clean_0[0] ),
    .RESET_B(net3),
    .CLK(clknet_6_9__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4665_ (.D(_0165_),
    .Q(\g_telemetry.u_reg_file.temp_clean_0[1] ),
    .RESET_B(net3),
    .CLK(clknet_6_9__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4666_ (.D(_0164_),
    .Q(\g_telemetry.u_reg_file.temp_clean_0[2] ),
    .RESET_B(net3),
    .CLK(clknet_6_12__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4667_ (.D(_0163_),
    .Q(\g_telemetry.u_reg_file.temp_clean_0[3] ),
    .RESET_B(net3),
    .CLK(clknet_6_9__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4668_ (.D(_0162_),
    .Q(\g_telemetry.u_reg_file.temp_clean_0[4] ),
    .RESET_B(net3),
    .CLK(clknet_6_3__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4669_ (.D(_0161_),
    .Q(\g_telemetry.u_reg_file.temp_clean_0[5] ),
    .RESET_B(net3),
    .CLK(clknet_6_9__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4670_ (.D(_0160_),
    .Q(\g_telemetry.u_reg_file.temp_clean_0[6] ),
    .RESET_B(net3),
    .CLK(clknet_6_9__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4671_ (.D(_0647_),
    .Q(\g_telemetry.u_reg_file.temp_clean_0[7] ),
    .RESET_B(net3),
    .CLK(clknet_6_9__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4672_ (.D(_0159_),
    .Q(\g_spi_filt.u_mosi_filt.disagree_counter[0] ),
    .RESET_B(net11),
    .CLK(clknet_6_34__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4673_ (.D(_0158_),
    .Q(\g_spi_filt.u_mosi_filt.disagree_counter[1] ),
    .RESET_B(net11),
    .CLK(clknet_6_35__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4674_ (.D(_0157_),
    .Q(\g_spi_filt.u_mosi_filt.disagree_counter[2] ),
    .RESET_B(net11),
    .CLK(clknet_6_35__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4675_ (.D(_0648_),
    .Q(\g_spi_filt.u_mosi_filt.disagree_counter[3] ),
    .RESET_B(net11),
    .CLK(clknet_6_35__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4676_ (.D(_0156_),
    .Q(\g_telemetry.u_reg_file.temp_clean_1[0] ),
    .RESET_B(net3),
    .CLK(clknet_6_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4677_ (.D(_0155_),
    .Q(\g_telemetry.u_reg_file.temp_clean_1[1] ),
    .RESET_B(net3),
    .CLK(clknet_6_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4678_ (.D(_0154_),
    .Q(\g_telemetry.u_reg_file.temp_clean_1[2] ),
    .RESET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4679_ (.D(_0153_),
    .Q(\g_telemetry.u_reg_file.temp_clean_1[3] ),
    .RESET_B(net3),
    .CLK(clknet_6_8__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4680_ (.D(_0152_),
    .Q(\g_telemetry.u_reg_file.temp_clean_1[4] ),
    .RESET_B(net3),
    .CLK(clknet_6_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4681_ (.D(_0151_),
    .Q(\g_telemetry.u_reg_file.temp_clean_1[5] ),
    .RESET_B(net3),
    .CLK(clknet_6_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4682_ (.D(_0150_),
    .Q(\g_telemetry.u_reg_file.temp_clean_1[6] ),
    .RESET_B(net3),
    .CLK(clknet_6_12__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4683_ (.D(_0649_),
    .Q(\g_telemetry.u_reg_file.temp_clean_1[7] ),
    .RESET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_14__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4684_ (.D(_0149_),
    .Q(\g_telemetry.u_pwm_stats.period_counter[0] ),
    .RESET_B(net12),
    .CLK(clknet_6_36__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4685_ (.D(_0148_),
    .Q(\g_telemetry.u_pwm_stats.period_counter[1] ),
    .RESET_B(net12),
    .CLK(clknet_6_37__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4686_ (.D(_0147_),
    .Q(\g_telemetry.u_pwm_stats.period_counter[2] ),
    .RESET_B(net10),
    .CLK(clknet_6_36__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4687_ (.D(_0146_),
    .Q(\g_telemetry.u_pwm_stats.period_counter[3] ),
    .RESET_B(net10),
    .CLK(clknet_6_36__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4688_ (.D(_0145_),
    .Q(\g_telemetry.u_pwm_stats.period_counter[4] ),
    .RESET_B(net10),
    .CLK(clknet_6_37__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4689_ (.D(_0651_),
    .Q(\g_telemetry.u_pwm_stats.period_counter[5] ),
    .RESET_B(net10),
    .CLK(clknet_6_36__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4690_ (.D(_0144_),
    .Q(\duty_count[0] ),
    .RESET_B(net12),
    .CLK(clknet_6_37__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4691_ (.D(_0143_),
    .Q(\duty_count[1] ),
    .RESET_B(net12),
    .CLK(clknet_6_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4692_ (.D(_0142_),
    .Q(\duty_count[2] ),
    .RESET_B(net12),
    .CLK(clknet_6_37__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4693_ (.D(_0141_),
    .Q(\duty_count[3] ),
    .RESET_B(net7),
    .CLK(clknet_6_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4694_ (.D(_0140_),
    .Q(\duty_count[4] ),
    .RESET_B(net12),
    .CLK(clknet_6_37__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4695_ (.D(_0652_),
    .Q(\duty_count[5] ),
    .RESET_B(net12),
    .CLK(clknet_6_37__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4696_ (.D(_0139_),
    .Q(\g_telemetry.u_pwm_stats.prev_period[0] ),
    .RESET_B(net12),
    .CLK(clknet_6_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4697_ (.D(_0138_),
    .Q(\g_telemetry.u_pwm_stats.prev_period[1] ),
    .RESET_B(net10),
    .CLK(clknet_6_37__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4698_ (.D(_0137_),
    .Q(\g_telemetry.u_pwm_stats.prev_period[2] ),
    .RESET_B(net12),
    .CLK(clknet_6_37__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4699_ (.D(_0136_),
    .Q(\g_telemetry.u_pwm_stats.prev_period[3] ),
    .RESET_B(net12),
    .CLK(clknet_6_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4700_ (.D(_0135_),
    .Q(\g_telemetry.u_pwm_stats.prev_period[4] ),
    .RESET_B(net12),
    .CLK(clknet_6_37__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4701_ (.D(_0653_),
    .Q(\g_telemetry.u_pwm_stats.prev_period[5] ),
    .RESET_B(net10),
    .CLK(clknet_6_37__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4702_ (.D(_0134_),
    .Q(\fault_time[0] ),
    .RESET_B(net10),
    .CLK(clknet_6_51__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4703_ (.D(_0133_),
    .Q(\fault_time[1] ),
    .RESET_B(net10),
    .CLK(clknet_6_51__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4704_ (.D(_0132_),
    .Q(\fault_time[2] ),
    .RESET_B(net10),
    .CLK(clknet_6_51__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4705_ (.D(_0131_),
    .Q(\fault_time[3] ),
    .RESET_B(net10),
    .CLK(clknet_6_51__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4706_ (.D(_0130_),
    .Q(\fault_time[4] ),
    .RESET_B(net8),
    .CLK(clknet_6_60__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4707_ (.D(_0129_),
    .Q(\fault_time[5] ),
    .RESET_B(net8),
    .CLK(clknet_6_60__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4708_ (.D(_0128_),
    .Q(\fault_time[6] ),
    .RESET_B(net8),
    .CLK(clknet_6_57__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4709_ (.D(_0127_),
    .Q(\fault_time[7] ),
    .RESET_B(net8),
    .CLK(clknet_6_56__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4710_ (.D(_0126_),
    .Q(\fault_time[8] ),
    .RESET_B(net8),
    .CLK(clknet_6_63__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4711_ (.D(_0125_),
    .Q(\fault_time[9] ),
    .RESET_B(net8),
    .CLK(clknet_6_58__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4712_ (.D(_0124_),
    .Q(\fault_time[10] ),
    .RESET_B(net8),
    .CLK(clknet_6_59__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4713_ (.D(_0123_),
    .Q(\fault_time[11] ),
    .RESET_B(net8),
    .CLK(clknet_6_62__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4714_ (.D(_0122_),
    .Q(\fault_time[12] ),
    .RESET_B(net8),
    .CLK(clknet_6_59__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4715_ (.D(_0121_),
    .Q(\fault_time[13] ),
    .RESET_B(net8),
    .CLK(clknet_6_59__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4716_ (.D(_0120_),
    .Q(\fault_time[14] ),
    .RESET_B(net8),
    .CLK(clknet_6_59__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4717_ (.D(_0119_),
    .Q(\fault_time[15] ),
    .RESET_B(net8),
    .CLK(clknet_6_59__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4718_ (.D(_0118_),
    .Q(\fault_time[16] ),
    .RESET_B(net5),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4719_ (.D(_0117_),
    .Q(\fault_time[17] ),
    .RESET_B(net10),
    .CLK(clknet_6_50__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4720_ (.D(_0116_),
    .Q(\fault_time[18] ),
    .RESET_B(net5),
    .CLK(clknet_6_49__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4721_ (.D(_0115_),
    .Q(\fault_time[19] ),
    .RESET_B(net5),
    .CLK(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4722_ (.D(_0114_),
    .Q(\fault_time[20] ),
    .RESET_B(net5),
    .CLK(clknet_6_49__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4723_ (.D(_0113_),
    .Q(\fault_time[21] ),
    .RESET_B(net10),
    .CLK(clknet_6_51__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4724_ (.D(_0112_),
    .Q(\fault_time[22] ),
    .RESET_B(net5),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4725_ (.D(_0655_),
    .Q(\fault_time[23] ),
    .RESET_B(net5),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4726_ (.D(_0656_),
    .Q(\fault_reg[2] ),
    .RESET_B(net12),
    .CLK(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4727_ (.D(_0654_),
    .Q(\fault_reg[1] ),
    .RESET_B(net12),
    .CLK(clknet_6_37__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4728_ (.D(_0658_),
    .Q(\fault_reg[3] ),
    .RESET_B(net12),
    .CLK(clknet_6_37__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4729_ (.D(_0650_),
    .Q(\fault_reg[4] ),
    .RESET_B(net12),
    .CLK(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4730_ (.D(_0612_),
    .Q(\fault_reg[0] ),
    .RESET_B(net12),
    .CLK(clknet_6_37__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4731_ (.D(_0111_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[0] ),
    .RESET_B(net10),
    .CLK(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4732_ (.D(_0110_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[1] ),
    .RESET_B(net10),
    .CLK(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4733_ (.D(_0109_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[2] ),
    .RESET_B(net10),
    .CLK(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4734_ (.D(_0108_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[3] ),
    .RESET_B(net10),
    .CLK(clknet_6_54__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4735_ (.D(_0107_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[4] ),
    .RESET_B(net10),
    .CLK(clknet_6_61__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4736_ (.D(_0106_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[5] ),
    .RESET_B(net10),
    .CLK(clknet_6_61__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4737_ (.D(_0105_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[6] ),
    .RESET_B(net10),
    .CLK(clknet_6_61__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4738_ (.D(_0104_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[7] ),
    .RESET_B(net8),
    .CLK(clknet_6_63__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4739_ (.D(_0103_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[8] ),
    .RESET_B(net8),
    .CLK(clknet_6_63__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4740_ (.D(_0102_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[9] ),
    .RESET_B(net8),
    .CLK(clknet_6_62__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4741_ (.D(_0101_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[10] ),
    .RESET_B(net8),
    .CLK(clknet_6_63__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4742_ (.D(_0100_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[11] ),
    .RESET_B(net8),
    .CLK(clknet_6_62__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4743_ (.D(_0099_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[12] ),
    .RESET_B(net8),
    .CLK(clknet_6_59__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4744_ (.D(_0098_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[13] ),
    .RESET_B(net8),
    .CLK(clknet_6_59__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4745_ (.D(_0097_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[14] ),
    .RESET_B(net8),
    .CLK(clknet_6_59__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4746_ (.D(_0096_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[15] ),
    .RESET_B(net8),
    .CLK(clknet_6_59__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4747_ (.D(_0095_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[16] ),
    .RESET_B(net8),
    .CLK(clknet_6_60__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4748_ (.D(_0094_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[17] ),
    .RESET_B(net10),
    .CLK(clknet_6_60__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4749_ (.D(_0093_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[18] ),
    .RESET_B(net10),
    .CLK(clknet_6_54__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4750_ (.D(_0092_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[19] ),
    .RESET_B(net10),
    .CLK(clknet_6_54__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4751_ (.D(_0091_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[20] ),
    .RESET_B(net10),
    .CLK(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4752_ (.D(_0090_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[21] ),
    .RESET_B(net10),
    .CLK(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4753_ (.D(_0089_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[22] ),
    .RESET_B(net10),
    .CLK(clknet_6_54__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4754_ (.D(_0657_),
    .Q(\g_telemetry.u_fault_cause.timestamp_ms[23] ),
    .RESET_B(net10),
    .CLK(clknet_6_54__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4755_ (.D(en_from_switch_sync_db),
    .Q(en_from_switch_sync_db_d),
    .RESET_B(net12),
    .CLK(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4756_ (.D(_0045_),
    .Q(\g_timestamp.u_timestamp.prescalar[0] ),
    .RESET_B(net10),
    .CLK(clknet_6_61__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4757_ (.D(_0050_),
    .Q(\g_timestamp.u_timestamp.prescalar[1] ),
    .RESET_B(net10),
    .CLK(clknet_6_61__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4758_ (.D(_0051_),
    .Q(\g_timestamp.u_timestamp.prescalar[2] ),
    .RESET_B(net10),
    .CLK(clknet_6_61__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4759_ (.D(_0052_),
    .Q(\g_timestamp.u_timestamp.prescalar[3] ),
    .RESET_B(net10),
    .CLK(clknet_6_61__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4760_ (.D(_0053_),
    .Q(\g_timestamp.u_timestamp.prescalar[4] ),
    .RESET_B(net10),
    .CLK(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4761_ (.D(_0054_),
    .Q(\g_timestamp.u_timestamp.prescalar[5] ),
    .RESET_B(net10),
    .CLK(clknet_6_54__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4762_ (.D(_0055_),
    .Q(\g_timestamp.u_timestamp.prescalar[6] ),
    .RESET_B(net10),
    .CLK(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4763_ (.D(_0056_),
    .Q(\g_timestamp.u_timestamp.prescalar[7] ),
    .RESET_B(net10),
    .CLK(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4764_ (.D(_0057_),
    .Q(\g_timestamp.u_timestamp.prescalar[8] ),
    .RESET_B(net10),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4765_ (.D(_0058_),
    .Q(\g_timestamp.u_timestamp.prescalar[9] ),
    .RESET_B(net10),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4766_ (.D(_0046_),
    .Q(\g_timestamp.u_timestamp.prescalar[10] ),
    .RESET_B(net10),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4767_ (.D(_0047_),
    .Q(\g_timestamp.u_timestamp.prescalar[11] ),
    .RESET_B(net10),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4768_ (.D(_0048_),
    .Q(\g_timestamp.u_timestamp.prescalar[12] ),
    .RESET_B(net10),
    .CLK(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4769_ (.D(_0049_),
    .Q(\g_timestamp.u_timestamp.prescalar[13] ),
    .RESET_B(net10),
    .CLK(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4770_ (.D(_0016_),
    .Q(\g_telemetry.u_reg_file.arm_timer[0] ),
    .RESET_B(net7),
    .CLK(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4771_ (.D(_0023_),
    .Q(\g_telemetry.u_reg_file.arm_timer[1] ),
    .RESET_B(net7),
    .CLK(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4772_ (.D(_0024_),
    .Q(\g_telemetry.u_reg_file.arm_timer[2] ),
    .RESET_B(net7),
    .CLK(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4773_ (.D(_0025_),
    .Q(\g_telemetry.u_reg_file.arm_timer[3] ),
    .RESET_B(net7),
    .CLK(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4774_ (.D(_0026_),
    .Q(\g_telemetry.u_reg_file.arm_timer[4] ),
    .RESET_B(net7),
    .CLK(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4775_ (.D(_0027_),
    .Q(\g_telemetry.u_reg_file.arm_timer[5] ),
    .RESET_B(net7),
    .CLK(clknet_6_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4776_ (.D(_0028_),
    .Q(\g_telemetry.u_reg_file.arm_timer[6] ),
    .RESET_B(net7),
    .CLK(clknet_6_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4777_ (.D(_0029_),
    .Q(\g_telemetry.u_reg_file.arm_timer[7] ),
    .RESET_B(net7),
    .CLK(clknet_6_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4778_ (.D(_0030_),
    .Q(\g_telemetry.u_reg_file.arm_timer[8] ),
    .RESET_B(net6),
    .CLK(clknet_6_22__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4779_ (.D(_0031_),
    .Q(\g_telemetry.u_reg_file.arm_timer[9] ),
    .RESET_B(net6),
    .CLK(clknet_6_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4780_ (.D(_0017_),
    .Q(\g_telemetry.u_reg_file.arm_timer[10] ),
    .RESET_B(net6),
    .CLK(clknet_6_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4781_ (.D(_0018_),
    .Q(\g_telemetry.u_reg_file.arm_timer[11] ),
    .RESET_B(net6),
    .CLK(clknet_6_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4782_ (.D(_0019_),
    .Q(\g_telemetry.u_reg_file.arm_timer[12] ),
    .RESET_B(net7),
    .CLK(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4783_ (.D(_0020_),
    .Q(\g_telemetry.u_reg_file.arm_timer[13] ),
    .RESET_B(net7),
    .CLK(clknet_6_28__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4784_ (.D(_0021_),
    .Q(\g_telemetry.u_reg_file.arm_timer[14] ),
    .RESET_B(net7),
    .CLK(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4785_ (.D(_0022_),
    .Q(\g_telemetry.u_reg_file.arm_timer[15] ),
    .RESET_B(net7),
    .CLK(clknet_6_25__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4786_ (.D(_0033_),
    .Q(\g_telemetry.u_reg_file.unlock_armed ),
    .RESET_B(net5),
    .CLK(clknet_6_48__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4787_ (.D(_0032_),
    .Q(\g_telemetry.u_reg_file.disable_armed ),
    .RESET_B(net12),
    .CLK(clknet_6_48__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4788_ (.D(_0044_),
    .Q(\g_telemetry.u_reg_file.wr_en ),
    .RESET_B(net11),
    .CLK(clknet_6_36__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4789_ (.D(\g_spi_filt.u_sck_filt.flag_out ),
    .Q(\g_telemetry.u_spi_slave.sck_d ),
    .RESET_B(net9),
    .CLK(clknet_6_43__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4790_ (.D(_0035_),
    .Q(\g_telemetry.u_reg_file.addr[0] ),
    .RESET_B(net11),
    .CLK(clknet_6_39__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4791_ (.D(_0036_),
    .Q(\g_telemetry.u_reg_file.addr[1] ),
    .RESET_B(net11),
    .CLK(clknet_6_39__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4792_ (.D(_0037_),
    .Q(\g_telemetry.u_reg_file.addr[2] ),
    .RESET_B(net11),
    .CLK(clknet_6_38__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4793_ (.D(_0038_),
    .Q(\g_telemetry.u_reg_file.addr[3] ),
    .RESET_B(net8),
    .CLK(clknet_6_39__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4794_ (.D(_0039_),
    .Q(\g_telemetry.u_reg_file.addr[4] ),
    .RESET_B(net8),
    .CLK(clknet_6_44__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4795_ (.D(_0040_),
    .Q(\g_telemetry.u_reg_file.addr[5] ),
    .RESET_B(net8),
    .CLK(clknet_6_45__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4796_ (.D(_0041_),
    .Q(\g_telemetry.u_reg_file.addr[6] ),
    .RESET_B(net8),
    .CLK(clknet_6_39__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4797_ (.D(cs_n_filt),
    .Q(\g_telemetry.u_spi_slave.cs_n_d ),
    .SET_B(net9),
    .CLK(clknet_6_43__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4798_ (.D(_0043_),
    .Q(\g_telemetry.u_spi_slave.sdio_oe ),
    .RESET_B(net9),
    .CLK(clknet_6_45__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4799_ (.D(_0000_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[0] ),
    .RESET_B(net9),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4800_ (.D(_0006_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[1] ),
    .RESET_B(net9),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4801_ (.D(_0007_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[2] ),
    .RESET_B(net9),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4802_ (.D(_0008_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[3] ),
    .RESET_B(net9),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4803_ (.D(_0009_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[4] ),
    .RESET_B(net9),
    .CLK(clknet_6_40__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4804_ (.D(_0010_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[5] ),
    .RESET_B(net9),
    .CLK(clknet_6_43__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4805_ (.D(_0011_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[6] ),
    .RESET_B(net9),
    .CLK(clknet_6_43__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4806_ (.D(_0012_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[7] ),
    .RESET_B(net9),
    .CLK(clknet_6_43__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4807_ (.D(_0013_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[8] ),
    .RESET_B(net9),
    .CLK(clknet_6_43__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4808_ (.D(_0014_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[9] ),
    .RESET_B(net9),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4809_ (.D(_0001_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[10] ),
    .RESET_B(net9),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4810_ (.D(_0002_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[11] ),
    .RESET_B(net9),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4811_ (.D(_0003_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[12] ),
    .RESET_B(net9),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4812_ (.D(_0004_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[13] ),
    .RESET_B(net9),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4813_ (.D(_0005_),
    .Q(\g_telemetry.u_spi_slave.idle_counter[14] ),
    .RESET_B(net9),
    .CLK(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4814_ (.D(_0015_),
    .Q(\g_telemetry.u_spi_slave.sck_timeout ),
    .RESET_B(net9),
    .CLK(clknet_6_43__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4815_ (.D(_0042_),
    .Q(\g_telemetry.u_reg_file.integrity_OK ),
    .RESET_B(net9),
    .CLK(clknet_6_47__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4816_ (.D(_0034_),
    .Q(\g_telemetry.u_reg_file.abort ),
    .RESET_B(net9),
    .CLK(clknet_6_45__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4817_ (.D(\g_telemetry.u_spi_slave.spi_state_next[0] ),
    .Q(\g_telemetry.u_spi_slave.spi_state[0] ),
    .RESET_B(net9),
    .CLK(clknet_6_46__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4818_ (.D(\g_telemetry.u_spi_slave.spi_state_next[1] ),
    .Q(\g_telemetry.u_spi_slave.spi_state[1] ),
    .RESET_B(net9),
    .CLK(clknet_6_46__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4819_ (.D(\g_telemetry.u_spi_slave.spi_state_next[2] ),
    .Q(\g_telemetry.u_spi_slave.spi_state[2] ),
    .RESET_B(net9),
    .CLK(clknet_6_47__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4820_ (.D(MOSI),
    .Q(\g_spi_sync.u_mosi_sync.meta_ff ),
    .RESET_B(net11),
    .CLK(clknet_6_34__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4821_ (.D(\g_spi_sync.u_mosi_sync.meta_ff ),
    .Q(\g_spi_filt.u_mosi_filt.flag_in ),
    .RESET_B(net11),
    .CLK(clknet_6_34__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4822_ (.D(CS_n),
    .Q(\g_spi_sync.u_cs_sync.meta_ff ),
    .SET_B(net11),
    .CLK(clknet_6_34__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4823_ (.D(\g_spi_sync.u_cs_sync.meta_ff ),
    .Q(cs_n_sync),
    .SET_B(net11),
    .CLK(clknet_6_34__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4824_ (.D(SCK),
    .Q(\g_spi_sync.u_sck_sync.meta_ff ),
    .RESET_B(net11),
    .CLK(clknet_6_34__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4825_ (.D(\g_spi_sync.u_sck_sync.meta_ff ),
    .Q(\g_spi_filt.u_sck_filt.flag_in ),
    .RESET_B(net11),
    .CLK(clknet_6_34__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4826_ (.D(PGOOD),
    .Q(pgood_LED),
    .RESET_B(net4),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4827_ (.D(_0061_),
    .Q(\u_fault_LED.blink_counter[0] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4828_ (.D(_0072_),
    .Q(\u_fault_LED.blink_counter[1] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4829_ (.D(_0074_),
    .Q(\u_fault_LED.blink_counter[2] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4830_ (.D(_0075_),
    .Q(\u_fault_LED.blink_counter[3] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4831_ (.D(_0076_),
    .Q(\u_fault_LED.blink_counter[4] ),
    .RESET_B(net4),
    .CLK(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4832_ (.D(_0077_),
    .Q(\u_fault_LED.blink_counter[5] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4833_ (.D(_0078_),
    .Q(\u_fault_LED.blink_counter[6] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4834_ (.D(_0079_),
    .Q(\u_fault_LED.blink_counter[7] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4835_ (.D(_0080_),
    .Q(\u_fault_LED.blink_counter[8] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4836_ (.D(_0081_),
    .Q(\u_fault_LED.blink_counter[9] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4837_ (.D(_0062_),
    .Q(\u_fault_LED.blink_counter[10] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4838_ (.D(_0063_),
    .Q(\u_fault_LED.blink_counter[11] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4839_ (.D(_0064_),
    .Q(\u_fault_LED.blink_counter[12] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4840_ (.D(_0065_),
    .Q(\u_fault_LED.blink_counter[13] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4841_ (.D(_0066_),
    .Q(\u_fault_LED.blink_counter[14] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4842_ (.D(_0067_),
    .Q(\u_fault_LED.blink_counter[15] ),
    .RESET_B(net4),
    .CLK(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4843_ (.D(_0068_),
    .Q(\u_fault_LED.blink_counter[16] ),
    .RESET_B(net4),
    .CLK(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4844_ (.D(_0069_),
    .Q(\u_fault_LED.blink_counter[17] ),
    .RESET_B(net4),
    .CLK(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4845_ (.D(_0070_),
    .Q(\u_fault_LED.blink_counter[18] ),
    .RESET_B(net4),
    .CLK(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4846_ (.D(_0071_),
    .Q(\u_fault_LED.blink_counter[19] ),
    .RESET_B(net4),
    .CLK(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4847_ (.D(_0073_),
    .Q(\u_fault_LED.blink_counter[20] ),
    .RESET_B(net4),
    .CLK(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4848_ (.D(_0060_),
    .Q(Red_LED1),
    .RESET_B(net4),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4849_ (.D(OTP_sync_db),
    .Q(Red_LED2),
    .RESET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4850_ (.D(UVLO_sync_db),
    .Q(Red_LED3),
    .RESET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4851_ (.D(_0059_),
    .Q(Green_LED),
    .RESET_B(net4),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4852_ (.D(_0087_),
    .Q(\u_pwm_mask.pulse_allowed ),
    .SET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4853_ (.D(_0088_),
    .Q(PWM_out),
    .RESET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_11__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4854_ (.D(Osc_sync),
    .Q(\g_telemetry.u_pwm_stats.pwm_sync_d ),
    .RESET_B(net10),
    .CLK(clknet_6_33__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4855_ (.D(hiccup_active),
    .Q(\u_strike_counter.hiccup_active_d ),
    .RESET_B(net6),
    .CLK(clknet_6_25__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4856_ (.D(_0082_),
    .Q(\u_fault_arbiter.cp_delay[0] ),
    .RESET_B(net7),
    .CLK(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4857_ (.D(_0083_),
    .Q(\u_fault_arbiter.cp_delay[1] ),
    .RESET_B(net7),
    .CLK(clknet_6_27__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4858_ (.D(_0084_),
    .Q(\u_fault_arbiter.cp_delay[2] ),
    .RESET_B(net7),
    .CLK(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4859_ (.D(_0085_),
    .Q(\u_fault_arbiter.cp_delay[3] ),
    .RESET_B(net7),
    .CLK(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__dfrtp_2 _4860_ (.D(_0086_),
    .Q(\u_fault_arbiter.cp_delay[4] ),
    .RESET_B(net7),
    .CLK(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4861_ (.D(\u_supervisor.next_state[0] ),
    .Q(\g_telemetry.u_reg_file.sup_state[0] ),
    .RESET_B(net7),
    .CLK(clknet_6_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4862_ (.D(\u_supervisor.next_state[1] ),
    .Q(\g_telemetry.u_reg_file.sup_state[1] ),
    .RESET_B(net7),
    .CLK(clknet_6_15__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4863_ (.D(en_from_switch),
    .Q(\u_en_from_switch_sync.meta_ff ),
    .RESET_B(net4),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4864_ (.D(\u_en_from_switch_sync.meta_ff ),
    .Q(en_from_switch_sync),
    .RESET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4865_ (.D(PGOOD_comp),
    .Q(\u_pgood_comp_sync.meta_ff ),
    .RESET_B(net4),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4866_ (.D(\u_pgood_comp_sync.meta_ff ),
    .Q(PGOOD_comp_sync),
    .RESET_B(net12),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4867_ (.D(latch_stat),
    .Q(\u_latch_stat_sync.meta_ff ),
    .SET_B(net4),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4868_ (.D(\u_latch_stat_sync.meta_ff ),
    .Q(latch_stat_sync),
    .SET_B(net4),
    .CLK(clknet_6_2__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4869_ (.D(UVLO_trig),
    .Q(\u_uvlo_sync.meta_ff ),
    .SET_B(net11),
    .CLK(clknet_6_34__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4870_ (.D(\u_uvlo_sync.meta_ff ),
    .Q(UVLO_sync),
    .SET_B(net11),
    .CLK(clknet_6_34__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4871_ (.D(OTP_trig),
    .Q(\u_otp_sync.meta_ff ),
    .SET_B(net4),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfstp_2 _4872_ (.D(\u_otp_sync.meta_ff ),
    .Q(OTP_sync),
    .SET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4873_ (.D(CP_trig),
    .Q(\u_cp_sync.meta_ff ),
    .SET_B(net4),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfstp_1 _4874_ (.D(\u_cp_sync.meta_ff ),
    .Q(CP_sync),
    .SET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4875_ (.D(Osc_in),
    .Q(\u_osc_sync.meta_ff ),
    .RESET_B(net4),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4876_ (.D(\u_osc_sync.meta_ff ),
    .Q(Osc_sync),
    .RESET_B(\g_spi_filt.u_cs_filt.rst_n ),
    .CLK(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__dfrtp_4 _4877_ (.D(\rst_sync.meta_ff ),
    .Q(\g_spi_filt.u_cs_filt.rst_n ),
    .RESET_B(rst_n_pin),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__dfrtp_1 _4878_ (.D(net1),
    .Q(\rst_sync.meta_ff ),
    .RESET_B(rst_n_pin),
    .CLK(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__buf_16 load_slew2 (.A(net3),
    .X(net2));
 sky130_fd_sc_hd__clkbuf_1 _4880_ (.A(PGOOD),
    .X(switch_supply));
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_0 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_1 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_2 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_3 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_4 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_5 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_6 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_7 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_8 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_9 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_10 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_11 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_12 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_13 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_14 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_15 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_16 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_17 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_18 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_19 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_20 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_21 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_22 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_23 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_24 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_25 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_26 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_27 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_28 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_29 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_30 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_31 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_32 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_33 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_34 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_35 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_36 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_37 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_38 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_39 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_40 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_41 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_42 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_43 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_44 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_45 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_46 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_47 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_48 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_49 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_50 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_51 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_52 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_53 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_54 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_55 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_56 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_57 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_58 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_59 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_60 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_61 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_62 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_63 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_64 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_65 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_66 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_67 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_68 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_69 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_70 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_71 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_72 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_73 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_74 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_75 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_76 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_77 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_78 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_79 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_80 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_81 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_82 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_83 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_84 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_85 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_86 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_87 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_88 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_89 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_90 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_91 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_92 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_93 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_94 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_95 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_96 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_97 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_98 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_99 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_100 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_101 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_102 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_103 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_104 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_105 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_106 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_107 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_108 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_109 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_110 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_111 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_112 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_113 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_114 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_115 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_116 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_117 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_118 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_119 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_120 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_121 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_122 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_123 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_124 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_125 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_126 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_127 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_128 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_129 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_130 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_131 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_132 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_133 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_134 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_135 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_136 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_137 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_138 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_139 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_140 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_141 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_142 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_143 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_144 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_145 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_146 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_147 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_148 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_149 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_150 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_151 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_152 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_153 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_154 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_155 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_156 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_157 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_158 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_159 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_160 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_161 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_162 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_163 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_164 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_165 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_166 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_167 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_168 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_169 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_170 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_171 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_172 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_173 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_174 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_175 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_176 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_177 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_178 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_179 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_180 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_181 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_182 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_183 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_184 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_185 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_186 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_187 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_188 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_189 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_190 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_191 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_192 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_193 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_194 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_195 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_196 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_197 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_198 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_199 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_200 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_201 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_202 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_203 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_204 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_205 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_206 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_207 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_208 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_209 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_210 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_211 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_212 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_213 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_214 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_215 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_216 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_217 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_218 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_219 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_220 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_221 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_222 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_223 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_224 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_225 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_226 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_227 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_228 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_229 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_230 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_231 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_232 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_233 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_234 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_235 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_236 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_237 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_238 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_239 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_240 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_241 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_242 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_243 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_244 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_245 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_246 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_247 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_248 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_249 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_250 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_251 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_252 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_253 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_254 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_255 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_256 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_257 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_258 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_259 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_260 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_261 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_262 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_263 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_43_264 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_43_265 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_43_266 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_43_267 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_43_268 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_43_269 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_44_270 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_44_271 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_44_272 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_44_273 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_44_274 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_44_275 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_45_276 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_45_277 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_45_278 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_45_279 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_45_280 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_45_281 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_282 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_283 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_284 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_285 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_286 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_46_287 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_47_288 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_47_289 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_47_290 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_47_291 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_47_292 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_47_293 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_48_294 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_48_295 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_48_296 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_48_297 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_48_298 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_48_299 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_49_300 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_49_301 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_49_302 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_49_303 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_49_304 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_49_305 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_50_306 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_50_307 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_50_308 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_50_309 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_50_310 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_50_311 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_51_312 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_51_313 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_51_314 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_51_315 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_51_316 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_51_317 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_52_318 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_52_319 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_52_320 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_52_321 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_52_322 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_52_323 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_53_324 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_53_325 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_53_326 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_53_327 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_53_328 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_53_329 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_54_330 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_54_331 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_54_332 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_54_333 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_54_334 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_54_335 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_55_336 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_55_337 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_55_338 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_55_339 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_55_340 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_55_341 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_56_342 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_56_343 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_56_344 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_56_345 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_56_346 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_56_347 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_57_348 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_57_349 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_57_350 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_57_351 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_57_352 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_57_353 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_58_354 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_58_355 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_58_356 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_58_357 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_58_358 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_58_359 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_59_360 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_59_361 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_59_362 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_59_363 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_59_364 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_59_365 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_60_366 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_60_367 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_60_368 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_60_369 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_60_370 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_60_371 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_61_372 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_61_373 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_61_374 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_61_375 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_61_376 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_61_377 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_62_378 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_62_379 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_62_380 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_62_381 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_62_382 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_62_383 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_63_384 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_63_385 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_63_386 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_63_387 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_63_388 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_63_389 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_64_390 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_64_391 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_64_392 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_64_393 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_64_394 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_64_395 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_65_396 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_65_397 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_65_398 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_65_399 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_65_400 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_65_401 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_66_402 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_66_403 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_66_404 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_66_405 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_66_406 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_66_407 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_67_408 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_67_409 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_67_410 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_67_411 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_67_412 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_67_413 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_68_414 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_68_415 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_68_416 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_68_417 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_68_418 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_68_419 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_69_420 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_69_421 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_69_422 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_69_423 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_69_424 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_69_425 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_70_426 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_70_427 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_70_428 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_70_429 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_70_430 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_70_431 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_71_432 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_71_433 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_71_434 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_71_435 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_71_436 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_71_437 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_72_438 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_72_439 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_72_440 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_72_441 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_72_442 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_72_443 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_73_444 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_73_445 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_73_446 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_73_447 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_73_448 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_73_449 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_74_450 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_74_451 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_74_452 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_74_453 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_74_454 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_74_455 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_75_456 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_75_457 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_75_458 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_75_459 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_75_460 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_75_461 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_76_462 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_76_463 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_76_464 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_76_465 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_76_466 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_76_467 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_77_468 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_77_469 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_77_470 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_77_471 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_77_472 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_77_473 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_78_474 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_78_475 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_78_476 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_78_477 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_78_478 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_78_479 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_79_480 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_79_481 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_79_482 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_79_483 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_79_484 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_79_485 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_80_486 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_80_487 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_80_488 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_80_489 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_80_490 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_80_491 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_81_492 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_81_493 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_81_494 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_81_495 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_81_496 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_81_497 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_82_498 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_82_499 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_82_500 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_82_501 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_82_502 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_82_503 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_83_504 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_83_505 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_83_506 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_83_507 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_83_508 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_83_509 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_84_510 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_84_511 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_84_512 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_84_513 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_84_514 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_84_515 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_85_516 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_85_517 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_85_518 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_85_519 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_85_520 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_85_521 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_86_522 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_86_523 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_86_524 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_86_525 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_86_526 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_86_527 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_87_528 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_87_529 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_87_530 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_87_531 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_87_532 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_87_533 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_88_534 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_88_535 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_88_536 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_88_537 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_88_538 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_88_539 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_89_540 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_89_541 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_89_542 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_89_543 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_89_544 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_89_545 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_90_546 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_90_547 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_90_548 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_90_549 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_90_550 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_90_551 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_91_552 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_91_553 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_91_554 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_91_555 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_91_556 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_91_557 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_92_558 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_92_559 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_92_560 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_92_561 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_92_562 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_92_563 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_93_564 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_93_565 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_93_566 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_93_567 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_93_568 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_93_569 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_94_570 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_94_571 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_94_572 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_94_573 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_94_574 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_94_575 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_95_576 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_95_577 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_95_578 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_95_579 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_95_580 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_95_581 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_96_582 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_96_583 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_96_584 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_96_585 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_96_586 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_96_587 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_97_588 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_97_589 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_97_590 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_97_591 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_97_592 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_97_593 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_98_594 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_98_595 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_98_596 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_98_597 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_98_598 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_98_599 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_99_600 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_99_601 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_99_602 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_99_603 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_99_604 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_99_605 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_100_606 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_100_607 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_100_608 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_100_609 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_100_610 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_100_611 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_101_612 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_101_613 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_101_614 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_101_615 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_101_616 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_101_617 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_102_618 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_102_619 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_102_620 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_102_621 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_102_622 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_102_623 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_103_624 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_103_625 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_103_626 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_103_627 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_103_628 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_103_629 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_103_630 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_103_631 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_103_632 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_103_633 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_103_634 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_103_635 ();
 sky130_fd_sc_hd__conb_1 _4878__1 (.HI(net1));
 sky130_fd_sc_hd__buf_16 load_slew3 (.A(\g_spi_filt.u_cs_filt.rst_n ),
    .X(net3));
 sky130_fd_sc_hd__buf_16 load_slew4 (.A(\g_spi_filt.u_cs_filt.rst_n ),
    .X(net4));
 sky130_fd_sc_hd__buf_12 load_slew5 (.A(net12),
    .X(net5));
 sky130_fd_sc_hd__buf_12 load_slew6 (.A(net7),
    .X(net6));
 sky130_fd_sc_hd__buf_16 load_slew7 (.A(net12),
    .X(net7));
 sky130_fd_sc_hd__buf_16 load_slew8 (.A(net11),
    .X(net8));
 sky130_fd_sc_hd__buf_16 load_slew9 (.A(net11),
    .X(net9));
 sky130_fd_sc_hd__buf_16 load_slew10 (.A(net11),
    .X(net10));
 sky130_fd_sc_hd__buf_16 max_cap11 (.A(net12),
    .X(net11));
 sky130_fd_sc_hd__buf_16 load_slew12 (.A(\g_spi_filt.u_cs_filt.rst_n ),
    .X(net12));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_0_clk (.A(clk),
    .X(clknet_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_0_0_clk (.A(clknet_0_clk),
    .X(clknet_4_0_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_1_0_clk (.A(clknet_0_clk),
    .X(clknet_4_1_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_2_0_clk (.A(clknet_0_clk),
    .X(clknet_4_2_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_3_0_clk (.A(clknet_0_clk),
    .X(clknet_4_3_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_4_0_clk (.A(clknet_0_clk),
    .X(clknet_4_4_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_5_0_clk (.A(clknet_0_clk),
    .X(clknet_4_5_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_6_0_clk (.A(clknet_0_clk),
    .X(clknet_4_6_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_7_0_clk (.A(clknet_0_clk),
    .X(clknet_4_7_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_8_0_clk (.A(clknet_0_clk),
    .X(clknet_4_8_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_9_0_clk (.A(clknet_0_clk),
    .X(clknet_4_9_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_10_0_clk (.A(clknet_0_clk),
    .X(clknet_4_10_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_11_0_clk (.A(clknet_0_clk),
    .X(clknet_4_11_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_12_0_clk (.A(clknet_0_clk),
    .X(clknet_4_12_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_13_0_clk (.A(clknet_0_clk),
    .X(clknet_4_13_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_14_0_clk (.A(clknet_0_clk),
    .X(clknet_4_14_0_clk));
 sky130_fd_sc_hd__clkbuf_8 clkbuf_4_15_0_clk (.A(clknet_0_clk),
    .X(clknet_4_15_0_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_0__f_clk (.A(clknet_4_0_0_clk),
    .X(clknet_6_0__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_1__f_clk (.A(clknet_4_0_0_clk),
    .X(clknet_6_1__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_2__f_clk (.A(clknet_4_0_0_clk),
    .X(clknet_6_2__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_3__f_clk (.A(clknet_4_0_0_clk),
    .X(clknet_6_3__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_4__f_clk (.A(clknet_4_1_0_clk),
    .X(clknet_6_4__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_5__f_clk (.A(clknet_4_1_0_clk),
    .X(clknet_6_5__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_6__f_clk (.A(clknet_4_1_0_clk),
    .X(clknet_6_6__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_7__f_clk (.A(clknet_4_1_0_clk),
    .X(clknet_6_7__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_8__f_clk (.A(clknet_4_2_0_clk),
    .X(clknet_6_8__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_9__f_clk (.A(clknet_4_2_0_clk),
    .X(clknet_6_9__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_10__f_clk (.A(clknet_4_2_0_clk),
    .X(clknet_6_10__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_11__f_clk (.A(clknet_4_2_0_clk),
    .X(clknet_6_11__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_12__f_clk (.A(clknet_4_3_0_clk),
    .X(clknet_6_12__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_13__f_clk (.A(clknet_4_3_0_clk),
    .X(clknet_6_13__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_14__f_clk (.A(clknet_4_3_0_clk),
    .X(clknet_6_14__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_15__f_clk (.A(clknet_4_3_0_clk),
    .X(clknet_6_15__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_16__f_clk (.A(clknet_4_4_0_clk),
    .X(clknet_6_16__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_17__f_clk (.A(clknet_4_4_0_clk),
    .X(clknet_6_17__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_18__f_clk (.A(clknet_4_4_0_clk),
    .X(clknet_6_18__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_19__f_clk (.A(clknet_4_4_0_clk),
    .X(clknet_6_19__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_20__f_clk (.A(clknet_4_5_0_clk),
    .X(clknet_6_20__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_21__f_clk (.A(clknet_4_5_0_clk),
    .X(clknet_6_21__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_22__f_clk (.A(clknet_4_5_0_clk),
    .X(clknet_6_22__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_23__f_clk (.A(clknet_4_5_0_clk),
    .X(clknet_6_23__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_24__f_clk (.A(clknet_4_6_0_clk),
    .X(clknet_6_24__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_25__f_clk (.A(clknet_4_6_0_clk),
    .X(clknet_6_25__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_26__f_clk (.A(clknet_4_6_0_clk),
    .X(clknet_6_26__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_27__f_clk (.A(clknet_4_6_0_clk),
    .X(clknet_6_27__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_28__f_clk (.A(clknet_4_7_0_clk),
    .X(clknet_6_28__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_29__f_clk (.A(clknet_4_7_0_clk),
    .X(clknet_6_29__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_30__f_clk (.A(clknet_4_7_0_clk),
    .X(clknet_6_30__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_31__f_clk (.A(clknet_4_7_0_clk),
    .X(clknet_6_31__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_32__f_clk (.A(clknet_4_8_0_clk),
    .X(clknet_6_32__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_33__f_clk (.A(clknet_4_8_0_clk),
    .X(clknet_6_33__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_34__f_clk (.A(clknet_4_8_0_clk),
    .X(clknet_6_34__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_35__f_clk (.A(clknet_4_8_0_clk),
    .X(clknet_6_35__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_36__f_clk (.A(clknet_4_9_0_clk),
    .X(clknet_6_36__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_37__f_clk (.A(clknet_4_9_0_clk),
    .X(clknet_6_37__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_38__f_clk (.A(clknet_4_9_0_clk),
    .X(clknet_6_38__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_39__f_clk (.A(clknet_4_9_0_clk),
    .X(clknet_6_39__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_40__f_clk (.A(clknet_4_10_0_clk),
    .X(clknet_6_40__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_41__f_clk (.A(clknet_4_10_0_clk),
    .X(clknet_6_41__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_42__f_clk (.A(clknet_4_10_0_clk),
    .X(clknet_6_42__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_43__f_clk (.A(clknet_4_10_0_clk),
    .X(clknet_6_43__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_44__f_clk (.A(clknet_4_11_0_clk),
    .X(clknet_6_44__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_45__f_clk (.A(clknet_4_11_0_clk),
    .X(clknet_6_45__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_46__f_clk (.A(clknet_4_11_0_clk),
    .X(clknet_6_46__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_47__f_clk (.A(clknet_4_11_0_clk),
    .X(clknet_6_47__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_48__f_clk (.A(clknet_4_12_0_clk),
    .X(clknet_6_48__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_49__f_clk (.A(clknet_4_12_0_clk),
    .X(clknet_6_49__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_50__f_clk (.A(clknet_4_12_0_clk),
    .X(clknet_6_50__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_51__f_clk (.A(clknet_4_12_0_clk),
    .X(clknet_6_51__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_52__f_clk (.A(clknet_4_13_0_clk),
    .X(clknet_6_52__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_53__f_clk (.A(clknet_4_13_0_clk),
    .X(clknet_6_53__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_54__f_clk (.A(clknet_4_13_0_clk),
    .X(clknet_6_54__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_55__f_clk (.A(clknet_4_13_0_clk),
    .X(clknet_6_55__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_56__f_clk (.A(clknet_4_14_0_clk),
    .X(clknet_6_56__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_57__f_clk (.A(clknet_4_14_0_clk),
    .X(clknet_6_57__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_58__f_clk (.A(clknet_4_14_0_clk),
    .X(clknet_6_58__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_59__f_clk (.A(clknet_4_14_0_clk),
    .X(clknet_6_59__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_60__f_clk (.A(clknet_4_15_0_clk),
    .X(clknet_6_60__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_61__f_clk (.A(clknet_4_15_0_clk),
    .X(clknet_6_61__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_62__f_clk (.A(clknet_4_15_0_clk),
    .X(clknet_6_62__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_6_63__f_clk (.A(clknet_4_15_0_clk),
    .X(clknet_6_63__leaf_clk));
 sky130_fd_sc_hd__fill_8 FILLER_0_0_0 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_8 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_16 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_0_24 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_28 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_31 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_39 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_43 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_51 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_59 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_91 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_99 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_107 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_0_115 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_119 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_121 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_123 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_0_144 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_148 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_151 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_159 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_167 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_177 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_179 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_181 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_189 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_197 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_0_205 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_209 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_211 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_219 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_0_227 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_229 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_0_236 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_241 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_249 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_257 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_0_265 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_269 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_271 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_279 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_287 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_0_295 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_299 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_309 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_317 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_0_325 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_347 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_0_355 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_0_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_0_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_0_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_1_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_1_21 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_1_30 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_1_54 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_1_58 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_61 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_1_69 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_1_91 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_1_113 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_1_117 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_1_119 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_1_130 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_1_181 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_1_183 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_1_187 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_211 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_1_239 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_249 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_257 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_265 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_273 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_281 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_289 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_1_297 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_1_299 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_309 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_317 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_325 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_333 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_341 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_349 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_1_357 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_1_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_1_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_1_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_2_8 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_2_66 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_2_91 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_2_124 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_2_151 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_2_153 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_255 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_2_263 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_2_267 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_2_269 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_271 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_279 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_287 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_295 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_303 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_311 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_319 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_2_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_2_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_2_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_2_379 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_3_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_3_4 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_3_68 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_3_98 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_3_121 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_3_123 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_3_164 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_3_185 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_3_220 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_3_264 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_3_272 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_3_280 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_3_288 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_3_296 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_3_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_3_309 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_3_317 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_3_325 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_3_333 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_3_341 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_3_349 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_3_357 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_3_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_3_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_3_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_3_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_4_31 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_4_97 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_4_208 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_4_268 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_4_271 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_4_279 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_4_287 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_4_295 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_4_303 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_4_311 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_4_319 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_4_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_4_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_4_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_4_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_4_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_4_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_4_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_4_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_4_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_5_36 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_5_85 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_5_89 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_5_134 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_5_138 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_5_140 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_5_161 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_5_172 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_5_178 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_5_185 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_5_195 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_5_234 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_5_261 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_5_269 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_5_277 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_5_285 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_5_293 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_5_297 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_5_299 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_5_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_5_309 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_5_317 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_5_325 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_5_333 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_5_341 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_5_349 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_5_357 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_5_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_5_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_5_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_5_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_6_25 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_6_31 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_6_41 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_6_46 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_68 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_6_76 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_6_80 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_6_91 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_6_101 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_113 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_6_121 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_134 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_142 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_6_151 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_6_168 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_197 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_6_205 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_6_209 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_6_211 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_6_235 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_256 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_6_264 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_6_268 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_271 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_279 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_287 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_295 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_303 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_311 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_319 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_6_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_6_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_6_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_6_379 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_7_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_7_4 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_7_35 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_7_58 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_65 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_7_73 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_7_77 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_7_79 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_7_100 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_110 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_7_118 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_141 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_149 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_7_157 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_7_159 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_7_187 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_7_211 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_7_215 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_7_226 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_7_234 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_7_238 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_246 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_254 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_262 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_270 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_278 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_286 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_7_294 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_7_298 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_309 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_317 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_325 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_333 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_341 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_349 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_7_357 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_7_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_7_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_7_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_0 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_8_8 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_8_12 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_8_14 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_8_26 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_8_85 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_8_89 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_8_91 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_133 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_141 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_8_149 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_8_180 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_8_185 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_8_239 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_8_241 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_8_246 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_254 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_262 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_271 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_279 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_287 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_295 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_303 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_311 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_319 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_8_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_8_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_8_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_8_379 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_0 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_9_8 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_9_12 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_9_14 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_9_59 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_9_141 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_9_174 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_9_176 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_9_181 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_9_210 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_219 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_227 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_9_235 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_9_239 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_9_245 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_268 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_276 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_284 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_292 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_309 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_317 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_325 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_333 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_341 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_349 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_9_357 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_9_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_9_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_9_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_10_0 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_10_21 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_10_29 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_10_88 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_10_91 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_10_115 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_10_169 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_10_173 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_10_209 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_10_211 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_10_215 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_10_217 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_10_221 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_10_275 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_10_283 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_10_291 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_10_299 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_10_307 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_10_315 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_10_323 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_10_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_10_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_10_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_10_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_10_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_10_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_10_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_10_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_10_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_11_30 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_11_59 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_11_104 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_11_115 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_11_119 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_11_121 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_11_140 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_11_162 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_11_229 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_11_238 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_11_274 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_11_282 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_11_290 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_11_298 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_11_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_11_309 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_11_317 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_11_325 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_11_333 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_11_341 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_11_349 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_11_357 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_11_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_11_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_11_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_11_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_12_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_12_28 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_12_38 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_12_60 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_12_91 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_12_101 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_12_117 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_12_125 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_12_136 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_12_144 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_12_148 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_12_175 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_12_205 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_12_209 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_12_239 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_12_247 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_12_271 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_12_279 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_12_287 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_12_291 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_12_317 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_12_325 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_12_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_12_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_12_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_12_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_12_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_12_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_12_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_12_379 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_13_27 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_13_35 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_13_39 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_13_48 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_13_56 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_13_61 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_13_69 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_13_79 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_13_100 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_13_119 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_13_121 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_13_125 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_13_127 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_13_198 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_13_263 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_13_271 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_13_279 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_13_285 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_13_293 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_13_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_13_337 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_13_345 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_13_353 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_13_357 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_13_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_13_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_13_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_13_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_14_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_8 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_14_20 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_28 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_14_31 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_14_39 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_14_47 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_14_55 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_59 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_91 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_134 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_14_145 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_14_149 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_14_151 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_164 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_14_199 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_207 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_14_209 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_216 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_14_218 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_226 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_242 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_14_244 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_14_265 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_14_269 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_291 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_14_293 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_14_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_14_334 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_14_342 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_14_350 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_14_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_14_366 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_14_374 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_14_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_14_380 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_15_0 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_15_8 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_15_16 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_15_28 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_15_37 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_15_44 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_15_48 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_15_50 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_15_61 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_15_121 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_15_143 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_15_145 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_15_175 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_15_206 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_15_226 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_15_241 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_15_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_15_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_15_347 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_15_355 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_15_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_15_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_15_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_15_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_16_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_16_8 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_16_58 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_16_88 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_16_91 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_16_93 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_16_144 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_16_148 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_16_151 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_16_155 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_16_179 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_16_234 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_16_264 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_16_268 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_16_302 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_16_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_16_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_16_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_16_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_16_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_16_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_16_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_17_92 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_94 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_119 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_17_128 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_179 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_181 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_17_203 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_207 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_217 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_17_230 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_17_238 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_17_244 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_246 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_17_255 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_17_259 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_261 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_299 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_17_307 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_17_335 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_17_343 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_17_351 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_17_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_17_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_17_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_17_377 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_18_0 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_18_5 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_18_42 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_18_91 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_18_112 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_18_124 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_18_128 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_18_151 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_18_164 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_18_175 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_18_211 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_18_218 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_18_222 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_18_237 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_18_239 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_18_269 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_18_316 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_18_324 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_18_328 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_18_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_18_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_18_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_18_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_18_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_18_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_18_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_20 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_19_22 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_49 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_57 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_19_59 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_19_85 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_19_90 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_98 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_19_100 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_19_104 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_108 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_19_110 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_19_114 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_118 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_121 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_19_128 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_19_157 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_178 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_19_181 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_19_185 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_19_193 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_19_201 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_205 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_19_207 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_19_226 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_19_239 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_254 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_19_296 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_305 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_19_320 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_19_326 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_19_334 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_19_342 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_19_350 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_19_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_19_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_19_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_19_377 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_28 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_20_55 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_59 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_20_69 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_20_111 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_115 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_20_117 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_139 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_20_155 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_176 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_20_190 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_194 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_20_196 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_208 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_20_211 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_215 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_20_280 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_20_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_20_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_20_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_20_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_20_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_20_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_20_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_20_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_21_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_21_29 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_21_37 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_21_51 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_21_59 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_21_73 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_21_98 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_21_188 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_21_210 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_21_241 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_21_253 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_21_282 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_21_290 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_21_298 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_21_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_21_335 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_21_343 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_21_351 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_21_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_21_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_21_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_21_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_22_29 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_22_43 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_22_66 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_22_97 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_22_184 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_22_186 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_22_211 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_22_241 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_22_249 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_22_271 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_22_302 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_22_328 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_22_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_22_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_22_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_22_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_22_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_22_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_22_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_23_58 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_23_125 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_23_133 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_23_135 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_23_157 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_23_159 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_23_181 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_23_268 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_23_270 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_23_275 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_23_299 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_23_322 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_23_330 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_23_338 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_23_346 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_23_354 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_23_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_23_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_23_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_23_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_24_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_24_8 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_24_65 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_24_67 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_24_85 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_24_91 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_24_100 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_24_121 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_24_129 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_24_137 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_24_145 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_24_149 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_24_151 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_24_159 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_24_188 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_24_211 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_24_219 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_24_224 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_24_269 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_24_271 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_24_304 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_24_310 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_24_323 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_24_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_24_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_24_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_24_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_24_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_24_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_24_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_24_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_24_379 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_0 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_8 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_25_16 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_25_39 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_25_51 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_25_58 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_25_81 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_25_85 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_25_92 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_25_99 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_25_101 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_25_109 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_25_119 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_25_121 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_25_128 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_25_139 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_152 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_160 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_168 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_25_176 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_195 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_203 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_211 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_25_219 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_249 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_25_257 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_25_261 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_25_263 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_25_288 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_25_292 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_25_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_326 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_334 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_342 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_350 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_25_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_25_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_25_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_26_0 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_26_8 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_26_16 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_26_24 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_28 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_26_60 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_26_84 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_88 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_26_94 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_102 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_26_128 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_162 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_26_180 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_26_190 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_26_194 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_26_204 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_208 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_26_220 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_253 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_26_255 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_26_264 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_26_271 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_275 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_328 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_26_338 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_26_346 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_26_354 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_26_362 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_26_370 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_26_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_26_380 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_27_24 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_27_32 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_27_40 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_27_48 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_27_50 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_27_101 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_27_141 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_27_175 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_27_179 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_27_197 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_27_227 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_27_298 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_27_324 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_27_332 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_27_340 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_27_348 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_27_356 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_27_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_27_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_27_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_28_0 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_28_31 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_28_39 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_28_116 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_28_171 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_28_204 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_28_231 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_28_239 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_28_247 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_28_249 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_28_276 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_28_315 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_28_323 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_28_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_28_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_28_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_28_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_28_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_28_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_28_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_28_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_28_379 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_29_162 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_29_241 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_29_249 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_29_286 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_29_294 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_29_298 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_29_301 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_29_305 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_29_326 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_29_334 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_29_342 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_29_350 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_29_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_29_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_29_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_29_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_30_31 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_30_46 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_30_89 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_30_107 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_30_119 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_30_149 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_30_251 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_30_259 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_30_264 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_30_269 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_30_280 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_30_282 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_30_287 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_30_296 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_30_300 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_30_321 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_30_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_30_338 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_30_346 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_30_354 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_30_362 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_30_370 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_30_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_30_380 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_31_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_31_4 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_31_15 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_31_46 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_31_50 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_31_61 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_31_111 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_31_121 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_31_198 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_31_246 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_31_267 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_31_275 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_31_292 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_31_341 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_31_349 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_31_357 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_31_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_31_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_31_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_31_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_32_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_32_8 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_32_10 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_32_25 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_32_29 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_32_42 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_32_46 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_32_95 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_32_102 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_32_107 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_32_149 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_32_151 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_32_188 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_32_192 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_32_251 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_32_269 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_32_271 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_32_273 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_32_298 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_32_300 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_32_328 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_32_351 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_32_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_32_367 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_32_375 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_32_379 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_33_0 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_33_8 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_33_16 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_33_18 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_33_39 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_33_47 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_33_55 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_33_59 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_33_61 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_33_75 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_33_83 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_33_104 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_33_106 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_33_118 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_33_206 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_33_228 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_33_241 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_33_245 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_33_292 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_33_321 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_33_342 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_33_350 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_33_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_33_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_33_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_33_377 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_34_20 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_34_24 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_34_41 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_34_49 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_34_51 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_34_102 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_34_104 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_34_126 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_34_209 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_34_216 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_34_268 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_34_325 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_34_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_34_338 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_34_346 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_34_354 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_34_362 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_34_370 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_34_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_34_380 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_35_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_35_59 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_35_70 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_35_78 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_35_111 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_35_119 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_35_121 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_35_226 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_35_237 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_35_239 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_35_241 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_35_252 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_35_258 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_35_266 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_35_308 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_35_316 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_35_324 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_35_332 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_35_340 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_35_348 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_35_356 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_35_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_35_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_35_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_36_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_36_28 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_36_73 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_36_83 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_36_87 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_36_89 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_36_91 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_36_95 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_36_97 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_36_118 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_36_126 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_36_137 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_36_142 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_36_154 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_36_164 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_36_208 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_36_220 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_36_224 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_36_226 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_36_250 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_36_258 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_36_266 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_36_271 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_36_297 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_36_305 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_36_313 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_36_321 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_36_351 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_36_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_36_367 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_36_375 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_36_379 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_37_44 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_37_48 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_37_50 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_37_61 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_37_66 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_37_93 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_37_113 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_37_117 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_37_119 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_37_141 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_37_149 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_37_151 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_37_159 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_37_167 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_37_175 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_37_179 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_37_190 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_37_216 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_37_224 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_37_239 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_37_251 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_37_259 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_37_267 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_37_277 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_37_288 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_37_296 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_37_348 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_37_356 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_37_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_37_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_37_377 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_38_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_38_4 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_38_13 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_38_19 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_38_23 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_38_25 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_38_35 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_38_59 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_38_85 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_38_124 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_38_149 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_38_186 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_38_188 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_38_211 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_38_219 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_38_257 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_38_261 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_38_271 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_38_296 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_38_304 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_38_326 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_38_351 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_38_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_38_367 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_38_375 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_38_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_39_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_39_2 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_39_29 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_39_33 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_39_55 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_39_59 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_39_118 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_39_124 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_39_175 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_39_221 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_39_239 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_39_287 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_39_295 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_39_299 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_39_348 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_39_356 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_39_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_39_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_39_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_40_121 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_40_149 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_40_151 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_40_178 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_40_227 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_40_268 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_40_326 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_40_338 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_40_346 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_40_354 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_40_362 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_40_370 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_40_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_40_380 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_41_49 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_41_70 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_41_74 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_41_121 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_41_129 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_41_157 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_41_179 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_41_189 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_41_191 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_41_299 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_41_328 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_41_336 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_41_344 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_41_352 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_41_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_41_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_41_377 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_42_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_42_29 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_42_77 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_42_81 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_42_86 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_42_94 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_42_126 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_42_137 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_42_141 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_42_172 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_42_211 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_42_248 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_42_250 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_42_256 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_42_269 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_42_289 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_42_297 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_42_305 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_42_313 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_42_321 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_42_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_42_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_42_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_42_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_42_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_42_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_42_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_42_379 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_43_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_43_4 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_43_16 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_43_23 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_43_31 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_43_82 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_43_90 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_43_98 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_43_141 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_43_145 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_43_154 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_43_158 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_43_168 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_43_170 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_43_174 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_43_179 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_43_184 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_43_222 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_43_237 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_43_239 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_43_241 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_43_245 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_43_254 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_43_258 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_43_283 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_43_291 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_43_299 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_43_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_43_309 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_43_317 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_43_325 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_43_333 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_43_355 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_43_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_43_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_43_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_43_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_44_20 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_44_28 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_44_31 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_44_77 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_44_87 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_44_89 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_44_91 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_44_99 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_44_131 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_44_149 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_44_180 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_44_206 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_44_211 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_44_216 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_44_241 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_44_257 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_44_269 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_44_271 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_44_282 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_44_286 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_44_294 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_44_322 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_44_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_44_366 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_44_374 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_44_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_44_380 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_45_0 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_45_8 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_45_12 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_45_14 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_45_36 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_45_38 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_45_61 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_45_72 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_45_121 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_45_179 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_45_181 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_45_204 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_45_271 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_45_355 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_45_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_45_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_45_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_45_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_46_21 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_46_29 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_46_51 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_46_55 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_46_64 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_46_68 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_46_91 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_46_167 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_46_246 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_46_295 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_46_303 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_46_307 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_46_329 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_46_331 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_46_335 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_46_357 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_46_365 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_46_373 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_47_21 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_47_45 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_47_53 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_47_57 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_47_59 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_47_88 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_47_119 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_47_121 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_47_154 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_47_166 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_47_279 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_47_301 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_47_312 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_47_333 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_47_337 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_47_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_47_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_47_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_47_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_48_20 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_48_28 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_48_31 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_48_55 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_48_63 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_48_68 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_48_72 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_48_74 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_48_118 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_48_122 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_48_131 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_48_149 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_48_162 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_48_179 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_48_241 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_48_255 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_48_263 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_48_271 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_48_305 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_48_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_48_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_48_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_48_353 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_48_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_48_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_48_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_49_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_49_42 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_49_81 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_49_89 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_49_100 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_49_104 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_49_106 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_49_116 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_49_128 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_49_166 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_49_207 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_49_254 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_49_256 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_49_260 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_49_268 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_49_292 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_49_321 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_49_329 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_49_333 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_49_335 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_49_356 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_49_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_49_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_49_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_50_20 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_50_28 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_50_55 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_50_81 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_50_91 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_50_104 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_50_106 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_50_127 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_50_129 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_50_148 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_50_202 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_50_211 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_50_264 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_50_269 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_50_271 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_50_275 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_50_280 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_50_288 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_50_319 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_50_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_50_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_50_345 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_50_353 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_50_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_50_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_50_377 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_51_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_51_4 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_51_8 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_51_16 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_51_18 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_51_98 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_51_115 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_51_151 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_51_212 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_51_288 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_51_296 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_51_348 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_51_356 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_51_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_51_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_51_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_52_20 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_52_28 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_52_31 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_52_39 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_52_43 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_52_45 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_52_54 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_52_91 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_52_112 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_52_116 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_52_144 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_52_151 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_52_189 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_52_231 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_52_269 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_52_298 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_52_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_52_351 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_52_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_52_367 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_52_375 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_52_379 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_53_20 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_53_28 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_53_69 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_53_73 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_53_220 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_53_248 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_53_294 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_53_298 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_53_301 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_53_305 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_53_327 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_53_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_53_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_53_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_53_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_54_21 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_54_29 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_54_31 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_54_65 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_54_75 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_54_141 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_54_143 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_54_157 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_54_166 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_54_179 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_54_211 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_54_219 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_54_227 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_54_235 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_54_239 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_54_250 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_54_267 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_54_269 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_54_271 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_54_280 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_54_315 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_54_323 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_54_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_54_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_54_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_54_366 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_54_374 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_54_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_54_380 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_55_0 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_55_8 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_55_12 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_55_84 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_55_88 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_55_90 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_55_96 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_55_108 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_55_115 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_55_119 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_55_121 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_55_125 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_55_127 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_55_134 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_55_138 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_55_150 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_55_155 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_55_181 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_55_222 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_55_230 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_55_234 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_55_244 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_55_246 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_55_278 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_55_308 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_55_316 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_55_324 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_55_328 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_55_330 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_55_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_55_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_55_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_55_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_56_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_56_8 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_56_31 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_56_54 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_56_81 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_56_89 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_56_106 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_56_114 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_56_122 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_56_126 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_56_131 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_56_136 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_56_140 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_56_142 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_56_215 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_56_217 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_56_269 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_56_274 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_56_282 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_56_284 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_56_312 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_56_316 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_56_324 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_56_328 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_56_331 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_56_335 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_56_356 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_56_364 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_56_372 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_56_380 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_57_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_57_8 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_57_59 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_57_61 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_57_84 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_57_113 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_57_117 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_57_119 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_57_144 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_57_168 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_57_179 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_57_191 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_57_232 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_57_239 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_57_255 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_57_276 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_57_284 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_57_292 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_57_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_57_350 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_57_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_57_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_57_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_57_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_58_20 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_58_28 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_58_53 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_58_78 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_58_84 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_58_88 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_58_116 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_58_144 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_58_159 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_58_241 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_58_265 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_58_269 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_58_271 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_58_279 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_58_283 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_58_285 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_58_291 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_58_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_58_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_58_366 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_58_374 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_58_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_58_380 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_59_20 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_59_28 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_59_36 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_59_57 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_59_59 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_59_131 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_59_159 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_59_208 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_59_219 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_59_227 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_59_299 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_59_301 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_59_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_59_350 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_59_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_59_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_59_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_59_377 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_60_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_60_2 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_60_6 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_60_10 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_60_12 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_60_22 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_60_26 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_60_31 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_60_50 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_60_52 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_60_125 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_60_227 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_60_255 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_60_257 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_60_265 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_60_269 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_60_308 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_60_316 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_60_320 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_60_322 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_60_338 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_60_346 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_60_354 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_60_362 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_60_370 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_60_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_60_380 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_61_20 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_61_41 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_61_119 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_61_126 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_61_179 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_61_181 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_61_247 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_61_263 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_61_267 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_61_312 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_61_320 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_61_328 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_61_336 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_61_344 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_61_352 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_61_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_61_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_61_377 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_62_0 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_62_45 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_62_137 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_62_187 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_62_269 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_62_271 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_62_284 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_62_310 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_62_318 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_62_326 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_62_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_62_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_62_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_62_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_62_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_62_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_62_379 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_63_49 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_63_61 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_63_66 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_63_94 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_63_202 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_63_262 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_63_293 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_63_310 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_63_318 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_63_326 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_63_334 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_63_342 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_63_350 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_63_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_63_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_63_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_63_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_64_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_64_8 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_64_29 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_64_61 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_64_127 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_64_148 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_64_151 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_64_209 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_64_271 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_64_279 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_64_283 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_64_293 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_64_302 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_64_310 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_64_318 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_64_326 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_64_331 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_64_335 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_64_344 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_64_352 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_64_360 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_64_368 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_64_376 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_64_380 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_65_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_65_4 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_65_6 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_65_81 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_65_85 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_65_179 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_65_247 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_65_298 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_65_309 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_65_317 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_65_321 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_65_325 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_65_329 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_65_355 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_65_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_65_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_65_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_65_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_66_25 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_66_34 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_66_38 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_66_80 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_66_91 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_66_151 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_66_189 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_66_244 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_66_248 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_66_271 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_66_275 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_66_307 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_66_315 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_66_317 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_66_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_66_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_67_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_67_61 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_67_63 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_67_107 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_67_119 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_67_268 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_67_285 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_67_287 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_67_306 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_67_308 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_67_368 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_67_376 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_67_380 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_68_28 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_68_54 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_68_56 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_68_89 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_68_122 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_68_209 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_68_251 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_68_255 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_68_264 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_68_268 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_68_307 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_68_315 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_68_323 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_68_329 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_68_336 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_68_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_68_366 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_68_374 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_68_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_68_380 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_69_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_69_8 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_69_18 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_69_61 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_69_207 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_69_209 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_69_234 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_69_238 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_69_241 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_69_249 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_69_253 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_69_255 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_69_276 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_69_291 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_69_298 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_69_301 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_69_324 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_69_328 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_69_353 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_69_357 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_69_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_69_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_69_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_69_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_70_0 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_70_8 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_70_16 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_70_24 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_70_28 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_70_31 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_70_39 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_70_43 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_70_45 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_70_69 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_70_89 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_70_111 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_70_179 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_70_205 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_70_209 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_70_211 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_70_215 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_70_217 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_70_263 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_70_267 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_70_269 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_70_271 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_70_273 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_70_281 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_70_298 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_70_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_70_334 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_70_342 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_70_350 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_70_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_70_366 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_70_374 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_70_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_70_380 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_71_20 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_71_24 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_71_45 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_71_47 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_71_57 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_71_59 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_71_81 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_71_85 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_71_207 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_71_217 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_71_232 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_71_241 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_71_249 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_71_351 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_71_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_71_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_71_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_71_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_72_20 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_72_28 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_72_64 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_72_88 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_72_111 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_72_207 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_72_209 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_72_231 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_72_268 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_72_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_72_366 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_72_374 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_72_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_72_380 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_73_64 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_73_68 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_73_121 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_73_137 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_73_284 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_73_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_73_366 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_73_374 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_73_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_73_380 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_74_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_74_8 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_74_31 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_74_35 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_74_66 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_74_91 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_74_115 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_74_208 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_74_266 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_74_279 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_74_329 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_74_334 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_74_362 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_74_370 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_74_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_74_380 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_75_21 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_75_59 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_75_90 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_75_119 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_75_160 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_75_168 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_75_181 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_75_221 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_75_229 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_75_237 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_75_239 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_75_241 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_75_263 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_75_272 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_75_296 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_75_304 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_75_306 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_75_357 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_75_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_75_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_75_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_75_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_76_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_76_8 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_76_64 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_76_88 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_76_115 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_76_149 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_76_163 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_76_239 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_76_249 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_76_257 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_76_314 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_76_328 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_76_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_76_353 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_76_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_76_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_76_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_77_0 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_77_8 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_77_16 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_77_41 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_77_54 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_77_58 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_77_61 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_77_91 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_77_95 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_77_109 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_77_148 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_77_166 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_77_178 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_77_187 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_77_239 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_77_294 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_77_298 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_77_308 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_77_319 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_77_323 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_77_327 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_77_335 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_77_343 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_77_351 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_77_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_77_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_77_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_77_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_78_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_78_8 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_78_17 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_78_25 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_78_29 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_78_53 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_78_91 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_78_99 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_78_109 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_78_117 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_78_136 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_78_140 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_78_142 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_78_182 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_78_190 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_78_198 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_78_202 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_78_268 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_78_271 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_78_296 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_78_300 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_78_302 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_78_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_78_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_78_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_78_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_78_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_78_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_78_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_78_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_78_379 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_79_20 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_79_28 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_79_52 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_79_58 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_79_61 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_79_65 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_79_70 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_79_74 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_79_76 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_79_86 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_79_121 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_79_175 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_79_179 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_79_181 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_79_185 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_79_187 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_79_197 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_79_205 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_79_227 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_79_237 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_79_239 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_79_241 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_79_249 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_79_273 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_79_277 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_79_279 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_79_310 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_79_321 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_79_334 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_79_350 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_79_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_79_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_79_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_79_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_80_20 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_80_28 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_80_67 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_80_88 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_80_91 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_80_139 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_80_147 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_80_149 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_80_151 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_80_155 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_80_163 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_80_209 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_80_215 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_80_223 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_80_227 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_80_229 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_80_239 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_80_241 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_80_326 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_80_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_80_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_80_366 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_80_374 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_80_378 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_80_380 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_81_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_81_59 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_81_114 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_81_121 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_81_150 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_81_158 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_81_186 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_81_198 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_81_235 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_81_239 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_81_250 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_81_252 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_81_262 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_81_270 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_81_278 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_81_298 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_81_328 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_81_330 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_81_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_81_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_81_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_81_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_82_29 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_82_53 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_82_89 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_82_122 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_82_160 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_82_201 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_82_269 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_82_271 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_82_279 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_82_287 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_82_328 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_82_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_82_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_82_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_82_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_82_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_83_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_83_61 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_83_111 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_83_175 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_83_181 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_83_211 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_83_232 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_83_281 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_83_289 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_83_301 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_83_303 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_83_349 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_83_357 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_83_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_83_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_83_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_83_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_84_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_84_7 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_84_28 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_84_38 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_84_89 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_84_95 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_84_109 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_84_155 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_84_223 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_84_263 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_84_267 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_84_269 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_84_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_84_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_84_335 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_84_343 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_84_351 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_84_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_84_367 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_84_375 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_84_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_85_58 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_85_61 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_85_92 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_85_103 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_85_130 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_85_137 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_85_141 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_85_143 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_85_202 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_85_222 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_85_233 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_85_237 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_85_239 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_85_252 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_85_256 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_85_299 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_85_308 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_85_312 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_85_314 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_85_330 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_85_338 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_85_346 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_85_354 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_85_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_85_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_85_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_85_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_86_71 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_86_89 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_86_94 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_86_96 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_86_123 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_86_145 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_86_183 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_86_208 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_86_211 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_86_213 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_86_234 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_86_271 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_86_275 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_86_292 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_86_306 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_86_314 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_86_335 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_86_343 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_86_351 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_86_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_86_367 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_86_375 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_86_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_87_20 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_87_57 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_87_59 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_87_61 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_87_69 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_87_77 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_87_85 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_87_89 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_87_91 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_87_159 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_87_185 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_87_203 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_87_211 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_87_239 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_87_241 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_87_245 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_87_273 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_87_277 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_87_279 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_87_285 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_87_287 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_87_299 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_87_344 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_87_352 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_87_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_87_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_87_377 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_88_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_88_4 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_88_6 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_88_23 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_88_52 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_88_60 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_88_68 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_88_76 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_88_86 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_88_114 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_88_148 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_88_154 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_88_162 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_88_189 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_88_202 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_88_238 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_88_240 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_88_271 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_88_282 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_88_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_88_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_88_337 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_88_345 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_88_353 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_88_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_88_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_88_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_89_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_89_8 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_89_18 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_89_44 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_89_52 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_89_68 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_89_72 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_89_118 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_89_136 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_89_160 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_89_168 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_89_175 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_89_179 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_89_181 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_89_189 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_89_210 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_89_218 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_89_250 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_89_258 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_89_286 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_89_294 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_89_298 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_89_301 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_89_309 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_89_311 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_89_334 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_89_342 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_89_350 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_89_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_89_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_89_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_89_377 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_90_24 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_90_28 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_90_31 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_90_39 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_90_43 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_90_45 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_90_86 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_90_91 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_90_108 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_90_121 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_90_164 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_90_177 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_90_181 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_90_206 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_90_211 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_90_219 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_90_223 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_90_225 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_90_246 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_90_254 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_90_262 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_90_275 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_90_277 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_90_285 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_90_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_90_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_90_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_90_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_90_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_90_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_90_379 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_91_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_91_8 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_91_13 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_91_21 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_91_25 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_91_27 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_91_48 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_91_119 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_91_128 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_91_178 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_91_181 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_91_189 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_91_197 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_91_199 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_91_209 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_91_219 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_91_221 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_91_229 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_91_237 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_91_239 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_91_241 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_91_245 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_91_247 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_91_255 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_91_257 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_91_278 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_91_282 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_91_284 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_91_296 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_91_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_91_309 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_91_322 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_91_330 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_91_338 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_91_346 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_91_354 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_91_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_91_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_91_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_91_377 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_92_27 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_92_29 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_92_31 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_92_89 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_92_142 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_92_184 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_92_211 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_92_215 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_92_239 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_92_243 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_92_300 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_92_310 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_92_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_92_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_92_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_92_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_92_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_92_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_92_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_92_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_93_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_93_29 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_93_61 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_93_234 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_93_238 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_93_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_93_338 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_93_346 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_93_354 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_93_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_93_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_93_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_93_377 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_94_28 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_94_31 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_94_35 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_94_37 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_94_88 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_94_91 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_94_124 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_94_149 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_94_157 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_94_159 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_94_168 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_94_269 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_94_311 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_94_319 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_94_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_94_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_94_336 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_94_344 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_94_352 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_94_360 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_94_368 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_94_376 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_94_380 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_95_0 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_95_21 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_95_29 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_95_59 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_95_85 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_95_130 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_95_189 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_95_261 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_95_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_95_325 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_95_333 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_95_341 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_95_349 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_95_357 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_95_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_95_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_95_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_95_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_96_0 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_96_8 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_96_16 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_96_24 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_96_28 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_96_56 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_96_85 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_96_89 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_96_148 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_96_194 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_96_202 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_96_238 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_96_266 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_96_314 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_96_323 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_96_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_96_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_96_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_96_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_96_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_96_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_96_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_96_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_96_379 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_97_0 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_97_8 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_97_16 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_97_61 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_97_71 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_97_77 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_97_98 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_97_118 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_97_121 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_97_144 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_97_152 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_97_178 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_97_188 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_97_196 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_97_200 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_97_210 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_97_218 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_97_220 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_97_238 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_97_241 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_97_249 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_97_253 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_97_293 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_97_299 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_97_314 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_97_322 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_97_330 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_97_338 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_97_346 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_97_354 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_97_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_97_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_97_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_97_377 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_98_20 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_98_44 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_98_80 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_98_82 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_98_105 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_98_140 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_98_148 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_98_151 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_98_159 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_98_163 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_98_168 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_98_220 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_98_259 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_98_263 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_98_265 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_98_269 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_98_271 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_98_282 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_98_290 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_98_314 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_98_322 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_98_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_98_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_98_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_98_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_98_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_98_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_98_379 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_99_26 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_99_59 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_99_101 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_99_118 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_99_131 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_99_139 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_99_147 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_99_155 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_99_163 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_99_171 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_99_179 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_99_181 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_99_185 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_99_187 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_99_241 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_99_265 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_99_299 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_99_321 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_99_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_99_337 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_99_345 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_99_353 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_99_357 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_99_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_99_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_99_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_99_377 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_100_0 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_100_91 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_100_133 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_100_141 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_100_149 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_100_151 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_100_159 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_100_167 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_100_175 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_100_183 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_100_187 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_100_208 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_100_220 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_100_249 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_100_311 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_100_319 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_100_327 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_100_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_100_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_100_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_100_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_100_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_100_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_100_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_100_379 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_101_53 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_101_58 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_101_65 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_101_75 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_101_116 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_121 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_129 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_137 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_145 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_153 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_161 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_169 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_101_177 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_101_179 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_181 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_189 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_197 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_205 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_101_213 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_101_299 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_306 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_314 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_322 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_330 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_338 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_346 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_101_354 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_101_358 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_101_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_101_377 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_0 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_102_8 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_102_28 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_102_31 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_60 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_68 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_102_76 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_102_80 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_102_82 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_102_91 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_102_95 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_102_104 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_102_108 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_102_110 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_118 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_126 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_134 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_142 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_151 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_159 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_167 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_175 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_183 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_191 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_199 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_102_207 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_102_209 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_211 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_233 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_102_241 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_260 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_102_268 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_102_271 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_102_275 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_297 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_305 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_313 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_321 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_102_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_347 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_355 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_363 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_102_371 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_102_379 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_0 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_8 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_16 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_103_24 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_103_28 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_31 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_103_39 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_50 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_103_58 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_61 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_69 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_77 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_103_85 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_103_89 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_98 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_106 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_103_114 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_103_118 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_121 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_129 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_137 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_103_145 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_103_149 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_151 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_159 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_167 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_103_175 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_103_179 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_181 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_189 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_197 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_103_205 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_103_209 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_211 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_219 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_227 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_103_235 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_103_239 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_241 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_249 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_257 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_103_265 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_103_269 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_271 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_279 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_287 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_103_295 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_103_299 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_301 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_309 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_317 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_103_325 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_103_329 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_331 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_339 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_347 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_103_355 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_103_359 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_361 ();
 sky130_fd_sc_hd__fill_8 FILLER_0_103_369 ();
 sky130_fd_sc_hd__fill_4 FILLER_0_103_377 ();
endmodule
